package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

data class AddSponcer(
    var sponcerLogo: String = "",
    var sponcerBanner: String = "",
    var sponorName: String = "",
    var sponcorWebUrl: String = "",
    var sponcorPlayStoreUrl: String = "",
    var sponcorAppleStoreUrl: String = ""
)