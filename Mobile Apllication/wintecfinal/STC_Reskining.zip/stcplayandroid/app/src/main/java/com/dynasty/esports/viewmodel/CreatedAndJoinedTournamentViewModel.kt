package com.dynasty.esports.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.getCurrentDateTime
import com.dynasty.esports.extenstion.string
import com.dynasty.esports.models.CreatedTournamentModel
import com.dynasty.esports.models.JoinedTournamentModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import org.json.JSONArray
import java.util.*

class CreatedAndJoinedTournamentViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val fetchCreatedTournamentSuccessResponse = MutableLiveData<CreatedTournamentModel>()
    val fetchCreatedTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val fetchJoinedTournamentSuccessResponse = MutableLiveData<JoinedTournamentModel>()
    val fetchJoinedTournamentErrorResponse = MutableLiveData<ResponseBody>()


    val jsonObjectForTournament = MutableLiveData<Pair<JsonObject, JsonObject>>()


//    val jsonObjectForCreateTournament = MutableLiveData<Pair<String, Pair<String,String>>>()
    fun fetchCreatedTournamentOngoingAndPast(status: Int, page: Int,sort: String,organized: String, type: String) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
            val response = restInterface.fetchCreatedTournamentPastAndOngoing(status, page,sort,organized)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchCreatedTournamentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchCreatedTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun fetchJoinedTournamentOngoingAndPast(query: String, pagination: String, type: String) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
            val response = restInterface.fetchJoinedTournamentPastAndOngoing(query, pagination)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchJoinedTournamentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchJoinedTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }


    fun makeJsonForCreatedTournament(
        page: Int,
        status:String,
        organized: String
    ) {

//        val arrayProjection = JsonArray()
//        arrayProjection.add("_id")
//        arrayProjection.add("name")
//        arrayProjection.add("description")
//        arrayProjection.add("banner")
//        arrayProjection.add("startDate")
//        arrayProjection.add("startTime")
//        arrayProjection.add("checkInStartDate")
//        arrayProjection.add("isPaid")
//
//
//        val pagignation = JsonObject()
//        pagignation.addProperty("page", page)
//        pagignation.addProperty("limit", limit)
//        pagignation.addProperty("sort", "Latest")
//        pagignation.add("projection", arrayProjection)
//
//        val rootObject = JsonObject()
//        rootObject.addProperty("organizer", id)
//        rootObject.addProperty("isSeeded", isSeeded)
//        if(!isUpcoming){
//            rootObject.addProperty("isFinished", isFinished)
//            rootObject.addProperty("tournamentStatus", "publish")
//        }
//
//        jsonObjectForTournament.postValue(Pair(rootObject, pagignation))


    }

    fun makeJsonForJoinedTournament(isUpcoming:Boolean,page: Int, limit: Int, isFinished: Boolean, isSeeded: Boolean) {
//        {"$or":[{"isSeeded":true,"isFinished":true},{"isSeeded":false,"isFinished":false,"startDate":{"$lt":"2020-09-04T06:59:34.318Z"}}]}&pagination={"page":1,"limit":5,"sort":"startDate","projection":["_id","name","description","startDate"]}

        val arrayProjection = JsonArray()
        arrayProjection.add("_id")
        arrayProjection.add("name")
        arrayProjection.add("description")
        arrayProjection.add("startDate")
        arrayProjection.add("checkInStartDate")
        arrayProjection.add("isPaid")

        val pagination = JsonObject()
        pagination.addProperty("page", page)
        pagination.addProperty("limit", limit)
        pagination.addProperty("sort", "startDate")
        pagination.add("projection", arrayProjection)

        val rootObject = JsonObject()
        rootObject.addProperty("isFinished", isFinished)
        rootObject.addProperty("isSeeded", isSeeded)

        if(isUpcoming){
            val jsonObjectStartDate = JsonObject()
            jsonObjectStartDate.addProperty("\$gt", getCurrentDateTime().string(AppConstants.API_DATE_FORMAT))
            rootObject.add("startDate", jsonObjectStartDate)
        }

        jsonObjectForTournament.postValue(Pair(rootObject, pagination))

    }

//    {"isSeeded":false,"isFinished":false,"startDate":{"$gt":"2020-09-04T07:22:18.087Z"}}

    fun makeJsonForPstJoinedTournament(page: Int, limit: Int) {
//        {"$or":[{"isSeeded":true,"isFinished":true},{"isSeeded":false,"isFinished":false,"startDate":{"$lt":"2020-09-04T06:59:34.318Z"}}]}
//

        val arrayProjection = JsonArray()
        arrayProjection.add("_id")
        arrayProjection.add("name")
        arrayProjection.add("description")
        arrayProjection.add("startDate")
        arrayProjection.add("checkInStartDate")
        arrayProjection.add("isPaid")

        val pagination = JsonObject()
        pagination.addProperty("page", page)
        pagination.addProperty("limit", limit)
        pagination.addProperty("sort", "startDate")
        pagination.add("projection", arrayProjection)

        val jsonObjectOne = JsonObject()
        jsonObjectOne.addProperty("isFinished", true)
        jsonObjectOne.addProperty("isSeeded", true)

        val jsonObjectStartDate = JsonObject()
        jsonObjectStartDate.addProperty("\$lt", getCurrentDateTime().string(AppConstants.API_DATE_FORMAT))
        val jsonObjectTwo = JsonObject()
        jsonObjectTwo.addProperty("isFinished", false)
        jsonObjectTwo.addProperty("isSeeded", false)
        jsonObjectTwo.add("startDate", jsonObjectStartDate)

//        {"$or":[{"isFinished":true,"isSeeded":true,"startDate":{"$lt":"2020-09-04T12:54:30.300Z"}},{}]}

        val jsonArray=JsonArray()
        jsonArray.add(jsonObjectOne)
        jsonArray.add(jsonObjectTwo)

        val jsonObjectRoot=JsonObject()
        jsonObjectRoot.add("\$or",jsonArray)





        jsonObjectForTournament.postValue(Pair(jsonObjectRoot, pagination))
    }


    fun onDetach() {
        viewModelScope.cancel()
    }

}
