package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class CreateTournamentErrorRes {


    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("err")
    @Expose
    var err: String? = null
}