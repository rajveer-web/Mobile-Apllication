package com.dynasty.esports.view.search


import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.ListitemUpcomingTournamentBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.SearchTournamentModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamentDetailActivity

/**
 * @desc this is class will use to show tournament result
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class SearchTournamentAdapter(
    private var searchTournamentList: MutableList<SearchTournamentModel.DocModel>,
    private val onItemClick: (Int, String) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<BindingHolder<ListitemUpcomingTournamentBinding>>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<ListitemUpcomingTournamentBinding> {
        return BindingHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.listitem_upcoming_tournament, parent, false))
    }
    /**
     * @desc search tournament array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return searchTournamentList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: BindingHolder<ListitemUpcomingTournamentBinding>, position: Int) {
        val data=searchTournamentList[position]
        holder.binding.root.context.loadImageFromServer(data.banner.toString(),holder.binding.imgUpcoming)
        holder.binding.gameNameTitle.text=data.name?.let { it } ?: "-"
        holder.binding.dateNtime.text=data.startDate?.let { it.convertDateToRequireDateFormat(AppConstants.API_DATE_FORMAT,AppConstants.DD_MM_YYYY_FORMAT).plus(" ").plus(data.startTime) } ?: "-"
        holder.binding.tvParticiPantJoind.text=data.participantJoined.toString().plus("/").plus(data.maxParticipants.toString())
        if(data.bracketType=="single"){
            holder.binding.eliminationTxt.text=holder.binding.root.context.getString(R.string.single_elimination)
        }else{
            holder.binding.eliminationTxt.text=holder.binding.root.context.getString(R.string.double_elimination)
        }
        if(data.isPaid!!){
            holder.binding.paidType.setTextColor(ContextCompat.getColor(holder.itemView.context,R.color.internal_app_text_color))
            holder.binding.paidType.text=holder.binding.root.context.getString(R.string.str_paid)
            holder.binding.isPaidBg.setBackgroundResource(R.drawable.upcoming_detail_round_border)
        }else{
            holder.binding.paidType.setTextColor(ContextCompat.getColor(holder.itemView.context,R.color.text_color))
            holder.binding.paidType.text=holder.binding.root.context.getString(R.string.str_free)
            holder.binding.isPaidBg.setBackgroundResource(R.drawable.roundedcornerred_free)
        }

         data.gameDetail?.apply {
             this.image?.apply {
                 holder.itemView.context.loadImageFromServer(
                     this,
                     holder.binding.imgUpcoming
                 )
             }
         }

        holder.binding.imgTrphy.beGone()

        holder.binding.cardViewTournament.click {

            onItemClick(position,data.id.toString())
        }
    }
}