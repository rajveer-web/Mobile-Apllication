package com.dynasty.esports.view.tournamet.tournamet_detail

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dynasty.esports.R
import com.dynasty.esports.models.CountriesModel
import com.dynasty.esports.models.TournamentDetailRes
import kotlinx.android.synthetic.main.price_layout.view.*
import kotlinx.android.synthetic.main.row_overview_sponsor.view.*

class OverViewPrizeAdapter (var listOfPrize: List<TournamentDetailRes.PrizeList>, var prizeCurr : String?
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var listOfPrizes : List<TournamentDetailRes.PrizeList>
    var prizeCurrency : String? = null
    init {
        this.listOfPrizes = listOfPrize
        this.prizeCurrency = prizeCurr
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        // add layout for prize list
        return PrizeDetailViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.price_layout, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return listOfPrizes.size
    }

    class PrizeDetailViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(
            prizeDetail: TournamentDetailRes.PrizeList,
            prizeCurrencyy : String?
        ) {
            val prizeName = prizeDetail.name?.subSequence(0,3)
            itemView.price_rank.text = prizeName
            itemView.price_amount.text = prizeCurrencyy.plus(" " + prizeDetail.value.toString())

            when (prizeName) {
                "1st" -> {
                    Glide.with(itemView.context).load(ContextCompat.getDrawable(itemView.context, R.mipmap.first_price)).into(itemView.price_img)
                }
                "2nd" -> {
                    Glide.with(itemView.context).load(ContextCompat.getDrawable(itemView.context, R.mipmap.second_price)).into(itemView.price_img)
                }
                "3rd" -> {
                    Glide.with(itemView.context).load(ContextCompat.getDrawable(itemView.context, R.mipmap.third_price)).into(itemView.price_img)
                }
                "4th" -> {
                    Glide.with(itemView.context).load(ContextCompat.getDrawable(itemView.context, R.mipmap.second_price)).into(itemView.price_img)
                }
                "5th" -> {
                    Glide.with(itemView.context).load(ContextCompat.getDrawable(itemView.context, R.mipmap.second_price)).into(itemView.price_img)
                }
                "6th" -> {
                    Glide.with(itemView.context).load(ContextCompat.getDrawable(itemView.context, R.mipmap.second_price)).into(itemView.price_img)
                }
            }
        }
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val gameViewHolder = viewHolder as PrizeDetailViewHolder
        gameViewHolder.bindView(listOfPrizes[position], prizeCurrency)
    }

}