package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.PhoneVerificationRequest
import com.dynasty.esports.models.PhoneVerificationResponse
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class PhoneNumberVerificationViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()
    val fbLoginObserver = MutableLiveData<Boolean>()
    val googleLoginObserver = MutableLiveData<Boolean>()
    val redirectPhoneRegistrationObserver = MutableLiveData<Boolean>()
    val redirectEmailRegistrationObserver = MutableLiveData<Boolean>()
    val phoneNumberVerifySuccessResponse = MutableLiveData<PhoneVerificationResponse>()
    val phoneNumberVerifyErrorResponse = MutableLiveData<ResponseBody>()
    val countryCodeObserver = MutableLiveData<Boolean>()


    fun formValidation(countryCode: String, phoneNumber: String) {
        when {
            countryCode.isFieldEmpty() -> validationLiveData.postValue(0)
            phoneNumber.isFieldEmpty() -> validationLiveData.postValue(1)
            phoneNumber.length != 10 -> validationLiveData.postValue(2)
            else -> isFormValid.postValue(true)
        }
    }


    fun updatePhoneNumber(phoneVerificationRequest: PhoneVerificationRequest) {
        viewModelScope.launch(apiException("verify") + Dispatchers.Main) {
            val response = restInterface.toVerifyGenerateOTP(phoneVerificationRequest)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    phoneNumberVerifySuccessResponse.postValue(response.body())
                }
                else -> {
                    phoneNumberVerifyErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    fun updatePhoneNumberSocial(phoneVerificationRequest: PhoneVerificationRequest) {
        viewModelScope.launch(apiException("verify") + Dispatchers.Main) {
            val response = restInterface.toVerifyGenerateSocialOTP(phoneVerificationRequest)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    phoneNumberVerifySuccessResponse.postValue(response.body())
                }
                else -> {
                    phoneNumberVerifyErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    fun countryCodeClick(){
        countryCodeObserver.postValue(true)
    }

    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
