package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ChatMessageListModel {
    @SerializedName("matchid")
    @Expose
    var matchid: String? = null

    @SerializedName("tournamentid")
    @Expose
    var tournamentid: String? = null

    @SerializedName("fullName")
    @Expose
     var fullName: String? = null

    @SerializedName("userid")
    @Expose
    var userid: String? = null

    @SerializedName("message")
    @Expose
     val message: MessageModel? = null

    @SerializedName("messagetype")
    @Expose
    var messagetype: String? = null

    @SerializedName("createdAt")
    @Expose
     val createdAt: String? = null

    @SerializedName("updatedAt")
    @Expose
     var updatedAt: String? = null

    @SerializedName("__v")
    @Expose
     val v: Int? = null

    @SerializedName("filesattached")
    @Expose
     val filesattached: List<Any>? = null

    @SerializedName("msg")
    @Expose
    var msg: String? = null

    @SerializedName("id")
    @Expose
     val id: String? = null

    class MessageModel{
        @SerializedName("type")
        @Expose
         val type: String? = null

        @SerializedName("data")
        @Expose
         val data: List<Int>? = null
    }
}