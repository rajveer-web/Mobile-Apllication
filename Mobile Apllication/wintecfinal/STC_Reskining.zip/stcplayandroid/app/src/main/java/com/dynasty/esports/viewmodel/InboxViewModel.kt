package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.InboxMessagesListModel
import com.dynasty.esports.models.InboxModel
import com.dynasty.esports.models.InboxPostMessageModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class InboxViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
    val getInboxMessageSuccessResponse = MutableLiveData<InboxModel>()
    val getInboxMessageErrorResponse = MutableLiveData<ResponseBody>()

    val deleteMessagesSuccessResponse = MutableLiveData<ResponseBody>()
    val deleteMessagesErrorResponse = MutableLiveData<ResponseBody>()

    val messagesListSuccessResponse = MutableLiveData<InboxMessagesListModel>()
    val messagesListErrorResponse = MutableLiveData<ResponseBody>()

    val seenMessageSuccessResponse = MutableLiveData<ResponseBody>()
    val seenMessageErrorResponse = MutableLiveData<ResponseBody>()

    val postMessageSuccessResponse = MutableLiveData<InboxPostMessageModel>()
    val postMessageErrorResponse = MutableLiveData<ResponseBody>()

    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val jsonObjectForSeenMessage = MutableLiveData<JsonObject>()
    val jsonObjectForDeleteMessages = MutableLiveData<JsonObject>()
    val jsonObjectForPostMessages = MutableLiveData<JsonObject>()


    /**
     * @desc Method will handle get all messages success and failure
     * @param query - pass query parameter
     */
    fun getAllMessages(query: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getAllInboxMessages(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    getInboxMessageSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    getInboxMessageErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle delete message success and failure
     * @param jsonObject - pass json object for delete message
     */
    fun deleteMessages(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("delete") + Dispatchers.Main) {
            val response = restInterface.deleteMessages(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    deleteMessagesSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    deleteMessagesErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     * @desc Method will handle get messages from inbox id success and failure
     * @param type - message type("get-message")
     * @param id - inbox id
     */
    fun getAllMessagesFromInboxId(type: String, id: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.getAllMessageFromInboxId(type, id)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    messagesListSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    messagesListErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle seen message success and failure
     * @param jsonObject - pass json object for seen new messages
     */
    fun seenMessage(jsonObject: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.seenMessage(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    seenMessageSuccessResponse.postValue(response.body())
                }

                else -> {
                    seenMessageErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle post message success and failure
     * @param jsonObject - pass json object for post new message
     */
    fun postMessage(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("post") + Dispatchers.Main) {
            val response = restInterface.postMessage(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    postMessageSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    postMessageErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will use to create json object for delete message
     * @param dataList - selected messages id array list
     */
    fun makeJsonForDeleteMessage(dataList: MutableList<String>) {
        val jsonObject = JsonObject()
        val jsonArray = JsonArray()
        jsonObject.addProperty("requesttype", "delete-multiple")
        dataList.forEach {
            jsonArray.add(it)
        }
        jsonObject.add("messageIds", jsonArray)
        jsonObjectForDeleteMessages.postValue(jsonObject)
    }

    /**
     * @desc Method will use to create json object for seen message
     * @param id - inbox id
     */
    fun makeJsonForSeenMessage(id:String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("requesttype", "message-seen")
        jsonObject.addProperty("id", id)
        jsonObject.addProperty("seen", true)
        jsonObjectForSeenMessage.postValue(jsonObject)
    }

    /**
     * @desc Method will use to create json object for post new message
     * @param message - message string
     * @param toUser - logged in user id
     * @param parentId - inbox id
     */
    fun makeJsonForPostMessage(message:String,toUser:String,parentId:String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("requesttype", "save-message")
        jsonObject.addProperty("subject", "User Message 1")
        jsonObject.addProperty("message", message)
        jsonObject.addProperty("toUser", toUser)
        jsonObject.addProperty("parentId", parentId)
        jsonObjectForPostMessages.postValue(jsonObject)
    }

    /**
     * @desc Method will use for check form validation
     * @param message - message string
     */
    fun checkMessageValidation(message:String) {
       when{
           message.isFieldEmpty() -> validationLiveData.postValue(0)
           else->isFormValid.postValue(true)
       }
    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
