package com.dynasty.esports.view.tournamet.manage_tournament.seed


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.core.widget.doOnTextChanged
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterSeedFooterBinding
import com.dynasty.esports.databinding.AdapterSeedHeaderBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.models.ParticipantsModel

//row_article_post

class SeedAdapter constructor(
    private var tournamentType: String,
    private val onItemClick: (Int) -> Unit = { _ -> }
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var listOfParticipants: MutableList<ParticipantsModel.DataModel> = ArrayList()
    private var isFilter = false
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            1 -> {
                val binding: AdapterSeedFooterBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_seed_footer,
                        parent,
                        false
                    )
                return ViewHolderSeed(binding)
            }
            else -> {
                val binding: AdapterSeedHeaderBinding =
                    DataBindingUtil.inflate(inflater, R.layout.adapter_seed_header, parent, false)
                return ViewHolderHeader(binding)
            }

        }

    }

    override fun getItemCount(): Int {
        return listOfParticipants.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) {
            0
        } else {
            1
        }
    }

    fun getAll(): MutableList<ParticipantsModel.DataModel> {
        return listOfParticipants
    }

    fun addAll(listOfParticipants_: MutableList<ParticipantsModel.DataModel>) {
        listOfParticipants.clear()
        listOfParticipants.addAll(listOfParticipants_)
        notifyDataSetChanged()
    }

    fun filterTeam(isFilter: Boolean) {
        this.isFilter = isFilter
        notifyDataSetChanged()
    }


    fun getItem(position: Int): ParticipantsModel.DataModel {
        return this.listOfParticipants[position]
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            1 -> {
                (holder as ViewHolderSeed).bind(listOfParticipants[position])
            }
        }
    }

    /**
     *@desc This call use for display participants list
     */
    inner class ViewHolderSeed(private var binding: AdapterSeedFooterBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: ParticipantsModel.DataModel) {
            if (isFilter) {
                if (data.checkedIn!!) {
                    binding.root.beVisible()
                } else {
                    binding.root.beGone()
                }
            } else {
                binding.root.beVisible()

            }

            if (data.checkedIn!!) {
                binding.imageViewCheckedIn.setImageResource(R.drawable.ic_round_check)
            } else {
                binding.imageViewCheckedIn.setImageResource(R.drawable.ic_round_close)
            }

            binding.textViewNumber.text = (adapterPosition).toString()
            binding.textViewTeamName.text = data.teamName?.let { it } ?: ""


            binding.editTextSeed.setText(data.seed?.let { it.toString() } ?: "")

            binding.editTextSeed.doOnTextChanged{ text, start, before, count ->
//                if (!text.isNullOrEmpty()) {
//                    if(text.toString().toInt()> listOfParticipants.size){
//                        binding.editTextSeed.setText(data.seed.toString())
//                    }else{
                       // data.seed = text.toString().toInt()
//                    }
//                }
            }

        }

    }


    /**
     *@desc This call use for display participants list
     */
    inner class ViewHolderHeader(private var binding: AdapterSeedHeaderBinding) :
        RecyclerView.ViewHolder(binding.root) {


    }
}