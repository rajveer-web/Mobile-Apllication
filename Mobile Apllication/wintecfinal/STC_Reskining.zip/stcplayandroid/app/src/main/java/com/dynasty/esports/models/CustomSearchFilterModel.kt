package com.dynasty.esports.models

data class CustomSearchFilterModel(
    val key:String?=null,
    val commonList:MutableList<String>?=null,
    val regionList:MutableList<String>?=null,
    var selectedKey:String="",
    var selectedName:String=""
)