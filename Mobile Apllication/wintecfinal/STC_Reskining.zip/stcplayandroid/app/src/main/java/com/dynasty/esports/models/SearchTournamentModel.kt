package com.dynasty.esports.models

import android.os.Parcelable
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

class SearchTournamentModel {
    @SerializedName("message")
    @Expose
    val message: String? = null

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: DataModel?=null


    class DataModel{

        @SerializedName("docs")
        @Expose
         val docs: MutableList<DocModel>? = null

        @SerializedName("totalDocs")
        @Expose
         val totalDocs: Int? = null

        @SerializedName("offset")
        @Expose
         val offset: Int? = null

        @SerializedName("limit")
        @Expose
         val limit: Int? = null

        @SerializedName("totalPages")
        @Expose
         val totalPages: Int? = null

        @SerializedName("page")
        @Expose
         val page: Int? = null

        @SerializedName("pagingCounter")
        @Expose
         val pagingCounter: Int? = null

        @SerializedName("hasPrevPage")
        @Expose
         val hasPrevPage: Boolean? = null

        @SerializedName("hasNextPage")
        @Expose
         val hasNextPage: Boolean? = null

        @SerializedName("prevPage")
        @Expose
         val prevPage: Any? = null

        @SerializedName("nextPage")
        @Expose
         val nextPage: Int? = null
        
        

    }

    @Parcelize
    class DocModel:Parcelable {
//        @SerializedName("participants")
//        @Expose
//        val participants: MutableList<String>? = null

//        @SerializedName("regionsAllowed")
//        @Expose
//        val regionsAllowed: MutableList<String>? = null

        @SerializedName("_id")
        @Expose
        val id: String? = null

        @SerializedName("name")
        @Expose
        val name: String? = null

        @SerializedName("startDate")
        @Expose
        val startDate: String? = null

        @SerializedName("startTime")
        @Expose
        val startTime: String? = null

        @SerializedName("banner")
        @Expose
        val banner: String? = null

        @SerializedName("bracketType")
        @Expose
        val bracketType: String? = null

        @SerializedName("maxParticipants")
        @Expose
        val maxParticipants: Int? = null

        @SerializedName("isPaid")
        @Expose
        val isPaid: Boolean? = null

        @SerializedName("endDate")
        @Expose
        val endDate: String? = null

        @SerializedName("participantJoined")
        @Expose
        val participantJoined: Int? = null

        @SerializedName("gameDetail")
        @Expose
        val gameDetail: TournamentListRes.GameDetail? = null

    }
}