package com.dynasty.esports.view.tournamet.tournamet_detail

import android.media.MediaPlayer.*
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.VideoView
import androidx.fragment.app.Fragment
import com.dynasty.esports.R


class TournamentStreamingFragment : Fragment() {

    lateinit var liveVideo : VideoView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
    }

    fun initialise(){
        liveVideo = requireActivity().findViewById(R.id.videoview)
        liveVideo.setVideoURI(Uri.parse("https://www.radiantmediaplayer.com/media/big-buck-bunny-360p.mp4"))
        liveVideo.requestFocus()
        liveVideo.setOnCompletionListener(OnCompletionListener { })
        liveVideo.setOnPreparedListener(OnPreparedListener { mediaPlayer ->
            liveVideo.start()
            mediaPlayer.setOnVideoSizeChangedListener { mp, width, height ->
                val mediaController =
                    MediaController(requireContext())
                liveVideo.setMediaController(mediaController)
                mediaController.setAnchorView(liveVideo)
            }
        })
        liveVideo.setOnErrorListener(OnErrorListener { mediaPlayer, i, i1 -> false })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tournament_streaming, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            TournamentStreamingFragment()
    }
}