package com.dynasty.esports.view.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dynasty.esports.R
import com.dynasty.esports.view.common.CommonPagerAdapter
import kotlinx.android.synthetic.main.fragment_transaction_history.*

/**
 * @desc this is class handle platform view
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class SettingsFragment : Fragment() {
    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_transaction_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textViewTitle.text = resources.getString(R.string.settings)
        /**
         * assign fragments in fragment list
         * Fragment list assign to viewpager adapter
         *
         *
         */

        fragmentList.add(
            Pair(ContentFragment(), resources.getString(R.string.prefered_content)))
        fragmentList.add(
            Pair(
                AccountFragment(),
                resources.getString(R.string.account)
            )
        )

        commonPagerAdapter =
            CommonPagerAdapter(
                fragmentList,
                childFragmentManager
            )
        viewPagerTransaction.adapter = commonPagerAdapter
        tabLayoutTransaction.setupWithViewPager(viewPagerTransaction)
    }

    /**
     * Make fragment instance.
     */
    companion object {
        fun newInstance() = SettingsFragment()
    }
}