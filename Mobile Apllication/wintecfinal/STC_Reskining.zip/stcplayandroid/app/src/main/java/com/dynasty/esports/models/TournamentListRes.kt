package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class TournamentListRes {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: Data? = null

    class Doc {
        @SerializedName("participants")
        @Expose
        var participants: List<Any> = ArrayList()

        @SerializedName("regionsAllowed")
        @Expose
        var regionsAllowed: List<Any> = ArrayList()

        @SerializedName("_id")
        @Expose
        var id: String = ""

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("startDate")
        @Expose
        var startDate: String? = null

        @SerializedName("startTime")
        @Expose
        var startTime: String? = null

        @SerializedName("isPaid")
        @Expose
        var isPaid = false

        @SerializedName("description")
        @Expose
        var description: String? = null

        @SerializedName("banner")
        @Expose
        var banner: String? = null

        @SerializedName("maxParticipants")
        @Expose
        var maxParticipants = 0

        @SerializedName("bracketType")
        @Expose
        var bracketType: String? = null

        @SerializedName("firstPrize")
        @Expose
        var firstPrize = 0

        @SerializedName("prizeCurrency")
        @Expose
        var prizeCurrency = ""

        @SerializedName("secondPrize")
        @Expose
        var secondPrize = 0

        @SerializedName("thirdPrize")
        @Expose
        var thirdPrize = 0

        @SerializedName("endDate")
        @Expose
        var endDate: String? = null

        @SerializedName("participantJoined")
        @Expose
        var participantJoined = 0

        @SerializedName("gameDetail")
        @Expose
         val gameDetail: GameDetail? = null

    }

    class GameDetail{
        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("name")
        @Expose
         val name: String? = null

        @SerializedName("image")
        @Expose
         val image: String = ""
    }
    class Data {
        @SerializedName("docs")
        @Expose
        var docs: List<Doc> = ArrayList()

        @SerializedName("totalDocs")
        @Expose
        var totalDocs = 0

        @SerializedName("offset")
        @Expose
        var offset = 0

        @SerializedName("limit")
        @Expose
        var limit = 0

        @SerializedName("totalPages")
        @Expose
        var totalPages = 0

        @SerializedName("page")
        @Expose
        var page = 0

        @SerializedName("pagingCounter")
        @Expose
        var pagingCounter = 0

        @SerializedName("hasPrevPage")
        @Expose
        var hasPrevPage = false

        @SerializedName("hasNextPage")
        @Expose
        var hasNextPage = false

        @SerializedName("prevPage")
        @Expose
        var prevPage: Any? = null

        @SerializedName("nextPage")
        @Expose
        var nextPage = 0
    }
}