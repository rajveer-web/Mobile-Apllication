package com.dynasty.esports.view.common

import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.databinding.ItemLoadMoreBinding

/**
 * @desc this class use for loading progress bar in bottom side when implement pagination functionality.
 * @author : Mahesh Vayak
 * @created : 24-07-2020
 * @modified : 24-08-2020
 * ©Dynasty eSports Pte ltd
 **/
class LoadingViewHolder constructor(binding: ItemLoadMoreBinding) :
    RecyclerView.ViewHolder(binding.root) {
    val progressBar: ProgressBar = binding.progressBarLoadMore  // set the progress bar
}