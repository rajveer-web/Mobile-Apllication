package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class Content(
    @SerializedName("desc")
    var description: String? = null,

    @SerializedName("catname")
    var catName: String? = null,

    @SerializedName("poster-image")
    var poster_image: String? = null




)