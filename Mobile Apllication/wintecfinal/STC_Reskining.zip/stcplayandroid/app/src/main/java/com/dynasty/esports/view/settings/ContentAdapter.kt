package com.dynasty.esports.view.settings

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterContentDataBinding
import com.dynasty.esports.databinding.AdapterContentRowTextBinding
import com.dynasty.esports.databinding.AdapterContentSettingSaveBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.ContentUserPrefModel
import com.dynasty.esports.models.CustomContentModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this class will show setting contents
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class ContentAdapter constructor(
    private var contentList: MutableList<CustomContentModel>,
    private val onSaveItemClick: (MutableList<String>, MutableList<String>, MutableList<String>,MutableList<String>) -> Unit = { _, _, _,_ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var gameCenterList: MutableList<String> = mutableListOf()
    private var gameChooseList: MutableList<String> = mutableListOf()
    private var gamePlatformList: MutableList<String> = mutableListOf()
    private var gameContentList: MutableList<String> = mutableListOf()

    private var chooseGameAdapter: ContentDataAdapter? = null
    private var gameCenterAdapter: ContentDataAdapter? = null
    private var contentGameAdapter: ContentDataAdapter? = null
    private var gamePlatformAdapter: ContentPlatformAdapter? = null

    /**
     *@desc This ViewHolder should be constructed with a new View that can represent the items
     * of the given type.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            1 -> {
                val binding: AdapterContentRowTextBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_content_row_text,
                        parent,
                        false
                    )
                return BindingHolder(binding)
            }
            6 -> {
                val binding: AdapterContentSettingSaveBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_content_setting_save,
                        parent,
                        false
                    )
                return SaveViewHolderData(binding)
            }
            else -> {
                val binding: AdapterContentDataBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_content_data,
                        parent,
                        false
                    )
                return ViewHolderData(binding)
            }

        }
    }


    /**
     * @desc content array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return contentList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return contentList[position].type!!
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val data = contentList[holder.adapterPosition]
        when (getItemViewType(position)) {
            2, 3, 4, 5 -> {
                (holder as ViewHolderData).bind(data)
            }
        }
    }

    /**
     *@desc update settings preference and notify adapter
     */
    fun updatedUserPref(dataModel: ContentUserPrefModel.DataModel) {
        dataModel.game?.apply {
            gameChooseList.addAll(this)
        }
        dataModel.platform?.apply {
            gamePlatformList.addAll(this)
        }
        dataModel.gamegenre?.apply {
            gameCenterList.addAll(this)
        }
        dataModel.prefercontent?.apply {
            gameContentList.addAll(this)
        }
        notifyDataSetChanged()

    }

    /**
     * This class will be call for show save button view and manage save click
     */
    inner class SaveViewHolderData(binding: AdapterContentSettingSaveBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.buttonSave.click {
                onSaveItemClick(gameChooseList,gameCenterList,gameContentList, gamePlatformList)
            }
        }
    }

    /**
     * This class will be call for load content data with different categories
     */
    inner class ViewHolderData(private val binding: AdapterContentDataBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: CustomContentModel) {
            binding.textViewTitle.text = data.title
            binding.recyclerViewContent.layoutManager =
                LinearLayoutManager(binding.root.context, LinearLayoutManager.HORIZONTAL, false)
            when (data.type) {
                2 -> {
                    chooseGameAdapter = ContentDataAdapter(
                        data.chooseGamesList!!,
                        gameChooseList,
                        onItemClick = { position: Int, id: String ->
                            updateSelectedList(position, id, "choose")
                        })
                    binding.recyclerViewContent.adapter = chooseGameAdapter

                }
                3 -> {
                    gamePlatformAdapter =
                        ContentPlatformAdapter(data.platformsList!!, gamePlatformList,  onItemClick = { position: Int, id: String ->
                            updateSelectedList(position, id, "platform")
                        })
                    binding.recyclerViewContent.adapter = gamePlatformAdapter
                }
                4 -> {
                    gameCenterAdapter = ContentDataAdapter(
                        data.gameCenterList!!,
                        gameCenterList,
                        onItemClick = { position: Int, id: String ->
                            updateSelectedList(position, id, "center")
                        })
                    binding.recyclerViewContent.adapter = gameCenterAdapter
                }
                5 -> {
                    contentGameAdapter = ContentDataAdapter(
                        data.contentCenterList!!,
                        gameContentList,
                        onItemClick = { position: Int, id: String ->
                            updateSelectedList(position, id, "content")
                        })
                    binding.recyclerViewContent.adapter = contentGameAdapter
                }
            }
        }
    }

    /**
     * This method use for update selected item in different categories
     */
    private fun updateSelectedList(position: Int, id: String, type: String) {
        when (type) {
            "choose" -> {
                chooseGameAdapter?.apply {
                    this.updateSelection(position, id)
                }
            }
            "center" -> {
                gameCenterAdapter?.apply {
                    this.updateSelection(position, id)
                }
            }
            "content" -> {
                contentGameAdapter?.apply {
                    this.updateSelection(position, id)
                }
            }
            "platform" -> {
                gamePlatformAdapter?.apply {
                    this.updateSelection(position, id)
                }
            }
        }
    }

}


