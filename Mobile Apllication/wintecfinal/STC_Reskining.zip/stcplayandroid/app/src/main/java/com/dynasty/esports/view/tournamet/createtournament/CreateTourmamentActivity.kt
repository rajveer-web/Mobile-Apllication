package com.dynasty.esports.view.tournamet.createtournament

import android.content.DialogInterface
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.viewpager.widget.ViewPager
import com.badoualy.stepperindicator.StepperIndicator
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CreateTournament
import com.dynasty.esports.models.SingleTournamentModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.viewmodel.CreateTournamentViewModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_create_tournament.*
import kotlinx.android.synthetic.main.create_tournament_app_bar_layout.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step1.*
import kotlinx.android.synthetic.main.fragment_esports.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will use for Create tournament
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
open class CreateTourmamentActivity : BaseActivity() {

    var tournamentId: String? = ""
    var isForEdit: Boolean = false
    private val mViewModel: CreateTournamentViewModel by viewModel()
    var createTournamentSave: CreateTournament = CreateTournament()
    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
    var tournamentName = ""
    var tournamentUrlIsValid = false
    var singleTournamentModel = SingleTournamentModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_tournament)
        initIntentParams()
        initialise()
        listenToViewModel()
    }

    private fun initIntentParams() {
        try {
            if (intent.extras != null) {
                if (intent.extras!!.containsKey("isForEdit")) {
                    isForEdit = intent.getBooleanExtra("isForEdit", false)
                }
                if (intent.extras!!.containsKey("tournamentId")) {
                    tournamentId = intent.getStringExtra("tournamentId")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * @desc this method is used for add fragments in fragmentlist and set in commonpageradapter
     *       and set observer clicks
     */
    fun initialise() {
        if (isForEdit) {
            createTournamentSave = CreateTournament()
            sharedPreferences.clearPreference("createTournamentSave")

            launchProgressDialog()
            mViewModel.getSingleTournament(tournamentId!!)
        }

        btn_prev.click {
            mViewModel.btnPrevClick()
        }

        btn_next.click {
            mViewModel.btnNextClick()
        }

        fragmentList.add(
            Pair(
                CreateTournamentStep1Fragment.newInstance("step1"),
                resources.getString(R.string.create_tournament_step1)
            )
        )
        fragmentList.add(
            Pair(
                CreateTournamentStep2Fragment.newInstance("step2"),
                resources.getString(R.string.create_tournament_step2)
            )
        )
        fragmentList.add(
            Pair(
                CreateTournamentStep3Fragment.newInstance("step3"),
                resources.getString(R.string.create_tournament_step3)
            )
        )
        commonPagerAdapter =
            CommonPagerAdapter(
                fragmentList,
                supportFragmentManager
            )

        //        Initilization of pager and stepper_indicator
        createTournamentPager.adapter = commonPagerAdapter
        createTournamentPager.offscreenPageLimit = 3
        stepper_indicator.setViewPager(createTournamentPager, createTournamentPager.adapter!!.count)
        stepper_indicator.addOnStepClickListener(StepperIndicator.OnStepClickListener { step ->
            createTournamentPager.setCurrentItem(
                step,
                true
            )
        })

//      addOnPageChangeListener -> Manage back button and next button in case of page change.
        createTournamentPager?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {

            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                setSeteper(position)
            }

            override fun onPageSelected(position: Int) {}

        })

//        If user have saveddata then refresh data on next page change.
        createTournamentPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {
            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                val page = commonPagerAdapter.getItem(createTournamentPager.currentItem)
                if (position == 0 && page != null) {
//                    (page as CreateTournamentStep1Fragment).isAbleToNext()
                } else if (position == 1 && page != null) {
                    (page as CreateTournamentStep2Fragment).refreshSaveData()
                } else if (position == 2 && page != null) {
                    (page as CreateTournamentStep3Fragment).refreshSaveData()
                }
            }
        })

        if (LocaleHelper.getLanguage(this@CreateTourmamentActivity) == "en") {

        } else {

//            val params = LinearLayout.LayoutParams(
//                LinearLayout.LayoutParams.WRAP_CONTENT,
//                LinearLayout.LayoutParams.WRAP_CONTENT
//            ).apply {
//                gravity = Gravity.START or Gravity.LEFT
//            }
            tvFinalDetails.gravity = Gravity.START or Gravity.LEFT
        }
    }

    private fun setSeteper(step: Int) {
        if (step == 0) {
            btn_prev.beGone()
            btn_next.beVisible()
            tvNext.text = resources.getString(R.string.next)

            imgStepperRoundOne.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_primary))
            imgStepperRoundTwo.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_black))
            imgStepperRoundThree.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_black))
            viewStepperLineOne.setBackgroundColor(resources.getColor(R.color.stroke_boder))
            viewStepperLineTwo.setBackgroundColor(resources.getColor(R.color.stroke_boder))
        } else if (step == 1) {
            btn_prev.beVisible()
            btn_next.beVisible()
            tvNext.text = resources.getString(R.string.next)

            imgStepperRoundOne.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_primary))
            imgStepperRoundTwo.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_primary))
            imgStepperRoundThree.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_black))
            viewStepperLineOne.setBackgroundColor(resources.getColor(R.color.background_color))
            viewStepperLineTwo.setBackgroundColor(resources.getColor(R.color.stroke_boder))
        } else {
            btn_prev.beVisible()
            btn_next.beVisible()
            tvNext.text = resources.getString(R.string.preview)

            imgStepperRoundOne.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_primary))
            imgStepperRoundTwo.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_primary))
            imgStepperRoundThree.setImageDrawable(resources.getDrawable(R.drawable.ic_baseline_round_dot_circle_primary))
            viewStepperLineOne.setBackgroundColor(resources.getColor(R.color.background_color))
            viewStepperLineTwo.setBackgroundColor(resources.getColor(R.color.background_color))
        }
    }

    /**
     * @desc listen observer and observer that will receive the events
     *       Next and previous button observer for fragment page change.
     */
    private fun listenToViewModel() {

        //      get single tournament data from api success responce
        mViewModel.singleTournamentSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("singleTournamentSuccessResponse", Gson().toJson(it))
                singleTournamentModel = it
                dismissProgressDialog()
            })

//      get single tournament data from api error responce
        mViewModel.singleTournamentErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {

                dismissProgressDialog()
            })



        mViewModel.btnNextClickObserver.observe(this, Observer {
            val page = commonPagerAdapter.getItem(createTournamentPager.currentItem)
            if (createTournamentPager.currentItem == 0 && page != null) {
                (page as CreateTournamentStep1Fragment).isAbleToNext()
            } else if (createTournamentPager.currentItem == 1 && page != null) {
                (page as CreateTournamentStep2Fragment).isAbleToNext()
            } else if (createTournamentPager.currentItem == 2 && page != null) {
                (page as CreateTournamentStep3Fragment).isValidated()
            }
        })

        mViewModel.btnPrevClickObserver.observe(this, Observer {
            if (createTournamentPager.currentItem == 2) {
                createTournamentPager.setCurrentItem(1, true)
            } else if (createTournamentPager.currentItem == 1) {
                createTournamentPager.setCurrentItem(0, true)
            } else if (createTournamentPager.currentItem == 0) {

            }
        })
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc Handle Back pressed. Finish activity only in case of currunt tab is 1st. Otherwise user will redirect to last tab.
     */
    override fun onBackPressed() {
        if (createTournamentPager.currentItem == 2) {
            createTournamentPager.setCurrentItem(1, true)
        } else if (createTournamentPager.currentItem == 1) {
            createTournamentPager.setCurrentItem(0, true)
        } else if (createTournamentPager.currentItem == 0) {
            super.onBackPressed()
        }
    }
}