package com.dynasty.esports.view.tournamet.joined_tournamet

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Window
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.Country
import com.dynasty.esports.models.MemberList
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.utils.UriHelper
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.common.ChooseMediaAdapter
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.viewmodel.JoinTournamentViewModel
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import kotlinx.android.synthetic.main.activity_join_tournament.*
import kotlinx.android.synthetic.main.article_app_bar_layout.appBarLayout
import kotlinx.android.synthetic.main.article_app_bar_layout.collapsingToolbar
import kotlinx.android.synthetic.main.article_app_bar_layout.toolbar
import org.koin.androidx.viewmodel.ext.android.viewModel
import pub.devrel.easypermissions.AppSettingsDialog
import pub.devrel.easypermissions.EasyPermissions
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

/**
 * @desc this is class will use for tournament join page
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class JoinTournamentActivity : BaseActivity(), EasyPermissions.PermissionCallbacks,
    CountryCodePicker.Listener {

    private var tournamentId: String = ""
    private var tournamentName: String = ""
    private var participantType: String = ""
    private val mViewModel: JoinTournamentViewModel by viewModel()
    private var isFromAdapter: Boolean = false
    private var adapterClickPosition: Int = 0
    private var memberUseradapterClickPosition: Int = 0
    private var memberUserGameadapterClickPosition: Int = 0
    private var memberUserNameGameadapterText = ""
    private var memberUserGameNameGameadapterText = ""
    private var isTeamNameValid: Boolean = false
    private var isCaptainUserNameValid: Boolean = false
    private var isCaptainUserGameNameValid: Boolean = false
    private lateinit var bottomSheetDialogChooseMedia: BottomSheetDialog
    var selectedLogoEncoded: String = ""
    private lateinit var memberAdapter: MemberAdapter
    private var isForTeam = false
    val handler = Handler()
    private var isProfilePicSelected: Boolean = false
    private var isMobileAutoPopulate: Boolean = false
    private var isForEditJoin = false
    private var participantId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join_tournament)
        initIntentParams()
        initialize()
        listenToViewModel()
    }

    /**
     * @desc this method is used for and set data to fields
     */
    private fun fillData(tournamentbject: TournamentDetailRes) {
        tvJoinAppBarTitle.text = nullSafeNA(tournamentbject.data!!.name)

//      set banner and logo
        loadImageFromServer(tournamentbject.data!!.banner, imgJoinGameBanner)


        if (!isForEditJoin) {
            val memberList: MutableList<MemberList>? = ArrayList<MemberList>()

//        only add members if tournament type is team . So add member only if team size is greater than 0
//        Then calculate member and add in adapter as much as teamsize.
            if (tournamentbject.data!!.teamSize > 0) {

//        Remove one member from captain (because captain already added in ui)
                val teamSize = tournamentbject.data!!.teamSize - 1

                for (i in 1..teamSize) {
                    val item = MemberList()
                    memberList!!.add(item)
                }
                memberAdapter.addAll(memberList)
            }
        }


        if (!tournamentbject.data!!.gameDetail!!.logo.isNullOrEmpty()) {
            loadImageFromServer(tournamentbject.data!!.gameDetail!!.logo!!, imgeJoinLogo)
        }

        tvJoinWhen.text = tournamentbject.data!!.startDate!!.convertDateToRequireDateFormat(
            AppConstants.API_DATE_FORMAT,
            AppConstants.DD_MM_YYYY_HH_MM_FORMAT
        )

        if (tournamentbject.data!!.participantType.equals("team", true)) {
            tvCaptain.text = resources.getString(R.string.captain_member_1)
            tvJoinTournamamentType.text = resources.getString(R.string.team)
            llTeamName.beVisible()
            tvCaptain.beVisible()
            isForTeam = true
        } else {
            tvCaptain.text = resources.getString(R.string.captain)
            tvJoinTournamamentType.text = resources.getString(R.string.one_vs_one)
            llTeamName.beGone()
            tvCaptain.beGone()
            isForTeam = false
        }

        tvJoinAppBarSubTitle.text = nullSafeNA(tournamentbject.data!!.gameDetail!!.name)

        val loginUserModel: UserModel.UserData =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData

        if (!loginUserModel.profilePicture.isNullOrEmpty()) {
            selectedLogoEncoded = loginUserModel.profilePicture
            isProfilePicSelected = true
            llImgJoinTournamentLogoPlace.beGone()
            imgSelectedJoinTournamentLogo.beVisible()
            loadImageFromServer(
                loginUserModel.profilePicture,
                imgSelectedJoinTournamentLogo
            )
        }
        if (loginUserModel.emailisVerified) {
            if (!loginUserModel.email.isNullOrEmpty()) {
                editJoinCaptainMail.setText(loginUserModel.email)
            }
        }

        if (!loginUserModel.fullName.isNullOrEmpty()) {
            editJoinCaptainName.setText(loginUserModel.fullName)
        }

        if (!loginUserModel.phoneNumber.isNullOrEmpty()) {
            isMobileAutoPopulate = true
            tlJoinCaptainAutoMobileNumber.beVisible()
            editJoinCaptainAutoMobileNumber.setText(loginUserModel.phoneNumber)
            llCaptainPhoneInput.beGone()
        } else {
            isMobileAutoPopulate = false
            llCaptainPhoneInput.beVisible()
            tlJoinCaptainAutoMobileNumber.beGone()
        }
    }

    /**
     * @desc this method is used for get and set data from intent.extras
     */
    private fun initIntentParams() {
        try {
            if (intent.extras != null) {
//                if (intent.extras!!.containsKey("tournamentbject")) {
//                    val data = intent.getStringExtra("tournamentbject")
//                    tournamentbject = Gson().fromJson(
//                        data,
//                        object : TypeToken<TournamentDetailRes?>() {}.type
//                    )
//                    debugE("tournamentbject ->", Gson().toJson(tournamentbject))
//                }
                if (intent.extras!!.containsKey("isForEditJoin")) {
                    isForEditJoin = intent.getBooleanExtra("isForEditJoin", false)
                }
                if (intent.extras!!.containsKey("tournamentId")) {
                    tournamentId = intent.getStringExtra("tournamentId")
                }
                if (intent.extras!!.containsKey("tournamentName")) {
                    tournamentName = intent.getStringExtra("tournamentName")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * @desc listen observer and receive the events of viewmodel and show snacbar for each validation
     */
    private fun listenToViewModel() {

//      check validation of join tournament form
        mViewModel.joinTournamentSubmitObserver.observe(
            this,
            androidx.lifecycle.Observer {
                mViewModel.onValidationForNextStep(
                    isForTeam,
                    editTeamName.text.toString().trim(),
                    isTeamNameValid,
                    selectedLogoEncoded,
                    editJoinCaptainName.text.toString().trim(),
                    editJoinCaptainMail.text.toString().trim(),
                    editJoinCaptainUserName.text.toString().trim(),
                    editJoinCaptainUserGameName.text.toString().trim(),
                    isMobileAutoPopulate,
                    editjoinCaptainPhoneCode.text.toString().trim(),
                    editjoinCaptainPhoneNumber.text.toString().trim(),
                    isCaptainUserNameValid,
                    isCaptainUserGameNameValid,
                    memberAdapter.isValidated()
                )
            })

//      join tournament cancle button oberver
        mViewModel.joinTournamentCancleObserver.observe(
            this,
            androidx.lifecycle.Observer {
                finish()
            })

//      Open countryCode picker
//      set isFromAdapter for manage click is from activity code picker or adapter code picker
        mViewModel.countryCodeObserver.observe(
            this,
            androidx.lifecycle.Observer {
                isFromAdapter = false
                CountryCodePicker.showDialog(supportFragmentManager)
            })

//      check team url click observer
        mViewModel.checkTeamUrlClickObserver.observe(
            this,
            androidx.lifecycle.Observer {
                mViewModel.checkValidation(editTeamName.text.toString().trim())
            })

//      join tournament success responce
        mViewModel.joinTournamentSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                debugE("joinTournamentSuccessResponse", Gson().toJson(it))
                showJoinSuccessDialog("", false)
            })

//      join tournament error responce
        mViewModel.joinTournamentErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("joinTournamentErrorResponse", Gson().toJson(it))
                try {
                    val message = it.string().getMessageFromObject("message")
                    showJoinSuccessDialog(message, true)
                } catch (e: Exception) {
                    showJoinSuccessDialog(it.string(), true)
                }
                dismissProgressDialog()
            })

//      join tournament success responce
        mViewModel.updateJoinTournamentSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                debugE("updateJoinTournamentSuccessResponse", Gson().toJson(it))
                showJoinUpdateSuccessDialog("", false)
            })

//      join tournament error responce
        mViewModel.updateJoinTournamentErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("updateJoinTournamentErrorResponse", Gson().toJson(it))
                try {
                    val message = it.string().getMessageFromObject("message")
                    showJoinUpdateSuccessDialog(message, true)
                } catch (e: Exception) {
                    showJoinUpdateSuccessDialog(it.string(), true)
                }
                dismissProgressDialog()
            })

//      join tournament success responce
        mViewModel.alreadyJoinTournamentSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("alreadyJoinTournamentSuccessResponse", Gson().toJson(it))
                dismissProgressDialog()
                if (it.data.size > 0) {
                    participantId = it.data[0].id!!
                    editTeamName.setText(it.data[0].teamName)
                    editJoinCaptainName.setText(it.data[0].name)
                    editJoinCaptainMail.setText(it.data[0].email)
                    editJoinCaptainUserName.setText(it.data[0].tournamentUsername)
                    editJoinCaptainUserGameName.setText(it.data[0].inGamerUserId)
                    editJoinCaptainAutoMobileNumber.setText(it.data[0].phoneNumber)
                    isMobileAutoPopulate = true
                    if (it.data[0].teamMembers.isNotEmpty()) {

                        val memberList: MutableList<MemberList>? = ArrayList<MemberList>()

                        it.data[0].teamMembers.forEach {
                            val item: MemberList = MemberList()
                            item.memberEmail = it.email
                            item.memberName = it.name
                            item.memberPhoneNumber = it.phoneNumber
                            item.memberUserName = it.tournamentUsername
                            item.memberInGameUserName = it.inGamerUserId
                            item.memberIsAutoPopulated = true
                            item.memberInGameUserNameIsAvailable = true
                            item.memberUserNameIsAvailable = true
                            memberList!!.add(item)
                        }
                        memberAdapter.addAll(memberList)
                    }
                }
            })

//      join tournament error responce
        mViewModel.alreadyJoinTournamentErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("alreadyJoinTournamentErrorResponse", Gson().toJson(it))

//                try {
//                    val message = it.string().getMessageFromObject("message")
//                    showJoinSuccessDialog(message, true)
//                } catch (e: Exception) {
//                    showJoinSuccessDialog(it.string(), true)
//                }
                dismissProgressDialog()
            })

//      join tournament success responce
        mViewModel.fetchTournamentDetailSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                debugE("joinTournamentDetailSuccessResponse", Gson().toJson(it))
                participantType = it.data!!.participantType!!
                fillData(it)
            })

//      join tournament error responce
        mViewModel.fetchTournamentDetailErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("joinTournamentDetailErrorResponse", Gson().toJson(it))
                dismissProgressDialog()
            })

//      validation for team name is empty or not observer
        mViewModel.isTeamNameNotEmptyObserver.observe(
            this,
            androidx.lifecycle.Observer {
//                launchProgressDialog()
//                [{"key":"query","value":"{"teamName":"vikraj"}","equals":true,"description":null,"enabled":true}]
                val jsonObjectQuery = JsonObject()
//                jsonObjectQuery.addProperty("teamName", editTeamName.text.toString().trim())
//                jsonObjectQuery.addProperty("equals", true)
//                jsonObjectQuery.addProperty("description", "")
//                jsonObjectQuery.addProperty("enabled", true)
//                mViewModel.checkTeamUrlValidOrNot(jsonObjectQuery.toString())
                mViewModel.checkTeamUrlValidOrNot(
                    "teamName",
                    editTeamName.text.toString().trim(),
                    tournamentId,
                    participantId
                )
            })

//      check team name success responce
        mViewModel.checkTeamNameSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("checkUrlSuccessResponse", Gson().toJson(it))
                tvIsTeamNameAvailable.beVisible()
                dismissProgressDialog()
                if (!it.data!!.isExist) {
                    isTeamNameValid = true
                    tvIsTeamNameAvailable.setTextColor(resources.getColor(R.color.join_tournament_green_color))
                    tvIsTeamNameAvailable.text = resources.getString(R.string.team_name_available)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.team_name_available)
                    )
                } else {
                    isTeamNameValid = false
                    tvIsTeamNameAvailable.setTextColor(resources.getColor(R.color.red))
                    tvIsTeamNameAvailable.text =
                        resources.getString(R.string.team_name_not_available)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.team_name_not_available)
                    )
                }
            })

//      check menu name error responce
        mViewModel.checkTeamNameErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
            })

        mViewModel.isCaptainUserNameValidSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("isCaptainUserNameValidSuccessResponse", Gson().toJson(it))
                tvCaptainUserName.beVisible()
                dismissProgressDialog()
                if (!it.data!!.isExist) {
                    isCaptainUserNameValid = true
                    tvCaptainUserName.setTextColor(resources.getColor(R.color.join_tournament_green_color))
                    tvCaptainUserName.text =
                        resources.getString(R.string.tournament_username_is_available)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_username_is_available)
                    )
                } else {
                    isCaptainUserNameValid = false
                    tvCaptainUserName.setTextColor(resources.getColor(R.color.red))
                    tvCaptainUserName.text =
                        resources.getString(R.string.tournament_username_is_not_available)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_username_is_not_available)
                    )
                }
            })

        mViewModel.isCaptainUserNameValidErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("isCaptainUserNameValidErrorResponse", it.string())
                isCaptainUserNameValid = false
                dismissProgressDialog()
            })

        mViewModel.isCaptainUserGameNameValidSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                hideKeyboard()
                debugE("isCaptainUserNameValidSuccessResponse", Gson().toJson(it))
                tvCaptainGameUserName.beVisible()
                dismissProgressDialog()
                if (!it.data!!.isExist) {
                    isCaptainUserGameNameValid = true
                    tvCaptainGameUserName.setTextColor(resources.getColor(R.color.join_tournament_green_color))
                    tvCaptainGameUserName.text =
                        resources.getString(R.string.in_game_userid_is_available)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.in_game_userid_is_available)
                    )
                } else {
                    isCaptainUserGameNameValid = false
                    tvCaptainGameUserName.setTextColor(resources.getColor(R.color.red))
                    tvCaptainGameUserName.text =
                        resources.getString(R.string.in_game_userid_is_not_available)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.in_game_userid_is_not_available)
                    )
                }
            })

        mViewModel.isCaptainUserGameNameValidErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
//                hideKeyboard()
                debugE("isCaptainUserGameNameValidErrorResponse", it.string())

                isCaptainUserGameNameValid = false
                dismissProgressDialog()
            })

        mViewModel.isMemberUserNameValidSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("isMemberUserNameValidSuccessResponse", Gson().toJson(it))
                dismissProgressDialog()
                if (!it.data!!.isExist) {
                    memberAdapter.setUserNameAvailable(memberUseradapterClickPosition, true)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_username_is_available)
                    )
                } else {
                    memberAdapter.setUserNameAvailable(memberUseradapterClickPosition, false)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_username_is_not_available)
                    )
                }
                Handler().postDelayed(Runnable {
                    memberAdapter.isFromNotify = false
                }, 1000)

            })

        mViewModel.isMemberUserNameValidErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
//                hideKeyboard()
                memberAdapter.setUserNameAvailable(memberUseradapterClickPosition, false)
                debugE("isMemberUserNameValidErrorResponse", it.string())
                dismissProgressDialog()
            })

        mViewModel.isMemberUserGameNameValidSuccessResponse.observe(
            this,
            androidx.lifecycle.Observer {
                debugE("isMemberUserGameNameValidSuccessResponse", Gson().toJson(it))
                dismissProgressDialog()
                if (!it.data!!.isExist) {
                    memberAdapter.setUserGameNameAvailable(memberUserGameadapterClickPosition, true)
                    makeSnackBar(
                        container,
                        resources.getString(R.string.in_game_userid_is_available)
                    )
                } else {
                    memberAdapter.setUserGameNameAvailable(
                        memberUserGameadapterClickPosition,
                        false
                    )
                    makeSnackBar(
                        container,
                        resources.getString(R.string.in_game_userid_is_not_available)
                    )
                }
                Handler().postDelayed(Runnable {
                    memberAdapter.isFromNotify = false
                }, 1000)
            })

        mViewModel.isMemberUserGameNameValidErrorResponse.observe(
            this,
            androidx.lifecycle.Observer {
                memberAdapter.setUserGameNameAvailable(memberUserGameadapterClickPosition, false)
                debugE("isMemberUserGameNameValidErrorResponse", it.string())
                dismissProgressDialog()
            })

//      validationLiveData and show snacbar for incorrect value
        mViewModel.validationLiveData.observe(
            this,
            androidx.lifecycle.Observer {
                when (it) {
                    0 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_name_error)
                        )
                    }
                    1 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_name_not_available)
                        )
                    }
                    2 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_logo_not_available)
                        )
                    }
                    3 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_name_error)
                        )
                    }
                    4 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_email_error)
                        )
                    }
                    5 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_email_not_valid)
                        )
                    }
                    6 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_user_name_error)
                        )
                    }
                    7 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_username_is_not_available)
                        )
                    }
                    8 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_in_game_user_error)
                        )
                    }
                    9 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.in_game_userid_is_not_available)
                        )
                    }
                    10 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_phone_code)
                        )
                    }
                    11 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.team_captain_phone_number)
                        )
                    }
                    12 -> {
                        makeSnackBar(
                            container,
                            resources.getString(R.string.member_details_error)
                        )
                    }
                }
            })

//      check isNextStepFormValid or not
        mViewModel.isNextStepFormValid.observe(
            this,
            androidx.lifecycle.Observer {
                launchProgressDialog()
                debugE("joinTournament #", Gson().toJson(getJsonForApi()))
                if (isForEditJoin) {
                    mViewModel.updateJoinTournament(
                        getJsonForApi(),
                        participantId
                    )
                } else {
                    mViewModel.joinTournament(
                        getJsonForApi(),
                        participantId
                    )
                }
            })
    }


    val runnableTeamNameName = Runnable {
        if (editTeamName.text.toString().trim({ it <= ' ' }).length <= 0) {
            tvIsTeamNameAvailable.beGone()
            isTeamNameValid = false
        } else {
//            launchProgressDialog()

//            val jsonObjectQuery = JsonObject()
//            jsonObjectQuery.addProperty("teamName", editTeamName.text.toString().trim())
//            jsonObjectQuery.addProperty("equals", true)
//            jsonObjectQuery.addProperty("description", "")
//            jsonObjectQuery.addProperty("enabled", true)
//            mViewModel.checkTeamUrlValidOrNot(jsonObjectQuery.toString())
            mViewModel.checkTeamUrlValidOrNot(
                "teamName",
                editTeamName.text.toString().trim(),
                tournamentId,
                participantId
            )
        }
    }

    val runnableCaptainUserName = Runnable {
        if (editJoinCaptainUserName.text.toString().trim({ it <= ' ' }).length <= 0) {
            tvCaptainUserName.beGone()
            isCaptainUserNameValid = false
        } else {
//            launchProgressDialog()

//            val jsonObjectQuery = JsonObject()
//            val jsonTournamentUsername = JsonObject()
//            val jsonTeamMembers = JsonObject()
//            val jsonTeamMembersName = JsonObject()
//            val jsonelemMatch = JsonObject()
//            jsonelemMatch.addProperty(
//                "tournamentUsername",
//                editJoinCaptainUserName.text.toString().trim()
//            )
//            jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//            jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//            jsonTournamentUsername.addProperty(
//                "tournamentUsername",
//                editJoinCaptainUserName.text.toString().trim()
//            )
//            val jsonArray = JsonArray()
//            jsonArray.add(jsonTournamentUsername)
//            jsonArray.add(jsonTeamMembersName)
//            jsonObjectQuery.add("\$or", jsonArray)
//            jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//            debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
            mViewModel.checkUserNameValid(
                "tournamentUsername",
                editJoinCaptainUserName.text.toString().trim(),
                tournamentId,
                participantId
            )
//            mViewModel.checkParticipantSearch(jsonObjectQuery)
        }
    }

    val runnableCaptainGameUserName = Runnable {
        if (editJoinCaptainUserGameName.text.toString().trim({ it <= ' ' }).length <= 0) {
            tvCaptainGameUserName.beGone()
            isCaptainUserGameNameValid = false
        } else {
//            launchProgressDialog()

//            val jsonObjectQuery = JsonObject()
//            val jsonTournamentUsername = JsonObject()
//            val jsonTeamMembers = JsonObject()
//            val jsonTeamMembersName = JsonObject()
//            val jsonelemMatch = JsonObject()
//            jsonelemMatch.addProperty(
//                "inGamerUserId",
//                editJoinCaptainUserGameName.text.toString().trim()
//            )
//            jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//            jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//            jsonTournamentUsername.addProperty(
//                "inGamerUserId",
//                editJoinCaptainUserGameName.text.toString().trim()
//            )
//            val jsonArray = JsonArray()
//            jsonArray.add(jsonTournamentUsername)
//            jsonArray.add(jsonTeamMembersName)
//            jsonObjectQuery.add("\$or", jsonArray)
//            jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//            debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//            mViewModel.checkGameUserNameValid(jsonObjectQuery)

            mViewModel.checkGameUserNameValid(
                "inGamerUserId",
                editJoinCaptainUserGameName.text.toString().trim(),
                tournamentId,
                participantId
            )
        }
    }

    var runnableMemberUserName = Runnable {
        launchProgressDialog()

//        val jsonObjectQuery = JsonObject()
//        val jsonTournamentUsername = JsonObject()
//        val jsonTeamMembers = JsonObject()
//        val jsonTeamMembersName = JsonObject()
//        val jsonelemMatch = JsonObject()
//        jsonelemMatch.addProperty(
//            "tournamentUsername",
//            memberUserNameGameadapterText
//        )
//        jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//        jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//        jsonTournamentUsername.addProperty(
//            "tournamentUsername",
//            memberUserNameGameadapterText
//        )
//        val jsonArray = JsonArray()
//        jsonArray.add(jsonTournamentUsername)
//        jsonArray.add(jsonTeamMembersName)
//        jsonObjectQuery.add("\$or", jsonArray)
//        jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)

//        debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//        mViewModel.checkMemberUserNameValid(jsonObjectQuery)

        mViewModel.checkMemberUserNameValid(
            "tournamentUsername",
            memberUserNameGameadapterText,
            tournamentId,
            participantId
        )
    }

    //
    var runnableMemberGameUserName = Runnable {
        launchProgressDialog()

//        val jsonObjectQuery = JsonObject()
//        val jsonTournamentUsername = JsonObject()
//        val jsonTeamMembers = JsonObject()
//        val jsonTeamMembersName = JsonObject()
//        val jsonelemMatch = JsonObject()
//        jsonelemMatch.addProperty(
//            "inGamerUserId",
//            memberUserGameNameGameadapterText
//        )
//        jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//        jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//        jsonTournamentUsername.addProperty(
//            "inGamerUserId",
//            memberUserGameNameGameadapterText
//        )
//        val jsonArray = JsonArray()
//        jsonArray.add(jsonTournamentUsername)
//        jsonArray.add(jsonTeamMembersName)
//        jsonObjectQuery.add("\$or", jsonArray)
//        jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//        debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//        mViewModel.checkMemberGameUserNameValid(jsonObjectQuery)

        mViewModel.checkMemberGameUserNameValid(
            "inGamerUserId",
            memberUserGameNameGameadapterText,
            tournamentId,
            participantId
        )
    }

    /**
     * @desc create json for send in api
     */
    private fun getJsonForApi(): JsonObject {
        val loginUserModel =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData


        val memberList = JsonArray()
        val substituteMembers = JsonArray()

//      get all data from member adapter and create array for send in api
        for (i in memberAdapter.getAll()) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("name", i.memberName)
            if (i.memberIsAutoPopulated) {
                jsonObject.addProperty("phoneNumber", i.memberPhoneNumber)
            } else {
                jsonObject.addProperty("phoneNumber", i.memberPhoneCode + i.memberPhoneNumber)
            }
            jsonObject.addProperty("email", i.memberEmail)
            jsonObject.addProperty("tournamentUsername", i.memberUserName)
            jsonObject.addProperty("inGamerUserId", i.memberInGameUserName)
            memberList.add(jsonObject)
        }

        val jsonObject = JsonObject()
        if (isProfilePicSelected) {
            jsonObject.addProperty("logo", selectedLogoEncoded)
        } else {
            jsonObject.addProperty("logo", "data:image/png;base64," + selectedLogoEncoded)
        }
        jsonObject.addProperty("teamName", editTeamName.text.toString().trim())
        jsonObject.addProperty("name", editJoinCaptainName.text.toString().trim())
        if (isMobileAutoPopulate) {
            jsonObject.addProperty(
                "phoneNumber",
                editJoinCaptainAutoMobileNumber.text.toString().trim()
            )
        } else {
            jsonObject.addProperty(
                "phoneNumber",
                editjoinCaptainPhoneCode.text.toString()
                    .trim() + editjoinCaptainPhoneNumber.text.toString().trim()
            )
        }
        jsonObject.addProperty("email", editJoinCaptainMail.text.toString().trim())
        jsonObject.addProperty("tournamentUsername", editJoinCaptainUserName.text.toString().trim())
        jsonObject.addProperty("inGamerUserId", editJoinCaptainUserGameName.text.toString().trim())
        jsonObject.add("teamMembers", memberList)
        jsonObject.add("substituteMembers", substituteMembers)
        if (isForEditJoin) {
            jsonObject.addProperty("id", participantId)
        }
        jsonObject.addProperty("participantType", participantType)
        jsonObject.addProperty("tournamentId", tournamentId)
        jsonObject.addProperty("userId", loginUserModel.id)
        return jsonObject
    }

    /**
     * @desc this method is used for initialize toolbar, view clicks, adapter and recyclerview
     */
    private fun initialize() {
        toolbar.title = ""
        setSupportActionBar(toolbar)
        collapsingToolbar.setCollapsedTitleTypeface(getFontTypeFace(R.font.hkgrotesk_medium))
        appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                Math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbar.title = tournamentName
                }
                else -> {
                    collapsingToolbar.title = ""
                    // Expanded
                }
            }
        })

//      dynamic member Adapter initilization
        memberAdapter = MemberAdapter(
            onItemPhoneCodeClick = ::onMemberPhonCodeClick,
            onJoinMemberUserNameChanged = ::onJoinMemberUserNameChanged,
            onJoinMemberInGameUserNameChanged = ::onJoinMemberInGameUserNameChanged,
            llMemberUserNameCheckClick = ::onllMemberUserNameCheckClick,
            llMemberGameNameCheckClick = ::onllMemberGameNameCheckClick
        )

//      dynamic member recyclerview initilization
        rvMemberList.layoutManager = LinearLayoutManager(this)
        rvMemberList.adapter = memberAdapter

        editTeamName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(editable: Editable?) {
                if (editable.toString().isNotEmpty()) {
                    handler.removeCallbacks(runnableTeamNameName)
                    handler.postDelayed(runnableTeamNameName, 500)
                } else {
                    tvIsTeamNameAvailable.beGone()
                    isTeamNameValid = false
                }
            }
        })

        editJoinCaptainUserName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(editable: Editable?) {
                if (editable.toString().isNotEmpty()) {
                    handler.removeCallbacks(runnableCaptainUserName)
                    handler.postDelayed(runnableCaptainUserName, 500)
                } else {
                    tvCaptainUserName.beGone()
                    isCaptainUserNameValid = false
                }
            }
        })

        editJoinCaptainUserGameName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(editable: Editable?) {
                if (editable.toString().isNotEmpty()) {
                    handler.removeCallbacks(runnableCaptainGameUserName)
                    handler.postDelayed(runnableCaptainGameUserName, 500)
                } else {
                    tvCaptainGameUserName.beGone()
                    isCaptainUserGameNameValid = false
                }
            }
        })


        llImgJoinTournamentLogo.click {
            launchChooseProfileBottomSheet()
        }

        llTeamUrlCheck.click {
            mViewModel.checkTeamUrlClick()
        }

        btnJoinSubmit.click {
            mViewModel.joinTournamentSubmitClick()
        }

        btnJoinCancel.click {
            mViewModel.joinTournamentCancelClick()
        }

        editjoinCaptainPhoneCode.click {
            mViewModel.countryCodeClick()
        }

        val loginUserModel =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData

        val jsonObjectQuery = JsonObject()
        jsonObjectQuery.addProperty("tournamentId", tournamentId)
        jsonObjectQuery.addProperty("userId", loginUserModel.id)

        launchProgressDialog()
        if (isForEditJoin) {
            mViewModel.getAlreadyJoinTournamentData(jsonObjectQuery)
        }
        mViewModel.fetchTournamentDetail(tournamentId, "latest", "")
    }

    private fun onllMemberUserNameCheckClick(position: Int, textUserName: String) {
        memberUseradapterClickPosition = position

        launchProgressDialog()
//        val jsonObjectQuery = JsonObject()
//        val jsonTournamentUsername = JsonObject()
//        val jsonTeamMembers = JsonObject()
//        val jsonTeamMembersName = JsonObject()
//        val jsonelemMatch = JsonObject()
//        jsonelemMatch.addProperty(
//            "tournamentUsername",
//            textUserName
//        )
//        jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//        jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//        jsonTournamentUsername.addProperty(
//            "tournamentUsername",
//            textUserName
//        )
//        val jsonArray = JsonArray()
//        jsonArray.add(jsonTournamentUsername)
//        jsonArray.add(jsonTeamMembersName)
//        jsonObjectQuery.add("\$or", jsonArray)
//        jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//        debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//        mViewModel.checkMemberUserNameValid(jsonObjectQuery)

        memberAdapter.isFromNotify = true
        mViewModel.checkMemberUserNameValid(
            "tournamentUsername",
            textUserName,
            tournamentId,
            participantId
        )
    }

    private fun onllMemberGameNameCheckClick(position: Int, textUserGameName: String) {
        memberUserGameadapterClickPosition = position

        launchProgressDialog()
//
//        val jsonObjectQuery = JsonObject()
//        val jsonTournamentUsername = JsonObject()
//        val jsonTeamMembers = JsonObject()
//        val jsonTeamMembersName = JsonObject()
//        val jsonelemMatch = JsonObject()
//        jsonelemMatch.addProperty(
//            "inGamerUserId",
//            textUserGameName
//        )
//        jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//        jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//        jsonTournamentUsername.addProperty(
//            "inGamerUserId",
//            textUserGameName
//        )
//        val jsonArray = JsonArray()
//        jsonArray.add(jsonTournamentUsername)
//        jsonArray.add(jsonTeamMembersName)
//        jsonObjectQuery.add("\$or", jsonArray)
//        jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//        debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//        mViewModel.checkMemberGameUserNameValid(jsonObjectQuery)
        memberAdapter.isFromNotify = true
        mViewModel.checkMemberGameUserNameValid(
            "inGamerUserId",
            textUserGameName,
            tournamentId,
            participantId
        )
    }

    private fun onJoinMemberUserNameChanged(position: Int, s: String) {
        memberUseradapterClickPosition = position
        memberUserNameGameadapterText = s

        if (s.isNotEmpty()) {

//            launchProgressDialog()

//            val jsonObjectQuery = JsonObject()
//            val jsonTournamentUsername = JsonObject()
//            val jsonTeamMembers = JsonObject()
//            val jsonTeamMembersName = JsonObject()
//            val jsonelemMatch = JsonObject()
//            jsonelemMatch.addProperty(
//                "tournamentUsername",
//                memberUserNameGameadapterText
//            )
//            jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//            jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//            jsonTournamentUsername.addProperty(
//                "tournamentUsername",
//                memberUserNameGameadapterText
//            )
//            val jsonArray = JsonArray()
//            jsonArray.add(jsonTournamentUsername)
//            jsonArray.add(jsonTeamMembersName)
//            jsonObjectQuery.add("\$or", jsonArray)
//            jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//            debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//            mViewModel.checkMemberUserNameValid(jsonObjectQuery)

            mViewModel.checkMemberUserNameValid(
                "tournamentUsername",
                memberUserNameGameadapterText,
                tournamentId,
                participantId
            )

//            handler.removeCallbacks(runnableMemberUserName)
//            handler.postDelayed(runnableMemberUserName, 500)
        } else {
            memberAdapter.setUserNameAvailable(position, false)
        }
    }

    private fun onJoinMemberInGameUserNameChanged(position: Int, s: String) {
        memberUserGameadapterClickPosition = position
        memberUserGameNameGameadapterText = s
        if (s.isNotEmpty()) {
//            launchProgressDialog()

//            val jsonObjectQuery = JsonObject()
//            val jsonTournamentUsername = JsonObject()
//            val jsonTeamMembers = JsonObject()
//            val jsonTeamMembersName = JsonObject()
//            val jsonelemMatch = JsonObject()
//            jsonelemMatch.addProperty(
//                "inGamerUserId",
//                memberUserGameNameGameadapterText
//            )
//            jsonTeamMembers.add("\$elemMatch", jsonelemMatch)
//            jsonTeamMembersName.add("teamMembers", jsonTeamMembers)
//            jsonTournamentUsername.addProperty(
//                "inGamerUserId",
//                memberUserGameNameGameadapterText
//            )
//            val jsonArray = JsonArray()
//            jsonArray.add(jsonTournamentUsername)
//            jsonArray.add(jsonTeamMembersName)
//            jsonObjectQuery.add("\$or", jsonArray)
//            jsonObjectQuery.addProperty("tournamentId", tournamentbject.data!!.id)
//
//            debugE("jsonObjectQuery £", Gson().toJson(jsonObjectQuery))
//            mViewModel.checkMemberGameUserNameValid(jsonObjectQuery)

            mViewModel.checkMemberGameUserNameValid(
                "inGamerUserId",
                memberUserGameNameGameadapterText,
                tournamentId,
                participantId
            )
//            handler.removeCallbacks(runnableMemberGameUserName)
//            handler.postDelayed(runnableMemberGameUserName, 500)
        } else {
            memberAdapter.setUserGameNameAvailable(position, false)
        }
    }

    /**
     * @desc Manage phone code picker from adapter and activity  on click and set position variable for last adapter code picker position click
     * @param isFromAdapter is true than picker was opened from adapter then set value in adapter item
     * @param adapterClickPosition set on each click for set right phone code to right item of adapter
     */
    private fun onMemberPhonCodeClick(position: Int) {
        isFromAdapter = true
        adapterClickPosition = position
        CountryCodePicker.showDialog(supportFragmentManager)
    }

    /**
     * @desc Get file url from gallery and camera using intent and encoded to base64 string
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == AppConstants.TAKE_PHOTO) {

                try {
                    if (mSelectedCameraImage == null || !mSelectedCameraImage!!.exists()) {
                        val tmp_fileUri = data!!.data
                        debugE("", "tmp_fileUri : " + tmp_fileUri!!.path)
                        // Debug.e("", "fileUri : " + fileUri.getPath());
                        val selectedImagePath: String = UriHelper.getPath(
                            this, tmp_fileUri
                        )!!
                        mSelectedCameraImage = File(selectedImagePath)
                    } else {
                    }
                    if (mSelectedCameraImage != null && mSelectedCameraImage!!.exists()) {
                        if (isJPEGorPNG(mSelectedCameraImage!!.absolutePath)) {
                            startCropActivity(Uri.fromFile(mSelectedCameraImage))
                        } else {
                            "Select PNG or JPEG file only".showToast(this)
                        }
                    }
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }

//                startCropActivity(data!!.data!!)
//
//                mSelectedCameraImage?.apply {
//                    llImgJoinTournamentLogoPlace.beGone()
//                    imgSelectedJoinTournamentLogo.beVisible()
//                    loadImageFromServer(
//                        "file://".plus(this.absolutePath),
//                        imgSelectedJoinTournamentLogo
//                    )
//                    selectedLogoEncoded = this.encoder()
//                    isProfilePicSelected = false
//                }

            } else if (requestCode == AppConstants.IMAGE_CODE) {
                if (data == null)
                    return


                val tmp_fileUri = data.data
                debugE("", "tmp_fileUri : " + tmp_fileUri!!.path)

                val selectedImagePath = UriHelper.getPath(
                    this,
                    tmp_fileUri
                )
                mSelectedCameraImage = File(selectedImagePath)

                if (isJPEGorPNG(mSelectedCameraImage!!.absolutePath)) {
                    startCropActivity(tmp_fileUri)
                } else {
                    "Select PNG or JPEG file only".showToast(this)
                }

//                startCropActivity(data!!.data!!)
//                data.data?.apply {
//                    mSelectedCameraImage = uriToImageFile(this)
//                    mSelectedCameraImage?.apply {
//                        llImgJoinTournamentLogoPlace.beGone()
//                        imgSelectedJoinTournamentLogo.beVisible()
//                        loadImageFromServer(
//                            "file://".plus(this.absolutePath),
//                            imgSelectedJoinTournamentLogo
//                        )
//                        selectedLogoEncoded = this.encoder()
//                        isProfilePicSelected = false
//                    }
//                }
            } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                val result = CropImage.getActivityResult(data)
                if (resultCode == RESULT_OK) {
//                    val resultUri = result.uri
//                    mSelectedCameraImage = uriToImageFile(result.uri)
//                    mSelectedCameraImage?.apply {
//                        llImgJoinTournamentLogoPlace.beGone()
//                        imgSelectedJoinTournamentLogo.beVisible()
//                        loadImageFromServer(
//                            "file://".plus(this.absolutePath),
//                            imgSelectedJoinTournamentLogo
//                        )
//                        selectedLogoEncoded = this.encoder()
//                        isProfilePicSelected = false
//                    }

                    val result = CropImage.getActivityResult(data)
                    if (resultCode == RESULT_OK) {
                        val resultUri = result.uri
                        val selectedImagePath = UriHelper.getPath(
                            this, resultUri
                        )
                        mSelectedCameraImage = File(selectedImagePath)
                        debugE("", "fileUri : " + mSelectedCameraImage!!.absolutePath)

//                    imageLoader.displayImage(fileUri.getPath(), imgProfile);
//                        imageLoader.displayImage(
//                            "file://" + fileUri.getAbsolutePath(),
//                            imgProfileUpdate
//                        )
//                        imgProfileUpdate.setTag(fileUri)
//                        llProfileUpdate.setVisibility(View.GONE)
//                        imgProfileUpdate.setVisibility(View.VISIBLE)

                        mSelectedCameraImage?.apply {
                            llImgJoinTournamentLogoPlace.beGone()
                            imgSelectedJoinTournamentLogo.beVisible()
                            loadImageFromServer(
                                "file://".plus(this.absolutePath),
                                imgSelectedJoinTournamentLogo
                            )
                            selectedLogoEncoded = this.encoder()
                            isProfilePicSelected = false
                        }
                    } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                        val error = result.error
                    }

                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    val error = result.error
                }
            }
        }
    }

    fun startCropActivity(tmp_fileUri: Uri) {
        CropImage.activity(tmp_fileUri)
            .setGuidelines(CropImageView.Guidelines.OFF)
            .setAllowRotation(true)
            .setFixAspectRatio(true)
            .setOutputCompressQuality(50)
            .start(this)
    }

    /**
     * @desc this method is used for onRequestPermissionsResult
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    /**
     * @desc this method is used for onPermissionsDenied
     */
    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            AppSettingsDialog.Builder(this).build().show()
        }
    }

    /**
     * @desc if permission granted from user when open gallery or camera for choose image
     */
    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
        if (requestCode == AppConstants.PERMISSION_CODE) {
            if (pos == 0) {
                chooseCamera(path = ::cameraPath)
            } else {
                chooseGallery()
            }
        }
    }

    /**
     * @desc temp camera file store in global file variable
     * @param file - temporary camera file
     */
    private fun cameraPath(file: File) {
        mSelectedCameraImage = file
    }

    /**
     * @desc this method will use choose media option(camera or gallery)
     * Display option inside bottom sheet
     */
    private fun launchChooseProfileBottomSheet() {
        bottomSheetDialogChooseMedia = BottomSheetDialog(this)
        val viewChooseMedia = layoutInflater.inflate(R.layout.bottom_sheet_choose_option, null)
        bottomSheetDialogChooseMedia.setContentView(viewChooseMedia)
        val recyclerViewChooseMedia =
            viewChooseMedia.findViewById(R.id.recyclerViewChooseMedia) as RecyclerView
        recyclerViewChooseMedia.layoutManager = LinearLayoutManager(this)
        val chooseMediaAdapter = ChooseMediaAdapter(
            resources.getStringArray(R.array.media_option),
            onChooseMediaClick = {
                pos = it
                when (it) {
                    0 -> {
                        chooseCamera(path = ::cameraPath)
                    }
                    1 -> {
                        chooseGallery()
                    }
                    else -> bottomSheetDialogChooseMedia.dismiss()
                }
                bottomSheetDialogChooseMedia.dismiss()
            }
        )
        recyclerViewChooseMedia.adapter = chooseMediaAdapter

        bottomSheetDialogChooseMedia.show()
    }

    /**
     * @desc launch camera for take image with check camera permission
     * Get file using file provide
     * @param path = temporary camera file
     *
     */
    private fun chooseCamera(path: (File) -> Unit = { _ -> }) {
        if (EasyPermissions.hasPermissions(this, *perms)) {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                // Ensure that there's a camera activity to handle the intent
                takePictureIntent.resolveActivity(packageManager)?.also {
                    // Create the File where the photo should go
                    val photoFile: File? = try {
                        createImageFile()
                    } catch (ex: IOException) {
                        null
                    }
                    // Continue only if the File was successfully created
                    photoFile?.also {
                        path(photoFile)
                        val photoURI: Uri = FileProvider.getUriForFile(
                            this,
                            packageName.plus(".provider"),
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        takePictureIntent.putExtra("forWhat", "banner")
                        startActivityForResult(
                            takePictureIntent,
                            AppConstants.TAKE_PHOTO
                        )
                    }
                }
            }
        } else {
            EasyPermissions.requestPermissions(
                this,
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    /**
     * @desc method will use create temporary file in local storage
     */
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        )
    }

    /**
     * @desc method will use launch gallery for choose profile
     */
    private fun chooseGallery() {
        if (EasyPermissions.hasPermissions(this, *perms)) {
            val pickIntent = Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            )
            pickIntent.type = "image/*"
            startActivityForResult(
                pickIntent, AppConstants.IMAGE_CODE
            )
        } else {
            EasyPermissions.requestPermissions(
                this,
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    /**
     * @desc method will use for set selected Country to tvEnterContactWhatsappCode
     */
    override fun onCountryChosen(country: Country) {
        if (isFromAdapter) {
            memberAdapter.setCountryCode("+".plus(country.phoneCode), adapterClickPosition)
        } else {
            editjoinCaptainPhoneCode.setText("+".plus(country.phoneCode))
        }
    }

    /**
     * @desc method will use for show success and failure dialog for join tournament
     */
    private fun showJoinSuccessDialog(messageFromObject: String, isFail: Boolean) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.dialog_join_success_view)
        val tvJoinSuccess = dialog.findViewById(R.id.tvJoinSuccess) as TextView
        val tvJoinSuccessTitle = dialog.findViewById(R.id.tvJoinSuccessTitle) as TextView
        val tvJoinSuccessFail = dialog.findViewById(R.id.tvJoinSuccessFail) as TextView

        if (isFail) {
            if (!messageFromObject.isFieldEmpty()) {
                tvJoinSuccessTitle.text = messageFromObject
            } else {
                tvJoinSuccessTitle.text = resources.getString(R.string.some_thing_went_wrong)
            }
            tvJoinSuccessFail.beGone()
        } else {
            tvJoinSuccessTitle.text = resources.getString(R.string.registered_successfully)

//            if (isForTeam) {
//                tvJoinSuccessFail.text =
//                    resources.getString(R.string.teams_has_been_registered_successfully)
//            } else {
//                tvJoinSuccessFail.text =
//                    resources.getString(R.string.teams_has_been_registered_successfully)
//            }
            tvJoinSuccessFail.beGone()
        }

        tvJoinSuccess.click {
            dialog.dismiss()
            if (!isFail) {
                setResult(RESULT_OK)
                finish()
            }
        }
        dialog.show()
    }

    /**
     * @desc method will use for show success and failure dialog for join tournament
     */
    private fun showJoinUpdateSuccessDialog(messageFromObject: String, isFail: Boolean) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.dialog_join_success_view)
        val tvJoinSuccess = dialog.findViewById(R.id.tvJoinSuccess) as TextView
        val tvJoinSuccessTitle = dialog.findViewById(R.id.tvJoinSuccessTitle) as TextView
        val tvJoinSuccessFail = dialog.findViewById(R.id.tvJoinSuccessFail) as TextView

        if (isFail) {
            if (!messageFromObject.isFieldEmpty()) {
                tvJoinSuccessTitle.text = messageFromObject
            } else {
                tvJoinSuccessTitle.text = resources.getString(R.string.some_thing_went_wrong)
            }
            tvJoinSuccessFail.beGone()
        } else {
            tvJoinSuccessTitle.text = resources.getString(R.string.participant_updated_successfully)
//            if (isForTeam) {
//                tvJoinSuccessFail.text =
//                    resources.getString(R.string.team_updated_successfully)
//            } else {
//                tvJoinSuccessFail.text =
//                    resources.getString(R.string.team_updated_successfully)
//            }
            tvJoinSuccessFail.beGone()
        }

        tvJoinSuccess.click {
            dialog.dismiss()
            if (!isFail) {
                setResult(RESULT_OK)
                finish()
            }
        }
        dialog.show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(runnableCaptainUserName)
        handler.removeCallbacks(runnableCaptainGameUserName)
        handler.removeCallbacks(runnableTeamNameName)
        handler.removeCallbacks(runnableMemberUserName)
        handler.removeCallbacks(runnableMemberGameUserName)
        super.onDestroy()
    }
}