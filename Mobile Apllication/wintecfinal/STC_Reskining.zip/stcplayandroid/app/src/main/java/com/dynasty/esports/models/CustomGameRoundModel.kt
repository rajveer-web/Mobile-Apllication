package com.dynasty.esports.models

data class CustomGameRoundModel(
    var round:Int?=null,
    var detailList:MutableList<GameRoundDetailModel.DataModel> = mutableListOf()
)