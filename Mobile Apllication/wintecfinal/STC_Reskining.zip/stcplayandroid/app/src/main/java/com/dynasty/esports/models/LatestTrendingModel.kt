package com.dynasty.esports.models

import android.icu.text.CaseMap.Title
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class LatestTrendingModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DatumModel>? = null

    class DatumModel{

        @SerializedName("trend")
        @Expose
         val trend: Int? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("author")
        @Expose
         val author: String? = null

        @SerializedName("authorDetails")
        @Expose
         val authorDetails: HottestPostArticleModel.AuthorDetailsModel? = null

        @SerializedName("createdDate")
        @Expose
         val createdDate: String? = null

        @SerializedName("game")
        @Expose
         val game: String? = null

        @SerializedName("image")
        @Expose
         val image: String? = null

        @SerializedName("views")
        @Expose
         val views: Int? = null

        @SerializedName("shortDescription")
        @Expose
         val shortDescription: TitleModel? = null

    }
}