package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class GamesModel {
    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("totals")
    @Expose
     val totals: TotalsModel? = null

    class DataModel{
        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("name")
        @Expose
         val name: String? = null

        @SerializedName("logo")
        @Expose
         val logo: String? = null

        @SerializedName("image")
        @Expose
         val image: String? = null

        @SerializedName("activeTournament")
        @Expose
         val activeTournament: String? = null

        @SerializedName("bracketTypes")
        @Expose
         val bracketTypes: BracketTypesModel? = null

        @SerializedName("platforms")
        @Expose
         val platforms: PlatformsModel? = null

        var isLoadMore=false
    }

    class PlatformsModel{
        @SerializedName("data")
        @Expose
         val data: MutableList<PlatformsDataModel>? = null
    }

    class PlatformsDataModel{
        @SerializedName("id")
        @Expose
         val id: Int? = null

        @SerializedName("name")
        @Expose
         val name: String? = null
    }

    class BracketTypesModel{
        @SerializedName("simple")
        @Expose
         val simple: Boolean? = null

        @SerializedName("double")
        @Expose
         val _double: Boolean? = null

        @SerializedName("single")
        @Expose
         val single: Boolean? = null

        @SerializedName("round-robin")
        @Expose
         val roundRobin: Boolean? = null
    }
}