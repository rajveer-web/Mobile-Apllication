package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import org.json.JSONObject

class DashBoardViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {

    val updateDrawerUI=MutableLiveData<UserModel>()
    val registerFCMTokenSuccessResponse = MutableLiveData<ResponseBody>()
    val registerFCMTokenErrorResponse = MutableLiveData<ResponseBody>()

    fun updateDrawerUI(userModel:UserModel) {
        updateDrawerUI.postValue(userModel)
    }


    fun registrationPushNotification(jsonObj:JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.registerfcmToken(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    registerFCMTokenSuccessResponse.postValue(response.body())
                }
                else -> {
                    registerFCMTokenErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    /**
     * Clears the [ViewModel] when the [DashboardActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
