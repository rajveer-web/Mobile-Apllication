package com.dynasty.esports.view.common

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.utils.CEditTextView
import com.dynasty.esports.utils.CLCheckBox
import com.dynasty.esports.utils.CMButtonView
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.viewmodel.CommonViewModel
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.material.button.MaterialButton
import com.google.firebase.iid.FirebaseInstanceId
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this is base calls of all activitys and in this call manage common things which need in more than one activity.
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

open class BaseActivity : AppCompatActivity(){
    val sharedPreferences: SharedPreferences by inject()
 //   val commonViewModel: CommonViewModel by viewModel()
    private lateinit var progressDialog: Dialog
  //  val localizationDelegate = LocalizationApplicationDelegate()

    private var connectivityReceiver = ConnectivityReceiver()
    var notification: String? = null
    var fcmtitle: String? = null
    var fcmdesc: String? = null
    var token: String? = null
    var finalToken : String? = null
    var countryID: String? = null
    var showPassword = false
    var alertDialog:AlertDialog?=null
    var isPhoneSignIn:Boolean=false
    var isCheckBoxchecked:Boolean=false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        getFCMToken()
        getIntentData()
        if(notification == "foreground"){
            displayCustomAlertDialog(fcmtitle!!,fcmdesc!!,isCancelable = false,positiveText = resources.getString(R.string.btn_ok),positiveClick = {
                it.dismiss()
                finish()
            })
        }else{
            showProgressDialog()
        }
//        showProgressDialog()
    }

    open fun checkSignInFieldsForEmptyValues(
        signinCountryCode: CEditTextView?,
        phoneNos: CEditTextView,
        password: CEditTextView,
        phoneSignin_continue: CMButtonView,
        phoneSignIn: Boolean
    ) {
        val b: CMButtonView = phoneSignin_continue
        var s1: String? = null
        val s2: String = phoneNos.getText().toString()
        val s3: String = password.getText().toString()

        if(phoneSignIn) {
            s1 = signinCountryCode?.getText().toString()
            if (s1 == "" || s2 == "" || s3 == "") {
                markButtonEnable(false, b)
            } else {
                markButtonEnable(true, b)
            }
        }else{
            if ( s2 == "" || s3 == "") {
                markButtonEnable(false, b)
            } else {
                markButtonEnable(true, b)
            }
        }
    }

    open fun checkRegisterFieldsForEmptyValues(
        signinCountryCode: CEditTextView?,
        phoneNos: CEditTextView,
        password: CEditTextView,
        phoneSignin_continue: CMButtonView,
        checkbox : Boolean,
        phoneSignIn: Boolean
    ) {
        val b: CMButtonView = phoneSignin_continue
        var s1: String? = null
        val s2: String = phoneNos.getText().toString()
        val s3: String = password.getText().toString()
        val c1: Boolean = checkbox

        if(phoneSignIn) {
            s1 = signinCountryCode?.getText().toString()
            if (s1 != "" && s2 != "" && s3 != "" && c1 == true) {
                markButtonEnable(true, b)
            } else {
                markButtonEnable(false, b)
            }
        }else{
            if ( c1 == true && s2 != "" && s3 != "") {
                markButtonEnable(true, b)
            } else {
                markButtonEnable(false, b)
            }
        }
    }

    fun markButtonEnable(booleanVal: Boolean, loginButton : CMButtonView) {
        loginButton.isEnabled = booleanVal
        loginButton.setTextColor(ContextCompat.getColor(this, R.color.white))
        if(booleanVal){
            loginButton.setBackgroundColor(ContextCompat.getColor(this, R.color.colorAccent))
        }else{
            loginButton.setBackgroundColor(ContextCompat.getColor(this, R.color.grey))
        }
    }

    fun EditText.onConfirmDrawableClicked(onClicked: (view: EditText) -> Unit) {
        showPassword = true
        this.setOnTouchListener { v, event ->
            var hasConsumed = false
            if (v is EditText) {
                if (event.x >= v.width - v.totalPaddingRight) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onClicked(this)
                    }
                    hasConsumed = true
                }
            }
            hasConsumed
        }
    }

    fun EditText.onRightDrawableClicked(onClicked: (view: EditText) -> Unit) {
        showPassword = true
        this.setOnTouchListener { v, event ->
            var hasConsumed = false
            if (v is EditText) {
                if (event.x >= v.width - v.totalPaddingRight) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onClicked(this)
                    }
                    hasConsumed = true
                }
            }
            hasConsumed
        }
    }

    override fun attachBaseContext(newBase: Context?) {
        newBase?.apply {
            super.attachBaseContext(LocaleHelper.onAttach(this))
        } ?: super.attachBaseContext(LocaleHelper.onAttach(this))
    }

    /**
     *@desc get data object from notification when app in background
     * @required
     */
    private fun getIntentData() {
        intent.extras?.apply {
            notification = this.getString("notification").toString()
            fcmtitle = this.getString("fcmTitle").toString()
            fcmdesc = this.getString("fcmDesc").toString()
        }
    }


    /**
     *@desc create progress dialog for doing api call or heavy task on main thread
     *@return Dialog
     */
    private fun showProgressDialog(): Dialog {
        progressDialog = Dialog(this)
        progressDialog.setContentView(R.layout.progress_dialog_view)
        progressDialog.setCancelable(false)
        progressDialog.window?.setBackgroundDrawable(ColorDrawable(0))
        return progressDialog
    }
    /**
     *@desc show progress dialog when doing api call or heavy task on main thread
     */
    open fun launchProgressDialog() {
        if (::progressDialog.isInitialized && progressDialog != null && !progressDialog.isShowing)
            progressDialog.show()
    }

    /**
     *@desc Hide progress dialog when doing api call or heavy task on main thread
     */
    fun dismissProgressDialog() {
        if (::progressDialog.isInitialized && progressDialog != null && progressDialog.isShowing) {
            progressDialog.dismiss()
        }
    }

    /**
     *@desc Get country dial code using device configuration
     * *@return String- get country dial code
     */
    fun getBaseCountryDialCode(): String? {
        var countryDialCode: String? = null
        val countryID: String? = resources.configuration.locale.country
        Log.d("Country ", "ssb " +countryID)
        val arrCountryCode =
            this.resources.getStringArray(R.array.DialingCountryCode)
        for (i in arrCountryCode.indices) {
            val arrDial = arrCountryCode[i].split(",".toRegex()).toTypedArray()
            if (arrDial[1].trim { it <= ' ' } == countryID) {
                countryDialCode = arrDial[0]
                break
            }
        }
        if(countryDialCode == null){
            countryDialCode = ""
        }else{
            countryDialCode = "+$countryDialCode"
        }
        return countryDialCode
    }

    /**
     *@desc Get firebase token from Firebase server for register server and Push notification
     */
    private fun getFCMToken() {
        FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("Base ", "getInstanceId failed", task.exception)
                    return@OnCompleteListener
                }
                // Get new Instance ID token
                 token = task.result?.token

                Log.d("Base ", token.toString())
                sharedPreferences.FCMToken = token.toString()
            })
    }


    /**
     *@desc Show country picker dialog
     */
    fun displayCountryCodeDialog() {
        CountryCodePicker.showDialog(supportFragmentManager)
    }

    /**
     *@desc this method will call when user refresh token expired and redirect to user login screen.
     */
    fun logOut() {
        dismissProgressDialog()
        displayCustomAlertDialog(title = resources.getString(R.string.session_expired),
            isCancelable = false,
            positiveText = resources.getString(R.string.btn_ok),
            positiveClick = {
                it.dismiss()
                sharedPreferences.clear()
                sharedPreferences.isAppOpenFirstTime = true
                startActivityInlineWithFinishAll<PhoneSignInActivity>()

            })
    }

    /**
     *@desc Custom Alert dialog for show dialog in the app when need.
     *@param string title - the title to be displayed
     *@param string desc - the desc to be displayed
     *@param bool isCancelable- set dialog is cancelable or not.
     *@param bool isCloseShow- need to show close icon or not.
     *@param bool isButtonShow- need to show cancel button or not.
     *@param String positiveText- positive text to be displayed
     *@param Unit positiveClick- assign positive button click
     *@param String negativeText- negative text to be displayed
     *@param Unit onCloseClick- assign Close icon click
     *
     */
    fun displayCustomAlertDialog(
        title: String = "",
        desc: String = "",
        isCancelable: Boolean = true,
        isCloseShow: Boolean = false,
        isButtonShow: Boolean = true,
        positiveText: String = "",
        positiveClick: (Dialog) -> Unit = { _ -> },
        negativeText: String? = "",
        negativeClick: (Dialog) -> Unit = { _ -> },
        onCloseClick: (Dialog) -> Unit = { _ -> }
    ) {
        val alertLayout: View = layoutInflater.inflate(R.layout.custom_dialog_view, null)
        val textViewTitle: TextView = alertLayout.findViewById(R.id.textViewTitle)
        val textViewDesc: TextView = alertLayout.findViewById(R.id.textViewDescription)
        val buttonPositive: MaterialButton = alertLayout.findViewById(R.id.buttonPositive)
        val buttonNegative: MaterialButton = alertLayout.findViewById(R.id.buttonNegative)
        val constraintLayoutButton: ConstraintLayout =
            alertLayout.findViewById(R.id.constraintLayoutButton)
        val imageViewClose: ImageView = alertLayout.findViewById(R.id.imageViewClose)

        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("")
        alertDialogBuilder.setView(alertLayout)
        alertDialogBuilder.setCancelable(isCancelable)
        alertDialog?.apply {
            if(this.isShowing){
                return
            }
        }
        alertDialog = alertDialogBuilder.create()
        if (title == "") {
            textViewTitle.beGone()
        } else {
            textViewTitle.beVisible()
        }

        if (isCloseShow) {
            imageViewClose.beVisible()
        }

        if (isButtonShow) {
            constraintLayoutButton.beVisible()
        } else {
            constraintLayoutButton.beGone()
        }

        if (positiveText == "") {
            buttonPositive.beGone()
        }
        if (negativeText == "") {
            buttonNegative.beGone()
        }

        buttonNegative.text = negativeText
        buttonPositive.text = positiveText
        textViewTitle.text = title
        textViewDesc.text = desc

        buttonPositive.click {
            positiveClick(alertDialog!!)
        }
        buttonNegative.click {
            negativeClick(alertDialog!!)
        }

        if (desc == "") {
            textViewDesc.beInVisible()
        } else {
            textViewDesc.beVisible()
        }

        imageViewClose.click {
            onCloseClick(alertDialog!!)
        }
        alertDialog?.apply {
            this.show()
        }


    }

    fun openUrlFromIntent() {
        val url: String = if (LocaleHelper.getLanguage(this) == "en") {
            " http://stc-1237359093.me-south-1.elb.amazonaws.com/privacy-policy"
        } else {
            " http://stc-1237359093.me-south-1.elb.amazonaws.com/privacy-policy"
        }
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(url)
        startActivity(intent)
    }




//    override fun onResume() {
//        super.onResume()
//        registerReceiver(connectivityReceiver, IntentFilter(AppConstants.CONNECTION_ACTION))
//        ConnectivityReceiver.connectivityReceiverListener = this
//    }
//
//    override fun onPause() {
//        super.onPause()
//        ConnectivityReceiver.connectivityReceiverListener?.apply {
//            unregisterReceiver(connectivityReceiver)
//        }
//    }

}