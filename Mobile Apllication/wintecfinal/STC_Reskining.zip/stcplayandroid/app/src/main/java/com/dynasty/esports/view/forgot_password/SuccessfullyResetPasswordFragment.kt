package com.dynasty.esports.view.forgot_password

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.dynasty.esports.R
import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.forgot_password.ForgotPasswordMobileActivity
import com.dynasty.esports.view.forgot_password.ForgotPasswordPageFragment
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity

class SuccessfullyResetPasswordFragment : ForgotPasswordPageFragment() {

    var mRequest: ForgotPasswordRequest? = null


    fun displayReceivedData(message: ForgotPasswordRequest) {
//        txtData.setText("Data received: $message")
        Log.d("Data Received : ","yipeee " + message.toString() + " forgotpass 3 data")
        mRequest!!.phoneNumber =  message.phoneNumber
        mRequest!!.type = message.type
        mRequest!!.phoneOTP = message.phoneOTP
        mRequest!!.emailOTP = message.emailOTP
        mRequest!!.email = message.email
        mRequest!!.password = message.password
    }

    override fun getPageType(): ForgotPasswordMobileActivity.ForgotPasswordWizardPageType {
        return ForgotPasswordMobileActivity.ForgotPasswordWizardPageType.SUCCEFUL_RESET
    }

    override fun onNextButtonClick() {
        requireActivity().finish()
//        val intent = Intent(context, PhoneSignInActivity::class.java)
//        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//        startActivity(intent)
    }

    override fun shouldEnableButton(): Boolean {
        TODO("Not yet implemented")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_successfully_reset_password, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = SuccessfullyResetPasswordFragment()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenToViewModel()
     initialise()
    }

    private fun listenToViewModel() {

    }

    private fun initialise() {
        mRequest = ForgotPasswordRequest()
    }
}