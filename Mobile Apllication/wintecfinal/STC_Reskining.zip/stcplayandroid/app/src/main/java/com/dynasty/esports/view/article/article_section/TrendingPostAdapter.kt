package com.dynasty.esports.view.article.article_section


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.RowArticlePostBinding
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.extenstion.loadThumbnailImageFromServer
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.LoadingViewHolder

/**
 * @desc this is class will handle Trending Post article
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class TrendingPostAdapter constructor(
    private var articleList: MutableList<HottestPostArticleModel.DataModel>,
    private val onItemClick: (String) -> Unit = { _ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindingHolder<RowArticlePostBinding> {
//        val binding: RowArticlePostBinding = DataBindingUtil.inflate(
//            LayoutInflater.from(parent.context),
//            R.layout.row_article_post,
//            parent,
//            false
//        )
//        return BindingHolder(binding)
//
//    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: RowArticlePostBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.row_article_post,
                        parent,
                        false
                    )
                return ViewHolderArticle(binding)
            }
            else -> {
                val binding: ItemLoadMoreBinding =
                    DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
                return LoadingViewHolder(binding)
            }

        }
    }

    /**
     * @desc trending post array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return articleList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (articleList[position].isLoadMore) {
            1
        } else {
            0
        }
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderArticle).bind(articleList[position])
            }
            else -> {
                (holder as LoadingViewHolder).progressBar.isIndeterminate = true
            }
        }
    }

    /**
     *@desc This call use for display Video data
     */
    inner class ViewHolderArticle(private var binding: RowArticlePostBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: HottestPostArticleModel.DataModel) {
            data.authorDetails?.apply {
                binding.textViewUserName.text = this.fullName?.let {
                    it
                } ?: "-"


                this.profilePicture?.apply {
                    itemView.context.loadThumbnailImageFromServer(this, binding.imageViewUser)
                }

            }
            binding.textViewDateTitle.text = data.game?.let {
                it.plus(" | ").plus(
                    data.createdDate.toString().convertDateToRequireDateFormat(
                        AppConstants.API_DATE_FORMAT,
                        AppConstants.APP_DATE_FORMAT
                    )
                )
            }

            if (LocaleHelper.getLanguage(binding.root.context) == "en") {
                binding.textViewAbout.text = data.title?.english?.let { it } ?: ""
            } else {
                binding.textViewAbout.text =
                    if (data.title?.malay.isNullOrEmpty()) data.title?.english?.let { it }
                        ?: "" else data.title?.malay?.let { it } ?: ""
            }


            data.image?.apply {
                itemView.context.loadImageFromServer(this, binding.imageViewBackground)
            }

            binding.topcardview.setOnClickListener {
                onItemClick(data.id!!)
            }
        }

    }


}