package com.dynasty.esports.models

import android.graphics.drawable.Drawable


data class TournamentTypeSpinnerImageItems (
    val icon: Drawable?,
    val text: String
)