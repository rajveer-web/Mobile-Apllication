package com.dynasty.esports.view.signup.email

import android.content.Intent
import android.os.Bundle
import android.text.*
import android.text.style.ClickableSpan
import android.view.View
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.SocialLoginActivity
import com.dynasty.esports.view.forgot_password.ForgotPasswordMobileActivity
import com.dynasty.esports.view.signin.email.EmailSignInActivity
import com.dynasty.esports.view.signup.password.CreatePasswordActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.SignUpViewModel
import kotlinx.android.synthetic.main.activity_email_registration.*
import kotlinx.android.synthetic.main.content_email_registration_screen.*
import kotlinx.android.synthetic.main.content_email_registration_screen.social_login_fb
import kotlinx.android.synthetic.main.content_email_registration_screen.social_login_gPlus
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class EmailRegistrationActivity : SocialLoginActivity() {
    private val mViewModel: SignUpViewModel by viewModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_email_registration)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        initialize()
//        initialiseSocialLogin()
        listenToViewModel()
    }


    var mTextWatcher: TextWatcher = object : TextWatcher {
        override fun beforeTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun onTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun afterTextChanged(editable: Editable) {
            // check Fields For Empty Values
            checkRegisterFieldsForEmptyValues(
                null,
                signup_email,
                nickname,
                signup_continue,
                checkBox1.isChecked,
                isPhoneSignIn
            )
        }
    }

    // initialise the view
    private fun initialize() {

        /*signup_email.addTextChangedListener(mTextWatcher);
        nickname.addTextChangedListener(mTextWatcher);
        checkBox1.click {
            checkRegisterFieldsForEmptyValues(null, signup_email, nickname, signup_continue, checkBox1.isChecked, false);
        }*/


        checkboxTxt.makeSpannableString(this,resources.getString(R.string.privacy_policy),
            if(LocaleHelper.getLanguage(this@EmailRegistrationActivity)=="en"){1}else{5},
            resources.getString(R.string.privacy_policy).length,
            object : ClickableSpan(){
                override fun onClick(widget: View) {
                    widget.cancelPendingInputEvents()
                    openUrlFromIntent()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            },true)

        emailSignUpbottom_view.makeSpannableString(
            this,
            resources.getString(R.string.already_have_acct),
            if(LocaleHelper.getLanguage(this@EmailRegistrationActivity)=="en"){25}else{23},
            resources.getString(R.string.already_have_acct).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    startActivityInline<EmailSignInActivity>(finish = true)
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })

        social_login_fb.click {
            mViewModel.fbLoginClick()
        }

        social_login_gPlus.click {
            mViewModel.googleLoginClick()
        }

        signup_continue.click {
            mViewModel.onValidationForEmailRegistration(
                nickname.text.toString().trim(),
                signup_email.text.toString().trim(),
                checkBox1.isChecked
            )
        }

        signup_phone_num.click {
            startActivityInline<PhoneNumRegistrationActivity>(finish = false)
//            startActivityInlineWithFinishAll<PhoneNumRegistrationActivity>()
//            startActivityInline<PhoneNumRegistrationActivity>()
        }

    }

    // to listen view model and manage the api
    private fun listenToViewModel() {
        mViewModel.fbLoginObserver.observe(this, Observer {
            fbLogin()
        })
        mViewModel.googleLoginObserver.observe(this, Observer {
            googleLogin()
        })

        mViewModel.validationLiveData.observe(this, Observer {
            when (it) {
                0 -> {
                    makeSnackBar(
                        constraintLayoutSignUpEmail,
                        resources.getString(R.string.nickname_error)
                    )
                }
                1 -> {
                    makeSnackBar(
                        constraintLayoutSignUpEmail,
                        resources.getString(R.string.email_error))
                }
                2 -> {
                    makeSnackBar(
                        constraintLayoutSignUpEmail,
                        resources.getString(R.string.email_valid_error)
                    )
                }
                3 -> {
                    makeSnackBar(
                        constraintLayoutSignUpEmail,
                        resources.getString(R.string.policy_error)
                    )
                }
            }
        })

        mViewModel.isRegistrationFormValid.observe(this, Observer {
            val bundle=Bundle()
            bundle.putString("fullname",nickname.text.toString().trim())
            bundle.putString("email",signup_email.text.toString().trim())
            bundle.putString("type","email")
            startActivityInline<CreatePasswordActivity>(bundle = bundle)
        })

    }

//    private fun emailSignUpContinue() {
//        val nickname: String = nickname.text.toString()
//        val email: String = signup_email.text.toString()
//        val isValidEmailTxt: Boolean = Validator.isValidEmail(email, true)
//        val isValidNicknameTxt: Boolean = Validator.isValidName(nickname, true)
//
//        //Checkbox condition needds to be handed
//        if (isValidNicknameTxt) {
//            signup_email.setError("erwer")
//        }
//
//        if (isValidNicknameTxt && isValidEmailTxt && checkBox1.isChecked) {
//            //If both fields are valid you can go to Create password screen with data
//
//        } else {
//            Toast.makeText(this, "Please fill the data", Toast.LENGTH_LONG).show()
//        }
//    }

    override fun redirectToDashBoard(isRedirect: Boolean) {
        if (isRedirect) {
//            startActivityInlineWithFinishAll<DashboardActivity>()
            val bundle=Bundle()
            bundle.putString("type",redirectType)
            val intent=Intent(AppConstants.NOTIFY_ACTION)
            intent.putExtras(bundle)
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
            killAllActivities()
        }
    }

    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }


}