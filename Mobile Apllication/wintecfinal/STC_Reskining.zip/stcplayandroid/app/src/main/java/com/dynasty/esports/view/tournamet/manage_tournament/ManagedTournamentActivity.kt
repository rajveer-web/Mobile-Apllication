package com.dynasty.esports.view.tournamet.manage_tournament

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ManageTournamentModel
import com.dynasty.esports.models.TournamentOptionModel
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.view.tournamet.TournamentOptionAdapter
import com.dynasty.esports.view.tournamet.manage_tournament.disucssion.DiscussionTournamentFragment
import com.dynasty.esports.view.tournamet.manage_tournament.match.GamePadTournamentFragment
import com.dynasty.esports.view.tournamet.manage_tournament.participants.ParticipantsFragment
import com.dynasty.esports.view.tournamet.manage_tournament.seed.SeedFragment
import com.dynasty.esports.view.tournamet.manage_tournament.stream.StreamTournamentFragment
import com.dynasty.esports.viewmodel.ManagedTournamentViewModel
import com.google.android.material.appbar.AppBarLayout
import kotlinx.android.synthetic.main.activity_managed_tournament.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ManagedTournamentActivity : BaseActivity(), ManageRedirectReceiver.NotifyActivityListener {
    private lateinit var tournamentOptionAdapter: TournamentOptionAdapter
    private var id: String = ""
    private var manageRedirectReceiver = ManageRedirectReceiver()
    private var gameID: String = ""
    val mViewModel: ManagedTournamentViewModel by viewModel()
    private var checkInTeamCounter: Int = 0
    private var registerTeamCounter: Int = 0
    private var streamList: MutableList<ManageTournamentModel.StreamModel> = mutableListOf()
    private val tournamentOptionList: MutableList<TournamentOptionModel> = mutableListOf()
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
    private var pos: Int = -2
    private var commonPagerAdapter: CommonPagerAdapter? = null
    private var title: String = ""
    private var type: String = ""
    private var isSeedDone: Boolean = false
    var participantsLimit = 0
    private var isValidDateAndTime: Boolean = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_managed_tournament)
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
        getIntentData()
        initView()
        viewClickListener()
        listenToViewModel()
    }

    private fun viewClickListener() {
        if (type == "upcoming") {
            imageViewEdit.beVisible()
        }

        imageViewEdit.click {
            tournamentOptionAdapter.updateSelection(-1)
            constraintLayoutEditTournament.beVisible()
        }

        buttonCancel.click {
            tournamentOptionAdapter.updateSelection(pos)
            constraintLayoutEditTournament.beGone()
        }

        buttonSave.click {
            mViewModel.checkFormValidation(
                editTextTournamentName.text.toString().trim(),
                editTextPickDate.text.toString().trim(),
                editTextPickTime.text.toString().trim(),
                editTextParticipantLimit.text.toString().trim().toInt(),
                isValidDateAndTime
            )
        }

        getDate(editTextPickDate, AppConstants.DD_MM_YYYY_FORMAT, updateTextValue = {
            if (!editTextPickDate.text.isNullOrEmpty()) {
                if (!it.plus(" ").plus(editTextPickTime.text.toString())
                        .isCurrentDateBiggerThanAPIDateTime(AppConstants.DD_MM_YYYY_HH_MM_FORMAT)
                ) {
                    isValidDateAndTime = true
                    editTextPickDate.setText(it)
                } else {
                    isValidDateAndTime = false
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.select_valid_date)
                    )
                }
            } else {
                isValidDateAndTime = false
                makeSnackBar(
                    coordinatorManageTournament,
                    resources.getString(R.string.select_valid_date)
                )
            }
        })

        getTime(editTextPickTime, AppConstants.TIME_FORMAT_API, false, updateTextValue = {
            if (!editTextPickDate.text.isNullOrEmpty()) {
                if (!editTextPickDate.text.toString().plus(" ").plus(it)
                        .isCurrentDateBiggerThanAPIDateTime(AppConstants.DD_MM_YYYY_HH_MM_FORMAT)
                ) {
                    editTextPickTime.setText(it)
                    isValidDateAndTime = true
                } else {
                    isValidDateAndTime = false
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.select_valid_date)
                    )
                }
            } else {
                isValidDateAndTime = false
                makeSnackBar(
                    coordinatorManageTournament,
                    resources.getString(R.string.select_valid_date)
                )
            }
        })
    }

    private fun getIntentData() {
        intent.extras?.apply {
            id = this.getString("id").toString()
            type = this.getString("type").toString()
        }
    }

    private fun initView() {
        tournamentOptionList.clear()

        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_participate))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_seed))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_games))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_live_tv_black_18dp))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_message))

        recyclerViewOption.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tournamentOptionAdapter =
            TournamentOptionAdapter(tournamentOptionList, onItemClick = ::onItemClick)
        recyclerViewOption.adapter = tournamentOptionAdapter


        mViewModel.makeJsonForGetTournament(id, true)

        appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                kotlin.math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbar.title = title
                }
                else -> {
                    collapsingToolbar.title = ""
                    // Expanded
                }
            }
        })
    }

    private fun makeFragmentList(bracketType: String?) {
        fragmentList.clear()

        fragmentList.add(
            Pair(
                ParticipantsFragment.newInstance(id, bracketType.toString(), type),
                ""
            )
        )
        fragmentList.add(
            Pair(
                SeedFragment.newInstance(id, type, isSeedDone),
                ""
            )
        )
        fragmentList.add(
            Pair(
                GamePadTournamentFragment.newInstance(id, type),
                ""
            )
        )
        fragmentList.add(
            Pair(
                StreamTournamentFragment.newInstance(id, streamList, type), ""
            )
        )
        fragmentList.add(
            Pair(
                DiscussionTournamentFragment.newInstance(id, gameID, type), ""
            )
        )

        viewPagerTournament.isSaveEnabled = false
        commonPagerAdapter = CommonPagerAdapter(fragmentList, supportFragmentManager)
        viewPagerTournament.adapter = commonPagerAdapter



        viewPagerTournament.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                pos = position
                tournamentOptionAdapter.updateSelection(position)
                recyclerViewOption.smoothScrollToPosition(position)
            }

            override fun onPageScrollStateChanged(state: Int) {

            }

        })
    }

    private fun onItemClick(position: Int) {
        commonPagerAdapter?.apply {
            constraintLayoutEditTournament.beGone()
            viewPagerTournament.currentItem = position
            pos = position
            tournamentOptionAdapter.updateSelection(position)
        }
    }

    private fun listenToViewModel() {
        mViewModel.validationLiveData.observe(this, {
            when (it) {
                0 -> {
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.tournament_name_error)
                    )
                }
                1 -> {
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.tournament_select_tournament_date)
                    )
                }
                2 -> {
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.tournament_select_tournament_time)
                    )
                }
                3 -> {
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.part_number_not_valid)
                    )
                }
                4 -> {
                    makeSnackBar(
                        coordinatorManageTournament,
                        resources.getString(R.string.select_valid_date)
                    )
                }
            }
        })

        mViewModel.isFormValid.observe(this, {
            if (it) {
                launchProgressDialog()

                val dateTime = mergeDateAndTime(
                    editTextPickDate.text.toString().trim().convertDateToRequireDateFormat(
                        AppConstants.DD_MM_YYYY_FORMAT,
                        AppConstants.YYYY_MM_DD_FORMAT_API
                    ).plus('T')
                        .plus(editTextPickTime.text.toString().trim()),
                    AppConstants.YYYY_MM_DD_T_HH_MM_FORMAT
                )

                mViewModel.makeJsonForUpdateTournament(
                    editTextTournamentName.text.toString().trim(),
                    editTextParticipantLimit.text.toString().trim(),
                    dateTime,
                    editTextPickTime.text.toString().trim()
                )
            }
        })

        mViewModel.jsonObjectForUpdateTournament.observe(this, {
            mViewModel.updateTournamentDetail(id, it)
        })

        mViewModel.tournamentUpdateSuccessResponse.observe(this, {
            mViewModel.makeJsonForGetTournament(id, true)
            if (type == "past") {
                val bundle = Bundle()
                bundle.putString("type", type)
                val intent = Intent(AppConstants.NOTIFY_ACTION)
                intent.putExtras(bundle)
                LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
            }
        })

        mViewModel.tournamentUpdateErrorResponse.observe(this, {
            dismissProgressDialog()
        })

        mViewModel.jsonObjectForGetTournament.observe(this, {
            mViewModel.getTournamentDetails(
                it.first.first.toString(),
                it.first.second.toString(),
                it.second.first.toString(),
                "",
                "",
                it.second.second.toString()
            )
        })

        mViewModel.tournamentRegisterTeamSuccessResponse.observe(this, {
            it.data?.apply {
                registerTeamCounter = this.size
            }
        })
        mViewModel.tournamentCheckInSuccessResponse.observe(this, {
            it.data?.apply {
                checkInTeamCounter = this.size
            }
        })

//        mViewModel.tournamentCheckInErrorResponse.observe(this, Observer {
//
//        })

        mViewModel.tournamentDetailSuccessResponse.observe(this, {
            dismissProgressDialog()
            it?.apply {
                this.data?.apply {
                    if (this.isNotEmpty())
                        updateTournamentUI(this[0])
                }
            }
        })

        mViewModel.tournamentDetailErrorResponse.observe(this, {
            dismissProgressDialog()
        })

        mViewModel.noInternetException.observe(this, {
            when (it) {
                "detail" -> {

                }
            }
        })
    }

    private fun updateTournamentUI(dataModel: ManageTournamentModel.DataModel) {
        dataModel.apply {
            streamList.clear()

            this.stream?.apply {
                streamList.addAll(this)
            }
            this.gameDetail?.apply {
                gameID = this._id
            }


            this.isSeeded?.apply {
                isSeedDone = this
            }


            this.name?.apply {
                title = this
                textViewTitle.text = this
                editTextTournamentName.setText(this)
            }

            this.url?.apply {
                textViewTournamentURL.text = this
            }

            this.banner?.apply {
                this@ManagedTournamentActivity.loadImageFromServer(this, imageViewBanner)
            }

            this.organizerDetail?.apply {
                textViewOrganisedBy.text = this.fullName
            }

            this.participantType?.apply {

                if (this == "individual") {
                    textViewType.text = resources.getString(R.string.one_vs_one)
                } else {
                    textViewType.text = resources.getString(R.string.team)
                }

                textViewTeamSize.text = this.let {
                    if (it == "individual") {
                        resources.getString(R.string.one_vs_one)
                    } else {
                        resources.getString(R.string.team_vs_team)
                    }
                }
            }
            this.startDate?.apply {
                editTextPickDate.setText(
                    this.convertDateToRequireDateFormat(
                        AppConstants.API_DATE_FORMAT,
                        AppConstants.DD_MM_YYYY_FORMAT
                    )
                )

            }


            this.startTime?.apply {
                editTextPickTime.setText(this)
            }

            this.maxParticipants?.apply {
                participantsLimit = this
                editTextParticipantLimit.setText(this.toString())
            }


            textViewDate.text = this.startDate?.let {

                this.isFinished?.apply {
                    if (this) {
                        textViewStartTimeGame.text =
                            resources.getString(R.string.start_in).plus("\n")
                                .plus(resources.getString(R.string.tournament_concluded))
                    } else {
                        when (type.toLowerCase()) {
                            "upcoming" -> {
                                if (it.getLeftTime(AppConstants.API_DATE_FORMAT).toInt() == 0) {
                                    this@ManagedTournamentActivity.countDownTimer(
                                        it,
                                        AppConstants.API_DATE_FORMAT,
                                        textViewStartTimeGame, type
                                    )
                                } else {
                                    textViewStartTimeGame.text =
                                        resources.getText(R.string.start_in).toString().plus(":\n")
                                            .plus(
                                                it.getLeftTime(AppConstants.API_DATE_FORMAT).toInt()
                                                    .toString().plus(" ").plus(
                                                        resources.getString(
                                                            R.string.days_left
                                                        )
                                                    )
                                            )

                                }
                            }
                            "past" -> {
                                imageViewEdit.beVisible()
                                textViewStartTimeGame.text =
                                    resources.getText(R.string.start_in).toString().plus(":\n")
                                        .plus(resources.getString(R.string.tournament_expired))
                            }
                            else -> {
                                textViewStartTimeGame.text =
                                    resources.getText(R.string.start_in).toString().plus(":\n")
                                        .plus(resources.getString(R.string.tournament_started))
                            }
                        }
                    }
                }


//                dateTimeTimer = it.convertDateToRequireDateFormat(AppConstants.API_DATE_FORMAT, "yyyy-MM-dd").plus(" ").plus(this.startTime)
//                if (this.startTime.toString().split(":")[0] > 12.toString()) {
//                    is24Hours = true
//                }

                it.convertDateToRequireDateFormat(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.APP_DATE_FORMAT
                )

            } ?: "-"
//            this@ManagedTournamentActivity.countDownTimer(
//                dateTimeTimer,
//                if (is24Hours) AppConstants.DATE_AND_TIME_24 else AppConstants.DATE_AND_TIME,
//                textViewStartTimeGame)

            textViewStartTime.text =
                this.startTime?.let { resources.getString(R.string.starts).plus(" : ").plus(it) }
                    ?: "-"
            textViewRegistrationTeams.text =
                registerTeamCounter.toString().plus("/").plus(this.maxParticipants)
            textViewCheckedTeams.text =
                checkInTeamCounter.toString().plus("/").plus(registerTeamCounter)


            textViewOrganisedName.text = this.organizerDetail?.fullName?.let {
                resources.getString(R.string.organized_by).plus(": ").plus(it)
            } ?: "-"

            textViewElimination.text = this.maxParticipants?.let {
                it.toString().plus(" ").plus(resources.getString(R.string.players)).plus(" ")
                    .plus(this.bracketType).plus(" ")
                    .plus(resources.getString(R.string.elimination))
            } ?: "-"
        }
        constraintLayoutEditTournament.beGone()
        if (pos != -2) {
            tournamentOptionAdapter.updateSelection(0)
            viewPagerTournament.currentItem = 0
        }

        makeFragmentList(dataModel.participantType)
    }

//    private fun replaceFragment(fragment: Fragment) {
//        val transaction = supportFragmentManager.beginTransaction()
//        transaction.replace(R.id.frameLayoutTournament, fragment)
//        transaction.commit()
//    }

    // Prevent to API call from view model
    override fun onDestroy() {
        super.onDestroy()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(this@ManagedTournamentActivity)
                .unregisterReceiver(this)
        }
    }

    override fun onNotify(notifyType: String) {
        if (notifyType == "reload") {
            initView()
        }
    }

}