package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class LeaderBoardViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val fetchLeaderBoardSuccessResponse = MutableLiveData<UserLeaderBoardProfileModel>()
    val fetchLeaderBoardErrorResponse = MutableLiveData<ResponseBody>()

    val fetchLeaderBoardByGameSuccessResponse = MutableLiveData<LeaderboardByGameModel>()
    val fetchLeaderBoardByGameErrorResponse = MutableLiveData<ResponseBody>()

    val gameListSuccessResponse = MutableLiveData<TournamentGameRes>()
    val gameListErrorResponse = MutableLiveData<ResponseBody>()

    fun fetchLeaderBoardUserDetail(id:String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getLeaderboardUserDetails(id)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchLeaderBoardSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchLeaderBoardErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun fetchLeaderBoardByGame(gameId: String,page: Int,
                               limit: Int) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getLeaderboardByGame(gameId,page,limit)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchLeaderBoardByGameSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchLeaderBoardByGameErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun getGameList() {
        viewModelScope.launch(apiException("gameList") + Dispatchers.Main) {
            val response = restInterface.getTournamentGameList()

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gameListSuccessResponse.postValue(response.body())
                }
                else -> {
                    gameListErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * Clears the [ViewModel] when the [ArticlesFragment] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}