package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import com.dynasty.esports.retrofit.RestInterface

class OnBoardingViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {

    val skipClickObserver=MutableLiveData<Boolean>()
    val nextClickObserver=MutableLiveData<Boolean>()


    fun skipClick() {
        skipClickObserver.postValue(true)
    }

    fun nextClick() {
        nextClickObserver.postValue(true)
    }




//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
