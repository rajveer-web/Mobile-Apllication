package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class CheckedInTournamentModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    @SerializedName("totals")
    @Expose
     val totals: TotalsModel? = null

    class DataModel{
        @SerializedName("_id")
        @Expose
         val id: String? = null
    }

}