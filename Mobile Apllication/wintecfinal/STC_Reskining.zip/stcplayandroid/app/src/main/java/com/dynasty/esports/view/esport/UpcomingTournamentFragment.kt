package com.dynasty.esports.view.esport

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CommonErrorRes
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.models.TournamentListRes
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamentDetailActivity
import com.dynasty.esports.viewmodel.UpcomingTournamentViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mugen.Mugen
import com.mugen.MugenCallbacks
import com.mugen.attachers.RecyclerViewAttacher
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will use for upcoming tournament
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class UpcomingTournamentFragment : BaseFragment() {

    private val mViewModel: UpcomingTournamentViewModel by viewModel()
    private lateinit var upcomingAdapter: UpcomingAdapter
    private var createdTournamentList: MutableList<CreatedTournamentFullModel.Doc> = mutableListOf()
    private var pageNo = 0
    private var limit = 10
    var isRunning = false
    lateinit var endlessList: RecyclerViewAttacher

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_upcoming_tournament, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
        initEndlessList()
    }

    /**
     * @desc method will initialize endless recyclerview to commonRecyclerView for pagination
     */
    private fun initEndlessList() {
        endlessList = Mugen.with(commonRecyclerView, object : MugenCallbacks {
            override fun onLoadMore() {
                if (endlessList.isLoadMoreEnabled) {
                    callUpcomingTournamentAPI(false)
                }
            }

            override fun isLoading(): Boolean {
                return isRunning
            }

            override fun hasLoadedAllItems(): Boolean {
                return false
            }
        })

        endlessList.start()
        endlessList.loadMoreOffset = 3
        endlessList.isLoadMoreEnabled = true
    }

    /**
     * @desc listen observer and receive the events
     * Also, Manage success and failure responces from API, Internet and un authorization.
     */
    private fun listenToViewModel() {
//        //      call UpcomingTournament api
//        mViewModel.jsonObjectForUpcomingTournament.observe(viewLifecycleOwner, Observer {
//            mViewModel.fetchUpcomingTournament(
//                it.first.toString(),
//                it.second.toString(),
//                "type"
//            )
//        })

//      get UpcomingTournament data from api success responce
        mViewModel.fetchUpcomingTournamentSuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beVisible()

            upcomingAdapter.setShowloader_(false)
            dismissProgressDialog()

            debugE("fetchSuccessResponse", Gson().toJson(it))

            if (!it.data!!.hasNextPage) {
                endlessList.isLoadMoreEnabled = false
            }
            upcomingAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            refreshPlaceHolder()
        })

        //      UpcomingTournament error responce
        mViewModel.fetchUpcomingTournamentErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutNoInternet.beGone()

            try {
                val errorRes: CommonErrorRes = Gson().fromJson(
                    it.string(),
                    object : TypeToken<CommonErrorRes?>() {}.type
                )
                errorRes.err!!.message!!.showToast(requireContext())
            } catch (e: Exception) {
            }
            if (createdTournamentList.isEmpty()) {
                constraintLayoutErrorView.beVisible()
            }

            dismissProgressDialog()
            upcomingAdapter.setShowloader_(false)
            endlessList.isLoadMoreEnabled = false
        })
    }

    companion object {
        fun newInstance(): Fragment {
            val args = Bundle()
            val fragment = UpcomingTournamentFragment()
            fragment.arguments = args
            return fragment
        }
    }

    /**
     * @desc this method is used for initialize views, adapter and recyclerview
     *       call get upcoming tournament api
     */
    fun initialise() {
        upcomingAdapter = UpcomingAdapter(onItemClick = ::onUpcomingClick)
        commonRecyclerView.layoutManager = LinearLayoutManager(requireActivity())
        commonRecyclerView.adapter = upcomingAdapter

        constraintLayoutNoData.beGone()
        constraintLayoutErrorView.beGone()
        constraintLayoutNoInternet.beGone()
        callUpcomingTournamentAPI(true)
    }

    /**
     * @desc method will call when tap on upcomingAdapter item and redirect to TournamentDetailActivity
     *       set isUpcoming value true when click from upcoming tournament and send data in tournamentbject
     */
    private fun onUpcomingClick(position: Int) {
        val item = upcomingAdapter.getItem(position)
        val bundle = Bundle()
        bundle.putString("tournamentId", item.id)
        bundle.putBoolean("isUpcoming", true)
        requireActivity().startActivityInline<TournamentDetailActivity>(
            bundle
        )
    }

    /**
     * @desc make json for upcoming tournament and call get upcoming tournament list api
     * @param pageNo every time add one unit in pageNo for get next page data
     */
    private fun callUpcomingTournamentAPI(showPrimaryLoader: Boolean) {
        pageNo++
        if (showPrimaryLoader) {
            linearLayoutProgressBar.beVisible()
        } else {
            upcomingAdapter.setShowloader_(true)
        }

//        mViewModel.makeJsonForUpcomingTournament(
//            pageNo,
//            limit,
//            false,
//            false
//        )
        mViewModel.fetchUpcomingTournament(
            "0",
            "latest",
            "type", pageNo, limit
        )
    }

    /**
     * @desc refresh view for no data display
     */
    private fun refreshPlaceHolder() {
        if (commonRecyclerView.adapter!!.itemCount > 0) {
            commonRecyclerView.beVisible()
            constraintLayoutNoData.beGone()
        } else {
            commonRecyclerView.beGone()
            constraintLayoutNoData.beVisible()
        }
    }
}