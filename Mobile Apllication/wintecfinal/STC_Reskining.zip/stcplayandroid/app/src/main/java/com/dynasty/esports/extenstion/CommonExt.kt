package com.dynasty.esports.extenstion

import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.text.*
import android.text.format.DateFormat
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.Base64.NO_WRAP
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT
import android.widget.*
import androidx.annotation.RawRes
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.CountriesModel
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.models.StateModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.view.common.SpinnerAdapter
import com.dynasty.esports.view.tournamet.createtournament.SpinnerCallback
import com.dynasty.esports.view.tournamet.createtournament.SpinnerSelAdapter
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.sql.Timestamp
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern


var redirectType: String = ""

val runningActivities: MutableList<Activity> = mutableListOf()

fun killAllActivities() {
    runningActivities.forEach {
        it.finish()
    }
//    for (stackActivity in runningActivities) {
//        if (activitiesToRemove.contains(stackActivity.javaClass)) {
//            stackActivity.finish()
//        }
//    }
}

fun killActivity(activitiesToRemove: Class<*>) {
    for (stackActivity in runningActivities) {
        if (activitiesToRemove == stackActivity.javaClass) {
            stackActivity.finish()
        }
    }
}


/**
 * method will use for gone view
 */
fun View.beGone() {
    if (this.visibility != View.GONE) {
        this.visibility = View.GONE
    }
}

/**
 * method will use for visible view
 */
fun View.beVisible() {
    if (this.visibility != View.VISIBLE) {
        this.visibility = View.VISIBLE
    }
}

/**
 * method will use for invisible view
 */
fun View.beInVisible() {
    if (this.visibility != View.INVISIBLE) {
        this.visibility = View.INVISIBLE
    }
}

/**
 * method will use for email valid or not.
 */
fun String.isEmailValid(): Boolean {
    return Patterns.EMAIL_ADDRESS.matcher(this).matches()
}

/**
 * method will use for data is empty
 */
fun String.isFieldEmpty(): Boolean {
    return TextUtils.isEmpty(this)
}

/**
 * method will use for check 0 contains in number or not
 */
fun String.checkPhoneValid(): Boolean {
    return if(this[0].toString()=="0" && this.length>2){
        this[1].toString()!="5"
    }else{
        this[0].toString()!="5"
    }
}

/**
 * method will use for check 0 contains in number or not
 */
fun String.removeZeroFormNumber(): String {
    return if(this[0].toString()=="0" && this.length>2){
        this.substring(1)
    }else{
        this
    }
}

/**
 * method will use for data is empty
 */
fun String.removeZero(): Boolean {
    return if(this[0].toString()=="0" && this.length>2){
        this[1].toString()!="5"
    }else{
        this[0].toString()!="5"
    }

}

/**
 * method will use for show tost message
 */
fun String.showToast(context: Context) {
    Toast.makeText(context, this, Toast.LENGTH_LONG).show()
}

/**
 * method will use show keyboard
 */
fun EditText.showSoftKeyboard(context: Context) {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
    imm!!.showSoftInput(this, SHOW_IMPLICIT)
}

/**
 * method will use for show alert dialog
 * @param title - alert dialog title.
 * @param desc - alert dialog description.
 * @param cancelable - make dialog cancelable or not
 * @param positiveText - positive button text
 * @param positiveClick - positive button click callback
 * @param negativeText - negative button text
 * @param negativeClick - negative button click callback
 */
fun Context.displayAlertDialog(
    title: String = "",
    desc: String = "",
    cancelable: Boolean = true,
    positiveText: String = "",
    positiveClick: DialogInterface.OnClickListener? = null,
    negativeText: String? = null,
    negativeClick: DialogInterface.OnClickListener? = null
) {
    val alertDialogBuilder = AlertDialog.Builder(this, R.style.AlertDialogStyle)
        .setTitle(title)
        .setMessage(desc)
        .setCancelable(cancelable)
        .setPositiveButton(positiveText, positiveClick)
        .setNegativeButton(negativeText, negativeClick)

    val alertDialog = alertDialogBuilder.create()

    alertDialog.setOnShowListener {
        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setBackgroundColor(ContextCompat.getColor(this, android.R.color.transparent))
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setBackgroundColor(ContextCompat.getColor(this, android.R.color.transparent))
        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(
                ContextCompat.getColor(
                    this,
                    R.color.article_post_list_bottom_text_background_color
                )
            )
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setTextColor(
                ContextCompat.getColor(
                    this,
                    R.color.article_post_list_bottom_text_background_color
                )
            )
    }
    alertDialog.show()
}

//fun Activity.displayCustomAlertDialog(
//    title: String = "",
//    desc: String = "",
//    cancelable: Boolean = true,
//    isCloseShow: Boolean = false,
//    isButtonShow: Boolean = true,
//    positiveText: String = "",
//    positiveClick: (Dialog) -> Unit = { _ -> },
//    negativeText: String? = null,
//    negativeClick: (Dialog) -> Unit = { _ -> },
//    onCloseClick: (Dialog) -> Unit = { _ -> }
//) {
//
//    val inflater: LayoutInflater = this.layoutInflater
//    val alertLayout: View = inflater.inflate(R.layout.custom_dialog_view, null)
//    val textViewTitle: TextView = alertLayout.findViewById(R.id.textViewTitle)
//    val textViewDesc: TextView = alertLayout.findViewById(R.id.textViewDescription)
//    val buttonPositive: MaterialButton = alertLayout.findViewById(R.id.buttonPositive)
//    val buttonNegative: MaterialButton = alertLayout.findViewById(R.id.buttonNegative)
//    val constraintLayoutButton: ConstraintLayout =
//        alertLayout.findViewById(R.id.constraintLayoutButton)
//    val imageViewClose: ImageView = alertLayout.findViewById(R.id.imageViewClose)
//
//    val alertDialogBuilder = AlertDialog.Builder(this)
//    alertDialogBuilder.setTitle("")
//    alertDialogBuilder.setView(alertLayout)
//    alertDialogBuilder.setCancelable(cancelable)
//    val dialog: AlertDialog = alertDialogBuilder.create()
//    if (title == "") {
//        textViewTitle.beGone()
//    } else {
//        textViewTitle.beVisible()
//    }
//
//    if (isCloseShow) {
//        imageViewClose.beVisible()
//    }
//
//    if (isButtonShow) {
//        constraintLayoutButton.beVisible()
//    } else {
//        constraintLayoutButton.beGone()
//    }
//
//    if (positiveText == "") {
//        buttonPositive.beGone()
//    }
//    if (negativeText == "") {
//        buttonNegative.beGone()
//    }
//
//    buttonNegative.text = negativeText
//    buttonPositive.text = positiveText
//    textViewTitle.text = title
//    textViewDesc.text = desc
//
//    buttonPositive.click {
//        positiveClick(dialog)
//    }
//    buttonNegative.click {
//        negativeClick(dialog)
//    }
//
//    if (desc == "") {
//        textViewDesc.beGone()
//    } else {
//        textViewDesc.beVisible()
//    }
//
//    imageViewClose.click {
//        onCloseClick(dialog)
//    }
//
////    dialog.getButton(AlertDialog.BUTTON_POSITIVE).beGone()
////    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).beGone()
//    dialog.show()
//
//
//}


fun TextView.makeSpannableMultipleString(
    context: Context,
    content: String,
    startIndex: Int,
    lastIndex: Int,
    endStartIndex: Int,
    endEndIndex: Int,
    onClickStartListener: ClickableSpan? = null,
    onClickEndListener: ClickableSpan? = null
) {
    val myString = SpannableString(content)


    //For Click
    myString.setSpan(onClickStartListener, startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    myString.setSpan(
        onClickEndListener,
        endStartIndex,
        endEndIndex,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )

    myString.setSpan(
        ForegroundColorSpan(context.getColorCompat(R.color.colorAccent)),
        startIndex,
        lastIndex,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )

    myString.setSpan(
        ForegroundColorSpan(context.getColorCompat(R.color.colorAccent)),
        endStartIndex,
        endEndIndex,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )


    this.text = myString
    this.highlightColor = Color.TRANSPARENT
    this.movementMethod = LinkMovementMethod.getInstance()


}

/**
 * method will use for make string to spannable and handle spannable text click
 * @param context - activity or fragment context
 * @param content - spannable text
 * @param startIndex - spannable text start index
 * @param lastIndex -spannable text last index
 * @param onClickListener - spannable text click
 */
fun TextView.makeSpannableString(
    context: Context,
    content: String,
    startIndex: Int,
    lastIndex: Int,
    onClickListener: ClickableSpan? = null,
    isPrivacy: Boolean = false
) {
    val myString = SpannableString(content)
    val typeface = context.lightFont()
    myString.setSpan(
        onClickListener,
        startIndex,
        lastIndex,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )

    myString.setSpan(
        StyleSpan(Typeface.NORMAL),
        startIndex,
        lastIndex,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )

    if (isPrivacy) {
        myString.setSpan(
            ForegroundColorSpan(context.getColorCompat(R.color.white)),
            startIndex,
            lastIndex,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
    } else {
        myString.setSpan(
            ForegroundColorSpan(context.getColorCompat(R.color.colorAccent)),
            startIndex,
            lastIndex,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
    }

    this.text = myString
    this.highlightColor = Color.TRANSPARENT
    this.movementMethod = LinkMovementMethod.getInstance()


}

/**
 * method will use for return typeface
 * @param id - font id
 */
fun Context.getFontTypeFace(id: Int): Typeface {
    return ResourcesCompat.getFont(this, id)!!
}

/**
 * method will use load server image in imageView
 * @param url - server image url
 * @param imageView - target imageview
 */
fun Context.loadImageFromServer(url: String, imageView: ImageView) {
    Glide.with(this).load(url).placeholder(R.mipmap.ic_placeholder_new).error(R.mipmap.ic_placeholder_new)
        .into(imageView)
}

/**
 * method will use load server image in imageView
 * @param url - server image url
 * @param imageView - target imageview
 */
fun Context.loadThumbnailImageFromServer(url: String, imageView: ImageView) {
    Glide.with(this).load(url).thumbnail(0.5f).placeholder(R.mipmap.ic_placehoder).error(R.mipmap.ic_placehoder)
        .into(imageView)
}


/**
 * method will return gradient color for post by games background
 */
fun Context.getGradientColor(): GradientDrawable {
    return GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
            ContextCompat.getColor(this, R.color.colorBlue),
            ContextCompat.getColor(this, R.color.colorRed),
            ContextCompat.getColor(this, R.color.colorOrange),
            ContextCompat.getColor(this, R.color.colorYellowLight)
        )
    )
}

/**
 * method will use for convert API dateformat to required dateformat
 * @param dateFormat - api date format
 * @param requiredFormat - required date format
 */
fun String.convertDateToRequireDateFormat(dateFormat: String, requiredFormat: String): String {
    val simpleDateFormat = SimpleDateFormat(dateFormat, Locale.ROOT)
    val simpleDateFormatRequired = SimpleDateFormat(requiredFormat, Locale.ROOT)
    val secondDate = simpleDateFormat.parse(this)
    return simpleDateFormatRequired.format(secondDate!!)
}

//fun getDateFromTimestamp(timestamp: Long) :String {
//    val calendar = Calendar.getInstance(Locale.ROOT)
//    calendar.timeInMillis = timestamp * 1000L
//    return DateFormat.format(AppConstants.API_DATE_FORMAT, calendar).toString()
//}

fun getDateFromTimestamp(time: Long): String {
    val date = Date(time * 1000L) // *1000 is to convert seconds to milliseconds
    val sdf = SimpleDateFormat(AppConstants.API_DATE_FORMAT,Locale.ROOT) // the format of your date
    sdf.timeZone = TimeZone.getTimeZone("UTC")
    return sdf.format(date)
}



fun String.isCurrentDateBiggerThanAPIDateTime(dateFormat: String):Boolean{
    val simpleDateFormat = SimpleDateFormat(dateFormat, Locale.ROOT)
    simpleDateFormat.timeZone = TimeZone.getTimeZone("UTC")

    if(getCurrentDateTimeMilliSec()>simpleDateFormat.parse(this).time){
        return true
    }
    return false
}

/**
 * method will use for convert string to date and time
 * @param dateFormat - date and time format
 */
fun String.getDateTimeFormString(dateFormat: String): Long {
    try {
        val strDateFormat = SimpleDateFormat(dateFormat, Locale.ROOT)
        strDateFormat.timeZone = TimeZone.getTimeZone("UTC")
        return strDateFormat.parse(this)?.time!!
    } catch (e: ParseException) {
        e.printStackTrace()
    }
    return 0
}

/**
 * method will use for count remain time using countdown timer
 * @param dateTime - date and time
 * @param dateFormat - date format
 * @param textViewTime - target textview
 */
fun Context.countDownTimer(
    dateTime: String,
    dateFormat: String,
    textViewTime: TextView,
    type: String = ""
) {

//    val current = Calendar.getInstance()
//    current.timeZone= TimeZone.getDefault()

    val current = getCurrentDateTimeMilliSec()
    val time = dateTime.getDateTimeFormString(dateFormat)


    if (current < time) {
        val newTime = time - current


        val timer = object : CountDownTimer(newTime, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                textViewTime.text =
                    this@countDownTimer.resources.getText(R.string.start_in).toString().plus(":\n")
                        .plus(timeString(millisUntilFinished))
            }

            override fun onFinish() {
                textViewTime.text =
                    this@countDownTimer.resources.getText(R.string.start_in).toString().plus(":\n")
                        .plus(this@countDownTimer.resources.getString(R.string.tournament_started))
            }
        }
        timer.start()
    } else {

        textViewTime.text =
            this@countDownTimer.resources.getText(R.string.start_in).toString().plus(":\n")
                .plus(this@countDownTimer.resources.getString(R.string.tournament_started))
    }


}

/**
 * method will use for convert millisecond time to readable format time
 * @param millisUntilFinished - time in millsecond
 */
private fun timeString(millisUntilFinished: Long): String {
    var millisUntilFinished: Long = millisUntilFinished
//    val days = TimeUnit.MILLISECONDS.toDays(millisUntilFinished)
//    millisUntilFinished -= TimeUnit.DAYS.toMillis(days)

    val hours = TimeUnit.MILLISECONDS.toHours(millisUntilFinished)
    millisUntilFinished -= TimeUnit.HOURS.toMillis(hours)

    val minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)
    millisUntilFinished -= TimeUnit.MINUTES.toMillis(minutes)

    val seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished)

    // Format the string
    return String.format(
        Locale.ROOT,
        "%02d:%02d:%02d",
        hours, minutes, seconds
    )
}

/**
 * method will use for show snackbar
 * @param coordinatorLayout - target parent view.
 * @param message - message which you want show
 *  @param actionText -action name by default empty
 *  @param onClickListener - action click callback.
 */
fun Context.makeSnackBar(
    coordinatorLayout: View,
    message: String,
    actionText: String = "",
    onClickListener: View.OnClickListener? = null

) {
    var snackbar: Snackbar? = null
    if (actionText == "") {
        snackbar = Snackbar.make(coordinatorLayout, message, Snackbar.LENGTH_SHORT)
    } else {
        if (onClickListener != null) {
            snackbar = Snackbar.make(coordinatorLayout, message, Snackbar.LENGTH_INDEFINITE)
                .setAction(actionText, onClickListener)
            snackbar.setActionTextColor(Color.RED)

        }
    }

    snackbar?.let {
        val textViewSnackBar = it.view.findViewById<TextView>(R.id.snackbar_text)

        textViewSnackBar.typeface = this.regularFont()

        it.show()
    }

}

/**
 * method will use for make view click
 */

fun <T : View> T.click(block: (T) -> Unit) = setOnClickListener { block(it as T) }

/**
 * method will use for get color using id
 * @param color - color id
 */

fun Context.getColorCompat(color: Int) = ContextCompat.getColor(this, color)

/**
 * method will use for redirect activity to other activity
 * @param bundle - pass data ib bundle. by default bundle is null
 *  @param finish - if true finish previous activity otherwise only redirect one activity to other activity
 */

inline fun <reified T : Activity> Activity.startActivityInline(
    bundle: Bundle? = null,
    finish: Boolean = false
) {

    startActivity(bundle?.let {
        Intent(this, T::class.java).putExtras(it)
    } ?: Intent(this, T::class.java))



    if (finish) {
        finish()
    }
}

inline fun <reified T : Activity> Activity.startActivityInlineWithAnimation(
    bundle: Bundle? = null,
    finish: Boolean = false,
    resultCode: Int?= null
) {
   if(resultCode!=null) {
        startActivityForResult(bundle?.let {
            Intent(this, T::class.java).putExtras(it)
        } ?: Intent(this, T::class.java),resultCode)
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }else{
       startActivity(bundle?.let {
           Intent(this, T::class.java).putExtras(it)} ?: Intent(this, T::class.java))
   }


    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
//    startActivityForResult(intent, 0)


    if (finish) {
        finish()
    }
}
/**
 * method will use for redirect activity to other activity and finish all previous activity
 * @param bundle - pass data in bundle. by default bundle is null
 */

inline fun <reified T : Activity> Activity.startActivityInlineWithFinishAll(bundle: Bundle? = null) {
    if (bundle != null) {
        startActivity(
            Intent(this.applicationContext, T::class.java)
                .putExtras(bundle).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    } else {
        startActivity(
            Intent(this.applicationContext, T::class.java).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    this.finishAffinity()
}

/**
 * method will use for redirect fragment to other activity and finish all previous activity
 * @param bundle - pass data in bundle. by default bundle is null
 */

inline fun <reified T : Activity> Fragment.startActivityFinishAllFromFragment(bundle: Bundle? = null) {
    if (bundle != null) {
        startActivity(
            Intent(this.requireContext(), T::class.java)
                .putExtras(bundle).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    } else {
        startActivity(
            Intent(this.requireContext(), T::class.java).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    requireActivity().finishAffinity()
}

/**
 * method will use for redirect fragment to other activity without finish previous activity
 * @param bundle - pass data in bundle. by default bundle is null
 */
inline fun <reified T : Activity> Fragment.startActivityFromFragment(
    bundle: Bundle? = null
) {
    if (bundle != null) {
        startActivity(Intent(this.context, T::class.java).putExtras(bundle))
    } else {
        startActivity(Intent(this.context, T::class.java))
    }
}

/**
 * method will use for redirect fragment to other activity with bundle and result code
 * @param bundle - pass data in bundle. by default bundle is null
 * @param resultCode -use fore reload or some expression execute when comeback in current fragment.
 */
inline fun <reified T : Activity> Fragment.startActivityFromFragmentWithBundleCode(
    bundle: Bundle,
    resultCode: Int
) {
    startActivityForResult(Intent(this.context, T::class.java).putExtras(bundle), resultCode)
}

//
//inline fun <reified T : Activity> Activity.startActivityInlineResult(code: Int) {
//    startActivityForResult(Intent(this, T::class.java), code)
//}
//
//inline fun <reified T : Activity> Activity.startActivityWithBundle(
//    bundle: Bundle
//) {
//    startActivity(Intent(this, T::class.java).putExtras(bundle))
//
//}
//
inline fun <reified T : Activity> Activity.startActivityWithBundleResult(
    bundle: Bundle,
    code: Int
) {
    startActivityForResult(Intent(this, T::class.java).putExtras(bundle), code)

}
//
//inline fun <reified T : Activity> Context.startActivityWithAnimation(
//    enterResId: Int = 0,
//    exitResId: Int = 0
//) {
//    val intent = Intent(this, T::class.java)
//    val bundle = ActivityOptionsCompat.makeCustomAnimation(this, enterResId, exitResId).toBundle()
//    ContextCompat.startActivity(this, intent, bundle)
//}
//
/**
 * method will use for check internet available or not.
 * @return true if internet available otherwise false
 */
fun Context.isOnline(): Boolean {
    val cm = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val n = cm.activeNetwork
        if (n != null) {
            val nc = cm.getNetworkCapabilities(n)
            //It will check for both wifi and cellular network
            return nc!!.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || nc.hasTransport(
                NetworkCapabilities.TRANSPORT_WIFI
            )
        }
        return false
    } else {
        val netInfo = cm.activeNetworkInfo
        return netInfo != null && netInfo.isConnectedOrConnecting
    }
}


/**
 * method will use for hide keyboard
 * @param view - current focus view in activity
 */
fun Context.hideKeyboard(view: View) {
    val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
    inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
}

/**
 * method will use for hide keyboard and pass view
 */
fun Activity.hideKeyboard() {
    hideKeyboard(currentFocus ?: View(this))
}

// Font
fun Context.regularFont(): Typeface {
    return ResourcesCompat.getFont(this, R.font.stc_forward_regular)!!
}

fun Context.mediumFont(): Typeface {
    return ResourcesCompat.getFont(this, R.font.stc_forward_medium)!!
}

fun Context.lightFont(): Typeface {
    return ResourcesCompat.getFont(this, R.font.stc_forward_light)!!
}

fun Context.boldFont(): Typeface {
    return ResourcesCompat.getFont(this, R.font.stc_forward_medium)!!
}

fun Context.semiBoldFont(): Typeface {
    return ResourcesCompat.getFont(this, R.font.stc_forward_regular)!!
}

fun Context.chaletRegular(): Typeface {
    return ResourcesCompat.getFont(this, R.font.stc_forward_medium)!!
}


/**
 * method will use for get data from json object
 */
fun String.getMessageFromObject(key: String): String {
    return try {
        val jsonErrorObject = JSONObject(this)
        if (jsonErrorObject.has(key)) {
            jsonErrorObject.getString(key)
        } else {
            ""
        }

    } catch (e: JSONException) {
        ""
    }

}

/**
 * method will use for get thumbnail image from video url
 * @return thumbnail image url
 */
fun String.getVideoIdFromYoutubeUrl(): String? {
    var videoId: String? = null
    val regex =
        "http(?:s)?:\\/\\/(?:m.)?(?:www\\.)?youtu(?:\\.be\\/|be\\.com\\/(?:watch\\?(?:feature=youtu.be\\&)?v=|v\\/|embed\\/|user\\/(?:[\\w#]+\\/)+))([^&#?\\n]+)"
    val pattern =
        Pattern.compile(regex, Pattern.CASE_INSENSITIVE)
    val matcher = pattern.matcher(this)
    if (matcher.find()) {
        videoId = matcher.group(1)
    }
    return videoId
}

fun SharedPreferences.checkUserLoggedInOrNot(): Boolean {
     return this.isLoggedIn
}

fun Date.string(format: String, locale: Locale = Locale.ROOT): String {
    val formatter = SimpleDateFormat(format, locale)
    return formatter.format(this)
}

fun getCurrentDateTime(): Date {
    val cal = Calendar.getInstance()
    cal.timeZone = TimeZone.getTimeZone("UTC")
    return cal.time
}

fun convertTimeStamp(date: Date): Long {
//    val format = SimpleDateFormat(inputFormat, Locale.ROOT)
//    format.timeZone = TimeZone.getTimeZone("UTC")
    return Timestamp(date.time).time / 1000L
}

fun getCurrentDateTimeMilliSec(): Long {
    val cal = Calendar.getInstance()
    cal.timeZone = TimeZone.getTimeZone("UTC")
    return cal.timeInMillis
}


fun String.getTimeAgo(inputFormat: String, requiredFormat: String): String? {
    val stringResult: String?


    val simpleDateFormat = SimpleDateFormat(inputFormat, Locale.ROOT)
    simpleDateFormat.timeZone = TimeZone.getTimeZone("UTC")

    val simpleDateFormatRequired = SimpleDateFormat(requiredFormat, Locale.ROOT)
    simpleDateFormatRequired.timeZone = TimeZone.getTimeZone("UTC")

//    val currentFormat = SimpleDateFormat(AppConstants.API_DATE_FORMAT, Locale.ENGLISH)
//    currentFormat.timeZone = TimeZone.getTimeZone("UTC")

    //val currentDateAndTime = currentFormat.format(Date())

    //  val current: Date = simpleDateFormat.parse(currentDateAndTime)!!
    val secondDate: Date = simpleDateFormat.parse(this)!!


    val diffInMilliSec = getCurrentDateTimeMilliSec() - secondDate.time

    val elapsedDays = TimeUnit.MILLISECONDS.toDays(diffInMilliSec)
    val elapsedHours = TimeUnit.MILLISECONDS.toHours(diffInMilliSec)
    val elapsedMinutes = TimeUnit.MILLISECONDS.toMinutes(diffInMilliSec)
    val elapsedSeconds = TimeUnit.MILLISECONDS.toSeconds(diffInMilliSec)

    stringResult = when {
        elapsedDays < 1 -> when {
            elapsedSeconds in 0..59 -> "just now"
            elapsedMinutes.toInt() == 1 -> elapsedMinutes.toString().plus(" min ago")
            elapsedMinutes in 1..59 -> elapsedMinutes.toString().plus(" mins ago")
            elapsedHours == 1.toLong() -> elapsedHours.toString().plus(" hour ago")
            else -> elapsedHours.toString().plus(" hours ago")
        }
        elapsedDays.toInt() == 1 -> "1 day ago"
        elapsedDays < 7 -> elapsedDays.toString().plus(" days ago")
        else -> simpleDateFormatRequired.format(secondDate)
    }

    return stringResult
}

fun String.getLeftTime(inputFormat: String): Long {
    val simpleDateFormat = SimpleDateFormat(inputFormat, Locale.ROOT)
    simpleDateFormat.timeZone = TimeZone.getTimeZone("UTC")


    val secondDate: Date = simpleDateFormat.parse(this)!!

    val diffInMilliSec = secondDate.time - getCurrentDateTimeMilliSec()

    return TimeUnit.MILLISECONDS.toDays(diffInMilliSec)
}

/**
 * method will use for update image tint color
 * @param id color id
 * @param imageView target image view
 */
fun Context.updateTintColor(id: Int, imageView: ImageView) {
    imageView.setColorFilter(
        ContextCompat.getColor(this, id),
        android.graphics.PorterDuff.Mode.SRC_IN
    )
}

/**
 * method will use show spinner with single option selection
 * @param title - spinner title
 * @param tv - target textView
 * @param data - list of spinner option
 * @param isFilterable -show filter option if true otherwise hide filter option
 * @param type - spinner type like
 * @param onItemClick - spinner item click callback
 */
fun Context.showSpinner(
    title: String,
    tv: TextView,
    data: MutableList<out Any>,
    isFilterable: Boolean,
    type: String = "",
    onItemClick: (Any) -> Unit = { _ -> }
) {


    val dialog = Dialog(this)
    val window = dialog.window
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
    dialog.setContentView(R.layout.spinner)
    window!!.setBackgroundDrawableResource(android.R.color.transparent)

    val lblselect = window.findViewById<View>(R.id.dialogtitle) as TextView
    lblselect.text = title.replace("*", "").trim { it <= ' ' }

    val dialogClear = window.findViewById<View>(R.id.dialogClear) as TextView
    dialogClear.setOnClickListener {
        tv.text = ""
        tv.tag = null
        dialog.dismiss()
    }

    val editSearch = window.findViewById<View>(R.id.editSearch) as EditText
    if (isFilterable) {
        editSearch.beVisible()
    } else {
        editSearch.beGone()
    }

    val adapter = SpinnerAdapter(this, type)
    adapter.setFilterable(isFilterable)
    val lv = window.findViewById<View>(R.id.lvSpinner) as ListView
    lv.adapter = adapter
    adapter.addAll(data)
    lv.onItemClickListener = AdapterView.OnItemClickListener { adapterview, view, position, l ->
        when (type) {
            "country" -> {
                val dataCountry = adapter.getItem(position) as CountriesModel.CountryModel
                tv.text = dataCountry.name
                tv.tag = dataCountry.id.toString()
                onItemClick(dataCountry)
            }
            "state" -> {
                val dataState = adapter.getItem(position) as StateModel.State
                tv.text = dataState.name
                tv.tag = dataState.id
                onItemClick(dataState)
            }
            "search" -> {
                val dataState = adapter.getItem(position) as String
                tv.text = dataState
                onItemClick(dataState)
            }
            "game" -> {
                val dataState = adapter.getItem(position) as TournamentGameRes.Datum
                tv.text = dataState.name
                onItemClick(dataState)
            }
            else -> {
                val dataSpinner = adapter.getItem(position) as Spinner
                tv.text = dataSpinner.title
                tv.tag = dataSpinner.ID
                onItemClick(dataSpinner)
            }
        }


        dialog.dismiss()
    }

    editSearch.addTextChangedListener(object : TextWatcher {

        override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
        }

        override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
        }

        override fun afterTextChanged(editable: Editable) {
            if (editable.toString().trim { it <= ' ' }.length >= 1) {
                adapter.filter!!.filter(editable.toString().trim { it <= ' ' })
            } else {
                adapter.filter!!.filter("")
            }
        }
    })

    dialog.show()
}


/**
 * method will use show spinner with multiple option selections
 * @param title - spinner title
 * @param data - list of spinner option
 * @param isFilterable -show filter option if true otherwise hide filter option
 * @param onItemClick - spinner item click callback
 */
fun Context.showSpinnerSel(
    title: String,
    data: ArrayList<Spinner>,
    isFilterable: Boolean,
    callback: SpinnerCallback?
) {
    val dialog = Dialog(this)
    val window = dialog.window
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
    dialog.setContentView(R.layout.spinner_sel)
    window!!.setBackgroundDrawableResource(android.R.color.transparent)
    val lblselect = window.findViewById<View>(R.id.dialogtitle) as TextView
    lblselect.text = title
    lblselect.text = title.replace("*", "").trim { it <= ' ' }

//    val dialogClear = window.findViewById<View>(R.id.dialogClear) as TextView
//    dialogClear.setOnClickListener {
//        tv.text = ""
//        tv.tag = null
//        dialog.dismiss()
//    }

    val editSearch = window.findViewById<View>(R.id.editSearch) as EditText
    if (isFilterable) {
        editSearch.beVisible()
    } else {
        editSearch.beGone()
    }
    val selectedStr = ""

//        if (tv == editIntensity) {
//            selectedStr = stoneParam.FancycolorIntensityList;
//        }
//        if (tv == editColor) {
//            selectedStr = stoneParam.FancyColorList;
//        }
//        if (tv == editOvertone) {
//            selectedStr = stoneParam.FancycolorOvertoneList;
//        }
//    if (!selectedStr.isEmpty()) {
//        val selected: ArrayList<String?> =
//            asList(selectedStr.replace("'".toRegex(), ""))
//        if (!selected.isEmpty()) {
//            for (i in data.indices) {
//                if (selected.contains(data[i].ID)) {
//                    data[i].setSelected(true)
//                } else {
//                    data[i].setSelected(false)
//                }
//            }
//        }
//    }
    val adapter = SpinnerSelAdapter(this)
    adapter.setFilterable(isFilterable)
    val lv =
        window.findViewById<View>(R.id.lvSpinner) as ListView
    lv.adapter = adapter
    adapter.addAll(data)

//        if (tv.getTag().toString().trim()!= null){
//            for (int i = 0; i <data.size() ; i++) {
//                if (tv.getTag().toString().trim().equals(data.get(i).ID)){
//                    Debug.e("Game Id" , data.get(i).ID);
//                }
//            }
//        }
    lv.onItemClickListener =
        AdapterView.OnItemClickListener { adapterview, view, position, l ->
            adapter.changeSelection(
                position,
                true
            )
        }

//        for (int i = 0; i <data.size() ; i++) {
//            if (adapter.isSelectedAtleastOne()){
//                adapter.changeSelection(Integer.valueOf(data.get(i).ID), true);
//            }else{
//                adapter.changeSelection(Integer.valueOf(data.get(i).ID), false);
//            }
//        }

    editSearch.doAfterTextChanged {
        if (it.toString().trim { it <= ' ' }.isNotEmpty()) {
            adapter.filter!!.filter(it.toString().trim { it <= ' ' })
        } else {
            adapter.filter!!.filter("")
        }
    }

    val btnSpinnerOk =
        window.findViewById<View>(R.id.btnPositive) as Button
    btnSpinnerOk.setOnClickListener {
        val selList: ArrayList<Spinner> = adapter.selectedAll
//            tv.setText(adapter.selectedTitle)
//            tv.tag = adapter.selectedIds
//            if (selList.size > 0) {
//                tv.tag = adapter.selectedIdArray
//            } else {
//                tv.tag = null
//            }
        callback?.onDone(selList)
        dialog.dismiss()
    }
    val btnSpinnerCancel = window
        .findViewById<View>(R.id.btnNegative) as Button
    btnSpinnerCancel.setOnClickListener { dialog.dismiss() }
    dialog.show()
}

/**
 * method will use for convert string to arraylist
 */
fun asList(str: String): ArrayList<String?> {
    return ArrayList(listOf(*str.split("\\s*,\\s*".toRegex()).dropLastWhile { it.isEmpty() }
        .toTypedArray())
    )
}

/**
 * method will use for show date picker dialog
 * @param textViewDate - target date textView
 * @param format - date format which you want
 * @param isPast - enable past date if true
 * @param isFuture - enable future date if true
 */
fun Context.getDate(
    textViewDate: TextView,
    format: String,
    isPast: Boolean = false,
    isFuture: Boolean = false,
    yearValidation: Boolean = false,
    updateTextValue: (String) -> Unit = { _ -> }
) {
    val cal = Calendar.getInstance()
    val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, monthOfYear)
        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
        val simpleDateFormat = SimpleDateFormat(format, Locale.ROOT)
        updateTextValue(simpleDateFormat.format(cal.time))
    }
    textViewDate.click {
        val year = if (textViewDate.text.isNullOrEmpty()) {
            cal.get(Calendar.YEAR)
        } else {
            textViewDate.text.split("/")[2].toInt()
        }
        val month = if (textViewDate.text.isNullOrEmpty()) {
            cal.get(Calendar.YEAR)
        } else {
            textViewDate.text.split("/")[1].toInt()
        }
        val day = if (textViewDate.text.isNullOrEmpty()) {
            cal.get(Calendar.YEAR)
        } else {
            textViewDate.text.split("/")[0].toInt()
        }
        val dialog = DatePickerDialog(
            this,R.style.MyDatePickerDialogTheme, dateSetListener,
            year,
            (month - 1),
            day,
        )
        if (isFuture) {
            dialog.datePicker.minDate = System.currentTimeMillis() - 1000
        }
        if (isPast) {
            if(yearValidation){
                dialog.datePicker.maxDate = convertStringToDate("01/01/".plus(getCurrentYears()-10),AppConstants.DD_MM_YYYY_FORMAT)?.time!!
            }else{
                dialog.datePicker.maxDate = System.currentTimeMillis()
            }
        }
        dialog.show()
    }
}

fun getCurrentYears():Int{
    val cal = Calendar.getInstance()
    return cal.get(Calendar.YEAR)
}



/**
 * method will use for show time picker dialog
 * @param textViewTime - target time textView
 * @param format - date format which you want
 * @param is24HourView - enable time picker 24 hour if true
 */
fun Context.getTime(
    textViewTime: TextView,
    format: String,
    is24HourView: Boolean = false,
    updateTextValue: (String) -> Unit = { _ -> }
) {
    val cal = Calendar.getInstance()
    val timeSetListener = TimePickerDialog.OnTimeSetListener { _, hour, minute ->
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        updateTextValue(SimpleDateFormat(format, Locale.ROOT).format(cal.time))
    }
    textViewTime.click {
        val time=if(!textViewTime.text.isNullOrEmpty()){
            textViewTime.text.toString().convert24to12TimeViceVersa(AppConstants.TIME_FORMAT_API,"HH:mm")
        }else{
            ""
        }

        val hours = if (time.isEmpty()) {
            cal.get(Calendar.HOUR_OF_DAY)
        } else {
            time.split(":")[0].toInt()
        }
        val minute = if (time.isEmpty()) {
            cal.get(Calendar.MINUTE)
        } else {
            time.split(":")[1].toInt()
        }

        TimePickerDialog(
            this,
            R.style.MyDatePickerDialogTheme,
            timeSetListener,
            hours,
            minute,
            is24HourView
        ).show()
    }
}


//fun ViewGroup.deepForEach(function: View.() -> Unit) {
//    this.forEach { child ->
//        child.function()
//        if (child is ViewGroup) {
//            child.deepForEach(function)
//        }
//    }
//}

/**
 * method will use for enable and disable child view
 */
fun View.forEachChildView(closure: (View) -> Unit) {
    closure(this)
    val groupView = this as? ViewGroup ?: return
    val size = groupView.childCount - 1
    for (i in 0..size) {
        groupView.getChildAt(i).forEachChildView(closure)
    }
}

/**
 * method will use for read json file and convert into model class
 * @param resourceId - json file id
 */
inline fun <reified T> Context.jsonToClass(@RawRes resourceId: Int): T =
    Gson().fromJson(
        resources.openRawResource(resourceId).bufferedReader().use { it.readText() },
        T::class.java
    )

/**
 * method will use for encode file to base64
 */
fun File.encoder(): String {
    val bytes = this.readBytes()
    return android.util.Base64.encodeToString(bytes, NO_WRAP)

}


fun String.convert24to12TimeViceVersa(inputFormat: String, requiredFormat: String):String{
    val inputSimpleFormat = SimpleDateFormat(inputFormat, Locale.ROOT)
    val requiredSimpleFormat = SimpleDateFormat(requiredFormat, Locale.ROOT)
   return requiredSimpleFormat.format(inputSimpleFormat.parse(this))

}

/**
 * method will use for convert string to date
 * @param dateString - date string
 * @param dateFormat - date format which you want.
 */
fun convertStringToDate(dateString: String?, dateFormat: String): Date? {
    val format = SimpleDateFormat(dateFormat, Locale.ROOT)
    val date = format.parse(dateString)
    return date
}


/**
 * method will use for convert string to date
 * @param dateString - date string
 * @param dateFormat - date format which you want.
 */
fun mergeDateAndTime(dateTimeString: String, dateFormat: String): String {
    val format = SimpleDateFormat(dateFormat, Locale.ROOT)
    val simpleDateFormatRequired = SimpleDateFormat(AppConstants.API_DATE_FORMAT, Locale.ROOT)
    simpleDateFormatRequired.timeZone = TimeZone.getTimeZone("UTC")
    return simpleDateFormatRequired.format(format.parse(dateTimeString)!!)
}

fun implode(data: ArrayList<String>): String {
    try {
        var devices = ""
        for (iterable_element in data) {
            devices = "$devices,$iterable_element"
        }
        if (devices.length > 0 && devices.startsWith(",")) {
            devices = devices.substring(1)
        }
        return devices
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return ""
}

fun parseTime(time: Long, pattern: String): String {
    val sdf = SimpleDateFormat(pattern, Locale.ROOT)
    return sdf.format(Date(time))
}

fun parseTimeDate(time: Long, pattern: String): Date {
    val sdf = SimpleDateFormat(pattern, Locale.ROOT)
    return parseTime(sdf.format(Date(time)), pattern)
}

fun parseTime(time: String, pattern: String): Date {
    val sdf = SimpleDateFormat(pattern, Locale.ROOT)
    return try {
        sdf.parse(time)
    } catch (e: ParseException) {
        Date()
    }
}

fun parseTime(time: String, fromPattern: String, toPattern: String): String {
    var sdf = SimpleDateFormat(fromPattern, Locale.ROOT)
    return try {
        val d = sdf.parse(time)
        sdf = SimpleDateFormat(toPattern, Locale.ROOT)
        sdf.format(d)
    } catch (e: Exception) {
        ""
    }
}

fun String.isUpcommingDate(): Boolean {
    val strDate = parseTime(this, AppConstants.API_DATE_FORMAT)
    return strDate.after(Date())
}

fun String.isOngoingDate(): Boolean {
    val strDate = parseTime(this, AppConstants.API_DATE_FORMAT)
    return strDate.before(Date())
}

fun nullSafe(content: String?): String {
    return content ?: ""
}

fun nullSafeNA(content: String?): String {
    if (content == null || content.isEmpty()) {
        return "N/A"
    } else {
        return content
    }
}

// at deployment time debug should be false
var DEBUG = true

fun debugE(tag: String = "unknown", msg: String) {
    if (DEBUG) {
        debugLog(msg, object : debugLogCB {
            override fun log(message: String) {
                Log.e(tag, message)
            }
        })
    }
}

private fun debugLog(message: String?, callback: debugLogCB) {
    if (message == null) {
        callback.log("null")
        return
    }
    var i = 0
    val length = message.length
    while (i < length) {
        var newline = message.indexOf('\n', i)
        newline = if (newline != -1) newline else length
        do {
            val end = Math.min(newline, i + 4000)
            callback.log(message.substring(i, end))
            i = end
        } while (i < newline)
        i++
    }
}

private interface debugLogCB {
    fun log(message: String)
}


fun isJPEGorPNG(url: String?): Boolean {
    try {
        val type: String = getMimeType(url!!)!!
        val ext = type.substring(type.lastIndexOf("/") + 1)
        if (ext.equals("jpeg", ignoreCase = true) || ext.equals(
                "jpg",
                ignoreCase = true
            ) || ext.equals("png", ignoreCase = true)
        ) {
            return true
        }
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        return true
    }
    return false
}