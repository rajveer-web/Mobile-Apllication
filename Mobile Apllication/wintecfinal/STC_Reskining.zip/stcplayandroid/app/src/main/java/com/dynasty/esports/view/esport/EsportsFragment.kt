package com.dynasty.esports.view.esport

import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CommonErrorRes
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.models.TournamentListRes
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.tournamet.createtournament.CreateTourmamentActivity
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamentDetailActivity
import com.dynasty.esports.viewmodel.EsportsViewModel
import com.google.android.material.appbar.AppBarLayout
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mugen.Mugen
import com.mugen.MugenCallbacks
import com.mugen.attachers.RecyclerViewAttacher
import kotlinx.android.synthetic.main.activity_tournament_detail.*
import kotlinx.android.synthetic.main.fragment_esports.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.tournament_app_bar_layout.*
import kotlinx.android.synthetic.main.tournament_app_bar_layout.appBarLayout
import kotlinx.android.synthetic.main.tournament_app_bar_layout.collapsingToolbar
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will use for esports page
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

/*Conditions to figure out tournament stages :
    * isFinished == true                                                    --- Completed
    * (startDate < currentDate) || isSeeded == true                         --- Ongoing
    * startDate > currentDate && isSeeded == false && isFinished == false   --- Upcomming*/
class EsportsFragment : BaseFragment(),
    ConnectivityReceiver.ConnectivityReceiverListener,
    ManageRedirectReceiver.NotifyActivityListener {

    private val mViewModel: EsportsViewModel by viewModel()
    private lateinit var upcomingAdapter: UpcomingAdapter
    private lateinit var ongGoingAdapter: OngoingAdapter
    lateinit var tournamentByGameAdapter: TournamentByGameAdapter
    lateinit var tournamentFilterAdapter: TournamentFilterAdapter
    private var connectivityReceiver = ConnectivityReceiver()
    private var manageRedirectReceiver = ManageRedirectReceiver()
    lateinit var endlessUpcomingList: RecyclerViewAttacher
    lateinit var endlessOngoingList: RecyclerViewAttacher
    lateinit var endlessGameFilterList: RecyclerViewAttacher
    var isendlessUpcomingRunning = false
    var isendlessOngoingRunning = false
    var isendlessGameFilterRunning = false
    private var upcomingPageNo = 0
    private var ongoingPageNo = 0
    private var gameFilterPageNo = 0
    private lateinit var esportsViewPagerAdapter: EsportsPageAdapter


    //    private var ongoingList: MutableList<TournamentListRes.Doc> = ArrayList()
    private var upcomingList: MutableList<TournamentListRes.Doc> = ArrayList()
    private var bannreList: MutableList<TournamentListRes.Doc> = ArrayList()

    //  set limit for how much data will fetch in single api call
    private var limit = 10

    //  set selectedGameId when user click on game list
    private var selectedGameId: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        LocalBroadcastManager.getInstance(requireContext())
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
        return inflater.inflate(R.layout.fragment_esports, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        initEndlessList()
        listenToViewModel()
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc this method is used for initialize adapter and recyclerview
     */
    fun initialise() {
//      set toolbar font
        collapsingToolbar.setCollapsedTitleTypeface(requireActivity().getFontTypeFace(R.font.stc_forward_medium))
//      set text to toolbar when toolbar Collapsed and Expanded
        appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                Math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbar.title = resources.getString(R.string.esports)
                }
                else -> {
                    collapsingToolbar.title = ""
                    // Expanded
                }
            }
        })

//      set title to top bar when scrolling to next recyclerview
        scrollEsport.setOnScrollChangeListener { v: NestedScrollView?, scrollX: Int, scrollY: Int, oldScrollX: Int, oldScrollY: Int ->
            if (collapsingToolbar != null) {
                try {
                    when {
                        scrollY in 191..1349 -> {
                            collapsingToolbar.title =
                                resources.getString(R.string.upcoming_tournament)
                        }
                        scrollY in 1351..2545 -> {
                            collapsingToolbar.title =
                                resources.getString(R.string.ongoing_tournament)
                        }
                        scrollY > 2546 -> {
                            collapsingToolbar.title =
                                resources.getString(R.string.tournaments_by_games)
                        }
                        scrollY == 0 -> {
                            collapsingToolbar.title = resources.getString(R.string.esports)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

//      Adapter initialition
        upcomingAdapter = UpcomingAdapter(onItemClick = ::onUpcomingClick)
        ongGoingAdapter = OngoingAdapter(onItemClick = ::onOngoingClick)
        tournamentByGameAdapter = TournamentByGameAdapter(onItemClick = ::onTournamentByGameClick)
        tournamentFilterAdapter = TournamentFilterAdapter(onItemClick = ::onTournamentFilterClick)

//      recyclerview layout initialition
        rvUpcomming.layoutManager = LinearLayoutManager(requireContext())
        rvOngoing.layoutManager = LinearLayoutManager(requireContext())
        rvTournamentGame.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        rvGameFilterdTournament.layoutManager = LinearLayoutManager(requireContext())

//      set adapter to recyclerview
        rvUpcomming.adapter = upcomingAdapter
        rvOngoing.adapter = ongGoingAdapter
        rvTournamentGame.adapter = tournamentByGameAdapter
        rvGameFilterdTournament.adapter = tournamentFilterAdapter

//      set create_tournament click
        flCreate.click {
            mViewModel.createTournmentClick()
        }

        if (LocaleHelper.getLanguage(requireContext()) == "en") {

        } else {

            val params = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.LEFT
            }

            create_tournament.layoutParams = params
        }
    }

    /**
     * @desc method will initialize endless recyclerview to rvUpcomming, rvOngoing and rvGameFilterdTournament for pagination
     */
    private fun initEndlessList() {
        endlessUpcomingList = Mugen.with(rvUpcomming, object : MugenCallbacks {
            override fun onLoadMore() {
                if (endlessUpcomingList.isLoadMoreEnabled) {
                    callUpcomingTournamentAPI(false)
                }
            }

            override fun isLoading(): Boolean {
                return isendlessUpcomingRunning
            }

            override fun hasLoadedAllItems(): Boolean {
                return false
            }
        })

        endlessUpcomingList.start()
        endlessUpcomingList.loadMoreOffset = 3
        endlessUpcomingList.isLoadMoreEnabled = true

        endlessOngoingList = Mugen.with(rvOngoing, object : MugenCallbacks {
            override fun onLoadMore() {
                if (endlessOngoingList.isLoadMoreEnabled) {
                    callOngoingTournamentAPI(false)
                }
            }

            override fun isLoading(): Boolean {
                return isendlessOngoingRunning
            }

            override fun hasLoadedAllItems(): Boolean {
                return false
            }
        })

        endlessOngoingList.start()
        endlessOngoingList.loadMoreOffset = 3
        endlessOngoingList.isLoadMoreEnabled = true

        endlessGameFilterList = Mugen.with(rvGameFilterdTournament, object : MugenCallbacks {
            override fun onLoadMore() {
                if (endlessGameFilterList.isLoadMoreEnabled) {
                    callGameFilterTournamentAPI(false)
                }
            }

            override fun isLoading(): Boolean {
                return isendlessGameFilterRunning
            }

            override fun hasLoadedAllItems(): Boolean {
                return false
            }
        })

        endlessGameFilterList.start()
        endlessGameFilterList.loadMoreOffset = 3
        endlessGameFilterList.isLoadMoreEnabled = true
    }

//    /**
//     * @desc make json for upcoming tournament and call get upcoming tournament list api
//     * @param upcomingPageNo add one unit in upcomingPageNo for get next page data
//     */
//    private fun callUpcomingTournamentAPI() {
//        upcomingPageNo++
//        upcomingAdapter.setShowloader_(true)
//
//        mViewModel.makeJsonForUpcomingTournament(
//            upcomingPageNo,
//            limit,
//            false,
//            false
//        )
//    }

//    /**
//     * @desc add one unit ongoingPageNo and make json for Ongoing tournament and call get Ongoing tournament list api
//     */
//    private fun callOngoingTournamentAPI() {
//        ongoingPageNo++
//        ongGoingAdapter.setShowloader_(true)
//
//        mViewModel.makeJsonForOngoingTournament(
//            ongoingPageNo,
//            limit,
//            true
//        )
//    }

    /**
     * @desc make json for GameFilter tournament and call get GameFilter tournament list api
     * @param showPrimaryLoader if api is calling for first time then show primary loader
     *       otherwise loader should be shown from adapter for endless recyclerview
     */
    private fun callGameFilterTournamentAPI(showPrimaryLoader: Boolean) {
        gameFilterPageNo++
        if (showPrimaryLoader) {
            rvGameFilterProgress.beVisible()
            tvGameFilterNoData.beGone()
            tournamentFilterAdapter.clearAll()
        } else {
            tournamentFilterAdapter.setShowloader_(true)
        }

//        0 = upcoming and  1 = ongoing
        mViewModel.fetchOngoingGameFilter(
            "0",
            "latest",
            selectedGameId,
            "type",
            gameFilterPageNo,
            limit
        )
    }

    /**
     * @desc method will call when tap on TournamentByGame recyclerview from tournamentByGameAdapter and call filter by game api
     */
    private fun onTournamentByGameClick(position: Int) {
        val data = tournamentByGameAdapter.getItem(position)
        if (position == 0) {
            selectedGameId = ""
            tournamentFilterAdapter.clearAll()
            tournamentFilterAdapter.addAll(upcomingList)
            refreshPlaceHolder(true)
        } else {
            selectedGameId = data.id
            gameFilterPageNo = 0
            callGameFilterTournamentAPI(true)
        }
        tournamentByGameAdapter.setSelected(data.id)
    }

    /**
     * @desc method will call when tap on TournamentFilter recyclerview from tournamentFilterAdapter and redirect to UpcomingDetailActivity
     */
    private fun onTournamentFilterClick(position: Int) {
        val item = tournamentFilterAdapter.getItem(position)
        val bundle = Bundle()
        bundle.putString("tournamentId", item.id)
        bundle.putBoolean("isUpcoming", true)
        requireActivity().startActivityInline<TournamentDetailActivity>(
            bundle
        )
    }

    /**
     * @desc method will call when tap on Ongoing tournament recyclerview from ongGoingAdapter and redirect to UpcomingDetailActivity
     *       set isUpcoming value false when click from ongGoingAdapter
     */
    private fun onOngoingClick(position: Int) {
        val item = ongGoingAdapter.getItem(position)
        val bundle = Bundle()
        bundle.putString("tournamentId", item.id)
        bundle.putBoolean("isUpcoming", false)
        requireActivity().startActivityInline<TournamentDetailActivity>(bundle)
    }

    /**
     * @desc method will call when tap on Upcoming tournament recyclerview from upcomingAdapter and redirect to UpcomingDetailActivity
     *       set isUpcoming value true when click from upcomingAdapter
     */
    private fun onUpcomingClick(position: Int) {
        val item = upcomingAdapter.getItem(position)
        val bundle = Bundle()
        bundle.putString("tournamentId", item.id)
        bundle.putBoolean("isUpcoming", true)
        requireActivity().startActivityInline<TournamentDetailActivity>(bundle)
    }

    private fun onItemClick(id: String) {
        val bundle = Bundle()
        bundle.putString("tournamentId", id)
        bundle.putBoolean("isUpcoming", false)
        startActivityFromFragment<TournamentDetailActivity>(bundle)
//        if (sharedPreferences.checkUserLoggedInOrNot()) {
//            startActivityFromFragment<CreateTourmamentActivity>()
//        } else {
//            displayCustomAlertDialog(resources.getString(R.string.please_login_to_access_page),
//                isCancelable = true,
//                isCloseShow = true,
//                positiveText = resources.getString(R.string.login),
//                positiveClick = {
//                    it.dismiss()
//                    redirectType = "create_tournament"
//                    startActivityFromFragment<PhoneSignInActivity>()
//                },
//                negativeText = resources.getString(R.string.str_cancel),
//                negativeClick = {
//                    it.dismiss()
//                }, onCloseClick = {
//                    it.dismiss()
//                })
//        }
    }

    /**
     * @desc listen observer and receive the events
     * Also, Manage success and failure responces from API, Internet and un authorization.
     */
    private fun listenToViewModel() {

//      get game list data from api success responce
        mViewModel.gameListSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                pbTournamentGame.beGone()

                val gameList: MutableList<TournamentGameRes.Datum> = ArrayList()

                val firstItem = TournamentGameRes.Datum()
                firstItem.isSelected = true
                firstItem.id = "firstItem"
                firstItem.name = "firstItem"
                firstItem.image = ""
                firstItem.logo = ""
                gameList.add(firstItem)


                it.data!!.forEach {
                    gameList.add(it)
                }


                tournamentByGameAdapter.addAll(gameList)
                refreshPlaceHolder(true)
            })

//      get game list data from api error responce
        mViewModel.gameListErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                pbTournamentGame.beGone()
                refreshPlaceHolder(requireActivity().isOnline())
                dismissProgressDialog()
            })

//      call UpcomingTournament api
        mViewModel.jsonObjectForUpcomingTournament.observe(viewLifecycleOwner, Observer {
            mViewModel.fetchUpcomingTournament(
                it.first.toString(),
                it.second.toString(),
                "type", 1, 5
            )
        })

//      call UpcomingTournament api, ongoing tournament api and get gamelist api for first time
//        mViewModel.jsonObjectallTournament.observe(viewLifecycleOwner, Observer {
//            mViewModel.getAllTournamentList(
//                it.queryUpcoming.toString(),
//                it.queryOngoing.toString(),
//                it.pagination.toString(),
//                "type"
//            )
//        })

//      get UpcomingTournament data from api success responce
        mViewModel.fetchUpcomingTournamentSuccessResponse.observe(viewLifecycleOwner, Observer {
            upcomingAdapter.setShowloader_(false)
            rvUpcommingProgress.beGone()
            dismissProgressDialog()
            debugE("fetchUpcomingSuccess", Gson().toJson(it))
            upcomingList.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            if (!it.data!!.hasNextPage) {
                endlessUpcomingList.isLoadMoreEnabled = false
            }
            upcomingAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            tournamentFilterAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            refreshPlaceHolder(true)
        })

//      UpcomingTournament error responce
        mViewModel.fetchUpcomingTournamentErrorResponse.observe(viewLifecycleOwner, Observer {
            rvUpcommingProgress.beGone()
            try {
                val errorRes: CommonErrorRes = Gson().fromJson(
                    it.string(),
                    object : TypeToken<CommonErrorRes?>() {}.type
                )
                errorRes.err!!.message!!.showToast(requireContext())
            } catch (e: Exception) {
            }
            dismissProgressDialog()
            upcomingAdapter.setShowloader_(false)
            //    endlessUpcomingList.isLoadMoreEnabled = false
            refreshPlaceHolder(requireActivity().isOnline())
        })

//      get game filter data from api success responce
//        mViewModel.jsonObjectForGameFilterTournament.observe(viewLifecycleOwner, Observer {
//            mViewModel.fetchOngoingGameFilter(
//                it.first.toString(),
//                it.second.toString(),
//                "type"
//            )
//        })

//      call OngoingTournament api
//        mViewModel.jsonObjectForOngoingTournament.observe(viewLifecycleOwner, Observer {
//            mViewModel.fetchOngoingTournament(
//                it.first.toString(),
//                it.second.toString(),
//                "type"
//            )
//        })

//      get OngoingTournament data from api success responce
        mViewModel.fetchOngoingTournamentSuccessResponse.observe(viewLifecycleOwner, Observer {
            ongGoingAdapter.setShowloader_(false)
            rvOngoingProgress.beGone()
            dismissProgressDialog()
            debugE("fetchOngoingSuccess", Gson().toJson(it))
//            ongoingList = it.data!!.docs as MutableList<TournamentListRes.Doc>
            if (!it.data!!.hasNextPage) {
                endlessOngoingList.isLoadMoreEnabled = false
            }
            ongGoingAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
//            tournamentFilterAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            refreshPlaceHolder(true)
        })

//      OngoingTournament error responce
        mViewModel.fetchOngoingTournamentErrorResponse.observe(viewLifecycleOwner, Observer {
            ongGoingAdapter.setShowloader_(false)
            rvOngoingProgress.beGone()
            try {
                val errorRes: CommonErrorRes = Gson().fromJson(
                    it.string(),
                    object : TypeToken<CommonErrorRes?>() {}.type
                )

                if (errorRes.err != null) {
                    errorRes.err!!.message!!.showToast(requireContext())
                }
            } catch (e: Exception) {
            }

            endlessOngoingList.isLoadMoreEnabled = false
            dismissProgressDialog()
            refreshPlaceHolder(requireActivity().isOnline())
        })

//      get GameFilter tournament data from api success responce
        mViewModel.fetchGameFilterTournamentSuccessResponse.observe(viewLifecycleOwner, Observer {
            tournamentFilterAdapter.setShowloader_(false)
            rvGameFilterProgress.beGone()
            dismissProgressDialog()
            debugE("fetchGameFilterSuccess", Gson().toJson(it))
            if (!it.data!!.hasNextPage) {
                endlessGameFilterList.isLoadMoreEnabled = false
            }
            tournamentFilterAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            refreshPlaceHolder(true)
        })

//      GameFilterTournament error responce
        mViewModel.fetchGameFilterTournamentErrorResponse.observe(viewLifecycleOwner, Observer {
            try {
                val errorRes: CommonErrorRes = Gson().fromJson(
                    it.string(),
                    object : TypeToken<CommonErrorRes?>() {}.type
                )
                errorRes.err!!.message!!.showToast(requireContext())
            } catch (e: Exception) {
            }

            tournamentFilterAdapter.setShowloader_(false)
            endlessGameFilterList.isLoadMoreEnabled = false
            dismissProgressDialog()
            refreshPlaceHolder(requireActivity().isOnline())
        })

//      createTournamentObservable click
        mViewModel.createTournamentObservable.observe(requireActivity(), Observer {
            if (sharedPreferences.checkUserLoggedInOrNot()) {
                startActivityFromFragment<CreateTourmamentActivity>()
            } else {
                displayCustomAlertDialog(resources.getString(R.string.please_login_to_access_page),
                    isCancelable = true,
                    isCloseShow = true,
                    positiveText = resources.getString(R.string.login),
                    positiveClick = {
                        it.dismiss()
                        redirectType = "create_tournament"
                        startActivityFromFragment<PhoneSignInActivity>()
                    },
                    negativeText = resources.getString(R.string.str_cancel),
                    negativeClick = {
                        it.dismiss()
                    }, onCloseClick = {
                        it.dismiss()
                    })
            }
        })

//      handle noInternetException from all apis
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            refreshPlaceHolder(false)
        })

        mViewModel.esportsbannerSuccessResponse.observe(viewLifecycleOwner, Observer {
            //  progressBarBanner.beGone()
            bannreList.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            if (bannreList.size == 0) {
//                esports_layout_id.beGone()
//                toolbar.beGone()
//                create_tournament.beVisible()
            } else {
//                create_tournament.beGone()
//                esports_layout_id.beVisible()
//                toolbar.beVisible()
                setHomePageBannerSlideAdapter(bannreList)
            }
            // setHomePageBannerSlideAdapter(bannreList)
        })

        mViewModel.esportsbannerErrorResponse.observe(viewLifecycleOwner, Observer {
//            progressBarBanner.beGone()
//            textViewBannerNoData.beVisible()
//            textViewBannerNoData.text = resources.getString(R.string.some_thing_went_wrong)
        })

    }


    val handler = Handler()

    var currentIndex = 0

    /**
     * @desc set Runnable for timeCounter for auto change images in banner
     */
    val timeCounter: Runnable = object : Runnable {
        override fun run() {
            if (currentIndex + 1 > esportsViewPagerAdapter.count) {
                currentIndex = 0
            } else {
                currentIndex++
            }
            esport_view_pager?.apply {
                this.setCurrentItem(currentIndex, true)
            }
            handler.postDelayed(this, 4 * 1000)
        }
    }

    /**
     * @desc method will set esportsViewPagerAdapter and run timer for next image in banner (auto change images every 3 sec)
     */
    private fun setHomePageBannerSlideAdapter(data: MutableList<TournamentListRes.Doc>) {
        esportsViewPagerAdapter =
            EsportsPageAdapter(requireContext(), data, onItemClick = ::onItemClick)
        esport_view_pager.adapter = esportsViewPagerAdapter
        // esportpageIndicatorView.setViewPager(esport_view_pager)
        //esportpageIndicatorView.beGone()
        handler.postDelayed(timeCounter, 4 * 1000)
    }

    override fun onNotify(notifyType: String) {
        if (notifyType == "create_tournament") {
            startActivityFromFragment<CreateTourmamentActivity>()
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
        LocalBroadcastManager.getInstance(requireContext())
            .unregisterReceiver(manageRedirectReceiver)
    }

    /**
     * @desc refresh view for show no internet view, progress bar and no data display view
     * @param isInternetAvailable when internet is unavailable then hide all view and show no internet view.
     */
    private fun refreshPlaceHolder(isInternetAvailable: Boolean) {
        if (isInternetAvailable) {
            if (rvUpcomming.adapter!!.itemCount > 0) {
                tvUpcommingNoData.beGone()
                rvUpcomming.beVisible()
            } else {
                tvUpcommingNoData.beVisible()
                rvUpcomming.beGone()
            }

            if (rvOngoing.adapter!!.itemCount > 0) {
                tvOngoingNoData.beGone()
                rvOngoing.beVisible()
            } else {
                tvOngoingNoData.beVisible()
                rvOngoing.beGone()
            }

            if (rvTournamentGame.adapter!!.itemCount > 0) {
                tvTournamentGameNoData.beGone()
                rvTournamentGame.beVisible()
            } else {
                tvTournamentGameNoData.beVisible()
                rvTournamentGame.beGone()
            }

            if (rvGameFilterdTournament.adapter!!.itemCount > 0) {
                tvGameFilterNoData.beGone()
                rvGameFilterdTournament.beVisible()
            } else {
                tvGameFilterNoData.beVisible()
                rvGameFilterdTournament.beGone()
            }

            llTournamentList.beVisible()
            constraintLayoutNoInternet.beGone()
        } else {
            llTournamentList.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     *       call apis and show primary loaders in each and every recyclerview.
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && upcomingAdapter.getAll().isNullOrEmpty()) {
            llTournamentList.beVisible()
            constraintLayoutNoInternet.beGone()
            pbTournamentGame.beVisible()
//            rvUpcommingProgress.beVisible()
//            rvOngoingProgress.beVisible()
            tvTournamentGameNoData.beGone()
            tvOngoingNoData.beGone()
            tvUpcommingNoData.beGone()
//            mViewModel.makeJsonForFetchAllTournamentAndGameList(
//                1,
//                limit
//            )
            callUpcomingTournamentAPI(true)
            callOngoingTournamentAPI(true)
//            mViewModel.fetchOngoingTournament(
//                "1",
//                "latest",
//                "type", ongoingPageNo, limit
//            )
            mViewModel.fetchGameList("")
            mViewModel.esportsGetBanner("6", "6", "participantJoined")
        } else if (upcomingAdapter.getAll().isNullOrEmpty()) {
            refreshPlaceHolder(false)
        }
    }


    /**
     * @desc make json for upcoming tournament and call get upcoming tournament list api
     * @param pageNo every time add one unit in pageNo for get next page data
     */
    private fun callUpcomingTournamentAPI(showPrimaryLoader: Boolean) {
        upcomingPageNo++
        if (showPrimaryLoader) {
            rvUpcommingProgress.beVisible()
//            linearLayoutProgressBar.beVisible()
        } else {
            upcomingAdapter.setShowloader_(true)
        }

//        mViewModel.makeJsonForUpcomingTournament(
//            pageNo,
//            limit,
//            false,
//            false
//        )
        mViewModel.fetchUpcomingTournament(
            "0",
            "latest",
            "type", upcomingPageNo, limit
        )
    }

    /**
     * @desc make json for onngoing tournament and call get ongoing tournament list api
     * @param ongoingPageNo every time add one unit in pageNo for get next page data
     */
    private fun callOngoingTournamentAPI(showPrimaryLoader: Boolean) {
        ongoingPageNo++
        if (showPrimaryLoader) {
            rvOngoingProgress.beVisible()
//            linearLayoutProgressBar.beVisible()
        } else {
            ongGoingAdapter.setShowloader_(true)
        }

//        mViewViewModel.makeJsonForOngoingTournament(
//            pageNo,
//            limit,
//            true
//        )
        mViewModel.fetchOngoingTournament(
            "1",
            "latest",
            "type", ongoingPageNo, limit
        )
    }

}