package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class InboxModel {
    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    class DataModel{
        @SerializedName("seen")
        @Expose
         val seen: Boolean? = null

        @SerializedName("status")
        @Expose
         val status: Int? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("sentBy")
        @Expose
         val sentBy: String? = null

//        @SerializedName("senderDetails")
//        @Expose
//         val senderDetails: String? = null

        @SerializedName("toUser")
        @Expose
         val toUser: String? = null

        @SerializedName("subject")
        @Expose
         val subject: String? = null

        @SerializedName("message")
        @Expose
         val message: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("createdAt")
        @Expose
         val createdAt: String? = null

        @SerializedName("updatedAt")
        @Expose
         val updatedAt: String? = null

        var isSelected=false
    }
}