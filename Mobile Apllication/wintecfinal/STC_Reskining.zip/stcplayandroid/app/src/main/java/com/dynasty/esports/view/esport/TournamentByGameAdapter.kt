package com.dynasty.esports.view.esport

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.TournamentGameListItemBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.GetTournmentModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.utils.BindingHolder
import kotlin.collections.ArrayList

/**
 * @desc this is class will use for tournament by game adapter
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class TournamentByGameAdapter constructor(
    private val onItemClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<TournamentGameListItemBinding>>() {

    private var gameList: MutableList<TournamentGameRes.Datum> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<TournamentGameListItemBinding> {
        val binding: TournamentGameListItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.tournament_game_list_item,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    /**
     * @desc get item data from position
     */
    fun getItem(position: Int): TournamentGameRes.Datum {
        return gameList.get(position)
    }

    /**
     * @desc gameList array size count
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return gameList.size
    }

    /**
     * @desc add data in gameList and notify adapter
     */
    fun addAll(gameList_: MutableList<TournamentGameRes.Datum>) {
        gameList.clear()
        gameList.addAll(gameList_)
        notifyDataSetChanged()
    }

    /**
     * @desc set selected from id
     */
    fun setSelected(id: String) {
        for (gameItem in gameList) {
            gameItem.isSelected = gameItem.id.equals(id, true)
        }
        notifyDataSetChanged()
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents and to reflect the item at the given position.
     */
    override fun onBindViewHolder(holder: BindingHolder<TournamentGameListItemBinding>, position: Int) {
        val data = gameList[position]

        if (position == 0) {
            holder.binding.llMainLayout.beGone()
            holder.binding.llAllGames.beVisible()
        } else {
            holder.binding.llMainLayout.beVisible()
            holder.binding.llAllGames.beGone()

            holder.binding.gameName.text = data.name
            if (!data.image.isNullOrEmpty()) {
                holder.itemView.context.loadImageFromServer(
                    data.image,
                    holder.binding.gameImage
                )
            } else {
                holder.binding.gameImage.setImageResource(R.mipmap.ic_placehoder)
            }
        }

        if (data.isSelected) {
            holder.binding.container.strokeWidth = 3
        } else {
            holder.binding.container.strokeWidth = 0
        }

        holder.itemView.click {
            onItemClick(position)
        }
    }
}