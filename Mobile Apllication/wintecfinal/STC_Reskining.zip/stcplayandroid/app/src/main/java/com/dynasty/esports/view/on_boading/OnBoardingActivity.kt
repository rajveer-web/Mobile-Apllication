package com.dynasty.esports.view.on_boading

import android.content.res.ColorStateList
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.viewpager.widget.ViewPager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.startActivityInlineWithFinishAll
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.OnBoardingViewModel
import kotlinx.android.synthetic.main.content_on_boarding.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class OnBoardingActivity : BaseActivity() {
    private val mViewModel: OnBoardingViewModel by viewModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_on_boarding)
        initialise()
        listenToViewModel()
    }

    // listen view model and manage api response
    private fun listenToViewModel() {
        mViewModel.skipClickObserver.observe(this, {
            startActivityInlineWithFinishAll<DashboardActivity>()
        })
        mViewModel.nextClickObserver.observe(this, {
            if (getItem(+1) > onboarding_view_pager.childCount - 1) {
                // on last screen next button redirect to PhoneNumRegistrationActivity
//                startActivityInlineWithFinishAll<PhoneNumRegistrationActivity>()
                startActivityInlineWithFinishAll<DashboardActivity>()
            } else {
                onboarding_view_pager.setCurrentItem(getItem(+1), true)
            }
        })
    }

    // initialize view
    fun initialise() {
        onboarding_view_pager.adapter =
            OnBoardingViewPagerAdapter(
                supportFragmentManager,
                this
            )
        onboarding_view_pager.offscreenPageLimit = 1
        onboarding_view_pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageSelected(position: Int) {

                when (position) {
                    1 -> {
                        buttonNext.setTextColor(
                            ContextCompat.getColor(
                                this@OnBoardingActivity,
                                R.color.button_active_text_color
                            )
                        )
                        buttonNext.text = getText(R.string.next)
                        buttonNext.strokeWidth = 0
                        buttonNext.backgroundTintList =
                            ColorStateList.valueOf(ContextCompat.getColor(this@OnBoardingActivity, R.color.button_active_bg_color))
                    }
                    2 -> {
                        buttonNext.setTextColor(
                            ContextCompat.getColor(
                                this@OnBoardingActivity,
                                R.color.button_active_text_color
                            )
                        )
                        buttonNext.text = getText(R.string.onboarding_getStarted)
                        buttonNext.strokeWidth = 0
                        buttonNext.backgroundTintList =
                            ColorStateList.valueOf(ContextCompat.getColor(this@OnBoardingActivity, R.color.button_active_bg_color))
                    }
                    else -> {
                        buttonNext.text = getText(R.string.next)
                        buttonNext.setTextColor(
                            ContextCompat.getColor(
                                this@OnBoardingActivity,
                                R.color.button_active_text_color
                            )
                        )
                        buttonNext.strokeWidth = 0
                        buttonNext.backgroundTintList =
                            ColorStateList.valueOf(ContextCompat.getColor(this@OnBoardingActivity, R.color.button_active_bg_color))


                    }
                }
            }

            override fun onPageScrolled(arg0: Int, arg1: Float, arg2: Int) {

            }
            override fun onPageScrollStateChanged(arg0: Int) {

            }
        })

        buttonSkip.click {
            mViewModel.skipClick()
        }

        buttonNext.click {
            mViewModel.nextClick()

        }
    }

    private fun getItem(position: Int): Int {
        return onboarding_view_pager.currentItem + position
    }
}