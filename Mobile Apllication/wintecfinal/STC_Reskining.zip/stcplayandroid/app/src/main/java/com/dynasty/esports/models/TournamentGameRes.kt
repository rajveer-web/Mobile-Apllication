package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class TournamentGameRes {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("messageCode")
    @Expose
    var messageCode: String? = null

    @SerializedName("data")
    @Expose
    var data: List<Datum> = ArrayList<Datum>()

    @SerializedName("totals")
    @Expose
    var totals: Totals? = null

    class BracketTypes {
        @SerializedName("simple")
        @Expose
        var simple = false

        @SerializedName("double")
        @Expose
        var _double = false

        @SerializedName("single")
        @Expose
        var single = false

        @SerializedName("round_robin")
        @Expose
        var roundRobin = false

        @SerializedName("battle_royale")
        @Expose
        var battleRoyale = false
    }

    class Datum {
        var isSelected: Boolean = false

        @SerializedName("activeTournament")
        @Expose
        var activeTournament: String? = null

        @SerializedName("status")
        @Expose
        var status = 0

        @SerializedName("order")
        @Expose
        var order = 0

        @SerializedName("platform")
        @Expose
        var platform: List<Platform> = ArrayList()

        @SerializedName("_id")
        @Expose
        var id: String = ""

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("slug")
        @Expose
        var slug: String? = null

        @SerializedName("logo")
        @Expose
        var logo: String? = null

        @SerializedName("image")
        @Expose
        var image: String = ""

        @SerializedName("bracketTypes")
        @Expose
        var bracketTypes: BracketTypes? = null

        @SerializedName("isTournamentAllowed")
        @Expose
        var isTournamentAllowed = false

        @SerializedName("updatedBy")
        @Expose
        var updatedBy: String? = null

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("srtatus")
        @Expose
        var srtatus = 0

        @SerializedName("__v")
        @Expose
        var v = 0

        @SerializedName("createdBy")
        @Expose
        var createdBy: String? = null
    }

    class Platform {
        var isSelected: Boolean = false

        @SerializedName("createdBy")
        @Expose
        var createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
        var updatedBy: String? = null

        @SerializedName("status")
        @Expose
        var status: String? = null

        @SerializedName("_id")
        @Expose
        var id: String = ""

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null
    }

    class Totals {
        @SerializedName("count")
        @Expose
        var count = 0
    }

}