package com.dynasty.esports.models

import com.google.gson.JsonObject
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

data class AllTournamentJson(
    var queryUpcoming: JsonObject,
    var queryOngoing: JsonObject,
    var pagination: JsonObject
)