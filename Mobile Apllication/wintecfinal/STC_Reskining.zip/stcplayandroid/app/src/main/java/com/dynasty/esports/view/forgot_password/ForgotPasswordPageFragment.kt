package com.dynasty.esports.view.forgot_password

import android.content.Context
import com.dynasty.esports.view.common.BaseFragment

abstract class ForgotPasswordPageFragment : BaseFragment()  {

    protected var mForgotPasswordWizard: ForgotPasswordWizard? = null
//    lateinit var pageAdapterCreateTournament: CreateTournamentPagerAdapter
    protected abstract fun getPageType(): ForgotPasswordMobileActivity.ForgotPasswordWizardPageType

    abstract fun onNextButtonClick()

    protected abstract fun shouldEnableButton(): Boolean

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mForgotPasswordWizard = activity as ForgotPasswordWizard?
    }

}