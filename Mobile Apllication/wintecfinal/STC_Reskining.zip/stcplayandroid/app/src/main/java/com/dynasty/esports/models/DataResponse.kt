package com.dynasty.esports.models

data class DataResponse (
    val token : String,
    val id: String
)