package com.dynasty.esports.view.settings


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterUserContentDataBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.ProfileContentModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this class will show content data for different categories
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class ContentDataAdapter(
    private var contentDataList: MutableList<ProfileContentModel.ContentModel>,
    private var chooseList: MutableList<String>,
    private val onItemClick: (Int,String) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterUserContentDataBinding>>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindingHolder<AdapterUserContentDataBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_user_content_data,
                parent,
                false
            )
        )

    }

    /**
     * @desc content Data array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return contentDataList.size
    }


    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterUserContentDataBinding>,
        position: Int
    ) {
        val data = contentDataList[holder.adapterPosition]

        if (chooseList.contains(data.id.toString())) {
            holder.binding.imageViewSelect.beVisible()
        } else {
            holder.binding.imageViewSelect.beGone()
        }

        holder.binding.textViewGameName.text = data.name?.let { it } ?: ""
        holder.itemView.context.loadImageFromServer(
            data.image.toString(),
            holder.binding.imageViewGame
        )

        holder.binding.topcardview.click {
            onItemClick(holder.adapterPosition,data.id.toString())
        }

    }


    /**
     *@desc Update preference list
     * @param position - adapter position
     * @param id- categories id
     */
    fun updateSelection(position: Int, id: String) {
        if (chooseList.contains(id)) {
            chooseList.remove(id)
        } else {
            chooseList.add(id)
        }
        notifyItemChanged(position)
    }

}