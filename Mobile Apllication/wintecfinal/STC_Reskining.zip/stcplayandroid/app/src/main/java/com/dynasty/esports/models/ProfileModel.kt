package com.dynasty.esports.models

import android.graphics.drawable.Drawable

data class ProfileModel (
    var title:String="",
    var isExpandable:Boolean=false,
    var isExpand:Boolean=false,
    var expandListData:MutableList<SubProfileOptionModel> = mutableListOf(),
    var drawable: Drawable? = null

)