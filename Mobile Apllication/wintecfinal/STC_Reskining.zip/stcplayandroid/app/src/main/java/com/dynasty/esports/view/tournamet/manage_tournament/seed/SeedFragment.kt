package com.dynasty.esports.view.tournamet.manage_tournament.seed

import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ParticipantsModel
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.tournamet.manage_tournament.ManagedTournamentActivity
import com.dynasty.esports.viewmodel.UpcomingParticipantsViewModel
import kotlinx.android.synthetic.main.fragment_seed.*
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*
import kotlin.collections.ArrayList


class SeedFragment : BaseFragment(),
    ConnectivityReceiver.ConnectivityReceiverListener {
    private val mViewModel: UpcomingParticipantsViewModel by viewModel()
    private var connectivityReceiver = ConnectivityReceiver()
    private var isSeeded:Boolean=false
    private var seedAdapter: SeedAdapter? = null
    private var participantsList: MutableList<ParticipantsModel.DataModel> = mutableListOf()
    private var id: String = ""
    private var tempSeed: MutableList<Int> = mutableListOf()
    private var tournamentType: String = ""
    private var isSave = false
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_seed, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            id = this.getString("id").toString()
            isSeeded=this.getBoolean("isSeeded")
            tournamentType = this.getString("tournamentType").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        seedAdapter = SeedAdapter(tournamentType)
        commonRecyclerView.adapter = seedAdapter


        webViewSeed.webViewClient = MyWebChromeClient()
        webViewSeed.settings.useWideViewPort = false
        webViewSeed.settings.javaScriptEnabled = true
        webViewSeed.settings.javaScriptCanOpenWindowsAutomatically = true
        webViewSeed.settings.loadWithOverviewMode = true
        webViewSeed.settings.builtInZoomControls = true
        webViewSeed.settings.setSupportZoom(true)
        webViewSeed.settings.displayZoomControls=false
        webViewSeed.isNestedScrollingEnabled=true


//        webViewSeed.settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
        webViewSeed.setBackgroundColor(Color.TRANSPARENT)


        if(isSeeded){
            constraintLayoutButtons.beGone()
            constraintLayoutData.beGone()
            webViewSeed.beVisible()
            webViewSeed.loadUrl(makeURLForWebView())

        }

        listenToViewModel()
        viewClickListener()
    }

    private fun viewClickListener() {
        textViewFilter.click {
            val filterOptionsList: MutableList<Spinner> = mutableListOf()
            filterOptionsList.add(Spinner("0", resources.getString(R.string.all_players)))
            filterOptionsList.add(Spinner("1", resources.getString(R.string.checked_in_only)))
            requireActivity().showSpinner(
                resources.getString(R.string.filter),
                textViewFilter,
                filterOptionsList,
                false,
                onItemClick = {
                    val data = it as Spinner
                    if (data.ID == "0") {
                        seedAdapter?.apply {
                            filterTeam(false)
                        }
                    } else {
                        seedAdapter?.apply {
                            filterTeam(true)
                        }
                    }
                })
        }
        textViewSeedType.click {
            val filterOptionsList: MutableList<Spinner> = mutableListOf()
            filterOptionsList.add(Spinner("0", resources.getString(R.string.by_registration_order)))
            filterOptionsList.add(Spinner("1", resources.getString(R.string.str_random)))
            requireActivity().showSpinner(
                resources.getString(R.string.filter),
                textViewSeedType,
                filterOptionsList,
                false,
                onItemClick = {
                    val data = it as Spinner
                    if (data.ID == "0") {
                        participantsList.forEachIndexed { index, dataModel ->
                            if (index != 0)
                                dataModel.seed = index
                        }
                        seedAdapter?.apply {
                            notifyDataSetChanged()
                        }

                    } else {
                        val randomList = getRandomNonRepeatingIntegers(1, participantsList.size - 1)
//                        randomList.add(0,-1)

                        participantsList.forEachIndexed { index, dataModel ->
                            if (index != 0)
                                dataModel.seed = randomList[index - 1]
                        }
                        seedAdapter?.apply {
                            notifyDataSetChanged()
                        }
                    }
                })
        }

        textViewShuffle.click {
            val suffleList = shuffleArrayList()
            participantsList.forEachIndexed { index, dataModel ->
                if (index != 0)
                    dataModel.seed = suffleList[index - 1]
            }
            seedAdapter?.apply {
                notifyDataSetChanged()
            }
        }

        textViewReset.click {
            participantsList.forEachIndexed { index, dataModel ->
                if (index != 0)
                    dataModel.seed = tempSeed[index - 1]
            }
            seedAdapter?.apply {
                notifyDataSetChanged()
            }
        }

        buttonCreateBracket.click {
            if (buttonCreateBracket.text.toString()
                    .toLowerCase() == resources.getString(R.string.confirm).toLowerCase()
            ) {


                displayCustomAlertDialog(title = resources.getString(R.string.generate_brackerts),
                    desc = resources.getString(R.string.generate_bracket_des_msg),
                    positiveText = resources.getString(
                        R.string.generate
                    ),
                    negativeText = resources.getString(R.string.str_cancel),
                    positiveClick = {
                        it.dismiss()
                        mViewModel.makeQueryForFinishMatch(id)
                    },
                    negativeClick = {
                        it.dismiss()
                    },
                    isCancelable = true,
                    isCloseShow = true,
                    onCloseClick = {
                        it.dismiss()
                    })


            } else {
                if (checkSeedValueRepeatOrNot()) {
                    resources.getString(R.string.seed_id_duplicate).showToast(requireContext())
                } else {
                    if (seedAdapter?.getAll()!!.size > 2) {
                        if (checkSeedValueIsZero()) {
                            resources.getString(R.string.assign_seed_id).showToast(requireContext())
                        } else {

                            if ((requireActivity() as ManagedTournamentActivity).participantsLimit >= seedAdapter?.getAll()!!.size - 1) {
                                mViewModel.makeJsonForParticipantsUpdate(seedAdapter?.getAll()!!)
                            } else {
                                resources.getString(R.string.participants_limit_error)
                                    .showToast(requireContext())
                            }
                        }
                    } else {
                        resources.getString(R.string.tournament_paricipants_less_than_2)
                            .showToast(requireContext())
                    }

                }
            }

        }

        buttonSaveAll.click {
            if (buttonSaveAll.text.toString()
                    .toLowerCase() == resources.getString(R.string.str_edit).toLowerCase()
            ) {
                webViewSeed.beGone()
                constraintLayoutData.beVisible()
                buttonSaveAll.text = resources.getString(R.string.save_all)
                buttonCreateBracket.text = resources.getString(R.string.create_bracket)
            } else {
                if (checkSeedValueRepeatOrNot()) {
                    resources.getString(R.string.seed_id_duplicate).showToast(requireContext())
                } else {
                    if (seedAdapter?.getAll()!!.size > 2) {
                        if (checkSeedValueIsZero()) {
                            resources.getString(R.string.assign_seed_id).showToast(requireContext())
                        } else {
                            isSave = true
                            mViewModel.makeJsonForParticipantsUpdate(seedAdapter?.getAll()!!)
                        }
                    } else {
                        resources.getString(R.string.tournament_paricipants_less_than_2)
                            .showToast(requireContext())
                    }
                }
            }

        }

    }

    private fun listenToViewModel() {
        mViewModel.makeJsonObjectForFinishMatch.observe(viewLifecycleOwner, {
            launchProgressDialog()
            mViewModel.finishMatch(it)
        })


        mViewModel.makeJsonObjectForParticipantsUpdate.observe(viewLifecycleOwner, {
            if (!it.toString().isNullOrEmpty()) {
                launchProgressDialog()
                mViewModel.updateAllParticipants(it)
            }
        })

        mViewModel.makeJsonObjectForParticipantsQuery.observe(viewLifecycleOwner, {
            mViewModel.getApproveParticipantsList(it.toString())
        })

        mViewModel.participantsListSuccessResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
            it.data?.apply {
                participantsList.clear()
                tempSeed.clear()
                participantsList.addAll(this)
                participantsList.forEach {
                    tempSeed.add(it.seed!!)
                }
                participantsList.add(0, ParticipantsModel.DataModel())

                seedAdapter?.apply {
                    addAll(participantsList)
                }

                if (participantsList.size > 1) {
                    if(!isSeeded) {
                        constraintLayoutButtons.beVisible()
                        webViewSeed.beGone()
                        commonRecyclerView.beVisible()
                        constraintLayoutFilter.beVisible()
                        constraintLayoutNoData.beGone()
                        constraintLayoutNoInternet.beGone()
                    }
                } else {
                    constraintLayoutButtons.beGone()
                    webViewSeed.beGone()
                    commonRecyclerView.beGone()
                    constraintLayoutFilter.beGone()
                    constraintLayoutNoData.beVisible()
                    constraintLayoutNoInternet.beGone()
                    textViewNoData.text = resources.getString(R.string.no_participants_approved_yet)
                }
            }
        })

        mViewModel.participantsListErrorResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
        })

        mViewModel.updateParticipantsSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            if (isSave) {
                isSave = false
            } else {
                webViewSeed.beVisible()
                constraintLayoutData.beGone()

                webViewSeed.loadUrl(makeURLForWebView())

                when(buttonCreateBracket.text.toString().toLowerCase()){
                    resources.getString(R.string.confirm).toLowerCase()->{
                        val bundle = Bundle()
                        bundle.putString("type", "past")
                        val intent = Intent(AppConstants.NOTIFY_ACTION)
                        intent.putExtras(bundle)
                        LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

                        val bundleReload = Bundle()
                        bundleReload.putString("type", "reload")
                        val intentReload = Intent(AppConstants.NOTIFY_ACTION)
                        intentReload.putExtras(bundleReload)
                        LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intentReload)
                    }
                }


                    buttonSaveAll.text = resources.getString(R.string.str_edit)
                    buttonCreateBracket.text = resources.getString(R.string.confirm)

            }
        })

        mViewModel.updateParticipantsErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })
    }


    companion object {
        fun newInstance(id: String, tournamentType: String,isSeeded:Boolean): Fragment {
            val args = Bundle()
            args.putString("tournamentType", tournamentType)
            args.putString("id", id)
            args.putBoolean("isSeeded",isSeeded)
            val fragment = SeedFragment()
            fragment.arguments = args
            return fragment
        }
    }

    // Register receiver for check internet connection
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    // Unregister receiver for internet connection
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    // Prevent to API call from view model
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    // Manage internet connection using receiver
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected) {
            mViewModel.makeJsonForApproveParticipantsStatus(id, "approved")
        }
    }

    private fun shuffleArrayList(): MutableList<Int> {
        val randomNumberList: MutableList<Int> = mutableListOf()

        seedAdapter?.getAll()?.forEachIndexed { index, dataModel ->
            if (index != 0)
                randomNumberList.add(index)
        }

        randomNumberList.shuffle()



        return randomNumberList
    }

    private fun getRandomNonRepeatingIntegers(
        min: Int, max: Int
    ): MutableList<Int> {
        val numbers = ArrayList<Int>()
        while (numbers.size < max) {
            val random: Int = getRandomInt(min, max)
            if (!numbers.contains(random)) {
                numbers.add(random)
            }
        }
        return numbers
    }

    private fun getRandomInt(min: Int, max: Int): Int {
        return Random().nextInt(max - min + 1) + min
    }

    private fun checkSeedValueRepeatOrNot(): Boolean {
        val tempList: MutableList<ParticipantsModel.DataModel> = mutableListOf()
        tempList.addAll(seedAdapter?.getAll()!!)
        tempList.removeAt(0)

        tempList.forEachIndexed { index, dataModel ->
            for (j in index + 1 until tempList.size) {
                if (dataModel.seed == tempList[j].seed) {
                    return true
                }
            }
        }
        return false
    }

    private fun checkSeedValueIsZero(): Boolean {
        val tempList: MutableList<ParticipantsModel.DataModel> = mutableListOf()
        tempList.addAll(seedAdapter?.getAll()!!)
        tempList.removeAt(0)

        tempList.forEachIndexed { index, dataModel ->
            if (dataModel.seed == 0) {
                return true
            }

        }
        return false
    }

    inner class MyWebChromeClient : WebViewClient() {

        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            view?.loadUrl(request?.url.toString());
            return true
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            progressBarWeb?.apply {
                progressBarWeb.beVisible()
            }
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            progressBarWeb?.apply {
                progressBarWeb.beGone()
            }
        }


    }

    private fun makeURLForWebView():String{
        val stringBuilder = StringBuilder()
        stringBuilder.append(BuildConfig.SEED_WEBVIEW_PATH)
            .append("bracket-web-view")
            .append(
                "?"
            ).append("_id").append("=").append(id)
            .append("&").append("token").append(sharedPreferences.accessToken)
            .append("&").append("allowSeeding").append("=").append("true")
            .append("&").append("admin").append("=").append("true")

        return  stringBuilder.toString()


    }
//    private fun checkValueExists(index:Int, seed:Int):Int{
//        participantsList.forEachIndexed { pos, dataModel ->
//            if(index!=pos){
//                if(seed==dataModel.seed){
//                    return 1
//                }
//            }
//        }
//        return 0
//    }

}