package com.dynasty.esports.view.chat


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterChatListBinding
import com.dynasty.esports.databinding.AdapterInboxBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.InboxModel
import com.dynasty.esports.models.MatchsListModel
import com.dynasty.esports.utils.BindingHolder
import kotlin.reflect.KFunction0

/**
 * @desc this is class will be display inbox data
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ChatListAdapter(
    private var matchesList: MutableList<MatchsListModel>,
    private val onItemClick:(String,String) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterChatListBinding>>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterChatListBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_chat_list,
                parent,
                false)
        )

    }

    /**
     * @desc inboxList array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return matchesList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterChatListBinding>,
        position: Int
    ) {

        holder.binding.textViewUserName.text=matchesList[position].tournamentId?.name
        holder.itemView.click {
            onItemClick(matchesList[position].id.toString(),matchesList[position].tournamentId?.id.toString())
        }

    }


}