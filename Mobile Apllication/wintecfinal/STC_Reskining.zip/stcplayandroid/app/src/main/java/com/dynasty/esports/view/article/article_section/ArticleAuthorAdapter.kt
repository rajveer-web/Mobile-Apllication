package com.dynasty.esports.view.article.article_section


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterArticlesVideosBinding
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.RowAuthorListArticleBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.ArticleAuthorsModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.view.common.LoadingViewHolder
import kotlin.concurrent.thread

/**
 * @desc this is class will handle list of article author
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ArticleAuthorAdapter constructor(
    private var authorList: MutableList<ArticleAuthorsModel.DataModel>,
    private val onItemClick: (String, String) -> Unit = { _,_ -> }
) :     RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: RowAuthorListArticleBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.row_author_list_article,
                        parent,
                        false
                    )
                return ViewHolderAuthor(binding)
            }
            else -> {
                val binding: ItemLoadMoreBinding =
                    DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
                return LoadingViewHolder(binding)
            }

        }
    }

//    override fun onCreateViewHolder(
//        parent: ViewGroup,
//        viewType: Int
//    ): BindingHolder<RowAuthorListArticleBinding> {
//        val binding: RowAuthorListArticleBinding = DataBindingUtil.inflate(
//            LayoutInflater.from(parent.context),
//            R.layout.row_author_list_article,
//            parent,
//            false
//        )
//        return BindingHolder(binding)
//
//    }
    /**
     * @desc authors array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return authorList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (authorList[position].isLoadMore) {
            1
        } else {
            0
        }
    }


    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderAuthor).bind(authorList[position])
            }
            else -> {
                (holder as LoadingViewHolder).progressBar.isIndeterminate = true
            }
        }
    }

    /**
     *@desc This call use for display Video data
     */
    inner class ViewHolderAuthor(private var binding: RowAuthorListArticleBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: ArticleAuthorsModel.DataModel) {
            binding.tvauthorname.text = data.fullName?.let {
                it
            } ?: "-"
            binding.totalarticle.text = data.articleCount?.let {
                it.toString().plus(" ")
                    .plus(itemView.context.resources.getString(R.string.articles))
            } ?: "0".plus(" ").plus(itemView.context.resources.getString(R.string.articles))


            data.profilePicture?.apply {
                if (this != "") {
                    itemView.context.loadImageFromServer(this, binding.ivauthor)
                }
            }

            binding.ivauthor.click {
                onItemClick(data.id.toString(),data.fullName.toString())
            }
        }

    }



}