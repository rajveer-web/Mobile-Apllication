package com.dynasty.esports.view.tournamet.joined_tournamet
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.models.ArticlePostList


class JoinedTournamentFragment : Fragment()  {

    lateinit var joinedTournamentAdapter: JoinedTournamentAdapter
    lateinit var tournamentRecyclerView: RecyclerView
    var dataList: ArrayList<ArticlePostList> = ArrayList<ArticlePostList>()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment


        val v=inflater.inflate(R.layout.fragment_joinedtournament, container, false)
        dataList.clear()
        dataList.add(
            ArticlePostList(
                "1",
                "Best Performer",
                "",
                "2nd Quarter",
                "December2019",
                "url"
            )
        )
        dataList.add(
            ArticlePostList(
                "1",
                "Best Performer",
                "",
                "2nd Quarter",
                "December2019",
                "url"
            )
        )
        dataList.add(
            ArticlePostList(
                "1",
                "Best Performer",
                "",
                "2nd Quarter",
                "December2019",
                "url"
            )
        )
        dataList.add(
            ArticlePostList(
                "1",
                "Best Performer",
                "",
                "2nd Quarter",
                "December2019",
                "url"
            )
        )

        tournamentRecyclerView=v.findViewById(R.id.TournamentRecyclerView)
        val relatedLayoutManager = LinearLayoutManager(activity?.applicationContext!!,LinearLayoutManager.VERTICAL,false)
        tournamentRecyclerView.layoutManager = relatedLayoutManager
        joinedTournamentAdapter =
            JoinedTournamentAdapter(
                activity?.applicationContext!!,
                dataList
            )

        tournamentRecyclerView.adapter = joinedTournamentAdapter


        return v
    }


    companion object


}