package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 24-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BasicInfoViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
    val updateSpinnerItem = MutableLiveData<Pair<Int,ArrayList<Spinner>>>()
    val updateUserSuccessResponse= MutableLiveData<ResponseBody>()
    val updateUserErrorResponse= MutableLiveData<ResponseBody>()
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()
    val makeJsonForUpdateUser=MutableLiveData<JsonObject>()

    /**
     * @desc Method will use for update spinner adapter and update spinner UI.
     * @param type- spinner type
     * @param array- spinner array
     */
    fun updateSpinnerValueAndUI(type:Int,array: ArrayList<Spinner>){
        updateSpinnerItem.postValue(Pair(type,array))
    }

    /**
     * @desc Method will use for call update user API.
     * @param jsonObject- update user parameter json object
     */
    fun updateUser(jsonObject: JsonObject){
        viewModelScope.launch(apiException("update") + Dispatchers.Main) {
            val response = restInterface.updateUser(jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateUserSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE->{
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    updateUserErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * @desc Method will use check form validation.
     * @param name- user name
     * @param marital- user marital status
     * @param country- user country
     * @param country- user state
     * @param postalCode- user postal code
     */
    fun checkValidationForm(name:String,country: String,state: String,postalCode:String){
        when{
            name.isFieldEmpty()->validationLiveData.postValue(1)

            country.isFieldEmpty()->validationLiveData.postValue(3)
            state.isFieldEmpty()->validationLiveData.postValue(4)
            postalCode.isFieldEmpty()->validationLiveData.postValue(5)
            else->isFormValid.postValue(true)
        }
    }

    /**
     * @desc Method will use for crete json object for update user API.
     * @param fullName- user name
     * @param profile- user profile
     * @param professional- user professional
     * @param gender- gender type
     * @param parental- parental status
     * @param dob- user date of birth
     * @param marital- user marital status
     * @param country- user country
     * @param country- user state
     * @param postalCode- user postal code
     * @param bio- user bio
     */
    fun makeJsonForUpdateUser(fullName:String,profile:String, gender:String,
                              dob:String,country:String,
                              state:String,postalCode:String,bio:String){
        val rootObject=JsonObject()
        rootObject.addProperty("fullName",fullName)
        if(profile!="") {
            rootObject.addProperty("profilePicture", profile)
        }
//        rootObject.addProperty("martialStatus",marital)
//        rootObject.addProperty("profession",professional)
        rootObject.addProperty("gender",gender)
//        rootObject.addProperty("parentalStatus",parental)
        rootObject.addProperty("dob",dob)
        rootObject.addProperty("country",country)
        rootObject.addProperty("state",state)
        rootObject.addProperty("postalCode",postalCode)
        rootObject.addProperty("shortBio",bio)
        rootObject.addProperty("updatedBy","user")
        makeJsonForUpdateUser.postValue(rootObject)
    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }



}
