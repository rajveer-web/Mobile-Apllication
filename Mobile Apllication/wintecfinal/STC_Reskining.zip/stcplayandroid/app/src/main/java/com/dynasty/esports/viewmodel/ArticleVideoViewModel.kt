package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.VideosModel
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import org.json.JSONObject

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class ArticleVideoViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    // define MutableLiveData for emit observer
//    val articleTrendingResponse = MutableLiveData<HottestPostArticleModel>()
//    val articleAuthorResponse = MutableLiveData<ArticleAuthorsModel>()
//    val articlePostByGamesResponse = MutableLiveData<GamesModel>()
    val latestVideoSuccessResponse = MutableLiveData<VideosModel>()
    val latestVideoErrorResponse = MutableLiveData<ResponseBody>()
    val makeJsonForArticleData = MutableLiveData<JSONObject>()


    /**
     * @desc Method will use for call API and get data for article tab[Article Trending post,Authors,Post Games,Latest Video]
     * @param jsonObjectVideo- video parameter json object
     */
    fun getAllArticleVideos(jsonObjectVideo: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getLatestVideo(jsonObjectVideo)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    latestVideoSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    latestVideoErrorResponse.postValue(response.errorBody())
                }
            }

        }

    }

    /**
     * @desc Method will use for create json object for video parameter.
     */
    fun makeJsonForVideoParameter(page: Int) {
        val jsonObject = JSONObject()
        jsonObject.put("page", page)
        jsonObject.put("limit", 10)
        jsonObject.put("sort", "-updatedOn")
        makeJsonForArticleData.postValue(jsonObject)
    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
