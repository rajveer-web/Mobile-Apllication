package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ArticleCommentModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null


    class  DataModel{
        @SerializedName("comments")
        @Expose
         val comments: MutableList<ArticleComment>? = null

        @SerializedName("article")
        @Expose
         val article: ArticleModel? = null
    }

    class ArticleComment{
        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("comment")
        @Expose
         val comment: String? = null

        @SerializedName("userId")
        @Expose
         val userId: String? = null

        @SerializedName("objectId")
        @Expose
         val objectId: String? = null

        @SerializedName("objectType")
        @Expose
         val objectType: String? = null

        @SerializedName("modifiedOn")
        @Expose
         val modifiedOn: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("userDetails")
        @Expose
         val userDetails: HottestPostArticleModel.UserDetailsModel? = null

        @SerializedName("id")
        @Expose
         val id: String? = null

        @SerializedName("type")
        @Expose
        var type: Int? = null

        @SerializedName("likeId")
        @Expose
         var likeId: String? = null

        @SerializedName("totalLikes")
        @Expose
         var totalLikes: Int? = null

        @SerializedName("replies")
        @Expose
        var replies: MutableList<ArticleComment>? = null

        var isReply=false
        var isViewVisible=false
    }

    class ArticleModel{
        @SerializedName("totalLikes")
        @Expose
         val totalLikes: Int? = null

        @SerializedName("type")
        @Expose
         val type: Int? = null

        @SerializedName("likeId")
        @Expose
         val likeId: String? = null
    }

    class RepliesModel{
        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("comment")
        @Expose
         val comment: String? = null

        @SerializedName("userId")
        @Expose
         val userId: String? = null

        @SerializedName("objectId")
        @Expose
         val objectId: String? = null

        @SerializedName("objectType")
        @Expose
         val objectType: String? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("modifiedOn")
        @Expose
         val modifiedOn: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("userDetails")
        @Expose
         val userDetails:  HottestPostArticleModel.UserDetailsModel? = null

        @SerializedName("id")
        @Expose
         val id: String? = null

        @SerializedName("type")
        @Expose
         val type: Int? = null

        @SerializedName("likeId")
        @Expose
         val likeId: Int? = null

        @SerializedName("totalLikes")
        @Expose
         val totalLikes: Int? = null
    }
    

    
}