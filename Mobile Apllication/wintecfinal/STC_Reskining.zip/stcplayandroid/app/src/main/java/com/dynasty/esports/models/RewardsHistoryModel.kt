package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class RewardsHistoryModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    class DataModel{
        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("user")
        @Expose
         val user: String? = null

        @SerializedName("type")
        @Expose
         val type: String? = null

        @SerializedName("reward_type")
        @Expose
         val rewardType: String? = null

        @SerializedName("description")
        @Expose
         val description: String? = null

        @SerializedName("reward_value")
        @Expose
         val rewardValue: Int? = null

        @SerializedName("reward_balance")
        @Expose
         val rewardBalance: Int? = null

        @SerializedName("platform")
        @Expose
         val platform: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
         val updatedBy: String? = null

        @SerializedName("expiredOn")
        @Expose
         val expiredOn: String? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null
    }
}