package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class VerifyResponse (
    @field: SerializedName("message")
    var message: String? = null,
    @field: SerializedName("error")
    var error: String? = null
)