package com.dynasty.esports.view.tournamet.publish_tournament

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CreateTournament
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.payment.PaymentTournamentActivity
import com.dynasty.esports.view.tournamet.createtournament.SponsorListAdapter
import com.dynasty.esports.viewmodel.PublishTournamentViewModel
import com.google.android.material.appbar.AppBarLayout
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_managed_tournament.*
import kotlinx.android.synthetic.main.activity_publish_tournament.*
import kotlinx.android.synthetic.main.article_app_bar_layout.toolbar
import kotlinx.android.synthetic.main.publish_tournament_app_bar_layout.*
import kotlinx.android.synthetic.main.publish_tournament_app_bar_layout.appBarLayout
import kotlinx.android.synthetic.main.publish_tournament_app_bar_layout.collapsingToolbar
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*


open class PublishTourmamentActivity : BaseActivity() {

    private var isForEdit: Boolean = false
    private val mViewModel: PublishTournamentViewModel by viewModel()

    private lateinit var sponsorListAdapter: SponsorListAdapter

    private var loginUserModel: UserModel.UserData? = null

    private lateinit var createTournamentSaved: CreateTournament

    private var totalPrize = 0
    private var totalAmt = 0
    private var dynastyFee = 0
    private var tournamentId: String = ""
    private var createdName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_publish_tournament)
        initIntentParams()
        initialize()
        listenToViewModel()
        fillData()
    }

    private fun initIntentParams() {
        try {
            if (intent.extras != null) {
                if (intent.extras!!.containsKey("tournamentId")) {
                    tournamentId = intent.getStringExtra("tournamentId")
                }
                if (intent.extras!!.containsKey("isForEdit")) {
                    isForEdit = intent.getBooleanExtra("isForEdit", false)
                }
                if (intent.extras!!.containsKey("name")) {
                    createdName = intent.getStringExtra("name")!!
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initialize() {
        toolbar.title = ""
        setSupportActionBar(toolbar)
        appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                Math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbar.title = createTournamentSaved.name
                }
                else -> {
                    collapsingToolbar.title = ""
                    // Expanded
                }
            }
        })

//      initialize adapter
        sponsorListAdapter = SponsorListAdapter()

//        get logindata from sharedPreferences
        loginUserModel =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData


//      get createTournamentSaved data from sharedPreferences
        createTournamentSaved = sharedPreferences.get<CreateTournament>("createTournamentSave")!!


//      rvSponcor list recyclerview initialize
        rvSponcor.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        rvSponcor.adapter = sponsorListAdapter


//      btnPayment click
        btnPayment.click {
            if (createTournamentSaved.isPrize) {
                val bundle = Bundle()
                bundle.putString("tournamentId", tournamentId)
                startActivityInline<PaymentTournamentActivity>(bundle)
            } else {
                launchProgressDialog()
                debugE("jsonObject £", Gson().toJson(getJsonForApi()))
                if (isForEdit) {
                    mViewModel.editTournament(getJsonForApi(), tournamentId)
                } else {
                    mViewModel.createTournament(getJsonForApi(), tournamentId)
                }
            }
        }
    }

    private fun listenToViewModel() {

//      createTournamentSuccessResponse
        mViewModel.createTournamentSuccessResponse.observe(this, Observer {
            debugE("createTournamentPublishResponse", Gson().toJson(it))
            showPublishSuccessDialog(it.message!!, false)
        })

//      createTournamentErrorResponse
        mViewModel.createTournamentErrorResponse.observe(this, Observer {
            debugE("createTournamentPublishErrorResponse", it.string())
            try {
                showPublishSuccessDialog("", true)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            dismissProgressDialog()
        })
    }

    //  Set data to each field from saved data
    private fun fillData() {
        tvTournamamentName.text = createTournamentSaved.name
        tvPublishTournamentGame.text = createTournamentSaved.gameName
        tvPublishWhen.text = createTournamentSaved.startDate
        loadImageFromServer(createTournamentSaved.banner, imgBanner)
        loadImageFromServer(createTournamentSaved.gameLogo, game_image)

        if (createTournamentSaved.isCheckInRequired) {
            llCheckInRequired.beVisible()
            if (isForEdit) {
                tvTournamamentCheckIn.text =
                    createTournamentSaved.checkInStartDate!!
            } else {
                tvTournamamentCheckIn.text =
                    createTournamentSaved.checkInStartDate!!.convertDateToRequireDateFormat(
                        AppConstants.API_DATE_FORMAT,
                        "d MMM YYYY h:mma"
                    )
            }

        } else {
            llCheckInRequired.beGone()
        }

        tvCreatedBy.text =
            resources.getString(R.string.by).plus(" ").plus(loginUserModel!!.fullName)

        if (createTournamentSaved.participantType.equals("team", true)) {
            tvTournamamentType.text = resources.getString(R.string.team)
        } else {
            tvTournamamentType.text = resources.getString(R.string.one_vs_one)
        }

        if (createTournamentSaved.isPaid) {
            tvTournamamentRegType.text = resources.getString(R.string.paid_registartion_txt)
        } else {
            tvTournamamentRegType.beGone()
        }

        if (createTournamentSaved.regionsAllowed.isNotEmpty()) {
            tvRegion.text = implode(createTournamentSaved.regionsAllowed as ArrayList<String>)
        }

        when {
            createTournamentSaved.tournamentType.equals("online", true) -> {
                tvTournamentType.text = resources.getString(R.string.online)
            }
            createTournamentSaved.tournamentType.equals("offline", true) -> {
                tvTournamentType.text = resources.getString(R.string.offline)
            }
            else -> {
                tvTournamentType.text = resources.getString(R.string.hybrid)
            }
        }

        if (createTournamentSaved.bracketType.equals("single", true)) {
            tvBracketFormat.text = resources.getString(R.string.single_elimination)
        } else if (createTournamentSaved.bracketType.equals("double", true)) {
            tvBracketFormat.text = resources.getString(R.string.double_elimination)
        } else if (createTournamentSaved.bracketType.equals("round_robin", true)) {
            tvBracketFormat.text = resources.getString(R.string.round_robin_txt)
        } else if (createTournamentSaved.bracketType.equals("battle_royale", true)) {
            tvBracketFormat.text = resources.getString(R.string.battle_royale_txt)
        }

        if (createTournamentSaved.prizeList.isNotEmpty()) {
            for (i in 0 until createTournamentSaved.prizeList.size) {
                when (i) {
                    0 -> {
                        tvPublishFirstPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    1 -> {
                        tvPublishSecondPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    2 -> {
                        tvPublishThirdPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    3 -> {
                        card_fourthprize.visibility = View.VISIBLE
                        tvPublishFourthPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    4 -> {
                        card_fifthprize.visibility = View.VISIBLE
                        tvPublishFifthPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    5 -> {
                        card_sixthprize.visibility = View.VISIBLE
                        tvPublishSixthPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                }
            }
        }
//        tvPublishFirstPrice.text =
//            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.firstPrize.toString()
//        tvPublishSecondPrice.text =
//            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.secondPrize.toString()
//        tvPublishThirdPrice.text =
//            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.thirdPrize.toString()

        tvDynastyFees.text = ""
        tvTotalAmt.text = ""

        if (createTournamentSaved.sponsors.isEmpty()) {
            llSponcerList.beGone()
        } else {
            sponsorListAdapter.addAll(createTournamentSaved.sponsors)
        }

        if (createTournamentSaved.tournamentType.equals("hybrid", false)) {
            tvVenue.text = createTournamentSaved.venueAddressHybrid.venue
        } else {
            if (createTournamentSaved.venueAddress.isNotEmpty()) {

                var venue: String = ""

                createTournamentSaved.venueAddress.forEachIndexed { index, venueAddress ->
                    if (index == 0) {
                        venue = venueAddress.venue
                    } else {
                        venue = venue + "\n" + venueAddress.venue
                    }
                }

                tvVenue.text = venue
            }
        }

        if (createTournamentSaved.isPrize) {
            llPayment.beVisible()
            btnPayment.text = resources.getString(R.string.str_payment)
//            totalPrize =
//                createTournamentSaved.firstPrize + createTournamentSaved.secondPrize + createTournamentSaved.thirdPrize


            for (i in 0 until createTournamentSaved.prizeList.size) {
                totalPrize += createTournamentSaved.prizeList[i].value
            }

            dynastyFee = totalPrize * 20 / 100
            totalAmt = totalPrize + dynastyFee

            tvPriceAmount.text = nullSafeNA(createTournamentSaved.prizeCurrency).plus(" ")
                .plus(nullSafeNA(totalPrize.toString())).plus("/-")
            tvDynastyFees.text = nullSafeNA(createTournamentSaved.prizeCurrency).plus(" ")
                .plus(nullSafeNA(dynastyFee.toString())).plus("/-")
            tvTotalAmt.text =
                nullSafeNA(createTournamentSaved.prizeCurrency).plus(" ")
                    .plus(nullSafeNA(totalAmt.toString())).plus("/-")
        } else {
            llPayment.beGone()
            btnPayment.text = resources.getString(R.string.publish)
        }
    }

    //   Create Json for send in api
    private fun getJsonForApi(): JsonObject {
        val startDateTime = mergeDateAndTime(
            createTournamentSaved.startDate.plus('T')
                .plus(createTournamentSaved.startTime), "yyyy-MM-dd'T'hh:mma"
        )

        val endDateTime = mergeDateAndTime(
            createTournamentSaved.endDate.plus('T')
                .plus(createTournamentSaved.startTime), "yyyy-MM-dd'T'hh:mma"
        )
        val jsonObject = JsonObject()
        jsonObject.addProperty("name", createTournamentSaved.name)
        jsonObject.addProperty("url", createTournamentSaved.url)
        jsonObject.addProperty("participantType", createTournamentSaved.participantType)
        jsonObject.addProperty("startDate", startDateTime)
        jsonObject.addProperty("endDate", endDateTime)
        jsonObject.addProperty("startTime", createTournamentSaved.startTime)
        jsonObject.addProperty("isPaid", createTournamentSaved.isPaid)
        jsonObject.addProperty("description", createTournamentSaved.description)
        jsonObject.addProperty("rules", createTournamentSaved.rules)
        jsonObject.addProperty("criticalRules", createTournamentSaved.criticalRules)
        jsonObject.addProperty("isPrize", createTournamentSaved.isPrize)
        jsonObject.addProperty("faqs", createTournamentSaved.faqs)
        jsonObject.addProperty("schedule", createTournamentSaved.schedule)
        jsonObject.addProperty("isIncludeSponsor", createTournamentSaved.isIncludeSponsor)
        jsonObject.addProperty("tournamentType", createTournamentSaved.tournamentType)
        jsonObject.addProperty("isScreenshotRequired", createTournamentSaved.isScreenshotRequired)
        jsonObject.addProperty("isShowCountryFlag", createTournamentSaved.isShowCountryFlag)

        jsonObject.addProperty(
            "allowSubstituteMember",
            createTournamentSaved.isallowSubstituteMember
        )
        jsonObject.addProperty("substituteMemberSize", createTournamentSaved.substituteMemberSize)

        jsonObject.addProperty(
            "isSpecifyAllowedRegions",
            createTournamentSaved.isSpecifyAllowedRegions
        )
        jsonObject.addProperty("isParticipantsLimit", createTournamentSaved.isParticipantsLimit)
        jsonObject.addProperty("scoreReporting", createTournamentSaved.scoreReporting)
        jsonObject.addProperty("invitationLink", createTournamentSaved.invitationLink)
        jsonObject.addProperty("youtubeVideoLink", createTournamentSaved.youtubeVideoLink)
        jsonObject.addProperty("facebookVideoLink", createTournamentSaved.facebookVideoLink)
        jsonObject.addProperty("contactDetails", createTournamentSaved.contactDetails)
        jsonObject.addProperty("twitchVideoLink", createTournamentSaved.twitchVideoLink)
        jsonObject.addProperty("visibility", createTournamentSaved.visibility)
        jsonObject.addProperty("checkInEndDate", createTournamentSaved.checkInEndDate)
        jsonObject.addProperty("banner", createTournamentSaved.banner)
        jsonObject.addProperty("maxParticipants", createTournamentSaved.maxParticipants)
        jsonObject.addProperty("bracketType", createTournamentSaved.bracketType)
        jsonObject.addProperty("noOfSet", createTournamentSaved.noOfSet)
        jsonObject.addProperty("contactOn", createTournamentSaved.contactOn)
        jsonObject.addProperty("gameDetail", createTournamentSaved.gameDetail)
        if (createTournamentSaved.participantType.equals("team", true)) {
            if (createTournamentSaved.teamFormat.equals("dou", true)) {
                jsonObject.addProperty("teamSize", "2")
            } else if (createTournamentSaved.teamFormat.equals("squad", true)) {
                jsonObject.addProperty("teamSize", "4")
            } else {
                jsonObject.addProperty("teamSize", createTournamentSaved.teamSize)
            }
        }
//        jsonObject.addProperty("firstPrize", createTournamentSaved.firstPrize)
//        jsonObject.addProperty("secondPrize", createTournamentSaved.secondPrize)
//        jsonObject.addProperty("thirdPrize", createTournamentSaved.thirdPrize)

        val prizeList = JsonArray()

        for (i in createTournamentSaved.prizeList) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("name", i.name)
            jsonObject.addProperty("value", i.value)
            prizeList.add(jsonObject)
        }
        jsonObject.add("prizeList", prizeList)

        jsonObject.addProperty("prizeCurrency", createTournamentSaved.prizeCurrency)
        jsonObject.addProperty("slug", createTournamentSaved.name)
//        draft & submitted_for_approval
        jsonObject.addProperty("tournamentStatus", "submitted_for_approval")
        jsonObject.addProperty("organizerDetail", loginUserModel!!.id)
        jsonObject.addProperty("updatedBy", loginUserModel!!.id)
        jsonObject.addProperty("createdBy", loginUserModel!!.id)
        jsonObject.addProperty("checkInStartDate", createTournamentSaved.checkInStartDate)

        jsonObject.addProperty("platform", createTournamentSaved.platform)

        if (!createTournamentSaved.bracketType.equals("battle_royale", true)) {
            jsonObject.addProperty("stageMatch", createTournamentSaved.tournnamentStage)
            jsonObject.addProperty("stageMatchNoOfSet", createTournamentSaved.nextStageMatchFormat)
        }

        if (createTournamentSaved.bracketType.equals("battle_royale", true)) {
            jsonObject.addProperty("noOfTeamInGroup", createTournamentSaved.noOfTeamInGroup)
            jsonObject.addProperty(
                "noOfWinningTeamInGroup",
                createTournamentSaved.noOfWinningTeamInGroup
            )
            jsonObject.addProperty("noOfRoundPerGroup", createTournamentSaved.noOfRoundPerStage)
            jsonObject.addProperty("isKillPointRequired", createTournamentSaved.isKillPointRequired)
            jsonObject.addProperty("pointsKills", createTournamentSaved.pointPerKill)
            jsonObject.addProperty("totalStage", createTournamentSaved.noOfStages)

            val placementPointList = JsonArray()

            for (i in createTournamentSaved.placementPointList) {
                val jsonObject = JsonObject()
                jsonObject.addProperty("position", i.id)
                jsonObject.addProperty("value", i.point)
                placementPointList.add(jsonObject)
            }
            jsonObject.add("placementPoints", placementPointList)
        }

        if (createTournamentSaved.bracketType.equals("round_robin", true)) {
            jsonObject.addProperty("noOfTeamInGroup", createTournamentSaved.noOfTeamInGroup)
            jsonObject.addProperty(
                "noOfWinningTeamInGroup",
                createTournamentSaved.noOfWinningTeamInGroup
            )
            jsonObject.addProperty("noOfRoundPerGroup", createTournamentSaved.noOfRoundRR)
            jsonObject.addProperty("allowAdvanceStage", createTournamentSaved.allowAdvanceStage)
//            jsonObject.addProperty("stageBracketType", createTournamentSaved.nextStageMatchFormat)
            jsonObject.addProperty("stageMatchNoOfSet", createTournamentSaved.nextStageMatchFormat)
            jsonObject.addProperty("stageBracketType", createTournamentSaved.nextStageBracketType)
        }


//      Get the data from createTournamentSaved and prepare json for send api
        val venueAddressList = JsonArray()

        if (createTournamentSaved.tournamentType.equals("offline", false)) {
            if (createTournamentSaved.venueAddress.isNotEmpty()) {
                for (i in createTournamentSaved.venueAddress) {
                    val jsonObject = JsonObject()
                    jsonObject.addProperty("country", i.country)
                    jsonObject.addProperty("region", i.region)
                    jsonObject.addProperty("venue", i.venue)
                    jsonObject.addProperty("stage", i.stage)
                    venueAddressList.add(jsonObject)
                }
            }
        } else if (createTournamentSaved.tournamentType.equals("hybrid", false)) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("country", createTournamentSaved.venueAddressHybrid.country)
            jsonObject.addProperty("region", createTournamentSaved.venueAddressHybrid.region)
            jsonObject.addProperty("venue", createTournamentSaved.venueAddressHybrid.venue)
            jsonObject.addProperty("stage", createTournamentSaved.venueAddressHybrid.stage)
            venueAddressList.add(jsonObject)
        }

        val sponsorsList = JsonArray()

        for (i in createTournamentSaved.sponsors) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("sponsorName", i.sponsorName)
            jsonObject.addProperty("website", i.website)
            jsonObject.addProperty("playStoreUrl", i.playStoreUrl)
            jsonObject.addProperty("appStoreUrl", i.appStoreUrl)
            jsonObject.addProperty("sponsorLogo", i.sponsorLogo)
            jsonObject.addProperty("sponsorBanner", i.sponsorBanner)
            sponsorsList.add(jsonObject)
        }

        val participantsList = JsonArray()

        for (i in createTournamentSaved.participants) {
            val jsonObjectpart = JsonObject()
            jsonObjectpart.addProperty("_id", i.id)
            jsonObjectpart.addProperty("fullName", i.fullName)
            jsonObjectpart.addProperty("phoneNumber", i.phoneNumber)
            jsonObjectpart.addProperty("email", i.email)
            jsonObjectpart.addProperty("profilePicture", i.profilePicture)
            participantsList.add(jsonObjectpart)
        }

        val regList = JsonArray()

        for (i in createTournamentSaved.regionsAllowed) {
            regList.add(i)
        }

        if (venueAddressList.size() != 0) {
            jsonObject.add("venueAddress", venueAddressList)
        }
        if (sponsorsList.size() != 0) {
            jsonObject.add("sponsors", sponsorsList)
        }
//        if (participantsList.size() != 0) {
        jsonObject.add("participants", participantsList)
//        }
        if (regList.size() != 0) {
            jsonObject.add("regionsAllowed", regList)
        }

        return jsonObject
    }

    //  Clears the [ViewModel] when the [PublishTournamentViewModel] is not visible to user.
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc method will use for show success and failure dialog for join tournament
     */
    private fun showPublishSuccessDialog(messageFromObject: String, isFail: Boolean) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.dialog_join_success_view)
        val tvJoinSuccess = dialog.findViewById(R.id.tvJoinSuccess) as TextView
        val tvJoinSuccessTitle = dialog.findViewById(R.id.tvJoinSuccessTitle) as TextView
        val tvJoinSuccessFail = dialog.findViewById(R.id.tvJoinSuccessFail) as TextView

        if (isFail) {
            if (!messageFromObject.isFieldEmpty()) {
                tvJoinSuccessTitle.text = messageFromObject
            } else {
                tvJoinSuccessTitle.text = resources.getString(R.string.some_thing_went_wrong)
            }
            tvJoinSuccessFail.beGone()
        } else {
            tvJoinSuccessTitle.text = resources.getString(R.string.published_successfully)
            tvJoinSuccessFail.text =
                resources.getString(R.string.tournament_publish_success)
        }

        tvJoinSuccess.click {
            dialog.dismiss()
            if (!isFail) {
                sharedPreferences.clearPreference("createTournamentSave")
                dismissProgressDialog()
                startActivityInlineWithFinishAll<DashboardActivity>()
            }
        }
        dialog.show()
    }
}