package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AnnouncementResponse {

    @SerializedName("message")
    @Expose
    val  message: String?= null
    @SerializedName("messageCode")
    @Expose
    val  messageCode : String?= null
    @SerializedName("success")
    @Expose
    val  success : Boolean ?= false
    @SerializedName("data")
    @Expose
    val data :List<Announcment>  ?= null;

}

 class Announcment {

     @SerializedName("status")
     @Expose
     val status: Int? = null
     @SerializedName("_id")
     @Expose
     val id :String ?= null;
     @SerializedName("name")
     @Expose
     val name:String ?= null;
     @SerializedName("header")
     @Expose
     val  header : String ?= null;
     @SerializedName("announcementFileUrl")
     @Expose
     val announcementFileUrl : String ?= null
     @SerializedName("description")
     @Expose
     val  description : String ?= null
     @SerializedName("destination")
     @Expose
     val  destination : String ?= null
     @SerializedName("createdBy")
     @Expose
     val  createdBy : String?= null
     @SerializedName("updatedBy")
     @Expose
     val  updatedBy : String?= null
     @SerializedName("createdOn")
     @Expose
     val createdOn : String ?= null
     @SerializedName("updatedOn")
     @Expose
     val  updatedOn : String ?= null
     @SerializedName("__v")
     @Expose
     val  v : Int ?= null

}