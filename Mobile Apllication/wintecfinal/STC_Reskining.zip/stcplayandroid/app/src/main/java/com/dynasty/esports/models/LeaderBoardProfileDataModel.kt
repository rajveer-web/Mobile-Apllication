package com.dynasty.esports.models

data class LeaderBoardProfileDataModel (val value:Int?, val title:String)