package com.dynasty.esports.view.bookmark

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.id
import com.dynasty.esports.extenstion.isOnline
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.viewmodel.BookmarkViewModel
import kotlinx.android.synthetic.main.fragment_transaction_history.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will be used for handle bookmark pager
 * @author : Mahesh Vayak
 * @created : 27-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BookmarkFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    private val mViewModel: BookmarkViewModel by viewModel()
    private lateinit var commonPagerAdapter: CommonPagerAdapter  // define common pager adapter
    private val fragmentList: MutableList<Pair<Fragment, String>> =
        mutableListOf()  // define fragment list
    private var connectivityReceiver = ConnectivityReceiver()// define connection receiver
    private var isDataLoaded = false
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_transaction_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenToViewModel()
        textViewTitle.text = resources.getString(R.string.my_bookmark)

        /**
         *  add Fragment inside fragment list and assign list to viewpager adapter
         */
        fragmentList.add(Pair(BookmarkArticleVideoFragment.newInstance("article"), resources.getString(R.string.str_articles)))
        fragmentList.add(Pair(BookmarkArticleVideoFragment.newInstance("video"), resources.getString(R.string.video)))
        commonPagerAdapter = CommonPagerAdapter(fragmentList, childFragmentManager)
        viewPagerTransaction.adapter = commonPagerAdapter
        tabLayoutTransaction.setupWithViewPager(viewPagerTransaction)


    }

    /**
     * @desc listen observer that will receive the events
     * Manage API success and failure,Internet connectivity and un authorization and pass data in view pager fragment.
     */
    private fun listenToViewModel() {
        mViewModel.jsonObjectForBookmark.observe(viewLifecycleOwner, {
            mViewModel.fetchBookmark(it.first.toString(), it.second)
        })
        mViewModel.bookmarkSuccessResponse.observe(viewLifecycleOwner, {
            isDataLoaded = true
            it?.apply {
                this.data?.apply {
                    val fragments = childFragmentManager.fragments
                    if (!this.isNullOrEmpty()) {
                        fragments[0]?.let {
                            (it as BookmarkArticleVideoFragment).notifyArticle(
                                this[0].articleBookmarks!!
                            )
                        }
                        fragments[1]?.let {
                            (it as BookmarkArticleVideoFragment).notifyVideo(this[0].videoLibrary!!)
                        }
                    } else {
                        isDataLoaded = false
                        fragments[0]?.let {
                            (it as BookmarkArticleVideoFragment).notifyArticleNoDataView()
                        }
                        fragments[1]?.let {
                            (it as BookmarkArticleVideoFragment).notifyVideoNoDataView()
                        }
                    }
                }
            }
        })
        mViewModel.bookmarkErrorResponse.observe(viewLifecycleOwner, {
            notifyStatusFragment()
        })
        mViewModel.noInternetException.observe(viewLifecycleOwner, {
            if (requireActivity().isOnline()) {
                notifyStatusFragment()
            }
        })
        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, {
            if (it) {
                logOut()
            }
        })
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && !isDataLoaded) {
            notifyStatusFragmentForInternet(true)
            mViewModel.makeJsonForBookmark(sharedPreferences.id)
        } else if (!isDataLoaded) {
            notifyStatusFragmentForInternet(false)
        }
    }

    /**
     * @desc notify fragment for internet availability
     * @param isOnline (true if internet available and false if internet not available )
     */
    private fun notifyStatusFragmentForInternet(isOnline: Boolean) {
        val fragments = childFragmentManager.fragments
        fragments[0]?.let {
            (it as BookmarkArticleVideoFragment).notifyInternet(isOnline)
        }
        fragments[1]?.let {
            (it as BookmarkArticleVideoFragment).notifyInternet(isOnline)
        }
    }

    /**
     * @desc notify fragment for API error
     * @param isOnline (true if internet available and false if internet not available )
     */
    private fun notifyStatusFragment() {
        val fragments = childFragmentManager.fragments
        fragments[0]?.let {
            (it as BookmarkArticleVideoFragment).notifyError()
        }
        fragments[1]?.let {
            (it as BookmarkArticleVideoFragment).notifyError()
        }
    }
}