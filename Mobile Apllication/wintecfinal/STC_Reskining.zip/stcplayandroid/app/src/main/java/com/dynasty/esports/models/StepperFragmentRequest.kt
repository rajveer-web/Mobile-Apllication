package com.dynasty.esports.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

data class StepperFragmentRequest(
/////////////////////////////////////////////////////////////////////////////////////////////
    @field:SerializedName("name")
    var tournamnetName: String? = null,

    @field:SerializedName("selectedGame")
    var selectedGame: String? = null,

    @field:SerializedName("tournamnetType")
    var tournamnetType: String? = null,


    @field:SerializedName("tournamentDate")
    var tournamentDate: String? = null,

    @field:SerializedName("startTime")
    var tournamnetTime: String? = null,


    @field:SerializedName("bracketSelected")
    var bracketSelected: Int? = null,

    @field:SerializedName("matchFormat")
    var matchFormat: String? = null,


    @field:SerializedName("paidRegistrationTyppe")
    var paidRegistrationTyppe: String? = null,

    @field:SerializedName("entryFee")
    var entryFee: String? = null,


    @field:SerializedName("checkInStartDate")
    var checkInStrt: String? = null,

    @field:SerializedName("checkInEndDate")
    var checkInClose: String? = null,

    /*@nd fragment : */

    @field:SerializedName("country")
    var country: String? = null,

    @field:SerializedName("slug")
    var slug: String? = null,


    @field:SerializedName("banner")
    var banner: String? = null,

    @field:SerializedName("logo")
    var logo: String? = null,


    @field:SerializedName("Platform")
    var Platform: String? = null,

    @field:SerializedName("isPaid")
    var isPaid: Boolean? = null,


    @field:SerializedName("isShowCountryFlag")
    var isShowCountryFlag: Boolean? = null,

    @field:SerializedName("isCheckInRequired")
    var isCheckInRequired: Boolean? = null,

    @field:SerializedName("isIncludeSponsor")
    var isIncludeSponsor: Boolean? = null,

    @field:SerializedName("isScreenshotRequired")
    var isScreenshotRequired: Boolean? = null,
    @field:SerializedName("isSpecifyAllowedRegions")
    var isSpecifyAllowedRegions: Boolean? = null,

//    @field:SerializedName("regionsAllowed")
//    var regionsAllowed: Array<String?> ,

////
    @field:SerializedName("url")
    var tournamentUrl: String? = null,

    @field:SerializedName("contactDetails")
    var contactDetails: String? = null,/*
    @field:SerializedName("participants")
    var addParticipants: String? = null,*/
    @field:SerializedName("youtubeVideoLink")
    var videoLink: String? = null,
    @field:SerializedName("facebookVideoLink")
    var fbLink: String? = null,
    @field:SerializedName("twitchVideoLink")
    var twitterLink: String? = null,
    @field:SerializedName("visibility")
    var visibility: String? = null,


    @field:SerializedName("isParticipantsLimit")
    var isPartitionLimit: Boolean? = null,
    @field:SerializedName("contactOption")
    var contactOption: String? = null,

    //////

    @field:SerializedName("priceAmt1")
    var priceAmt1: String? = null,

    @field:SerializedName("priceAmt2")
    var priceAmt2: String? = null,

    @field:SerializedName("priceAmt3")
    var priceAmt3: String? = null,

    @field:SerializedName("selectCurrency")
    var selectCurrency: String? = null,

    @field:SerializedName("sponsorName")
    var sponsorName: String? = null,

    @field:SerializedName("webUrl")
    var webUrl: String? = null,

    @field:SerializedName("appStoreUrl")
    var appStoreUrl: String? = null,


    @field:SerializedName("playStoreUrl")
    var playStoreUrl: String? = null,

    /*Tournament typeis remaining*/

    @field:SerializedName("screenshot")
    var screenshot: Boolean? = null,


    @field:SerializedName("countryFlag")
    var countryFlag: Boolean? = null,

    @field:SerializedName("scoreReporting")
    var scoreReporting: Int? = null,

    @field:SerializedName("tournamentType")
    var tournamentType: String? = null,
    @field:SerializedName("maxParticipants")
    var participationLimit: Int? = null


)