package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class UpcomingTournamentModel (
    @field:SerializedName("gameName")
    var gameName : String? =null,

    @field:SerializedName("gameImage")
    //var gameImage : ImageView? = null
    var gameImage : Int? = null,

    @field:SerializedName("gameDatenTime")
    var gameDatenTime : String? = null,

    @field:SerializedName("gameRange")
    var gameRange : String? = null,

    @field:SerializedName("gameEliminationType")
    var gameEliminationType : String? = null,

    @field:SerializedName("gamePaidPrice")
    var gamePaidPrice : String? = null,

    @field:SerializedName("gameType")
    var gameType : String? = null
)