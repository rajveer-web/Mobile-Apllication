package com.dynasty.esports.models

data class CustomArticleModel(
    val type:Int?= null,
    val title:String?=null,
    val trendingPostList:MutableList<LatestTrendingModel.DatumModel>?=null,
    val latestArticleList:MutableList<LatestArticleModel.DocModel>?=null,
    val gamesList :MutableList<GamesModel.DataModel>?=null,
    val postByAuthorList:MutableList<ArticleAuthorsModel.DataModel>?=null,
    val latestViewPostList:MutableList<VideosModel.DocModel>?=null,
    val hottestPostList:MutableList<LatestArticleModel.DocModel>?=null,
    val newsList:MutableList<LatestArticleModel.DocModel>?=null
)