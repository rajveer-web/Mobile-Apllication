package com.dynasty.esports.view.tournamet.createtournament


import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.SelectedRegionsItemBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.nullSafeNA
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use for selected regions list from CreateTournamentStep2Fragment
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SelectedRegionsAdapter constructor(
    private val onItemRegionsRemoveClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<SelectedRegionsItemBinding>>() {

    private var selectedRegionsList: MutableList<Spinner> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<SelectedRegionsItemBinding> {
        val binding: SelectedRegionsItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.selected_regions_item,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    /**
     * @desc selectedRegionsList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return selectedRegionsList.size
    }

    /**
     * @desc add list in selectedRegionsList and notify adapter
     */
    fun addAll(selectedRegionsList_: MutableList<Spinner>) {
        selectedRegionsList.addAll(selectedRegionsList_)
        notifyDataSetChanged()
    }

    /**
     * @desc remove or clear all data from selectedRegionsList
     */
    fun clearAll() {
        selectedRegionsList.clear()
        notifyDataSetChanged()
    }

    /**
     * @desc add item in selectedRegionsList and notify adapter
     */
    fun add(item: Spinner) {
        if (selectedRegionsList.isEmpty()) {
            selectedRegionsList.add(item)
            notifyDataSetChanged()
        } else {
            selectedRegionsList.add(selectedRegionsList.size - 1, item)
            notifyItemInserted(selectedRegionsList.size - 1)
        }
    }

    /**
     * @desc remove item from selectedRegionsList and notify adapter
     */
    fun remove(item: Spinner) {
        selectedRegionsList.remove(item)
        notifyDataSetChanged()
    }

    /**
     * @desc get selectedRegionsList( main array list)
     */
    fun getAll(): MutableList<Spinner>? {
        return selectedRegionsList
    }

    /**
     * @desc get single item from position
     */
    fun get(position: Int): Spinner {
        return selectedRegionsList[position]
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents and to reflect the item at the given position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<SelectedRegionsItemBinding>,
        position: Int) {
        val data = selectedRegionsList[position]
        holder.binding.tvSelectedRegionsText.text = nullSafeNA(data.title)
        holder.binding.imgClear.click {
            onItemRegionsRemoveClick(position)
        }
    }
}