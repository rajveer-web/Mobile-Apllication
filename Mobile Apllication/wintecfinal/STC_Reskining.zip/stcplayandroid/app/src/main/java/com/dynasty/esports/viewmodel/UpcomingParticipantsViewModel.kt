package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.ParticipantsModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class UpcomingParticipantsViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val participantsListSuccessResponse = MutableLiveData<ParticipantsModel>()
    val participantsListErrorResponse = MutableLiveData<ResponseBody>()
    val makeJsonObjectForParticipantsQuery = MutableLiveData<JsonObject>()
    val makeJsonObjectForFinishMatch = MutableLiveData<JsonObject>()
    val makeJsonObjectForParticipantsUpdate = MutableLiveData<JsonObject>()
    val updateParticipantsSuccessResponse = MutableLiveData<ResponseBody>()
    val updateParticipantsErrorResponse = MutableLiveData<ResponseBody>()
    val passDataAndUpdateUI = MutableLiveData<MutableList<ParticipantsModel.DataModel>>()

    fun getParticipantsList(query: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getParticipantsList(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    participantsListSuccessResponse.postValue(response.body())
                }
                else -> {
                    participantsListErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun updateStatusParticipants(id:String,query: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.updateParticipantStatus(id,query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateParticipantsSuccessResponse.postValue(response.body())
                }
                else -> {
                    updateParticipantsErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun updateAllParticipants(body: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.updateParticipant(body)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateParticipantsSuccessResponse.postValue(response.body())
                }
                else -> {
                    updateParticipantsErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun finishMatch(body: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.finisMatch(body)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateParticipantsSuccessResponse.postValue(response.body())
                }
                else -> {
                    updateParticipantsErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun getApproveParticipantsList(query: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getParticipantsList(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    participantsListSuccessResponse.postValue(response.body())
                }
                else -> {
                    participantsListErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }



    fun makeQueryForParticipantsList(tournamentId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("tournamentId", tournamentId)
        makeJsonObjectForParticipantsQuery.postValue(jsonObject)
    }


    fun makeQueryForFinishMatch(tournamentId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("tournamentId", tournamentId)
        makeJsonObjectForFinishMatch.postValue(jsonObject)
    }


    fun makeJsonForParticipantsStatus(status: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("participantStatus", status)
        makeJsonObjectForParticipantsQuery.postValue(jsonObject)
    }

    fun makeJsonForParticipantsUpdate(list:MutableList<ParticipantsModel.DataModel>) {
        val tempList:MutableList<ParticipantsModel.DataModel> = mutableListOf()
        tempList.addAll(list)
        tempList.removeAt(0)

        val jsonObject = JsonObject()
        val jsonArrayData = JsonArray()
        tempList.forEach {
            val jsonObjectData = JsonObject()
            jsonObjectData.addProperty("_id",it.id)
            jsonObjectData.addProperty("seed",it.seed)
            jsonArrayData.add(jsonObjectData)
        }
        jsonObject.add("data", jsonArrayData)
        makeJsonObjectForParticipantsUpdate.postValue(jsonObject)
    }

    fun makeJsonForApproveParticipantsStatus(tournamentId: String,status: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("participantStatus", status)
        jsonObject.addProperty("tournamentId", tournamentId)
        makeJsonObjectForParticipantsQuery.postValue(jsonObject)
    }

    fun updateUI(data: MutableList<ParticipantsModel.DataModel>?) {
        passDataAndUpdateUI.postValue(data)
    }

    /**
     * Clears the [ViewModel] when the [SignInActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }
}
