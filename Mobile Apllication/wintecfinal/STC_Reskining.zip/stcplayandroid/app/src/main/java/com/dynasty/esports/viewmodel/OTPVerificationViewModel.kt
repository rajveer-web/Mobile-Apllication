package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.*
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.HttpException
import java.net.ConnectException
import java.net.UnknownHostException

class OTPVerificationViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()
    val fbLoginObserver = MutableLiveData<Boolean>()
    val googleLoginObserver = MutableLiveData<Boolean>()
    val redirectPhoneRegistrationObserver = MutableLiveData<Boolean>()
    val redirectPhoneSignInObserver = MutableLiveData<Boolean>()
    val socialOTPVerificationSuccessResponse = MutableLiveData<Pair<String, SignInResponse>>()
    val socialOTPVerificationErrorResponse = MutableLiveData<ResponseBody>()
//    val otpVerificationSuccessResponse = MutableLiveData<ResponseBody>()
    val otpVerificationSuccessResponse = MutableLiveData<Pair<String, SignInResponse>>()
  //  val otpVerificationErrorResponse = MutableLiveData<ResponseBody>()
    val otpVerificationErrorResponse = MutableLiveData<String>()
    val emailOTPVerificationSuccessResponse = MutableLiveData<ResponseBody>()
    val emailOTPVerificationErrorResponse = MutableLiveData<ResponseBody>()
    val registerFCMTokenSuccessResponse = MutableLiveData<ResponseBody>()
    val registerFCMTokenErrorResponse = MutableLiveData<ResponseBody>()
    val resendOTPSuccessResponse = MutableLiveData<ResponseBody>()
    val resendOTPErrorResponse = MutableLiveData<ResponseBody>()


    fun registrationPushNotification(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.registerfcmToken(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    registerFCMTokenSuccessResponse.postValue(response.body())
                }
                else -> {
                    registerFCMTokenErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun resendOtp(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.resendOtp(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    resendOTPSuccessResponse.postValue(response.body())
                }
                else -> {
                    resendOTPErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun resendSocialOtp(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.resendSocialOtp(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    resendOTPSuccessResponse.postValue(response.body())
                }
                else -> {
                    resendOTPErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }




    fun formValidation(countryCode:String,phoneNumber:String) {
        when {
            countryCode.isFieldEmpty() -> validationLiveData.postValue(0)
            phoneNumber.isFieldEmpty() -> validationLiveData.postValue(1)
            phoneNumber.length!=10->validationLiveData.postValue(2)
            else -> isFormValid.postValue(true)
        }
    }

    fun fbLoginClick() {
        fbLoginObserver.postValue(true)
    }

    fun googleLoginClick() {
        googleLoginObserver.postValue(true)
    }

    fun redirectPhoneRegistration(){
        redirectPhoneRegistrationObserver.postValue(true)
    }

    fun redirectPhoneSignIn(){
        redirectPhoneSignInObserver.postValue(true)
    }

    fun socialOTPVerification(socialVerificationRequest: SocialVerificationRequest) {
        viewModelScope.launch {
            val response = restInterface.socialloginVerify(socialVerificationRequest)
            withContext(Dispatchers.Main) {
                when (response.code()) {
                    AppConstants.API_SUCCESS_CODE -> {
                        socialOTPVerificationSuccessResponse.postValue(Pair(response.headers().get("set-cookie").toString().split(";")[0],response.body()!!))
                    }
                    else -> {
                        socialOTPVerificationErrorResponse.postValue(response.errorBody())
                    }
                }
            }
        }

    }

    fun otpVerify(verifyRequest: VerifyRequest) {
        viewModelScope.launch(apiException("otp")+Dispatchers.Main) {
            val response = restInterface.loginVerify(verifyRequest)
                when (response.code()) {
                    AppConstants.API_SUCCESS_CODE -> {
                        otpVerificationSuccessResponse.postValue(Pair(response.headers().get("set-cookie").toString().split(";")[0],response.body()!!))
                    }
                    else -> {
                        val jObjError = JSONObject(response.errorBody()!!.string())
                        otpVerificationErrorResponse.postValue(jObjError.getString("message"))
                       // otpVerificationErrorResponse.postValue(response.errorBody())
                    }
                }

        }
    }


    fun verifyEmailOtp(jsonObject: JsonObject){
        viewModelScope.launch(apiException("email_otp")+Dispatchers.Main) {
            val response = restInterface.verifyOTP(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    emailOTPVerificationSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    emailOTPVerificationErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }






    /**
     * Clears the [ViewModel] when the [SignInActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
