package com.dynasty.esports.view.esport

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.ListitemUpcomingTournamentBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.TournamentListRes
import com.dynasty.esports.view.common.LoadingViewHolder
import kotlinx.android.synthetic.main.listitem_upcoming_tournament.view.*

/**
 * @desc this is class will use for upcoming tournament adapter
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class UpcomingAdapter constructor(
    private val onItemClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var upcomingList: MutableList<TournamentListRes.Doc> = ArrayList()
    val TYPE_DATA = 1
    val TYPE_LOADER = 2
    var showloader = false
    var loaderCalc = false

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_LOADER) {
            val binding: ItemLoadMoreBinding =
                DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
            LoadingViewHolder(binding)
        } else {
            val binding: ListitemUpcomingTournamentBinding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.listitem_upcoming_tournament,
                parent,
                false
            )
            ViewHolderTournament(binding)
        }
    }

    /**
     * @desc get item data from position
     */
    fun getItem(position: Int): TournamentListRes.Doc {
        return upcomingList.get(position)
    }

    /**
     * @desc upcomingList array size count + 1(for loader item calculation)
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return if (upcomingList.size == 0) {
            0
        } else upcomingList.size + 1
    }

    /**
     * @desc Return the view type of the item at <code>position</code> for the purposes
     * of view recycling.
     */
    override fun getItemViewType(position: Int): Int {
        return if (position != 0 && position == itemCount - 1) {
            TYPE_LOADER
        } else TYPE_DATA
    }

    /**
     * @desc add data in ongoingList and notify adapter
     */
    fun addAll(upcomingList_: MutableList<TournamentListRes.Doc>) {
        upcomingList.addAll(upcomingList_)
        notifyDataSetChanged()
    }

    /**
     * @desc showloader at last adapter item
     */
    fun setShowloader_(status: Boolean) {
        showloader = status
        if (!status) notifyItemChanged(itemCount - 1)
    }

    /**
     * @desc return main arraylist
     */
    fun getAll(): MutableList<TournamentListRes.Doc>? {
        return upcomingList
    }

    /**
     * @desc method will use for manage main UI and loader UI.Also, pass object to ViewHolderTournament
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            TYPE_DATA -> {
                loaderCalc = false
                (holder as ViewHolderTournament).bind(upcomingList[position])
            }
            else -> {
                loaderCalc = true
                if (showloader) {
                    (holder as LoadingViewHolder).progressBar.beVisible()
                } else {
                    (holder as LoadingViewHolder).progressBar.beGone()
                }
            }
        }
    }

    /**
     * @desc class use for main UI and handle components
     * @param binding -listitem_upcoming_tournament layout binder
     */
    inner class ViewHolderTournament(private var binding: ListitemUpcomingTournamentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: TournamentListRes.Doc) {

            binding.gameNameTitle.text = nullSafeNA(data.name!!.capitalize())

            binding.dateNtime.text = data.startDate!!.convertDateToRequireDateFormat(
                AppConstants.API_DATE_FORMAT,
                AppConstants.REQUIRED_TIME_FORMAT
            ) + ", " + data.startTime

            binding.eliminationTxt.text =
                data.bracketType!!.capitalize()

            if (data.isPaid) {
                binding.paidType.text = itemView.context.getString(R.string.str_paid)
                binding.paidType.setTextColor(ContextCompat.getColor(itemView.context,R.color.text_color))

                binding.tvRpm.beVisible()
                binding.imgTrphy.beVisible()
                itemView.tvRpm.text =
                    "" + nullSafe(data.prizeCurrency) + " " + (data.firstPrize + data.secondPrize + data.thirdPrize)
                binding.isPaidBg.background =
                    itemView.context.getDrawable(R.drawable.coloraccent_square_border)
            } else {

                binding.paidType.text = itemView.context.getString(R.string.str_free)
                binding.paidType.setTextColor(ContextCompat.getColor(itemView.context,R.color.text_color))
                binding.isPaidBg.background =
                    itemView.context.getDrawable(R.drawable.roundedcornerred_free)
                binding.tvRpm.beGone()
                binding.imgTrphy.beGone()
            }

            binding.tvParticiPantJoind.text = data.participants.size.toString().plus("/")
                .plus(data.maxParticipants.toString())


            data.gameDetail?.apply {
               this.image?.apply {
                   itemView.context.loadImageFromServer(
                       this,
                       binding.imgUpcoming
                   )
               }
            }
            itemView.click {
                onItemClick(adapterPosition)
            }
        }
    }
}