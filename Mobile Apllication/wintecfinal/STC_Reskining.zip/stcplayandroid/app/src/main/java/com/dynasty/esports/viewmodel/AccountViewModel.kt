package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.SocialLoginRequest
import com.dynasty.esports.models.SocialLoginResponse
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 28-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class AccountViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
    val addSocialSuccessResponse = MutableLiveData<SocialLoginResponse>()
    val addSocialErrorResponse = MutableLiveData<ResponseBody>()

    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val jsonObjectForAddSocial = MutableLiveData<SocialLoginRequest>()
    val jsonObjectForUpdateEmail = MutableLiveData<JsonObject>()
    val updateUserSuccessResponse = MutableLiveData<ResponseBody>()
    val updateUserErrorResponse = MutableLiveData<ResponseBody>()

    /**
     *@desc Method will use for connect account with social media
     * @param jsonObject- pass social json object
     */
    fun addSocial(jsonObject: SocialLoginRequest) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.addSocial(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    addSocialSuccessResponse.postValue(response.body())
                }
                else -> {
                    addSocialErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     *@desc Method will use for update user information
     * @param jsonObject- pass json object with updated data
     */
    fun updateUser(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("update") + Dispatchers.Main) {
            val response = restInterface.updateUser(jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateUserSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    updateUserErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     *@desc Method will use check form validation
     * @param email- email address
     */
    fun checkFormValidation(email: String) {
        when {
            email.isFieldEmpty() -> validationLiveData.postValue(0)
            !email.isEmailValid() -> validationLiveData.postValue(1)
            else -> isFormValid.postValue(true)
        }
    }

    /**
     *@desc Method will use for create add social json object
     * @param token- login user token
     *@param provider- login provide // Google // Facebook
     */
    fun makeJsonForAddSocial(token: String, provider: String) {
        val socialLoginReq = SocialLoginRequest()
        socialLoginReq.provider = provider
        socialLoginReq.token = token
        jsonObjectForAddSocial.postValue(socialLoginReq)
    }

    /**
     *@desc Method will use for update user data
     * @param email- email address
     */
    fun makeJsonForUpdateEmail(email: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("email", email)
        jsonObjectForUpdateEmail.postValue(jsonObject)

    }


    /**
     * Clears the [ViewModel] when the [Fragment or Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
