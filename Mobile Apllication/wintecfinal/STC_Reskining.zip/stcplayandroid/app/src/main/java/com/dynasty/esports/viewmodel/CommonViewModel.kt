package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.ChatInterface
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle common API functions
 * @author : Mahesh Vayak
 * @created : 22-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CommonViewModel constructor(
    private val restInterface: RestInterface
) : BaseViewModel() {
    // define MutableLiveData for emit observer
//    val socialLoginSuccessResponse = MutableLiveData<SocialLoginResponse>()
    val socialLoginSuccessResponse = MutableLiveData<Pair<String, SocialLoginResponse>>()

    // val socialLoginSuccessResponse = MutableLiveData<Pair<String, ResponseBody>>()
    val socialLoginErrorResponse = MutableLiveData<ResponseBody>()

    val logOutSuccessResponse = MutableLiveData<ResponseBody>()
    val logOutErrorResponse = MutableLiveData<ResponseBody>()


    val userSuccessResponse = MutableLiveData<UserModel>()
    val userErrorResponse = MutableLiveData<ResponseBody>()







    val registerFCMTokenSuccessResponse = MutableLiveData<ResponseBody>()
    val registerFCMTokenErrorResponse = MutableLiveData<ResponseBody>()

    fun registrationPushNotification(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.registerfcmToken(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    registerFCMTokenSuccessResponse.postValue(response.body())
                }
                else -> {
                    registerFCMTokenErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }



    /**
     * @desc Method will handle social media API success, failure
     * @param socialLoginRequest- pass json object with parameter
     */
    fun socialLogin(socialLoginRequest: SocialLoginRequest) {
        viewModelScope.launch(apiException("social") + Dispatchers.Main) {
            val response = restInterface.socialLogin(socialLoginRequest)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    socialLoginSuccessResponse.postValue(
                        Pair(
                            response.headers().get("set-cookie").toString().split(";")[0],
                            response.body()!!
                        )
                    )
                }
                else -> {
                    socialLoginErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle fetch user API success, failure
     */
    fun fetchUser() {
        viewModelScope.launch(apiException("user")+ Dispatchers.Main) {
            val response = restInterface.getUserData()
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    userSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    userErrorResponse.postValue(response.errorBody())
                }
            }

        }

    }

    /**
     * @desc Method will handle logout user API success, failure
     */
    fun logoutUser(withCredentials:String,refreshToken:String) {
        viewModelScope.launch(apiException("logout") + Dispatchers.Main) {
            val response = restInterface.logOut(withCredentials,refreshToken)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    logOutSuccessResponse.postValue(response.body())
                }
                else -> {
                    logOutErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


}
