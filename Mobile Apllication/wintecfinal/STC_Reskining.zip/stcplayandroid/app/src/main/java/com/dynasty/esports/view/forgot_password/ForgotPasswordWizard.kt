package com.dynasty.esports.view.forgot_password

import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.view.forgot_password.ForgotPasswordMobileActivity

interface ForgotPasswordWizard {

    fun getCurrentPageType(): ForgotPasswordMobileActivity.ForgotPasswordWizardPageType
    fun setNextButtonEnabled(enable: Boolean)
    fun nextPage()
    fun createAPIRequest(mReq: ForgotPasswordRequest?)
    fun sendDataToSuccessfulFragment(mReq: ForgotPasswordRequest?)
    fun sendDataToChangePasswordFragment(mReq: ForgotPasswordRequest?)
    fun senDataToVerificationFragment(mReq: ForgotPasswordRequest?)




}