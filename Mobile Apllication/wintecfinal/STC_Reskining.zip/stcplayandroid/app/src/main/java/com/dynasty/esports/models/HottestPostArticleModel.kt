package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class HottestPostArticleModel {
    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("totals")
    @Expose
     val totals: TotalsModel? = null

    class DataModel{
        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("shortDescription")
        @Expose
        val shortDescription: TitleModel? = null

        @SerializedName("_id")
        @Expose
         val _id: String? = null

        @SerializedName("game")
        @Expose
         val game: String? = null

        @SerializedName("image")
        @Expose
         val image: String? = null

        @SerializedName("author")
        @Expose
         val author: String? = null

        @SerializedName("createdDate")
        @Expose
         val createdDate: String? = null

        @SerializedName("comments")
        @Expose
         val comments: MutableList<CommentModel>? = null

        @SerializedName("authorDetails")
        @Expose
         val authorDetails: AuthorDetailsModel? = null

        @SerializedName("id")
        @Expose
         val id: String? = null
        var isLoadMore=false
    }

    class CommentModel{
        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("_id")
        @Expose
         val _id: String? = null

        @SerializedName("comment")
        @Expose
         val comment: String? = null

        @SerializedName("userId")
        @Expose
         val userId: String? = null

        @SerializedName("objectId")
        @Expose
         val objectId: String? = null

        @SerializedName("objectType")
        @Expose
         val objectType: String? = null

        @SerializedName("modifiedOn")
        @Expose
         val modifiedOn: String? = null

        @SerializedName("__v")
        @Expose
         val __v: Int? = null

        @SerializedName("userDetails")
        @Expose
         val userDetails: UserDetailsModel? = null

        @SerializedName("id")
        @Expose
         val id: String? = null
    }

    class AuthorDetailsModel{
        @SerializedName("_id")
        @Expose
         val _id: String? = null

        @SerializedName("fullName")
        @Expose
         val fullName: String? = null

        @SerializedName("profilePicture")
        @Expose
         val profilePicture: String? = null

    }

    class UserDetailsModel{
        @SerializedName("_id")
        @Expose
         val _id: String? = null

        @SerializedName("fullName")
        @Expose
         val fullName: String? = null

        @SerializedName("profilePicture")
        @Expose
         val profilePicture: String? = null

    }


}