package com.dynasty.esports.view.tournamet.tournamet_detail


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterParticipantsTeamBinding
import com.dynasty.esports.models.TeamPlayers
import kotlinx.android.synthetic.main.adapter_participants_team.view.*

class ParticipantsTeamAdapter constructor(
    private var playerList: MutableList<TeamPlayers>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>()  {


    var playerLists : MutableList<TeamPlayers>

    init {
        this.playerLists = playerList
    }

     override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
         return PlayerListViewHolder(
             LayoutInflater.from(parent.context)
                 .inflate(R.layout.adapter_participants_team, parent, false)
         )
     }

    override fun getItemCount(): Int {
        return playerList.size
    }


     override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
         val gameViewHolder = viewHolder as  PlayerListViewHolder
         gameViewHolder.bindView(playerLists[position], position)
     }

     class PlayerListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
         fun bindView( listt:TeamPlayers,pos : Int) {
                val currentPos = pos + 1
                 itemView.playerName.text = currentPos.toString() + ". "+listt.name?.capitalize()
         }
     }

     interface OnItemClickListener {
         fun onItemClick()
     }

}