package com.dynasty.esports.view.search


import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterSearchFilterViewBinding
import com.dynasty.esports.databinding.AdapterSearchOptionBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.CustomSearchFilterModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use to show search filter option
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SearchFilterOptionAdapter(
    private var searchOptionList: MutableList<CustomSearchFilterModel>,
    private val onItemClick: (Int, CustomSearchFilterModel,TextView) -> Unit = { _, _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterSearchFilterViewBinding>>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterSearchFilterViewBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_search_filter_view,
                parent,
                false
            ))
    }

    /**
     * @desc search filter option array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return searchOptionList.size
    }


    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterSearchFilterViewBinding>,
        position: Int
    ) {
        val data=searchOptionList[position]
        holder.binding.textViewSearchKey.text = data.key
        holder.binding.textViewSelectedOption.text = data.selectedName
        holder.binding.textViewSelectedOption.click {
            onItemClick(position,data,it)
        }
    }
}