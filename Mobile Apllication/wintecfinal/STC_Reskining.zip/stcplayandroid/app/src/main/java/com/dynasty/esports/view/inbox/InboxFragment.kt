package com.dynasty.esports.view.inbox

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.InboxModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.viewmodel.InboxViewModel
import kotlinx.android.synthetic.main.fragment_inbox.*
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will display inbox list
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class InboxFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    val mViewModel: InboxViewModel by viewModel()
    private var dataList: MutableList<InboxModel.DataModel> = mutableListOf()
    private lateinit var inboxListAdapter: InboxListAdapter
    private var connectivityReceiver = ConnectivityReceiver()

    private var selectedIdList: MutableList<String> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_inbox, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        viewClickListener()
        listenToViewModel()

    }

    /**
     * @desc Initialize view and assign inbox adapter to recyclerview
     */
    private fun initView() {
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        inboxListAdapter = InboxListAdapter(
            dataList,
            onCheckMarkClick = ::onCheckMarkClick,
            onItemClick = ::onItemClick
        )
        commonRecyclerView.adapter = inboxListAdapter
    }

    /**
     * @desc this method use for assign callback to view
     */
    private fun viewClickListener() {
        checkBoxSelectAll.click {
            if (!checkBoxSelectAll.isChecked) {
                dataList.forEach {
                    it.isSelected=false
                }
               // inboxListAdapter.isCheckboxVisible=true
//                inboxListAdapter.selectAllCheckbox(false)
            } else {
                dataList.forEach {
                    it.isSelected=true
                }
//                inboxListAdapter.selectAllCheckbox(true)
            }
            inboxListAdapter.notifyDataSetChanged()
        }

        imageViewDelete.click {
            val count = checkIdSelectedOrNot()

            if (count == 0) {
                resources.getString(R.string.please_select_atlease_one_message)
                    .showToast(requireContext())
            } else {

                displayCustomAlertDialog(
                    title = count
                        .toString().plus(" ")
                        .plus(resources.getString(R.string.delete_conversation_msg)),
                    positiveText = resources.getString(R.string.delete),
                    negativeText = resources.getString(android.R.string.cancel),
                    positiveClick = {
                        it.dismiss()
                        mViewModel.makeJsonForDeleteMessage(selectedIdList)
                    },
                    negativeClick = {
                        it.dismiss()
                    },
                )
            }

        }
    }

    /**
     * @desc method will call when tap inbox item.
     * @param id inbox id
     * @param seen is message seen or not
     */
    private fun onItemClick(id: String, seen: Boolean) {
        val bundle = Bundle()
        bundle.putString("id", id)
        bundle.putBoolean("seen", seen)
        DashboardActivity.navController.navigate(R.id.inboxMessage, bundle)
    }

    /**
     * @desc method will use add and remove id in selected array list.
     * @param id inbox id
     * @param position inbox adapter position
     */
    // add and remove messages id from selected id list
    private fun onCheckMarkClick(id: String, position: Int) {

        dataList[position].isSelected = !dataList[position].isSelected
        inboxListAdapter.notifyItemChanged(position)
        when (checkIdSelectedOrNot()) {
            dataList.size -> {
                checkBoxSelectAll.isChecked =true
            }
            0 -> {
                checkBoxSelectAll.isChecked =false
                inboxListAdapter.notifyDataSetChanged()
            }
            else -> {
                checkBoxSelectAll.isChecked =false
            }
        }



    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make jsonobject for API and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it) {
                logOut()
            }
        })

        mViewModel.jsonObjectForDeleteMessages.observe(viewLifecycleOwner, Observer {
            launchProgressDialog()
            mViewModel.deleteMessages(it)
        })

        mViewModel.deleteMessagesSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            inboxListAdapter.isCheckboxVisible=false

            checkBoxSelectAll.isChecked = false
            displayCustomAlertDialog(title = resources.getString(R.string.deleted_success_msg),
                desc = selectedIdList.size
                    .toString().plus(" ")
                    .plus(resources.getString(R.string.deleted_conversion_msg)),
                isCancelable = false,
                isButtonShow = false,
                isCloseShow = true, onCloseClick = {
                    it.apply {
                        dismiss()
                        dataList.removeAll { it.isSelected }
                        selectedIdList.clear()
                        inboxListAdapter.notifyDataSetChanged()
                    }
                })
        })
        mViewModel.deleteMessagesErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            displayCustomAlertDialog(
                resources.getString(R.string.something_wrong_try_again),
                isCancelable = false,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })

        mViewModel.getInboxMessageSuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()
            it.data?.apply {
                dataList.clear()
                dataList.addAll(this)
                inboxListAdapter.notifyDataSetChanged()
            }
            if (!dataList.isNullOrEmpty()) {
                checkBoxSelectAll.beVisible()
                imageViewDelete.beVisible()
            } else {
                constraintLayoutNoData.beVisible()
            }
        })

        mViewModel.getInboxMessageErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            when (it) {
                "delete" -> {
                    if (requireActivity().isOnline()) {
                        displayCustomAlertDialog(
                            resources.getString(R.string.something_wrong_try_again),
                            isCancelable = false,
                            positiveText = resources.getString(R.string.btn_ok),
                            positiveClick = {
                                it.dismiss()
                            })
                    } else {
                        displayCustomAlertDialog(
                            resources.getString(R.string.no_internet_message),
                            isCancelable = false,
                            positiveText = resources.getString(R.string.btn_ok),
                            positiveClick = {
                                it.dismiss()
                            })
                    }
                }
                else -> {
                    if (requireActivity().isOnline()) {
                        linearLayoutProgressBar.beGone()
                        constraintLayoutNoData.beGone()
                        constraintLayoutErrorView.beVisible()
                        commonRecyclerView.beGone()
                        constraintLayoutNoInternet.beGone()
                    }
                }
            }
        })
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc UnRegister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && dataList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
            mViewModel.getAllMessages("message-list")
        } else if (dataList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }


    private fun checkIdSelectedOrNot(): Int {
        selectedIdList.clear()
        dataList.forEach {
            if (it.isSelected) {
                selectedIdList.add(it.id.toString())
            }
        }
        return selectedIdList.size
    }


}