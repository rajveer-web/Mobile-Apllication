package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class StateModel {
    @SerializedName("states")
    @Expose
     val states: MutableList<State>? = null

    class State{
        @SerializedName("id")
        @Expose
         val id: String? = null

        @SerializedName("name")
        @Expose
         val name: String = ""

        @SerializedName("country_id")
        @Expose
         val countryId: String? = null
    }
}