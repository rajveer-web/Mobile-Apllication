package com.dynasty.esports.view.chat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*

class MessageListActivity : AppCompatActivity() {
    private var messagesAdapter: MessagesAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message_list)

        initView()
    }

    private fun initView() {
        linearLayoutProgressBar.beGone()
        messagesAdapter = MessagesAdapter(mutableListOf())
        commonRecyclerView.layoutManager = LinearLayoutManager(this)
        commonRecyclerView.adapter = messagesAdapter
    }
}