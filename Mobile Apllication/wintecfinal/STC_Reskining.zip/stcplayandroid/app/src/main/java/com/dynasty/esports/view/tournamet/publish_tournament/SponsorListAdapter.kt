package com.dynasty.esports.view.tournamet.createtournament


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.SponsorListItemBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.CreateTournament


//row_author_list_article

class SponsorListAdapter :
    RecyclerView.Adapter<SponsorListAdapter.MyViewHolder>() {

    inner class MyViewHolder(val binding: SponsorListItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    private var sponcerList: MutableList<CreateTournament.Sponsor>? =
        ArrayList<CreateTournament.Sponsor>()

    private var mClickListener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val binding: SponsorListItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.sponsor_list_item,
            parent,
            false
        )
        return MyViewHolder(binding)

//        val layoutInflater = LayoutInflater.from(parent.context)
//        val itemBinding = AddSponsorListItemBinding.inflate(layoutInflater, parent, false)
//        return BindingHolder(itemBinding)
    }


    override fun getItemCount(): Int {
        return sponcerList!!.size
    }

    fun addAll(sponcerList: List<CreateTournament.Sponsor>) {
        this.sponcerList!!.addAll(sponcerList)
        notifyDataSetChanged()
    }

    fun remove(item: CreateTournament.Sponsor, position: Int) {
        sponcerList!!.remove(item)
        notifyDataSetChanged()
    }

    fun getAll(): MutableList<CreateTournament.Sponsor> {
        return sponcerList!!
    }

    fun clear() {
        sponcerList!!.clear()
        notifyDataSetChanged()
    }


    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = sponcerList!![position]
        holder.binding.tvSponcerName.text = data.sponsorName.let {
            it
        }

        holder.itemView.context.loadImageFromServer(
            data.sponsorBanner,
            holder.binding.imgSponcerBanner
        )

        holder.itemView.context.loadImageFromServer(
            data.sponsorLogo,
            holder.binding.imgSponcerLogo
        )

        if (data.website.isNotEmpty()) {
            holder.binding.tvSponcerUrl.beVisible()
            holder.binding.tvSponcerUrl.text = "Visit Us : " + data.website
        } else {
            holder.binding.tvSponcerUrl.beGone()
        }

        if (data.playStoreUrl.isNotEmpty()) {
            holder.binding.imgSponcerPlaystore.beVisible()
        } else {
            holder.binding.imgSponcerPlaystore.beGone()
        }

        if (data.appStoreUrl.isNotEmpty()) {
            holder.binding.imgSponcerAppstore.beVisible()
        } else {
            holder.binding.imgSponcerAppstore.beGone()
        }

//        holder.binding.llimageSponsor.click {
//            if (mClickListener != null) {
//                mClickListener!!.onimageSponsorClick(position)
//            }
//        }
    }

    // allows clicks events to be caught
    internal fun setClickListener(itemClickListener: ItemClickListener) {
        this.mClickListener = itemClickListener
    }

    // parent activity will implement this method to respond to click events
    interface ItemClickListener {
        fun onItemClick(position: Int)
        fun onimageSponsorClick(position: Int)
        fun onItemRemoveClick(position: Int)
    }
}