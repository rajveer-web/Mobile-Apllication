package com.dynasty.esports.models

data class CustomContentModel(
    val type: Int? = null,
    val title: String? = null,
    val chooseGamesList: MutableList<ProfileContentModel.ContentModel>? = null,
    val platformsList: MutableList<PlatformModel>? = null,
    val gameCenterList: MutableList<ProfileContentModel.ContentModel>? = null,
    val contentCenterList: MutableList<ProfileContentModel.ContentModel>? = null

)