package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class UploadFilesRes {
    @SerializedName("message")
    @Expose
    var message: String = ""

    @SerializedName("success")
    @Expose
    var success: Boolean = false

    @SerializedName("data")
    @Expose
    var data: List<Datum> = ArrayList<Datum>()

    class Datum {
        @SerializedName("ETag")
        @Expose
        var eTag: String = ""

        @SerializedName("Location")
        @Expose
        var location: String = ""

        @SerializedName("Bucket")
        @Expose
        var bucket: String = ""
    }
}