package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class PostCommentModel {
    @SerializedName("data")
    @Expose
     val data: ArticleCommentModel.ArticleComment? = null

    @SerializedName("message")
    @Expose
     val message: String? = null

}