package com.dynasty.esports.models

data class CreateTournamentResponse(
    val message: String,
    val data: DataResponse,
    val code: String
)