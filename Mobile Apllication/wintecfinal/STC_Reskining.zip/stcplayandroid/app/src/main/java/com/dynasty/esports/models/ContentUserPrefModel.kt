package com.dynasty.esports.models

import com.dynasty.esports.models.BookmarkModel.ArticleBookmark
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ContentUserPrefModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null


    class DataModel{


        @SerializedName("articleBookmarks")
        @Expose
         val articleBookmarks: MutableList<ArticleBookmark>? = null

        @SerializedName("game")
        @Expose
         val game: MutableList<String>? = null

        @SerializedName("gamegenre")
        @Expose
         val gamegenre: MutableList<String>? = null

        @SerializedName("prefercontent")
        @Expose
         val prefercontent: MutableList<String>? = null

        @SerializedName("platform")
        @Expose
         val platform: MutableList<String>? = null

        @SerializedName("videoLibrary")
        @Expose
         val videoLibrary: MutableList<Any>? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("userId")
        @Expose
         val userId: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null
    }

}