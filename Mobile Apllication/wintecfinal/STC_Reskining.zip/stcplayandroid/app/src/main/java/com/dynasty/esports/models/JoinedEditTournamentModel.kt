package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class JoinedEditTournamentModel {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("messageCode")
    @Expose
    var messageCode: String? = null

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: List<Datum> = ArrayList<Datum>()

    @SerializedName("totals")
    @Expose
    var totals: Totals? = null

    class Datum {
        @SerializedName("teamMembers")
        @Expose
        var teamMembers: List<TeamMember> = ArrayList<TeamMember>()

        @SerializedName("seed")
        @Expose
        var seed = 0

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("checkedIn")
        @Expose
        var checkedIn = false

        @SerializedName("status")
        @Expose
        var status = 0

        @SerializedName("participantStatus")
        @Expose
        var participantStatus: Any? = null

        @SerializedName("matchWin")
        @Expose
        var matchWin = 0

        @SerializedName("matchLoss")
        @Expose
        var matchLoss = 0

        @SerializedName("matchTie")
        @Expose
        var matchTie = 0

        @SerializedName("substituteMembers")
        @Expose
        var substituteMembers: List<Any> = ArrayList()

        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("logo")
        @Expose
        var logo: String? = null

        @SerializedName("teamName")
        @Expose
        var teamName: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("phoneNumber")
        @Expose
        var phoneNumber: String? = null

        @SerializedName("email")
        @Expose
        var email: String? = null

        @SerializedName("tournamentUsername")
        @Expose
        var tournamentUsername: String? = null

        @SerializedName("inGamerUserId")
        @Expose
        var inGamerUserId: String? = null

        @SerializedName("participantType")
        @Expose
        var participantType: String? = null

        @SerializedName("tournamentId")
        @Expose
        var tournamentId: String? = null

        @SerializedName("userId")
        @Expose
        var userId: String? = null

        @SerializedName("__v")
        @Expose
        var v = 0
    }

    class TeamMember {
        @SerializedName("name")
        @Expose
        var name: String = ""

        @SerializedName("phoneNumber")
        @Expose
        var phoneNumber: String = ""

        @SerializedName("email")
        @Expose
        var email: String = ""

        @SerializedName("tournamentUsername")
        @Expose
        var tournamentUsername: String = ""

        @SerializedName("inGamerUserId")
        @Expose
        var inGamerUserId: String = ""
    }

    class Totals {
        @SerializedName("count")
        @Expose
        var count = 0
    }

}