package com.dynasty.esports.view.search

import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.startActivityFromFragment
import com.dynasty.esports.models.SearchTournamentModel
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamentDetailActivity
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*

/**
 * @desc this is class will show search tournament list
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SearchTournamentFragment : BaseFragment() {
    private var dataList: ArrayList<SearchTournamentModel.DocModel> = arrayListOf()
    private var type:String=""
    private lateinit var searchTournamentAdapter: SearchTournamentAdapter
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.recycler_progress_bar_view, container, false)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /**
         * @desc get array list from arguments
         */
        arguments?.apply {
            dataList.clear()
            type=this.getString("type").toString()
            dataList.addAll(this.getParcelableArrayList("data")!!)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        /**
         * @desc initialize view and adapter
         */
        linearLayoutProgressBar.beGone()
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        commonRecyclerView.isNestedScrollingEnabled = false
        searchTournamentAdapter = SearchTournamentAdapter(dataList, onItemClick = ::onItemClick)
        commonRecyclerView.adapter = searchTournamentAdapter
        if (dataList.isNullOrEmpty()) {
            commonRecyclerView.beGone()
            constraintLayoutNoData.beVisible()
        }
    }

    private fun onItemClick(position: Int, id: String) {
        val bundle = Bundle()
        bundle.putString("tournamentId", id)
        bundle.putBoolean("isUpcoming", type==  resources.getString(R.string.upcoming))
        startActivityFromFragment<TournamentDetailActivity>(bundle)
    }

    /**
     * @desc make fragment instance with set arguments
     * @param tournamentList - pass tournament list
     */
    companion object {
        fun newInstance(tournamentList: MutableList<SearchTournamentModel.DocModel>,type:String): Fragment {
            val args = Bundle()
            args.putParcelableArrayList("data", ArrayList<Parcelable>(tournamentList))
            args.putString("type",type);
            val fragment = SearchTournamentFragment()
            fragment.arguments = args
            return fragment
        }
    }
}