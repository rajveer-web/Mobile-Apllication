package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.checkPhoneValid
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.LoginRequest
import com.dynasty.esports.models.RegisterResponse
import com.dynasty.esports.models.SignInResponse
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import retrofit2.HttpException
import java.net.ConnectException
import java.net.UnknownHostException

class SignUpViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isRegistrationFormValid = MutableLiveData<Boolean>()
    val fbLoginObserver = MutableLiveData<Boolean>()
    val googleLoginObserver = MutableLiveData<Boolean>()
    val redirectPhoneRegistrationObserver = MutableLiveData<Boolean>()
    val redirectEmailRegistrationObserver = MutableLiveData<Boolean>()
    val countryCodeObserver = MutableLiveData<Boolean>()

    val signUpSuccessResponse = MutableLiveData<RegisterResponse>()
    val signUpErrorResponse = MutableLiveData<ResponseBody>()

    fun signUpAPI(loginRequest: LoginRequest) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.registerUser(loginRequest)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    signUpSuccessResponse.postValue(response.body())
                }
                else -> {
                    signUpErrorResponse.postValue(response.errorBody())
                }
            }

        }

    }

    fun onValidationForPhoneRegistration(
        nickName: String,
        code: String,
        phone: String,
        email: String,
        dob: String,
        isPolicySelect: Boolean,
        isParental: Boolean,
        isParentalShow: Boolean=false
    ) {
        when {
            nickName.isFieldEmpty() -> validationLiveData.postValue(0)
            code.isFieldEmpty() -> validationLiveData.postValue(1)
            phone.isFieldEmpty() -> validationLiveData.postValue(2)
            code=="+966" && phone.checkPhoneValid() -> validationLiveData.postValue(7)
            !email.isEmailValid() -> validationLiveData.postValue(3)
            dob.isFieldEmpty() -> validationLiveData.postValue(4)
            !isPolicySelect -> validationLiveData.postValue(5)
            isParentalShow && !isParental->validationLiveData.postValue(6)
            else -> isRegistrationFormValid.postValue(true)
        }
    }

    fun onValidationForEmailRegistration(nickname: String, email: String, isPolicySelect: Boolean) {
        when {
            nickname.isFieldEmpty() -> validationLiveData.postValue(0)
            email.isFieldEmpty() -> validationLiveData.postValue(1)
            !email.isEmailValid() -> validationLiveData.postValue(2)
            !isPolicySelect -> validationLiveData.postValue(3)
            else -> isRegistrationFormValid.postValue(true)
        }
    }

    fun fbLoginClick() {
        fbLoginObserver.postValue(true)
    }

    fun googleLoginClick() {
        googleLoginObserver.postValue(true)
    }

    fun phoneRegisterClick() {
        redirectPhoneRegistrationObserver.postValue(true)
    }

    fun emailRegisterClick() {
        redirectEmailRegistrationObserver.postValue(true)
    }

    fun countryCodeClick(){
        countryCodeObserver.postValue(true)
    }

//    fun callPhoneOrEmailLoginAPI(signInRequest: SignInRequest) {
//        viewModelScope.launch {
//            val response = restInterface.signIn(signInRequest)
//            withContext(Dispatchers.Main) {
//                when (response.code()) {
//                    AppConstants.API_SUCCESS_CODE -> {
//                        loginSuccessResponse.postValue(response.body())
//                    }
//                    else -> {
//                        loginErrorResponse.postValue(response.errorBody())
//                    }
//                }
//            }
//        }
//
//    }




    /**
     * Clears the [ViewModel] when the [SignInActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
