package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class CountriesModel {

    @SerializedName("countries")
    @Expose
    val countries: MutableList<CountryModel>? = null

    class CountryModel {
        @SerializedName("id")
        @Expose
        val id: Int? = null

        @SerializedName("sortname")
        @Expose
        val sortname: String? = null

        @SerializedName("name")
        @Expose
        val name: String = ""

        @SerializedName("phoneCode")
        @Expose
        val phoneCode: Int? = null
    }
}