package com.dynasty.esports.view.tournamet.manage_tournament.stream

import android.graphics.Color
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import com.dynasty.esports.R
import com.dynasty.esports.view.common.BaseActivity
import kotlinx.android.synthetic.main.activity_view_totrnament_video.*


class ViewTournamentVideoActivity : BaseActivity() {

    var path = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_totrnament_video)
        setView()
    }

    private fun setView() {
        //set toolbar
        setUpToolBar()

        //load webview

        intent.extras?.apply {
            path = this.getString("url").toString()
        }


        val finalUrl =
            "<html><body><iframe width='100%' height='100%' allowfullscreen='true' webkitallowfullscreen='true' mozallowfullscreen='true'  src=$path  style='border: none;'></iframe></body></html>"

        webView.webChromeClient = WebChromeClient()
        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.useWideViewPort = true
        webSettings.loadWithOverviewMode = true

        webView.setBackgroundColor(Color.TRANSPARENT)
        webView.loadUrl(path)
        if(!path.contains("twitch")) {
            webView.loadData(finalUrl, "text/html", "UTF-8")
        }


    }

    private fun setUpToolBar() {
        toolbar.title = resources.getString(R.string.see_video)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }
}