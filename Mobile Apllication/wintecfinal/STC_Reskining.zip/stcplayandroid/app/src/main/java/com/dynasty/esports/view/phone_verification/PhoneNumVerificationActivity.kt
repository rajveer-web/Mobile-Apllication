package com.dynasty.esports.view.phone_verification

import android.os.Bundle
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.view.otp_verification.OTPVerificationActivity
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.models.Country
import com.dynasty.esports.models.PhoneVerificationRequest
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.viewmodel.PhoneNumberVerificationViewModel
import kotlinx.android.synthetic.main.activity_phone_num_verification.*
import kotlinx.android.synthetic.main.content_phone_num_verification_screen.*
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class PhoneNumVerificationActivity : BaseActivity(), CountryCodePicker.Listener {

    var id: String? = null
    var type: String? = null
    var isEmail: Boolean = false
    var isSocial: Boolean = false
    private val mViewModel: PhoneNumberVerificationViewModel by viewModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_num_verification)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        getIntentData()
        initialise()
        listenToViewModel()
    }

    // to get data
    private fun getIntentData() {
        intent.extras?.apply {
            id = this.getString("id").toString()
            type = this.getString("type").toString()
            isEmail = this.getBoolean("isEmail")
            isSocial=this.getBoolean("isSocial")
        }
    }

    //to initialise the view
    fun initialise(){
        ph_verify_country_code.setText(getBaseCountryDialCode())

        ph_verify_country_code.click {
            mViewModel.countryCodeClick()
        }

        phverify_continue.click {
            mViewModel.formValidation(ph_verify_country_code.text.toString().trim(),ph_verify_phone_nos.text.toString().trim())
        }

//        btnPhVerifyCountryCode = ph_verify_country_code
//        btnPhVerifyNumber = ph_verify_phone_nos
//        btnPhVerifyContinue = phverify_continue
//        btnPhVerifyCountryCode.setText(getBaseCountryDialCode())
//        btnPhVerifyContinue.setOnClickListener(View.OnClickListener {
//            val countryCode : String = ph_verify_country_code.text.toString()
//            val phoneNos : String = ph_verify_phone_nos.text.toString()
//            val phoneNumber :String = countryCode + phoneNos
//
//            if(phoneNos.length==10){
//                val phVerifyRequest = PhoneVerificationRequest()
//                phVerifyRequest.id =id
//                phVerifyRequest.phoneNo = phoneNumber
//                verifyOTP(phVerifyRequest)
//            }else{
//                Toast.makeText(this,"Please fill the data", Toast.LENGTH_LONG).show()
//            }
//        })
    }

    // listen view model and manage the api
    private fun listenToViewModel() {
        mViewModel.countryCodeObserver.observe(this, {
            displayCountryCodeDialog()
        })

        mViewModel.validationLiveData.observe(this, {
            when (it) {
                0 -> {
                    makeSnackBar(
                        constraintLayoutPhoneNumber,
                        resources.getString(R.string.mobile_code_error)
                    )
                }
                1 -> {
                    makeSnackBar(
                        constraintLayoutPhoneNumber,
                        resources.getString(R.string.mobile_number_error)
                    )
                }
                2 -> {
                    makeSnackBar(
                        constraintLayoutPhoneNumber,
                        resources.getString(R.string.mobile_number_not_valid_error)
                    )
                }
            }
        })

        mViewModel.isFormValid.observe(this, {
            launchProgressDialog()
            val phVerifyRequest = PhoneVerificationRequest()
            phVerifyRequest.id = id
            phVerifyRequest.phoneNo = ph_verify_country_code.text.toString().trim().plus(ph_verify_phone_nos.text.toString().trim())
            if(isSocial){
                phVerifyRequest.type = "update_mobile"
                mViewModel.updatePhoneNumberSocial(phVerifyRequest)
            }else{
                mViewModel.updatePhoneNumber(phVerifyRequest)
            }
        })

        mViewModel.phoneNumberVerifySuccessResponse.observe(this, {
            dismissProgressDialog()
            val bundle=Bundle()
            bundle.putString("id",id)
            bundle.putString("phoneNumber",ph_verify_country_code.text.toString().trim().plus(ph_verify_phone_nos.text.toString().trim()))
            bundle.putString("activity",this@PhoneNumVerificationActivity::class.java.simpleName)
            if(type == "login"){
                bundle.putString("type",type)
            }else{
                bundle.putString("type","phone")
            }
            bundle.putBoolean("isEmail",isEmail)
            bundle.putBoolean("isSocial",isSocial)
            startActivityInline<OTPVerificationActivity>(bundle)
        })

        mViewModel.phoneNumberVerifyErrorResponse.observe(this, Observer {
            dismissProgressDialog()
            makeSnackBar(constraintLayoutPhoneNumber,it.string().getMessageFromObject("message"))
        })
    }

    override fun onCountryChosen(country: Country) {
        ph_verify_country_code.setText("+"+country.phoneCode )
    }

    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }

}