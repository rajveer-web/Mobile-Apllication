package com.dynasty.esports.view.inbox


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterInboxBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.InboxModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will be display inbox data
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class InboxListAdapter(
    private var inboxList: MutableList<InboxModel.DataModel>,
    private val onItemClick: (String,Boolean) -> Unit = { _,_ -> },
    private val onCheckMarkClick: (String,Int) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterInboxBinding>>() {
    var isCheckboxVisible=false

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterInboxBinding> {

        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_inbox,
                parent,
                false
            )
        )

    }

    /**
     * @desc inboxList array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return inboxList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterInboxBinding>,
        position: Int
    ) {
        val data = inboxList[holder.adapterPosition]
        holder.binding.textViewMessage.text=data.subject?.let { it } ?: "-"
        data.createdAt?.apply {
            holder.binding.textViewDate.text=this.convertDateToRequireDateFormat(AppConstants.API_DATE_FORMAT,AppConstants.MM_DD_YYYY_HH_MM_FORMAT)
        }

        if(checkMessageSelected()){
            holder.binding.checkBoxSelect.beVisible()
        }else{
            holder.binding.checkBoxSelect.beGone()
        }


        holder.binding.checkBoxSelect.isChecked=data.isSelected
//        holder.binding.checkBoxSelect.isChecked = selectedIds.contains(JsonPrimitive(data.id.toString()))

        holder.binding.checkBoxSelect.click {
            onCheckMarkClick(data.id.toString(),holder.adapterPosition)
        }

        holder.binding.cardView.click {
            onItemClick(data.id.toString(),data.seen!!)
        }
    }

    /**
     * @desc this method will call when tap select all option and add all ids in @selectedIds list
     * @return bool- if select all option
     */
    fun selectAllCheckbox(checked:Boolean){
        if(checked){
            inboxList.forEach {
                it.isSelected=true
            }
        }else{
            inboxList.forEach {
                it.isSelected=false
            }
        }

        isCheckboxVisible=checked
        notifyDataSetChanged()
    }

    private fun checkMessageSelected():Boolean{
        inboxList.forEach {
            if(it.isSelected){
                return true
            }
        }
        return false
    }

    fun getAll(): MutableList<InboxModel.DataModel>? {
        return inboxList
    }




}