package com.dynasty.esports.viewmodel

import android.app.Activity
import android.net.Uri
import android.webkit.URLUtil
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.CheckUrlRes
import com.dynasty.esports.models.CreateTournamentRes
import com.dynasty.esports.models.SearchUser
import com.dynasty.esports.retrofit.RestInterface
import com.dynasty.esports.view.payment.PaymentTournamentActivity
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class CreateTournamentStep3ViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val iseditUrlNotEmpty = MutableLiveData<Boolean>()
    val isNextStepFormValid = MutableLiveData<Boolean>()

    val checkUrlSuccessResponse = MutableLiveData<CheckUrlRes>()
    val checkUrlErrorResponse = MutableLiveData<ResponseBody>()

    val searchUserSuccessResponse = MutableLiveData<SearchUser>()
    val searchUserErrorResponse = MutableLiveData<ResponseBody>()

    val createTournamentSuccessResponse = MutableLiveData<CreateTournamentRes>()
    val createTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val countryCodeObserver = MutableLiveData<Boolean>()

    fun onValidationForNextStep(
        activity: Activity,
        tournamentUrlName: String,
        isTournamentUrlValid: Boolean,
        selectContactOption: String,
        tvEnterContactFacebookDetail: String,
        tvEnterContactWhatsappDetail: String,
        tvEnterContactEmailDetail: String,
//        isParticipantAdded: Boolean,
        youtubeLink: String,
        facebookLink: String,
        twichVideoLink: String
    ) {
        when {
            tournamentUrlName.isFieldEmpty() -> validationLiveData.postValue(0)
            !isTournamentUrlValid -> validationLiveData.postValue(1)
            !selectContactOption.isFieldEmpty() && selectContactOption.equals(
                "Facebook",
                true
            ) && tvEnterContactFacebookDetail.isFieldEmpty() -> validationLiveData.postValue(2)
            !selectContactOption.isFieldEmpty() && selectContactOption.equals(
                "WhatsApp",
                true
            ) && tvEnterContactWhatsappDetail.isFieldEmpty() -> validationLiveData.postValue(
                3
            )
            !selectContactOption.isFieldEmpty() && selectContactOption.equals(
                activity.getString(R.string.email),
                true
            ) && tvEnterContactEmailDetail.isFieldEmpty() && !tvEnterContactEmailDetail.isEmailValid() -> validationLiveData.postValue(
                4
            )
            !tvEnterContactEmailDetail.isFieldEmpty() && !tvEnterContactEmailDetail.isEmailValid() -> validationLiveData.postValue(
                9
            )
            !selectContactOption.isFieldEmpty() && selectContactOption.equals(
                "Twitter",
                true
            ) && tvEnterContactFacebookDetail.isFieldEmpty() -> validationLiveData.postValue(2)
            !selectContactOption.isFieldEmpty() && selectContactOption.equals(
                "Discord",
                true
            ) && tvEnterContactFacebookDetail.isFieldEmpty() -> validationLiveData.postValue(2)
//            isParticipantAdded -> validationLiveData.postValue(5)
            !youtubeLink.isFieldEmpty() && !isYoutubeUrl(youtubeLink) -> validationLiveData.postValue(
                6
            )
            !facebookLink.isFieldEmpty() && !isFacebookUrl(facebookLink) -> validationLiveData.postValue(
                7
            )
            !twichVideoLink.isFieldEmpty() && !isTwitchUrl(twichVideoLink) -> validationLiveData.postValue(
                8
            )
            else -> isNextStepFormValid.postValue(true)
        }
    }

    fun checkUrlValidOrNot(query: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.checkUrlExiestOrNot(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    checkUrlSuccessResponse.postValue(response.body())
                }
                else -> {
                    checkUrlErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun searchParticipant(query: String) {

        val jsonObject: JsonObject = JsonObject()

        val jsonText: JsonObject = JsonObject()

        jsonText.addProperty("\$regex", query)
        jsonText.addProperty("\$options", "i")

        jsonObject.add("text", jsonText)

        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response =
                restInterface.searchParticipant(
                    jsonObject,
                    "fullName,phoneNumber,email,profilePicture"
                )
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    searchUserSuccessResponse.postValue(response.body())
                }
                else -> {
                    searchUserErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun createTournament(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.createTournament(jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    createTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    createTournamentErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    private fun isYoutubeUrl(url: String?): Boolean {
        if (url == null) {
            return false
        }
        if (URLUtil.isValidUrl(url)) {
            // Check host of url if youtube exists
            val uri: Uri = Uri.parse(url)
            if ("www.youtube.com" == uri.host) {
                return true
            }
            // Other way You can check into url also like
            //if (url.startsWith("https://www.youtube.com/")) {
            //return true;
            //}
        }
        // In other any case
        return false
    }

    private fun isFacebookUrl(url: String?): Boolean {
        if (url == null) {
            return false
        }
        if (URLUtil.isValidUrl(url)) {
            // Check host of url if youtube exists
            val uri: Uri = Uri.parse(url)
            if ("www.facebook.com" == uri.host) {
                return true
            }
            // Other way You can check into url also like
            //if (url.startsWith("https://www.youtube.com/")) {
            //return true;
            //}
        }
        // In other any case
        return false
    }

    private fun isTwitchUrl(url: String?): Boolean {
        if (url == null) {
            return false
        }
        val uri: Uri = Uri.parse(url)
        if ("www.twitch.tv" == uri.host) {
            return true
        }
        // In other any case
        return false
    }

    fun checkValidation(editUrl: String) {
        when {
            editUrl.isFieldEmpty() -> validationLiveData.postValue(11)
            else -> iseditUrlNotEmpty.postValue(true)
        }
    }

    /**
     * Clears the [ViewModel] when the [CreateTournamentActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

    fun countryCodeClick() {
        countryCodeObserver.postValue(true)
    }
}
