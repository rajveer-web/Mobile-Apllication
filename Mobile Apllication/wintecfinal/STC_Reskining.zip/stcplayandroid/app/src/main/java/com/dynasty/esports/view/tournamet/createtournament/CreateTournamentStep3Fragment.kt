package com.dynasty.esports.view.tournamet.createtournament

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.*
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.view.payment.PaymentTournamentActivity
import com.dynasty.esports.view.tournamet.publish_tournament.PublishTourmamentActivity
import com.dynasty.esports.viewmodel.CreateTournamentStep3ViewModel
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_phone_num_verification.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step1.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step3.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step3.container
import kotlinx.android.synthetic.main.fragment_create_tournament_step3.llCheckUrl
import kotlinx.android.synthetic.main.spinner_sel.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.regex.Pattern

/**
 * @desc this is class will use for step 3 of create tournament
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CreateTournamentStep3Fragment : BaseFragment(), CountryCodePicker.Listener {

    private var isValidatedForm: Boolean = false
    private val mViewModel: CreateTournamentStep3ViewModel by viewModel()
    var visibilityRadioButton: Int = 1
    var selectContactOption: String = ""
    var isTournamentUrlValid: Boolean = false
    private lateinit var selectedUserParticipantAdapter: SelectedUserParticipantAdapter
    private lateinit var loginUserModel: UserModel.UserData
    val handler = Handler()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_create_tournament_step3, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialize()
        listenToViewModel()
    }

    /**
     * @desc this method is used for initialize view clicks, adapter and recyclerview
     *       set static data in spinner views
     */
    private fun initialize() {
//        get logindata from sharedPreferences
        loginUserModel =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData


//        remove selected user paricipant if click on remove from adapter
        selectedUserParticipantAdapter = SelectedUserParticipantAdapter(onItemRemoveClick = {
            val item = selectedUserParticipantAdapter.get(it)
            selectedUserParticipantAdapter.remove(item)
        })


//      rvSelectedUserParticipants recyclerView initialization
        rvSelectedUserParticipants.layoutManager =
            GridLayoutManager(requireActivity(), 2)
        rvSelectedUserParticipants.adapter = selectedUserParticipantAdapter

//        manage rgVisibility radioGroup
        rgVisibility.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            /* visibilityRadioButton = if (rbPublic.isChecked) {
                 1
             } else {
                 2
             }*/
            if (rbPublic.isChecked) {
                visibilityRadioButton = 1
                rbPublic.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                rbPrivate.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.background_color
                    )
                )

            } else {
                visibilityRadioButton = 2
                rbPublic.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.background_color
                    )
                )
                rbPrivate.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            }
        })


//      add static data in shareItemList
        val shareItemList = ArrayList<Spinner>()
        shareItemList.add(Spinner("0", "None"))
        shareItemList.add(Spinner("1", "Facebook"))
        shareItemList.add(Spinner("2", "WhatsApp"))
        shareItemList.add(Spinner("3", resources.getString(R.string.email)))
        shareItemList.add(Spinner("4", "Twitter"))
        shareItemList.add(Spinner("5", "Discord"))

//        if select facebook then facebook edittext should be visible and id select contact via whatsapp then whatsapp view should be visible
        tvselectContactOption.click {
            requireActivity().showSpinner(
                resources.getString(R.string.select_contact_option),
                tvselectContactOption,
                shareItemList,
                false,
                onItemClick = {
                    val data = it as Spinner
                    when {
                        data.title.equals("Facebook", true) -> {
                            tlInputFacebook.hint =
                                resources.getString(R.string.enter_facebook_details)
                            llContactDetails.beVisible()
                            tlEnterContactFacebookDetail.beVisible()
                            llContactWhatsappDetail.beGone()
                            tlEnterContactEmailDetail.beGone()
                            selectContactOption = data.title
                        }
                        data.title.equals("Twitter", true) -> {
                            tlInputFacebook.hint =
                                resources.getString(R.string.enter_twitter_details)
                            llContactDetails.beVisible()
                            tlEnterContactFacebookDetail.beVisible()
                            llContactWhatsappDetail.beGone()
                            tlEnterContactEmailDetail.beGone()
                            selectContactOption = data.title
                        }
                        data.title.equals("Discord", true) -> {
                            tlInputFacebook.hint =
                                resources.getString(R.string.enter_discord_details)
                            llContactDetails.beVisible()
                            tlEnterContactFacebookDetail.beVisible()
                            llContactWhatsappDetail.beGone()
                            tlEnterContactEmailDetail.beGone()
                            selectContactOption = data.title
                        }
                        data.title.equals("WhatsApp", true) -> {
                            llContactDetails.beVisible()
                            tlEnterContactFacebookDetail.beGone()
                            llContactWhatsappDetail.beVisible()
                            tlEnterContactEmailDetail.beGone()
                            selectContactOption = data.title
                        }
                        data.title.equals(resources.getString(R.string.email), true) -> {
                            llContactDetails.beVisible()
                            tlEnterContactFacebookDetail.beGone()
                            llContactWhatsappDetail.beGone()
                            tlEnterContactEmailDetail.beVisible()
                            selectContactOption = data.title
                        }
                        else -> {
                            llContactDetails.beVisible()
                            tlEnterContactFacebookDetail.beGone()
                            llContactWhatsappDetail.beGone()
                            tlEnterContactEmailDetail.beGone()
                            selectContactOption = ""
                            tvselectContactOption.setText("")
                        }
                    }
                }
            )
        }

//      open add Participants dialog on tvAppParticipants click
        tvAppParticipants.click {
            showParticipantDialog()
        }


//      check validation on Checkurl button click
        llCheckUrl.click {
            mViewModel.checkValidation(editTournamentStep3.text.toString().trim())
        }

        //      TournamentName textchangelistner for url is available or not
        editTournamentStep3.doAfterTextChanged {
            handler.removeCallbacks(runnableTeamUrlName)
//            val removeSpaceUrl = it.toString().replace(" ", "_")
            val regex: Pattern = Pattern.compile("[$&+,:;=\\\\?@#|/'<>.^*()%!-]")
            if (regex.matcher(it.toString()).find()) {
                tvTournamentStep3Url.text =
                    BuildConfig.ARTICLE_PATH.plus(it.toString().replace(" ", "_"))
                tvTournamentStep3Url.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.red
                    )
                )
                isTournamentUrlValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentName = it.toString()
            } else {
                tvTournamentStep3Url.text =
                    BuildConfig.ARTICLE_PATH.plus(it.toString().replace(" ", "_"))
                tvTournamentStep3Url.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.red
                    )
                )
                isTournamentUrlValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentName = it.toString()

                if (!it.toString().replace(" ", "_").isFieldEmpty()) {
                    handler.removeCallbacks(runnableTeamUrlName)
                    handler.postDelayed(runnableTeamUrlName, 1000)
                }
            }
        }

        tvEnterContactWhatsappCode.click {
            mViewModel.countryCodeClick()
        }

        share_fb.click {
            val intent = Intent(Intent.ACTION_SEND)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            val urlLink = BuildConfig.ARTICLE_PATH.plus("article/$id")
            val urlLink = tvTournamentStep3Url.text.toString().trim()
            intent.putExtra(Intent.EXTRA_TEXT, urlLink)
            intent.type = "text/plain"
            startActivity(Intent.createChooser(intent, "Share Tournament via"))
        }
    }

    /**
     * @desc listen observer and receive the events of viewmodel
     * Also, Manage validation for next step and show snacbar for every validation if its not validated
     */
    private fun listenToViewModel() {
//      save as draft api call SuccessResponse
        mViewModel.createTournamentSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            debugE("createTournamentSaveSuccessResponse", Gson().toJson(it))
            try {
                requireActivity().makeSnackBar(
                    container,
                    it.message!!
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
            val bundle = Bundle()
            bundle.putString("tournamentId", it.data!!.data!!.id)
            bundle.putString("name", it.data!!.data!!.createdBy)
            requireActivity().startActivityInline<PaymentTournamentActivity>(bundle)
        })

//      save as draft api call ErrorResponse
        mViewModel.createTournamentErrorResponse.observe(viewLifecycleOwner, Observer {
            debugE("createTournamentSaveErrorResponse", Gson().toJson(it))
            dismissProgressDialog()
            try {
                val errorRes: CreateTournamentErrorRes = Gson().fromJson(
                    it.string(),
                    object : TypeToken<CreateTournamentErrorRes?>() {}.type
                )
                errorRes.message!!.showToast(requireActivity())
            } catch (e: Exception) {
            }
        })

//      check tournament url success responce
        mViewModel.checkUrlSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                debugE("checkUrlSuccessResponse", Gson().toJson(it))
                dismissProgressDialog()
                if (it.totals!!.count == 0) {
                    isTournamentUrlValid = true
                    tvTournamentStep3Url.setTextColor(resources.getColor(R.color.join_tournament_green_color))
                    requireActivity().makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_url_is_valid)
                    )
                } else {
                    isTournamentUrlValid = false
                    tvTournamentStep3Url.setTextColor(resources.getColor(R.color.red))
                    requireActivity().makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_url_error)
                    )
                }
            })

//      check tournament url error responce
        mViewModel.checkUrlErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                debugE("checkUrlErrorResponse", Gson().toJson(it))
                dismissProgressDialog()
            })


//      Open countryCode picker
        mViewModel.countryCodeObserver.observe(viewLifecycleOwner, Observer {
            CountryCodePicker.showDialog(childFragmentManager)
        })

//      check validation for iseditUrlNotEmpty
        mViewModel.iseditUrlNotEmpty.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                launchProgressDialog()
                val jsonObjectQuery = JsonObject()
                jsonObjectQuery.addProperty("url", tvTournamentStep3Url.text.toString().trim())
                if ((requireActivity() as CreateTourmamentActivity).isForEdit) {
                    val jsonObjectNe = JsonObject()
                    jsonObjectNe.addProperty(
                        "\$ne",
                        (requireActivity() as CreateTourmamentActivity).tournamentId
                    )
                    jsonObjectQuery.add("_id", jsonObjectNe)
                }
                debugE("jsonObjectQuery £", jsonObjectQuery.toString())
                mViewModel.checkUrlValidOrNot(jsonObjectQuery.toString())
            })

//      validationLiveData and show snacbar for incorrect value
        mViewModel.validationLiveData.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                isValidatedForm = false
                when (it) {
                    0 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_name_error)
                        )
                    }
                    1 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_url_error)
                        )
                    }
                    2 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.enter_contact_detail)
                        )
                    }
                    3 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.enter_contact_detail)
                        )
                    }
                    4 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.enter_contact_detail)
                        )
                    }
                    5 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.add_participant_detail)
                        )
                    }
                    6 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.youtube_url_is_not_validated)
                        )
                    }
                    7 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.facebook_url_is_not_validated)
                        )
                    }
                    8 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.twitch_url_is_not_validated)
                        )
                    }
                    9 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.email_valid_error)
                        )
                    }
                    11 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_name_error)
                        )
                    }
                }
            })

//      check isNextStepFormValid or not
        mViewModel.isNextStepFormValid.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                saveData()
                isValidatedForm = true
                val bundle = Bundle()
                bundle.putBoolean(
                    "isForEdit",
                    (requireActivity() as CreateTourmamentActivity).isForEdit
                )
                bundle.putString(
                    "tournamentId",
                    (requireActivity() as CreateTourmamentActivity).tournamentId
                )
                requireActivity().startActivityInline<PublishTourmamentActivity>(bundle)
//                val createTournamentJson = getTournamentObject(createTournamentSaved)
//                debugE("jsonObject £", Gson().toJson(createTournamentJson))
//                launchProgressDialog()
//                mViewModel.createTournament(createTournamentJson)
            })
    }

//    /**
//     * @desc method will generate TournamentObject for send in create tournament api
//     */
//    private fun getTournamentObject(createTournamentSaved: CreateTournament): JsonObject {
//        val jsonObject: JsonObject = JsonObject()
//        jsonObject.addProperty("name", createTournamentSaved.name)
//        jsonObject.addProperty("url", createTournamentSaved.url)
//        jsonObject.addProperty("participantType", createTournamentSaved.participantType)
//        jsonObject.addProperty("startDate", createTournamentSaved.startDate)
//        jsonObject.addProperty("startTime", createTournamentSaved.startTime)
//        jsonObject.addProperty("isPaid", createTournamentSaved.isPaid)
//        jsonObject.addProperty("description", createTournamentSaved.description)
//        jsonObject.addProperty("rules", createTournamentSaved.rules)
//        jsonObject.addProperty("criticalRules", createTournamentSaved.criticalRules)
//        jsonObject.addProperty("isPrize", createTournamentSaved.isPrize)
//        jsonObject.addProperty("faqs", createTournamentSaved.faqs)
//        jsonObject.addProperty("schedule", createTournamentSaved.schedule)
//        jsonObject.addProperty("isIncludeSponsor", createTournamentSaved.isIncludeSponsor)
//        jsonObject.addProperty("tournamentType", createTournamentSaved.tournamentType)
//        jsonObject.addProperty(
//            "isScreenshotRequired",
//            createTournamentSaved.isScreenshotRequired
//        )
//        jsonObject.addProperty("isShowCountryFlag", createTournamentSaved.isShowCountryFlag)
//        jsonObject.addProperty(
//            "isSpecifyAllowedRegions",
//            createTournamentSaved.isSpecifyAllowedRegions
//        )
//        jsonObject.addProperty(
//            "isParticipantsLimit",
//            createTournamentSaved.isParticipantsLimit
//        )
//        jsonObject.addProperty("scoreReporting", createTournamentSaved.scoreReporting)
//        jsonObject.addProperty("invitationLink", createTournamentSaved.invitationLink)
//        jsonObject.addProperty("youtubeVideoLink", createTournamentSaved.youtubeVideoLink)
//        jsonObject.addProperty("facebookVideoLink", createTournamentSaved.facebookVideoLink)
//        jsonObject.addProperty("contactDetails", createTournamentSaved.contactDetails)
//        jsonObject.addProperty("twitchVideoLink", createTournamentSaved.twitchVideoLink)
//        jsonObject.addProperty("visibility", createTournamentSaved.visibility)
//        jsonObject.addProperty("checkInEndDate", createTournamentSaved.checkInEndDate)
//        jsonObject.addProperty("banner", createTournamentSaved.banner)
//        jsonObject.addProperty("maxParticipants", createTournamentSaved.maxParticipants)
//        jsonObject.addProperty("bracketType", createTournamentSaved.bracketType)
//        jsonObject.addProperty("noOfSet", createTournamentSaved.noOfSet)
//        jsonObject.addProperty("contactOn", createTournamentSaved.contactOn)
//        jsonObject.addProperty("gameDetail", createTournamentSaved.gameDetail)
//        jsonObject.addProperty("teamSize", createTournamentSaved.teamSize)
//        jsonObject.addProperty("firstPrize", createTournamentSaved.firstPrize)
//        jsonObject.addProperty("secondPrize", createTournamentSaved.secondPrize)
//        jsonObject.addProperty("thirdPrize", createTournamentSaved.thirdPrize)
//        jsonObject.addProperty("prizeCurrency", createTournamentSaved.prizeCurrency)
//        jsonObject.addProperty("slug", createTournamentSaved.name)
////        draft & submitted_for_approval
//        jsonObject.addProperty("tournamentStatus", "draft")
//        jsonObject.addProperty("organizerDetail", loginUserModel.id)
//        jsonObject.addProperty("updatedBy", loginUserModel.id)
//        jsonObject.addProperty("createdBy", loginUserModel.id)
////        jsonObject.addProperty("endDate", "2020-07-21T08:58:29.288Z")
//        jsonObject.addProperty("checkInStartDate", createTournamentSaved.checkInStartDate)
//
//        val venueAddressList: JsonArray = JsonArray()
//
//        for (i in createTournamentSaved.venueAddress) {
//            val jsonObject = JsonObject()
//            jsonObject.addProperty("country", i.country)
//            jsonObject.addProperty("region", i.region)
//            jsonObject.addProperty("venue", i.venue)
//            jsonObject.addProperty("stage", i.stage)
//            venueAddressList.add(jsonObject)
//        }
//
//        val sponsorsList: JsonArray = JsonArray()
//
//        for (i in createTournamentSaved.sponsors) {
//            val jsonObject = JsonObject()
//            jsonObject.addProperty("sponsorName", i.sponsorName)
//            jsonObject.addProperty("website", i.website)
//            jsonObject.addProperty("playStoreUrl", i.playStoreUrl)
//            jsonObject.addProperty("appStoreUrl", i.appStoreUrl)
//            jsonObject.addProperty("sponsorLogo", i.sponsorLogo)
//            jsonObject.addProperty("sponsorBanner", i.sponsorBanner)
//            sponsorsList.add(jsonObject)
//        }
//
//        val participantsList: JsonArray = JsonArray()
//
//        for (i in createTournamentSaved.participants) {
//            val jsonObjectpart = JsonObject()
//            jsonObjectpart.addProperty("_id", i.id)
//            jsonObjectpart.addProperty("fullName", i.fullName)
//            jsonObjectpart.addProperty("phoneNumber", i.phoneNumber)
//            jsonObjectpart.addProperty("email", i.email)
//            jsonObjectpart.addProperty("profilePicture", i.profilePicture)
//            participantsList.add(jsonObjectpart)
//        }
//
//        val regList: JsonArray = JsonArray()
//
//        for (i in createTournamentSaved.regionsAllowed) {
//            regList.add(i)
//        }
//        if (venueAddressList.size() != 0) {
//            jsonObject.add("venueAddress", venueAddressList)
//        }
//        if (sponsorsList.size() != 0) {
//            jsonObject.add("sponsors", sponsorsList)
//        }
////        if (participantsList.size() != 0) {
//        jsonObject.add("participants", participantsList)
////        }
//        if (regList.size() != 0) {
//            jsonObject.add("regionsAllowed", regList)
//        }
//
//        return jsonObject
//    }

    companion object {
        fun newInstance(type: String): Fragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = CreateTournamentStep3Fragment()
            fragment.arguments = args
            return fragment
        }
    }

    /**
     * @desc this method is used for get data from local and if local data is available then set values in fields
     */
    fun refreshSaveData() {
        try {
            val createTournamentSaved: CreateTournament? =
                sharedPreferences.get<CreateTournament>("createTournamentSave")

            if (createTournamentSaved == null) {
                return
            }

            createTournamentSaved.apply {
                if ((requireActivity() as CreateTourmamentActivity).tournamentName.isFieldEmpty()) {
                    editTournamentStep3.setText(this.name)
                } else {
                    editTournamentStep3.setText((requireActivity() as CreateTourmamentActivity).tournamentName)
                }

                if ((requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid) {
                    isTournamentUrlValid = true
                    tvTournamentStep3Url.setTextColor(resources.getColor(R.color.join_tournament_green_color))
                } else {
                    isTournamentUrlValid = false
                    tvTournamentStep3Url.setTextColor(resources.getColor(R.color.white))
                }

                tvTournamentStep3Url.text = this.url

                if (this.visibility == 1) {
                    visibilityRadioButton = 1
                    rbPublic.isChecked = true
                } else {
                    visibilityRadioButton = 2
                    rbPrivate.isChecked = false
                }

                editYoutubeLink.setText(this.youtubeVideoLink)
                editFacebookLink.setText(this.facebookVideoLink)
                edittwitchLink.setText(this.twitchVideoLink)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * @desc this method is used for save data to local when click on save tournament.
     */
    fun saveData() {

        val createTournamentSaved: CreateTournament? =
            sharedPreferences.get<CreateTournament>("createTournamentSave")

        if (createTournamentSaved != null) {
            (requireActivity() as CreateTourmamentActivity).createTournamentSave =
                createTournamentSaved
        }


        val participantList: MutableList<CreateTournament.Participant>? =
            ArrayList<CreateTournament.Participant>()

        for (i in selectedUserParticipantAdapter.getAll()!!) {
            val participant = CreateTournament.Participant()
            participant.email = i.email!!
            participant.fullName = i.fullName!!
            participant.id = i.id!!
            participant.phoneNumber = i.phoneNumber!!
            participant.profilePicture = i.profilePicture!!
            participantList!!.add(participant)
        }

        (requireActivity() as CreateTourmamentActivity).createTournamentSave.apply {
            this.youtubeVideoLink = editYoutubeLink.text.toString().trim()
            this.facebookVideoLink = editFacebookLink.text.toString().trim()
            this.twitchVideoLink = edittwitchLink.text.toString().trim()
            this.visibility = visibilityRadioButton
            this.contactOn = selectContactOption
            if (selectContactOption.equals("Facebook", true)) {
                this.contactDetails = tvEnterContactFacebookDetail.text.toString().trim()
            } else if (selectContactOption.equals("WhatsApp", true)) {
                this.contactDetails =
                    tvEnterContactWhatsappCode.text.toString()
                        .trim() + tvEnterContactWhatsappDetail.text.toString()
                        .trim()
            } else if (selectContactOption.equals(resources.getString(R.string.email), true)) {
                this.contactDetails = tvEnterContactFacebookDetail.text.toString().trim()
            }
            if (participantList!!.isNotEmpty()) {
                this.participants = participantList
            }
            this.url = tvTournamentStep3Url.text.toString().trim()
            this.name = editTournamentStep3.text.toString().trim()
        }

        sharedPreferences.put(
            "createTournamentSave",
            (requireActivity() as CreateTourmamentActivity).createTournamentSave
        )
//        return (requireActivity() as CreateTourmamentActivity).createTournamentSave
    }

    /**
     * @desc this method is used for check validation for is able to send data in api
     */
    fun isValidated() {
        mViewModel.onValidationForNextStep(
            requireActivity(),
            editTournamentStep3.text.toString().trim(),
            isTournamentUrlValid,
            selectContactOption,
            tvEnterContactFacebookDetail.text.toString().trim(),
            tvEnterContactWhatsappDetail.text.toString().trim(),
            tvEnterContactEmailDetail.text.toString().trim(),
//            selectedUserParticipantAdapter.getAll()!!.isEmpty(),
            editYoutubeLink.text.toString().trim(),
            editFacebookLink.text.toString().trim(),
            edittwitchLink.text.toString().trim()
        )
    }

    /**
     * @desc this method is used for Add participant Dialog with search functionality
     */
    private fun showParticipantDialog() {
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_search_participant)
        val editParticipantSearch = dialog.findViewById(R.id.editParticipantSearch) as EditText
        val dialogtitle = dialog.findViewById(R.id.dialogtitle) as TextView
        val llPlaceHolder = dialog.findViewById(R.id.llPlaceHolder) as TextView
        val rvSearchParticipants = dialog.findViewById(R.id.rvSearchParticipants) as RecyclerView
        val pbSearchParticipant = dialog.findViewById(R.id.pbSearchParticipant) as ProgressBar

        dialogtitle.text = resources.getString(R.string.add_participants)

        val handler = Handler()

//      adapter initialization
        val searchUserAdapter =
            SearchUserAdapter(onSearchUserItemClick = { poition: Int, datum: SearchUser.Datum ->
                if (selectedUserParticipantAdapter.isAlreadyAdded(datum.id!!)) {
                    getString(R.string.user_already_added).showToast(requireContext())
                } else {
                    selectedUserParticipantAdapter.add(datum)
                    refreshPlaceHolderUser()
                    dialog.dismiss()
                }
            })

        rvSearchParticipants.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        rvSearchParticipants.adapter = searchUserAdapter

        val runnableSearch = Runnable {
            if (editParticipantSearch.text.toString().trim().isEmpty()) {
                searchUserAdapter.clear()
                refreshPlaceHolderDialog(llPlaceHolder, rvSearchParticipants, pbSearchParticipant)
            } else {
                pbSearchParticipant.beVisible()
                llPlaceHolder.beGone()
                rvSearchParticipants.beGone()
                mViewModel.searchParticipant(editParticipantSearch.text.toString().trim())
            }
        }

        editParticipantSearch.doAfterTextChanged {
            if (it.toString().isNotEmpty()) {
                handler.removeCallbacks(runnableSearch)
                handler.postDelayed(runnableSearch, 500)
            } else {
                searchUserAdapter.clear()
                refreshPlaceHolderDialog(llPlaceHolder, rvSearchParticipants, pbSearchParticipant)
            }
        }

        mViewModel.searchUserSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                searchUserAdapter.addAll(it.data)
                refreshPlaceHolderDialog(llPlaceHolder, rvSearchParticipants, pbSearchParticipant)
                dismissProgressDialog()
            })

        mViewModel.searchUserErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                try {
                    requireActivity().makeSnackBar(
                        constraintLayoutPhoneNumber,
                        it.string().getMessageFromObject("message")
                    )
                } catch (e: Exception) {
                }
                llPlaceHolder.beVisible()
                rvSearchParticipants.beGone()
                dismissProgressDialog()
                refreshPlaceHolderDialog(llPlaceHolder, rvSearchParticipants, pbSearchParticipant)
            })

        searchUserAdapter.clear()
        dialog.show()
        dialog.setOnDismissListener {
            searchUserAdapter.clear()
            handler.removeCallbacks(null)
        }
    }

    val runnableTeamUrlName = Runnable {
        if (editTournamentStep3.text.toString().trim({ it <= ' ' }).isEmpty()) {
            isTournamentUrlValid = false
        } else {
//            launchProgressDialog()
            val jsonObjectQuery = JsonObject()
            jsonObjectQuery.addProperty("url", tvTournamentStep3Url.text.toString().trim())
            if ((requireActivity() as CreateTourmamentActivity).isForEdit) {
                val jsonObjectNe = JsonObject()
                jsonObjectNe.addProperty(
                    "\$ne",
                    (requireActivity() as CreateTourmamentActivity).tournamentId
                )
                jsonObjectQuery.add("_id", jsonObjectNe)
            }
            debugE("jsonObjectQuery £", jsonObjectQuery.toString())
            mViewModel.checkUrlValidOrNot(jsonObjectQuery.toString())
        }
    }

    /**
     * @desc this method is used for llSelectedUserParticipants visible if adapter is not empty
     */
    fun refreshPlaceHolderUser() {
        if (selectedUserParticipantAdapter.getAll()!!.isNotEmpty()) {
            llSelectedUserParticipants.beVisible()
        } else {
            llSelectedUserParticipants.beGone()
        }
    }

    /**
     * @desc this method is used for refresh placeholder in add participant dialog
     *       if participant list is empty then placeholder will be shown
     */
    fun refreshPlaceHolderDialog(
        llPlaceHolder: TextView,
        rvSearchParticipants: RecyclerView,
        pbSearchParticipant: ProgressBar
    ) {
        pbSearchParticipant.beGone()
        if (rvSearchParticipants.adapter!!.itemCount > 0) {
            llPlaceHolder.beGone()
            rvSearchParticipants.beVisible()
        } else {
            llPlaceHolder.beVisible()
            rvSearchParticipants.beGone()
        }
    }

    /**
     * @desc this method is used for set selected Country to tvEnterContactWhatsappCode
     */
    override fun onCountryChosen(country: Country) {
        tvEnterContactWhatsappCode.text = "+" + country.phoneCode
    }


    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnableTeamUrlName)
        mViewModel.onDetach()
    }
}