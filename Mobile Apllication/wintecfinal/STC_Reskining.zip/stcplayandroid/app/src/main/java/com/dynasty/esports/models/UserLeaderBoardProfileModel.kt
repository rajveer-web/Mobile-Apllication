package com.dynasty.esports.models

import com.dynasty.esports.models.LeaderboardByGameModel.Id
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class UserLeaderBoardProfileModel {

    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("messageCode")
    @Expose
     val messageCode: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null

    class DataModel{

        @SerializedName("_id")
        @Expose
         val id: Id? = null

        @SerializedName("winCount")
        @Expose
         val winCount: Int? = null

        @SerializedName("lossCount")
        @Expose
         val lossCount: Int? = null

        @SerializedName("streak")
        @Expose
         val streak: Int? = null

        @SerializedName("firstPosition")
        @Expose
         val firstPosition: Int? = null

        @SerializedName("secondPosition")
        @Expose
         val secondPosition: Int? = null

        @SerializedName("thirdPosition")
        @Expose
         val thirdPosition: Int? = null

        @SerializedName("awardDocCount")
        @Expose
         val awardDocCount: Int? = null

        @SerializedName("points")
        @Expose
         val points: Int? = null

        @SerializedName("count")
        @Expose
         val count: Int? = null

        @SerializedName("user")
        @Expose
         val user: MutableList<UserDetailModel>? = null

        @SerializedName("totalGameCount")
        @Expose
         val totalGameCount: Int? = null

        @SerializedName("winPercent")
        @Expose
         val winPercent: Int? = null

        @SerializedName("gameStreakData")
        @Expose
         val gameStreakData: MutableList<GameStreakDatumModel>? = null

        @SerializedName("rank")
        @Expose
         val rank: Int? = null
    }
    class GameStreakDatumModel{
        @SerializedName("_id")
        @Expose
         val id: Ids? = null

        @SerializedName("winCount")
        @Expose
         val winCount: Int? = null
    }

    class Ids{
        @SerializedName("month")
        @Expose
        val month: Int? = null
        @SerializedName("day")
        @Expose
        val day: Int? = null
        @SerializedName("year")
        @Expose
        val year: Int? = null


    }
    class UserDetailModel{
        @SerializedName("fullName")
        @Expose
         val fullName: String? = null

        @SerializedName("profilePicture")
        @Expose
         val profilePicture: String? = null

        @SerializedName("country")
        @Expose
         val country: String? = null

        @SerializedName("state")
        @Expose
         val state: String? = null
    }
}