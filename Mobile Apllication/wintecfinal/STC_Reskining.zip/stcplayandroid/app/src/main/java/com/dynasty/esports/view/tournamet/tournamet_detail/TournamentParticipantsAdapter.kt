package com.dynasty.esports.view.tournamet.tournamet_detail


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterUpcomingParticipantsBinding
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.ParticipantsModel
import com.dynasty.esports.utils.BindingHolder
import kotlinx.android.synthetic.main.adapter_upcoming_participants.view.*
//row_article_post

class TournamentParticipantsAdapter constructor(
    private val onItemClick: (Int) -> Unit = { _ -> }
) :
    RecyclerView.Adapter<BindingHolder<AdapterUpcomingParticipantsBinding>>() {

    private var listOfParticipants: MutableList<ParticipantsModel.DataModel> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterUpcomingParticipantsBinding> {
        val binding: AdapterUpcomingParticipantsBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_upcoming_participants,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    override fun getItemCount(): Int {
        return listOfParticipants.size
    }

    fun getAll(): MutableList<ParticipantsModel.DataModel>? {
        return listOfParticipants
    }

    fun addAll(listOfParticipants_: MutableList<ParticipantsModel.DataModel>) {
        listOfParticipants.clear()
        listOfParticipants.addAll(listOfParticipants_)
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(
        holder: BindingHolder<AdapterUpcomingParticipantsBinding>,
        position: Int
    ) {
        val data = listOfParticipants[position]

        holder.binding.teammName.text = data.teamName

        if (data.logo.isNotEmpty()) {
            holder.itemView.context.loadImageFromServer(data.logo, holder.itemView.team_img)
        }

        holder.itemView.setOnClickListener {
            onItemClick(position)
        }
    }

    fun getItem(position: Int): ParticipantsModel.DataModel {
        return this.listOfParticipants[position]
    }
}