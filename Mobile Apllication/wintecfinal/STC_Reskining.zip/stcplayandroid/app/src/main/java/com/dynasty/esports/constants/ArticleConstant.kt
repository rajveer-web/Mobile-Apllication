package com.dynasty.esports.constants

object ArticleConstant{
    const val CONST_TRENDING_POST=9
    const val CONST_LATEST_ARTICLE=1
    const val CONST_POST_BY_AUTHOR=2
    const val CONST_POST_BY_GAMES=3
    const val CONST_LATEST_VIDEO=4
    const val CONST_HOME_POST_BY_GAMES=5
    const val CONST_LATEST_NEWS=6
    const val CONST_HOTTEST_GAMES=7
    const val CONST_ALL_GAMES = 8

}