package com.dynasty.esports.models

import java.io.Serializable

data class ChildDataItem(var childName: String) : Serializable