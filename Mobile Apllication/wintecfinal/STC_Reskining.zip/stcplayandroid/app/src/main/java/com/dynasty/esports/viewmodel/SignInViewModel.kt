package com.dynasty.esports.viewmodel

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.checkPhoneValid
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.SignInRequest
import com.dynasty.esports.models.SignInResponse
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.*
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.HttpException
import java.net.ConnectException
import java.net.UnknownHostException

class SignInViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isLoginFormValid = MutableLiveData<Boolean>()
    val fbLoginObserver = MutableLiveData<Boolean>()
    val googleLoginObserver = MutableLiveData<Boolean>()
    val redirectPhoneRegistrationObserver = MutableLiveData<Boolean>()
    val redirectEmailRegistrationObserver = MutableLiveData<Boolean>()
    val loginSuccessResponse = MutableLiveData<Pair<String,SignInResponse>>()
    val loginErrorResponse = MutableLiveData<String>()
    val countryCodeObserver = MutableLiveData<Boolean>()

    val registerFCMTokenSuccessResponse = MutableLiveData<ResponseBody>()
    val registerFCMTokenErrorResponse = MutableLiveData<ResponseBody>()

    fun registrationPushNotification(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.registerfcmToken(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    registerFCMTokenSuccessResponse.postValue(response.body())
                }
                else -> {
                    registerFCMTokenErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun onValidationForPhoneLogin(code: String, phone: String, password: String) {
        when {
            code.isFieldEmpty() -> validationLiveData.postValue(0)
            phone.isFieldEmpty() -> validationLiveData.postValue(1)
            code=="+966" && phone.checkPhoneValid() -> validationLiveData.postValue(2)
            password.isFieldEmpty() -> validationLiveData.postValue(3)
            else -> isLoginFormValid.postValue(true)
        }
    }
    fun onValidationForEmailLogin(email: String, password: String) {
        when {
            email.isFieldEmpty() -> validationLiveData.postValue(0)
            !email.isEmailValid() -> validationLiveData.postValue(1)
            password.isFieldEmpty() -> validationLiveData.postValue(2)
            else -> isLoginFormValid.postValue(true)
        }
    }

    fun countryCodeClick(){
        countryCodeObserver.postValue(true)
    }

    fun fbLoginClick() {
        fbLoginObserver.postValue(true)
    }

    fun googleLoginClick() {
        googleLoginObserver.postValue(true)
    }

    fun phoneRegisterClick() {
        redirectPhoneRegistrationObserver.postValue(true)
    }

    fun emailRegisterClick() {
        redirectEmailRegistrationObserver.postValue(true)
    }

    fun callPhoneOrEmailLoginAPI(signInRequest: SignInRequest) {
        viewModelScope.launch(apiException("login")+Dispatchers.Main) {
            val response = restInterface.signIn(signInRequest)

                when (response.code()) {
                    AppConstants.API_SUCCESS_CODE -> {
                        loginSuccessResponse.postValue(Pair(response.headers().get("set-cookie").toString().split(";")[0],response.body()!!))
                    }
                    else -> {
                        val jObjError = JSONObject(response.errorBody()!!.string())
                        loginErrorResponse.postValue(jObjError.getString("message"))
                        //loginErrorResponse.postValue(response.errorBody())
                    }
                }

        }

    }


    /**
     * Clears the [ViewModel] when the [SignInActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
