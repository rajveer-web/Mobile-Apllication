package com.dynasty.esports.retrofit

import com.dynasty.esports.models.*
import com.google.gson.JsonObject
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*

interface RestInterface {


    @FormUrlEncoded
    @POST("createuser")
    fun userLogin(
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<LoginResponse>


/*   @FormUrlEncoded
    @POST("register")
    fun registerUserByEmail(
       @Field("fullName") fullname: String?,
       @Field("email") email:String?,
       @Field("password") password: String?,
       @Field("type") type: String?
    ):Call<RegisterResponse>*/

    //tested
    @POST("auth/stc_register")
    suspend fun registerUser(@Body loginReq: LoginRequest): Response<RegisterResponse>

    @Headers("withCredentials: true")
    @POST("auth/stc_verify")
    suspend fun loginVerify(@Body verifyReq: VerifyRequest): Response<SignInResponse>

    @Headers("withCredentials: true")
    @POST("auth/social_login")
    suspend fun socialloginVerify(@Body verifyReq: SocialVerificationRequest): Response<SignInResponse>

    @POST("auth/social_login")
    suspend fun resendSocialOtp(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @Headers("withCredentials: true")
    @POST("auth/login")//tested
    suspend fun signIn(@Body verifyReq: SignInRequest): Response<SignInResponse>


    @GET("user/profile")//tested
    suspend fun getUserData(): Response<UserModel>

    @Headers("withCredentials: true")
    @POST("auth/social_login")
    suspend fun socialLogin(@Body socialLoginReq: SocialLoginRequest): Response<SocialLoginResponse>


    @PUT("auth/login_update")
    suspend fun toVerifyGenerateOTP(@Body socialLoginReq: PhoneVerificationRequest): Response<PhoneVerificationResponse>

    @PUT("auth/social_login")
    suspend fun toVerifyGenerateSocialOTP(@Body socialLoginReq: PhoneVerificationRequest): Response<PhoneVerificationResponse>


    @POST("tournament")
    suspend fun createTournamnet(@Body stepperFragReq: StepperFragmentRequest): Call<PhoneVerificationResponse>

    @GET("home/hottest_post")
    suspend fun getHottestPost(): Response<HottestPostArticleModel>

    @GET("home/getGames")
    suspend fun getGames(
        @Query("query") query: String = "",
        @Query("option") option: String = ""
    ): Response<GamesModel>


    @GET("home/trending-authors")
    suspend fun authorArticle(): Response<ArticleAuthorsModel>


//    @GET("home/trending_posts")
//    suspend fun articleTrendingPost(): Response<HottestPostArticleModel>


    @GET("home/latestarticles")
    suspend fun articleTrendingPost(
        @Query("query") query:String,
        @Query("pagination") pagination:String,
        @Query("preference") preference:String
    ): Response<LatestArticleModel>

    @GET("home/article-list")
    suspend fun latestTrendingPost(): Response<LatestTrendingModel>

    @GET("video-library")
    suspend fun getLatestVideo(@Query("pagination") pagination: String): Response<VideosModel>

    @GET("article/{id}")
    suspend fun getArticleDetail(@Path("id") id: String): Response<ArticleDetailModel>

    @POST("auth/forgot_password")//tested
    suspend fun emailPhoneerfication(@Body verifyReq: ForgotPasswordRequest): Response<ResponseBody>

    @POST("auth/resend_otp")//tested
    suspend fun resetPAsswordResendOtp(@Body verifyReq: ForgotPasswordRequest): Response<ResponseBody>


    @PUT("article/updateViews/{id}")
    suspend fun updateArticleViews(
        @Path("id") id: String,
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @GET("like/article")
    suspend fun getArticleComment(
        @Query("articleId") id: String,
        @Query("userId") userId: String
    ): Response<ArticleCommentModel>


    @POST("comment")
    suspend fun postArticleComment(
        @Body jsonObject: JsonObject
    ): Response<PostCommentModel>


    @POST("comment")
    suspend fun postDisComment(
        @Body jsonObject: JsonObject
    ): Response<DiscussionPostCommentModel>


    @POST("like")
    suspend fun likeArticleAndComment(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @PUT("like/{id}")
    suspend fun updateLikeArticleAndComment(
        @Path("id") id: String,
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @GET("userpreference")
    suspend fun checkBookMark(
        @Query("query") query: String,
        @Query("select") type: String
    ): Response<ResponseBody>

    @PATCH("userpreference/add_bookmark")
    suspend fun addBookMark(@Body jsonObject: JsonObject): Response<ResponseBody>

    @GET("home/getArticles")
    suspend fun getMoreTrendingPost(
        @Query("query") query: String,
        @Query("pagination") pagination: String
    ): Response<HottestPostArticleModel>

    @GET("home/getArticles")
    suspend fun getMoreTrendingPostByGames(
        @Query("query") query: String
    ): Response<HottestPostArticleModel>


    @GET("home/getAuthors")
    suspend fun getMoreAuthor(
        @Query("page") page: Int,
        @Query("limit") limit: Int
    ): Response<ArticleAuthorsModel>


    @DELETE("userpreference/remove_bookmark")
    suspend fun deleteBookMark(
        @QueryMap options: Map<String, String>
    ): Response<ResponseBody>

    @GET("bracket")//tested
    suspend fun fetchAllBracket(@Query("pagination") pagination: String): Response<BracketData>

    @GET("tournament")
    suspend fun getTournaments(
        @Query("query") query: String,
        @Query("option") option: String
    ): Response<GetTournmentModel>

    @GET("tournament")
    suspend fun checkUrlExiestOrNot(
        @Query("query") query: String
    ): Response<CheckUrlRes>

    @GET("participant")
    suspend fun checkTeamUrlExiestOrNot(
        @Query("query") query: String
    ): Response<CheckTeamNameModel>

    @GET("tournament")
    suspend fun getSavedDraft(
        @Query("query") query: JsonObject
    ): Response<ResponseBody>

    @GET("user/search_users")
    suspend fun searchParticipant(
        @Query("query") query: JsonObject, @Query("select") select: String
    ): Response<SearchUser>

    @POST("file-upload")
    suspend fun uploadFiles(
        @Body jsonObject: JsonObject
    ): Response<UploadFilesRes>


    @GET("game")
    suspend fun getTournamentGameList(): Response<TournamentGameRes>

    @GET("user/reward_transaction")
    suspend fun rewardTransaction(): Response<RewardsHistoryModel>

    @GET("userpreference")
    suspend fun getMyBookMark(
        @Query("query") query: String,
        @Query("select") select: String
    ): Response<BookmarkModel>

    //
    @GET("userpreference/get_all_setting_preference")
    suspend fun fetchContent(): Response<ProfileContentModel>

    @GET("userpreference/login_user")
    suspend fun fetchContentUserPref(): Response<ContentUserPrefModel>

    @POST("userpreference/add_preference")
    suspend fun updateContentUserPref(@Body jsonObject: JsonObject): Response<ResponseBody>

    @POST("user/user_update")
    suspend fun updateUser(@Body jsonObject: JsonObject): Response<ResponseBody>

    @GET("home/tournament")
    suspend fun fetchCreatedTournamentPastAndOngoing(
        @Query("status") status: Int,
        @Query("page") page: Int,
        @Query("sort") sort: String,
        @Query("organizer") organizer: String
    ): Response<CreatedTournamentModel>


    @GET("home/tournament")
    suspend fun getAllTournament(
        @Query("status") query: String,
        @Query("sort") sort: String,
        @Query("page") page: Int,
        @Query("limit") limit: Int
    ): Response<TournamentListRes>

    @GET("home/tournament")
    suspend fun getFilterByGameTournament(
        @Query("status") query: String,
        @Query("sort") sort: String,
        @Query("game") game: String,
        @Query("page") page: Int,
        @Query("limit") limit: Int
    ): Response<TournamentListRes>

    @GET("participant/tournament")
    suspend fun fetchJoinedTournamentPastAndOngoing(
        @Query("query") query: String,
        @Query("pagination") pagination: String
    ): Response<JoinedTournamentModel>

    @GET("participant")
    suspend fun getParticipantsList(
        @Query("query") query: String
    ): Response<ParticipantsModel>

    @POST("tournament")
    suspend fun createTournament(
        @Body jsonObject: JsonObject
    ): Response<CreateTournamentRes>

    @PUT("tournament/{tournamentId}")
    suspend fun editTournament(
        @Path("tournamentId") id: String,
        @Body jsonObject: JsonObject
    ): Response<CreateTournamentRes>

    @PUT("tournament/{tournamentID}")
    suspend fun postStream(
        @Path("tournamentID") id: String,
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @POST("participant")
    suspend fun joinTournament(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @PATCH("participant/{partId}")
    suspend fun updateJoinTournament(
        @Path("partId") id: String,
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @GET("participant")
    suspend fun getJoinTournamentData(
        @Query("query") query: String?
    ): Response<JoinedEditTournamentModel>

    @GET("participant")
    suspend fun checkParticipant(
        @Query("query") query: String?
    ): Response<ParticipantRes>

    @GET("participant/search")
    suspend fun checkParticipantSearch(
        @Query("field") field: String?,
        @Query("text") text: String?,
        @Query("tournamentId") tournamentId: String?,
        @Query("pId") pId: String?
    ): Response<ParticipantSearchRes>

    @GET("banner")
    suspend fun getBanner(): Response<BannerModel>


    @POST("user/add_social")
    suspend fun addSocial(@Body socialLoginReq: SocialLoginRequest): Response<SocialLoginResponse>

    @POST("user/user_verify")
    suspend fun verifyOTP(@Body jsonObject: JsonObject): Response<ResponseBody>

    @GET("like/tournament")
    suspend fun getDiscussionComment(
        @Query("userId") id: String,
        @Query("tournamentId") userId: String
    ): Response<DiscussionComment>

    @POST("comment")
    suspend fun postDiscussionComment(
        @Body jsonObject: JsonObject
    ): Response<DiscussionPostCommentModel>

    @GET("tournament")
    suspend fun getTournamentDetail(
        @Query("query") query: String?,
        @Query("select") select: String?
    ): Response<ManageTournamentModel>

    @GET("tournament")
    suspend fun getJoinTournamentDetail(
        @Query("query") query: String?,
        @Query("select") select: String?
    ): Response<TournamentJoinDetailModel>

//    @GET("dev/tournament/(tournamentID)")
//    suspend fun getTournamentDetails(
//        @Query("tournamentId") tournamentId: String?,
//        @Query("select") select: String?
//    ): Response<ResponseBody>

    @GET("tournament/{tournamentID}")
    suspend fun getTournamentDetails(@Path("tournamentID") id: String): Response<TournamentDetailRes>

    @PUT("tournament/{tournamentID}")
    suspend fun updateTournamentDetails(
        @Path("tournamentID") id: String,
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @GET("participant")
    suspend fun getCheckInParticipant(
        @Query("query") query: String?,
        @Query("select") select: String?,
        @Query("option") option: String
    ): Response<CheckedInTournamentModel>

    @GET("match/distict-round")
    suspend fun getMatchRound(
        @Query("query") query: String?
    ): Response<GameRoundModel>

    @GET("match")
    suspend fun getMatchRoundDetail(
        @Query("query") query: String?,
        @Query("select") select: String?
    ): Response<GameRoundDetailModel>

    @GET("messages")
    suspend fun getAllInboxMessages(
        @Query("requesttype") query: String?
    ): Response<InboxModel>

    @POST("messages")
    suspend fun deleteMessages(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @GET("messages")
    suspend fun getAllMessageFromInboxId(
        @Query("requesttype") requesttype: String?,
        @Query("id") id: String?
    ): Response<InboxMessagesListModel>

    @POST("messages")
    suspend fun seenMessage(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @POST("messages")
    suspend fun postMessage(
        @Body jsonObject: JsonObject
    ): Response<InboxPostMessageModel>


    @GET("home/tournament")
    suspend fun getSearchTournament(
        @QueryMap options: Map<String, String>
    ): Response<SearchTournamentModel>

    @GET("home/article")
    suspend fun getSearchArticle(
        @QueryMap options: Map<String, String>
    ): Response<SearchArticleModel>

    @GET("home/video")
    suspend fun getVideos(
        @QueryMap options: Map<String, String>
    ): Response<SearchVideoModel>

    @POST("user-notifications")
    suspend fun registerfcmToken(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @POST("user/logout")
    suspend fun logOut(
        @Header("withCredentials") withCredentials: String,
        @Header("Cookie") cookie: String
    ): Response<ResponseBody>

    @POST("auth/resend_otp")
    suspend fun resendOtp(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @PATCH("participant/{id}")
    suspend fun updateParticipantStatus(
        @Path("id") id: String,
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>


    @PUT("participant/updateAll")
    suspend fun updateParticipant(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @POST("match/save")
    suspend fun finisMatch(
        @Body jsonObject: JsonObject
    ): Response<ResponseBody>

    @GET("home/fetchleaderboard/{id}")
    suspend fun getLeaderboardUserDetails(@Path("id") id: String): Response<UserLeaderBoardProfileModel>

    @GET("home/fetchleaderboard")
    suspend fun getLeaderboardDetails(): Response<LeaderboardModel>

    @GET("home/fetchleaderboard/game/{id}")
    suspend fun getLeaderboardByGame(
        @Path("id") id: String,
        @Query("page") page: Int,
        @Query("limit") limit: Int
    ): Response<LeaderboardByGameModel>


    @GET("general/announcement")
    suspend fun getLatestAnnouncement(): Response<AnnouncementResponse>

    @GET("game")
    suspend fun getAllGamesTab(): Response<GamesModel>

    @GET("home/tournament")
    suspend fun getEsportsBanner(
        @Query("status") query: String,
        @Query("sort") sort: String,
        @Query("limit") game: String
    ): Response<TournamentListRes>


    @GET("userpreference/matchmaking/{id}")
    suspend fun findMatch(@Path("id") id: String): Response<MatchFindModel>

    @GET("tournament")
    suspend fun getSingleTournamentData(
        @Query("query") query: String
    ): Response<SingleTournamentModel>
}

interface ChatInterface {

    @POST("login")
    suspend fun loginChat(@Body jsonObject: JsonObject): Response<ResponseBody>

    @POST("logout")
    suspend fun logOutChat(@Body jsonObject: JsonObject): Response<ResponseBody>

    // Tournament chat list
    @GET("chats/{id}")
    suspend fun getChatList(@Path("id") id: String): Response<MutableList<ChatMessageListModel>>

    // Matches chat list
    @GET("matchlist/{id}")
    suspend fun getMatchList(@Path("id") id: String): Response<MutableList<MatchsListModel>>

}