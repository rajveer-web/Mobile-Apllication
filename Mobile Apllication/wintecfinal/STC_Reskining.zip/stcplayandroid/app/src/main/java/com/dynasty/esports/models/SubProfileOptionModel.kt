package com.dynasty.esports.models

data class SubProfileOptionModel (
    var type:String="",
    var title:String=""
)