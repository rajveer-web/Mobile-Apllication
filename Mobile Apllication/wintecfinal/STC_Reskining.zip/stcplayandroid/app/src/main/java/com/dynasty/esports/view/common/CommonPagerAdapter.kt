package com.dynasty.esports.view.common

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter

/**
 * @desc this is class use for * uses a {@link Fragment} to manage each page. This class also handles saving and restoring of fragment's state.
 * @author : Mahesh Vayak
 * @created : 25-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CommonPagerAdapter(
    private val list: MutableList<Pair<Fragment, String>>,
    fm: FragmentManager
) : FragmentStatePagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getCount(): Int = list.size

    override fun getItem(i: Int): Fragment {
        return list[i].first
    }

    override fun getPageTitle(position: Int): CharSequence {
        return list[position].second
    }
}