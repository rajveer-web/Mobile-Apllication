package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName


data class TeamPlayers(
    @SerializedName("email")
    var email: String? = null,

    @SerializedName("phoneNumber")
    var phoneNumber: String? = null,

    @SerializedName("name")
    var name: String? = null,

    @SerializedName("inGamerUserId")
    var inGamerUserId: String? = null,

    @SerializedName("tournamentUsername")
    var tournamentUsername: String? = null,

    var teamLogo: String? = null

)