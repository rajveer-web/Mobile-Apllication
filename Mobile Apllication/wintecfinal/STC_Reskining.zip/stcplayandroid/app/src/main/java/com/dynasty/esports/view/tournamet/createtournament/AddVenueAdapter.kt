package com.dynasty.esports.view.tournamet.createtournament


import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AddOfflineVenueItemBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.AddVenue

/**
 * @desc this is class will use for add venue item
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class AddVenueAdapter constructor(
    private val onVenueItemRemoveClick: (Int) -> Unit = { _ -> },
    private val onVenueSelectCountryClick: (Int, TextView,TextView) -> Unit = { _, _ ,_-> },
    private val onVenueSelectRegionClick: (Int, TextView) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<AddVenueAdapter.MyViewHolder>() {
    class MyViewHolder(val binding: AddOfflineVenueItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    private var venueList: MutableList<AddVenue> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val binding: AddOfflineVenueItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.add_offline_venue_item,
            parent,
            false
        )
        return MyViewHolder(binding)
    }

    /**
     * @desc vanueList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return venueList.size
    }

    /**
     * @desc add item in venueList and notify adapter
     */
    fun add(item: AddVenue) {
        venueList.add(item)
        notifyDataSetChanged()
    }

    /**
     * @desc add list in venueList and notify adapter
     */
    fun addAll(venueList: MutableList<AddVenue>) {
        this.venueList.addAll(venueList)
        notifyDataSetChanged()
    }

    /**
     * @desc remove item from venueList and notify adapter
     */
    fun remove(item: AddVenue) {
        venueList.remove(item)
        notifyDataSetChanged()
    }

    /**
     * @desc get single item from position
     */
    fun getItem(position: Int): AddVenue {
        return venueList[position]
    }

    /**
     * @desc get venueList( main array list)
     */
    fun getAll(): MutableList<AddVenue> {
        return venueList
    }

    /**
     * @desc clear or remove all data from venueList( main array list)
     */
    fun clear() {
        venueList.clear()
        notifyDataSetChanged()
    }

    /**
     * @desc check validation in venue form
     */
    fun isValidated(): Boolean {
        for (i in venueList) {
            if (i.venue.isEmpty()) {
                return false
            } else if (i.country.isEmpty()) {
                return false
            } else if (i.region.isEmpty()) {
                return false
            }
        }
        return true
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = venueList[position]

        holder.binding.addVenue = data
        holder.binding.tvVenueNumber.text =
            holder.itemView.resources.getString(R.string.venue_name).plus(position + 1)

        if (position == 0) {
            holder.binding.imgRemove.beGone()
        }

        holder.binding.imgRemove.click {
            onVenueItemRemoveClick(position)
        }

        holder.binding.tvOfflineSelectCountry.click {
            onVenueSelectCountryClick(
                position,
                holder.binding.tvOfflineSelectCountry,
                holder.binding.tvOfflineSelectRegion
            )
        }

        holder.binding.tvOfflineSelectRegion.click {
            onVenueSelectRegionClick(
                position,
                holder.binding.tvOfflineSelectRegion
            )
        }
    }
}