package com.dynasty.esports.view.tournamet.manage_tournament.match


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterTournamentGamepadBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.CustomGameRoundModel
import com.dynasty.esports.utils.BindingHolder
import kotlin.math.abs

class GamePadTournamentAdapter(
    private var gameRoundList: MutableList<CustomGameRoundModel>,
    private val onItemClick: (Int,Int) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterTournamentGamepadBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterTournamentGamepadBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_tournament_gamepad,
                parent,
                false
            )
        )

    }

    override fun getItemCount(): Int {
        return gameRoundList.size
    }


    override fun onBindViewHolder(
        holder: BindingHolder<AdapterTournamentGamepadBinding>,
        position: Int
    ) {


        if(gameRoundList[position].round!!>0){
            holder.binding.textViewLabel.text=holder.itemView.context.resources.getString(R.string.round).plus(" ").plus(gameRoundList[position].round)
        }else{
            holder.binding.textViewLabel.text=holder.itemView.context.resources.getString(R.string.loser_round).plus(" ").plus(
                abs(gameRoundList[position].round!!))
        }



        if(!gameRoundList[position].detailList.isNullOrEmpty()) {
            holder.binding.recyclerViewGameDetail.beVisible()
            holder.binding.textViewNoRound.beGone()
            holder.binding.recyclerViewGameDetail.layoutManager =
                LinearLayoutManager(holder.itemView.context)
            holder.binding.recyclerViewGameDetail.isNestedScrollingEnabled=false
            (gameRoundList[position].detailList.add(0,gameRoundList[position].detailList[0]))
            val matchRoundDetailAdapter =
                MatchRoundDetailAdapter(gameRoundList[position].detailList)
            holder.binding.recyclerViewGameDetail.adapter = matchRoundDetailAdapter
        }else{
            holder.binding.recyclerViewGameDetail.beGone()
            holder.binding.textViewNoRound.beVisible()
        }


        holder.binding.linearLayoutRound.click {
            if(holder.binding.frameLayoutRoundDetail.visibility== View.GONE) {
                holder.binding.linearLayoutRound.setBackgroundColor(ContextCompat.getColor(holder.itemView.context,R.color.colorAccent))
                holder.binding.frameLayoutRoundDetail.beVisible()
                onItemClick(gameRoundList[position].round!!,position)
            }else{
                holder.binding.linearLayoutRound.setBackgroundColor(ContextCompat.getColor(holder.itemView.context,R.color.black))
                holder.binding.frameLayoutRoundDetail.beGone()
            }
        }
    }
}