package com.dynasty.esports.models

import android.os.Parcelable
import com.dynasty.esports.models.GetTournmentModel.GameDetail
import com.dynasty.esports.models.GetTournmentModel.OrganizerDetail
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


class ManageTournamentModel {
    @SerializedName("message")
    @Expose
    val message: String? = null

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: MutableList<DataModel>? = null

    @SerializedName("totals")
    @Expose
    val totals: TotalsModel? = null

    class DataModel {
        @SerializedName("substituteMembers")
        @Expose
         val substituteMembers: Int? = null

        @SerializedName("participants")
        @Expose
         val participants: List<Any>? = null

        @SerializedName("isSeeded")
        @Expose
         val isSeeded: Boolean? = null

        @SerializedName("regionsAllowed")
        @Expose
         val regionsAllowed: List<Any>? = null

        @SerializedName("sponsors")
        @Expose
         val sponsors: List<Any>? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("venueAddress")
        @Expose
         val venueAddress: List<Any>? = null

        @SerializedName("stream")
        @Expose
         val stream: List<StreamModel>? = null

        @SerializedName("isFinished")
        @Expose
         val isFinished: Boolean? = null

        @SerializedName("rating")
        @Expose
         val rating: Int? = null

        @SerializedName("changeRequest")
        @Expose
         val changeRequest: Any? = null

        @SerializedName("nfMatchBetweenTwoTeam")
        @Expose
         val nfMatchBetweenTwoTeam: Int? = null

        @SerializedName("prizeList")
        @Expose
         val prizeList: List<Any>? = null

        @SerializedName("isAllowMultipleRounds")
        @Expose
         val isAllowMultipleRounds: Boolean? = null

        @SerializedName("placementPoints")
        @Expose
         val placementPoints: List<Any>? = null

        @SerializedName("isFeature")
        @Expose
         val isFeature: Boolean? = null

        @SerializedName("tournamentStageType")
        @Expose
         val tournamentStageType: String? = null

        @SerializedName("noOfTeamInGroup")
        @Expose
         val noOfTeamInGroup: Any? = null

        @SerializedName("noOfWinningTeamInGroup")
        @Expose
         val noOfWinningTeamInGroup: Any? = null

        @SerializedName("noOfRoundPerGroup")
        @Expose
         val noOfRoundPerGroup: Any? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("name")
        @Expose
         val name: String? = null

        @SerializedName("url")
        @Expose
         val url: String? = null

        @SerializedName("participantType")
        @Expose
         val participantType: String? = null

        @SerializedName("startDate")
        @Expose
         val startDate: String? = null

        @SerializedName("startTime")
        @Expose
         val startTime: String? = null

        @SerializedName("isPaid")
        @Expose
         val isPaid: Boolean? = null

        @SerializedName("isCheckInRequired")
        @Expose
         val isCheckInRequired: Boolean? = null

        @SerializedName("description")
        @Expose
         val description: String? = null

        @SerializedName("rules")
        @Expose
         val rules: String? = null

        @SerializedName("criticalRules")
        @Expose
         val criticalRules: String? = null

        @SerializedName("isPrize")
        @Expose
         val isPrize: Boolean? = null

        @SerializedName("faqs")
        @Expose
         val faqs: String? = null

        @SerializedName("schedule")
        @Expose
         val schedule: String? = null

        @SerializedName("isIncludeSponsor")
        @Expose
         val isIncludeSponsor: Boolean? = null

        @SerializedName("tournamentType")
        @Expose
         val tournamentType: String? = null

        @SerializedName("isScreenshotRequired")
        @Expose
         val isScreenshotRequired: Boolean? = null

        @SerializedName("isShowCountryFlag")
        @Expose
         val isShowCountryFlag: Boolean? = null

        @SerializedName("isSpecifyAllowedRegions")
        @Expose
         val isSpecifyAllowedRegions: Boolean? = null

        @SerializedName("isParticipantsLimit")
        @Expose
         val isParticipantsLimit: Boolean? = null

        @SerializedName("scoreReporting")
        @Expose
         val scoreReporting: Int? = null

        @SerializedName("invitationLink")
        @Expose
         val invitationLink: String? = null

        @SerializedName("youtubeVideoLink")
        @Expose
         val youtubeVideoLink: String? = null

        @SerializedName("facebookVideoLink")
        @Expose
         val facebookVideoLink: String? = null

        @SerializedName("contactDetails")
        @Expose
         val contactDetails: String? = null

        @SerializedName("twitchVideoLink")
        @Expose
         val twitchVideoLink: String? = null

        @SerializedName("visibility")
        @Expose
         val visibility: Int? = null

        @SerializedName("checkInStartDate")
        @Expose
         val checkInStartDate: String? = null

        @SerializedName("checkInEndDate")
        @Expose
         val checkInEndDate: String? = null

        @SerializedName("banner")
        @Expose
         val banner: String? = null

        @SerializedName("maxParticipants")
        @Expose
         val maxParticipants: Int? = null

        @SerializedName("bracketType")
        @Expose
         val bracketType: String? = null

        @SerializedName("noOfSet")
        @Expose
         val noOfSet: Int? = null

        @SerializedName("stageMatch")
        @Expose
         val stageMatch: String? = null

        @SerializedName("stageMatchNoOfSet")
        @Expose
         val stageMatchNoOfSet: Int? = null

        @SerializedName("contactOn")
        @Expose
         val contactOn: String? = null

        @SerializedName("gameDetail")
        @Expose
         val gameDetail: GameDetail? = null

        @SerializedName("teamSize")
        @Expose
         val teamSize: Int? = null

        @SerializedName("pointsKills")
        @Expose
         val pointsKills: Int? = null

        @SerializedName("slug")
        @Expose
         val slug: String? = null

        @SerializedName("country")
        @Expose
         val country: String? = null

        @SerializedName("endDate")
        @Expose
         val endDate: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
         val updatedBy: String? = null

        @SerializedName("tournamentStatus")
        @Expose
         val tournamentStatus: String? = null

        @SerializedName("organizerDetail")
        @Expose
         val organizerDetail: OrganizerDetail? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("fullText")
        @Expose
         val fullText: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null
        
        
        
//        @SerializedName("_id")
//        @Expose
//        val id: String? = null
//
//        @SerializedName("name")
//        @Expose
//        val name: String? = null
//
//        @SerializedName("startDate")
//        @Expose
//        val startDate: String? = null
//
//        @SerializedName("participantType")
//        @Expose
//        val participantType: String? = null
//
//        @SerializedName("url")
//        @Expose
//        val url: String? = null
//
//        @SerializedName("banner")
//        @Expose
//        val banner: String? = null
//
//
//        @SerializedName("startTime")
//        @Expose
//        val startTime: String? = null
//
//        @SerializedName("maxParticipants")
//        @Expose
//        val maxParticipants: Int? = null
//
//        @SerializedName("bracketType")
//        @Expose
//        val bracketType: String? = null
//
//        @SerializedName("gameDetail")
//        @Expose
//        val gameDetail: GameDetail? = null
//
//        @SerializedName("teamSize")
//        @Expose
//        val teamSize: String? = null
//
//        @SerializedName("organizerDetail")
//        @Expose
//        val organizerDetail: OrganizerDetail? = null
//
//
//        @SerializedName("stream")
//        @Expose
//        val stream: MutableList<StreamModel>? = null
    }

    @Parcelize
    class StreamModel : Parcelable {
        @SerializedName("type")
        @Expose
        var type: String? = null

        @SerializedName("videoUrl")
        @Expose
        var videoUrl: VideoUrlModel? = null

        @SerializedName("title")
        @Expose
        var title: String? = null

        @SerializedName("description")
        @Expose
        var description: String? = null


    }

    @Parcelize
    class VideoUrlModel:Parcelable {
        @SerializedName("providerName")
        @Expose
        var providerName: String? = null

        @SerializedName("channelName")
        @Expose
        var channelName: String? = null

    }
}