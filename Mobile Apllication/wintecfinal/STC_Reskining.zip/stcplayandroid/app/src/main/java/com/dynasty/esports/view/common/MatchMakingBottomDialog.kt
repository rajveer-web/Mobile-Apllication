package com.dynasty.esports.view.common


import android.app.Dialog

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible

import com.dynasty.esports.extenstion.click
import com.dynasty.esports.viewmodel.ChatViewModel

import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.android.synthetic.main.custom_match_found_dialog.*

import kotlinx.android.synthetic.main.custom_match_making_dialog.*
import kotlinx.android.synthetic.main.custom_match_making_dialog.imageViewClose
import kotlinx.android.synthetic.main.custom_match_making_dialog.textViewTitle
import org.koin.androidx.viewmodel.ext.android.viewModel


class MatchMakingBottomDialog : BottomSheetDialogFragment() {
    private var id:String=""
    private var name:String=""
    private  val chatViewModel: ChatViewModel by viewModel()

    override fun setupDialog(dialog: Dialog, style: Int) {
        val contentView: View = View.inflate(context, R.layout.custom_match_making_dialog, null)
        dialog.setContentView(contentView)
        isCancelable=false
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.custom_match_making_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textViewDescription.text=resources.getString(R.string.stc_pay_message).plus(" ").plus(name)
        btn_continue.click {
            textViewTitle.text=resources.getString(R.string.matching_in_progress)
            textViewDescription.text=resources.getString(R.string.we_are_processing_your_request_hang_in_there_while_we_find_you_a_match)
            btn_continue.beGone()
            progressBar.beVisible()
            chatViewModel.findMatch(id)
        }
        imageViewClose.click {
            dialog?.apply {
                dismiss()
            }
        }
        listenToViewModel()
    }

    private fun listenToViewModel() {
        chatViewModel.findMatchSuccessResponse.observe(viewLifecycleOwner,{
//            dialog?.apply {
//                dismiss()
//            }
            it.data?.apply {
                MatchFoundBottomDialog.newInstance(this).show(childFragmentManager, "match_found")
//                bottomSheetDialog.show(childFragmentManager, "match_found")
            }
        })
        chatViewModel.findMatchErrorResponse.observe(viewLifecycleOwner,{

        })
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(DialogFragment.STYLE_NO_FRAME,R.style.AppBottomSheetDialogTheme);
        arguments?.apply {
            id=this.getString("id").toString()
            name=this.getString("gameName").toString()
        }
    }

    companion object {
        fun newInstance(
           id:String,
           gameName:String
        ): MatchMakingBottomDialog {
            val args = Bundle()
            args.putString("id", id)
            args.putString("gameName", gameName)
            val fragment = MatchMakingBottomDialog()
            fragment.arguments = args
            return fragment
        }
    }
}