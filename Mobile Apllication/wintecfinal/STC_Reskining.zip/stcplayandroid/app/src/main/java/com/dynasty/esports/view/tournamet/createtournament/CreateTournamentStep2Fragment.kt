package com.dynasty.esports.view.tournamet.createtournament

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.provider.MediaStore
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.*
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.ChooseMediaAdapter
import com.dynasty.esports.viewmodel.CreateTournamentStep2ViewModel
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_create_tournament.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.container
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.llparticipants
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.tvPartMinus
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.tvPartNumber
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.tvPartNumbererror
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.tvPartPlus
import kotlinx.android.synthetic.main.fragment_mybasicinfo.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import pub.devrel.easypermissions.AppSettingsDialog
import pub.devrel.easypermissions.EasyPermissions
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * @desc this is class will use for step 2 of create tournament
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CreateTournamentStep2Fragment : BaseFragment(), EasyPermissions.PermissionCallbacks {

    private var prizeCurruncyType: String = ""
    private val mViewModel: CreateTournamentStep2ViewModel by viewModel()
    private lateinit var bottomSheetDialogChooseMedia: BottomSheetDialog
    private lateinit var addSponsorAdapter: AddSponsorAdapter
    private lateinit var selectedRegionsAdapter: SelectedRegionsAdapter
    private lateinit var addVenueAdapter: AddVenueAdapter
    private lateinit var step2FieldsAdapter: Step2FieldsAdapter
    var screenshot: Boolean? = null
    var countryflag: Boolean? = null
    var socoreReportLocal: Int = 2
    var selectedStage: String = ""
    var selectedCountry: String = ""
    var selectedRegion: String = ""
    var isAbletoNext: Boolean = false
    var partNumber = 2
    var imagePosition = 0
    var isForBanner = false
    private var countryList: MutableList<CountriesModel.CountryModel> =
        mutableListOf() // define country list
    private var regionList: MutableList<StateModel.State> = mutableListOf() // define state list

    //    val regionList = ArrayList<Spinner>()
    private var countryStateList: MutableList<StateModel.State> =
        mutableListOf() // define specific country state list

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_create_tournament_step2, container, false)
    }

    companion object {
        fun newInstance(type: String): Fragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = CreateTournamentStep2Fragment()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialize()
        listenToViewModel()
    }

    /**
     * @desc this method is used for initialize view clicks, adapter and recyclerview
     *       add static data to step2FieldsAdapter for desc, rules and etc.
     */
    private fun initialize() {
        countryList.addAll(requireContext().jsonToClass<CountriesModel>(R.raw.countries).countries!!) // read country json file and save data in list.
        regionList.addAll(requireContext().jsonToClass<StateModel>(R.raw.states).states!!) // read state json file and save data in list.

        step2FieldsAdapter = Step2FieldsAdapter(onItemClick = ::onSte2FieldsItemClick)

        val step2FieldList: MutableList<Step2Fields> = ArrayList()

        val step2Item1 = Step2Fields()
        step2Item1.step2Id = requireActivity().resources.getString(R.string.description)
        step2Item1.step2ParantTitle =
            requireActivity().resources.getString(R.string.add_description)

        val step2Item2 = Step2Fields()
        step2Item2.step2Id = requireActivity().resources.getString(R.string.rules)
        step2Item2.step2ParantTitle = requireActivity().resources.getString(R.string.add_rules)

//        val step2Item3 = Step2Fields()
//        step2Item3.step2Id = requireActivity().resources.getString(R.string.critical_rules)
//        step2Item3.step2ParantTitle = requireActivity().resources.getString(R.string.critical_rules)
//
//        val step2Item4 = Step2Fields()
//        step2Item4.step2Id = requireActivity().resources.getString(R.string.faq)
//        step2Item4.step2ParantTitle = requireActivity().resources.getString(R.string.faq)
//
//        val step2Item5 = Step2Fields()
//        step2Item5.step2Id = requireActivity().resources.getString(R.string.schedules)
//        step2Item5.step2ParantTitle = requireActivity().resources.getString(R.string.schedules)

        step2FieldList.add(step2Item1)
        step2FieldList.add(step2Item2)
//        step2FieldList.add(step2Item3)
//        step2FieldList.add(step2Item4)
//        step2FieldList.add(step2Item5)

        step2FieldsAdapter.addAll(step2FieldList)

        rvStep2Fields.layoutManager = LinearLayoutManager(requireContext())
        rvStep2Fields.adapter = step2FieldsAdapter

//      recyclerview and adapter initialization
        addSponsorAdapter = AddSponsorAdapter(
            onimageSponsorClick = ::onimageSponsorClick,
            onimageSponsorBannerClick = ::onimageSponsorBannerClick,
            onItemRemoveClick = ::onItemRemoveClick
        )
        addVenueAdapter = AddVenueAdapter(
            onVenueItemRemoveClick = ::onVenueItemRemoveClick,
            onVenueSelectCountryClick = ::onVenueSelectCountryClick,
            onVenueSelectRegionClick = ::onVenueSelectRegionClick
        )
        selectedRegionsAdapter =
            SelectedRegionsAdapter(onItemRegionsRemoveClick = ::onItemRegionsRemoveClick)

        rvAddSponsor.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        rvAddSponsor.adapter = addSponsorAdapter
        rvOfline.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        rvOfline.adapter = addVenueAdapter
        rvSecifiedAllowedRegion.layoutManager =
            GridLayoutManager(requireActivity(), 2)
        rvSecifiedAllowedRegion.adapter = selectedRegionsAdapter

//        Add item to sponsorlist
        llAddSponcer.click {
            val item = AddSponcer()
            addSponsorAdapter.add(item)
        }

//      Add item to venueAddresslist
        llAddOffline.click {
            val item = AddVenue()
            addVenueAdapter.add(item)
        }

//      Add static data on country list
//        requireContext().jsonToClass<CountriesModel>(R.raw.countries).countries!!.forEachIndexed { index, countryModel ->
//            countryList.add(Spinner(index.toString(), countryModel.name))
//        }

//        requireContext().jsonToClass<StateModel>(R.raw.states).states!!

//        regionList.addAll(requireContext().jsonToClass<StateModel>(R.raw.states).states!!) // read state json file and save data in list.

//        countryList.addAll(requireContext().jsonToClass<CountriesModel>(R.raw.countries).countries!!) // read country json file and save data in list.
//        stateList.addAll(requireContext().jsonToClass<StateModel>(R.raw.states).states!!) // read state json file and save data in list.

//      Add static data on region list
//        regionList.add(Spinner("1", "Johor"))
//        regionList.add(Spinner("2", "Melaka"))
//        regionList.add(Spinner("3", "Negeri Sembilan"))
//        regionList.add(Spinner("4", "Pahang"))
//        regionList.add(Spinner("5", "Pulau Pinang"))
//        regionList.add(Spinner("6", "Perak"))
//        regionList.add(Spinner("7", "Perlis"))
//        regionList.add(Spinner("8", "Kedah"))
//        regionList.add(Spinner("9", "Kelantan"))
//        regionList.add(Spinner("10", "Sabah"))
//        regionList.add(Spinner("11", "Sarawak"))
//        regionList.add(Spinner("12", "Selangor"))
//        regionList.add(Spinner("13", "Terengganu"))
//        regionList.add(Spinner("14", "WP Kuala Lumpur"))
//        regionList.add(Spinner("15", "WP Labuan"))
//        regionList.add(Spinner("16", "WP Putrajaya"))

//      set static data on tournamentTypeList
        val tournamentTypeList = ArrayList<Spinner>()
        tournamentTypeList.add(Spinner("1", "SAR"))

//      select prize spinner
        tvSelectPrize.click {
            requireActivity().showSpinner(
                resources.getString(R.string.currency),
                tvSelectPrize,
                tournamentTypeList,
                false,
                onItemClick = {
                    val data = it as Spinner
                    prizeCurruncyType = data.title
                })
        }

//      Minimum 2 participant member required
        tvPartMinus.click {
            if (partNumber > 2) {
                partNumber--
                tvPartNumber.setText(partNumber.toString())
            }
        }

//      add one unit in part number
        tvPartPlus.click {
            if (partNumber < 100000) {
                partNumber++
                tvPartNumber.setText(partNumber.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and part member is not empty.
        tvPartNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                tvPartNumbererror.beVisible()
                tvPartNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                tvPartNumbererror.text = getString(R.string.required_field)
                partNumber = 2
                tvPartNumber.setText("2")
            } else {
                partNumber = it.toString().toInt()
                if (it.toString().toInt() < 2) {
                    tvPartNumbererror.beVisible()
                    tvPartNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvPartNumbererror.text = getString(R.string.minimum_allowed_limit_is_2)
                } else if (it.toString().toInt() > 1024) {
                    tvPartNumbererror.beVisible()
                    tvPartNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvPartNumbererror.text = getString(R.string.maximum_allowed_limit_is_1024)
                } else {
                    tvPartNumbererror.beGone()
                }
            }
        }

//      Screenshot requred or not switch
        switchScreenshotReq.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                screenshot = isChecked
                // do something when check is selected
            } else {
                screenshot = isChecked
                //do something when unchecked
            }
        })

//      add static data in staglist arraylist
        val stageList = ArrayList<Spinner>()
        stageList.add(Spinner("1", resources.getString(R.string.quarter_stage)))
        stageList.add(Spinner("2", resources.getString(R.string.semi_final_stage)))
        stageList.add(Spinner("3", resources.getString(R.string.final_stage)))

//      open stage spinner on tvHybridSelectStage
        tvHybridSelectStage.click {
            requireActivity().showSpinner(
                resources.getString(R.string.select_stage), tvHybridSelectStage,
                stageList,
                false,
                onItemClick = {
                    val data = it as Spinner
                    selectedStage = data.title
                })
        }

//      open country spinner on tvHybridSelectCountry
        tvHybridSelectCountry.click {
            requireActivity().showSpinner(
                resources.getString(R.string.select_country), tvHybridSelectCountry,
                countryList,
                false, type = "country",
                onItemClick = {
                    val data = it as CountriesModel.CountryModel
//                    val data = it as Spinner
                    tvHybridSelectRegion.setText("")
                    selectedRegion = ""
                    selectedCountry = data.name
                    countryStateList.clear()

                    regionList.forEach {
                        if (data.id.toString().equals(it.countryId.toString(), true)) {
                            countryStateList.add(it)
                        }
                    }
                })
        }

//      open Region spinner on tvHybridSelectRegion
        tvHybridSelectRegion.click {
            if (countryStateList.isNullOrEmpty()) {
                resources.getString(R.string.select_country_first_msg).showToast(requireContext())
            } else {
                requireActivity().showSpinner(
                    resources.getString(R.string.select_region), tvHybridSelectRegion,
                    countryStateList,
                    true, type = "state",
                    onItemClick = {
                        val data = it as StateModel.State
                        selectedRegion = data.name
                    })
            }
        }


//      country show or not flag
        switchShowCountryFlag.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                countryflag = isChecked
            } else {
                countryflag = isChecked
            }
        })

        val secifiedAllowedRegionList = ArrayList<Spinner>()

//
//      Add static region in secifiedAllowedRegionList array

        resources.getStringArray(R.array.region_option).toMutableList().forEachIndexed { index, s ->
            secifiedAllowedRegionList.add(Spinner(index.toString(), s))
        }

//        regionList.forEachIndexed { index, state ->
//            secifiedAllowedRegionList.add(Spinner(index.toString(), state.name))
//        }

//        val secifiedAllowedRegionList = ArrayList<Spinner>()
//        secifiedAllowedRegionList.add(Spinner("1", "Johor, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("2", "Melaka, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("3", "Negeri Sembilan, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("4", "Pahang, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("5", "Pulau Pinang, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("6", "Perak, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("7", "Perlis, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("8", "Kedah, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("9", "Kelantan, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("10", "Sabah, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("11", "Sarawak, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("12", "Selangor, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("13", "Terengganu, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("14", "WP Kuala Lumpur, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("15", "WP Labuan, Malaysia"))
//        secifiedAllowedRegionList.add(Spinner("16", "WP Putrajaya, Malaysia"))

//      after select regions from spinner and there is no data in selected list then switchSecifiedAllowedRegion should be false
        switchSecifiedAllowedRegion.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                requireActivity().showSpinnerSel(
                    resources.getString(R.string.select_allowed_regions),
                    secifiedAllowedRegionList,
                    true,
                    object : SpinnerCallback {
                        override fun onDone(list: java.util.ArrayList<Spinner>) {
                            if (list.isEmpty()) {
                                switchSecifiedAllowedRegion.isChecked = false
                            } else {
                                selectedRegionsAdapter.addAll(list)
                            }
                        }
                    })
                llSecifiedAllowedRegion.beVisible()
            } else {
                selectedRegionsAdapter.clearAll()
                llSecifiedAllowedRegion.beGone()
            }
        })

//       rgScorReporting radio button -> if checked then 1 and if not checked then 2
        rgScorReporting.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (rbAdmins.isChecked) {
                socoreReportLocal = 1
                rbAdmins.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                rbAdminsAndPlayer.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.background_color
                    )
                )
            } else {
                socoreReportLocal = 2
                rbAdminsAndPlayer.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.white
                    )
                )
                rbAdmins.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.background_color
                    )
                )
            }
        })

//      llSelectPrice should be visible if switchPrize is checked
        switchPrize.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                llSelectPrice.beVisible()
            } else {
                llSelectPrice.beGone()
            }
        }

        llAddPrize.setOnClickListener(View.OnClickListener {
            if (llForthPrice.visibility != View.VISIBLE) {
                llForthPrice.visibility = View.VISIBLE;
            } else if (llFifthPrice.visibility != View.VISIBLE) {
                llFifthPrice.visibility = View.VISIBLE;

            } else if (llSixthPrice.visibility != View.VISIBLE) {
                llSixthPrice.visibility = View.VISIBLE;
            } else {
                resources.getString(R.string.prize_popup_mes).showToast(requireContext())
            }
        })

        ivdel_forthPrice.setOnClickListener(View.OnClickListener {
            llForthPrice.visibility = View.GONE
            tvFourthPrice.text!!.clear()
        })

        ivdel_fifthPrice.setOnClickListener(View.OnClickListener {
            llFifthPrice.visibility = View.GONE
            tvFifthPrice.text!!.clear()

        })
        ivdel_SixPrice.setOnClickListener(View.OnClickListener {
            llSixthPrice.visibility = View.GONE
            tvSixPrice.text!!.clear()

        })
//      if sponsor list is empty then add one item on switchsposor checked
        switchSponsors.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                if (addSponsorAdapter.getAll().isEmpty()) {
                    val item = AddSponcer()
                    addSponsorAdapter.add(item)
                }
                llSponsor.beVisible()
            } else {
                addSponsorAdapter.clear()
                llSponsor.beGone()
            }
        }

//      llparticipants should be visible if switchPart is checked
        switchPart.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener {
            override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
                if (isChecked) {
                    llparticipants.beVisible()
                } else {
                    llparticipants.beGone()
                }
            }
        })

//      Manage radio group for tournament type
//      If rboffline selected and venue list is empty then add one data on venue list
        rgTournamentType.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (rbOnline.isChecked) {
                tvRadioButtonSelectedTitle.text = resources.getString(R.string.online)
                tvRadioButtonSelectedDesc.text =
                    resources.getString(R.string.your_tournament_will_be_held_on_only_as_online_event)
                llOffline.beGone()
                llHybrid.beGone()

                rbOnline.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                rbOffline.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.text_placeholder_color
                    )
                )
                rbHybrid.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.text_placeholder_color
                    )
                )
            } else if (rbOffline.isChecked) {
                tvRadioButtonSelectedTitle.text = resources.getString(R.string.offline)
                tvRadioButtonSelectedDesc.text =
                    resources.getString(R.string.your_tournament_will_be_held_on_only_as_offline_event)
                llOffline.beVisible()
                llHybrid.beGone()
                if (addVenueAdapter.getAll().isEmpty()) {
                    val item = AddVenue()
                    addVenueAdapter.add(item)
                }

                rbOnline.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.text_placeholder_color
                    )
                )
                rbOffline.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                rbHybrid.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.text_placeholder_color
                    )
                )
            } else {
                tvRadioButtonSelectedTitle.text = resources.getString(R.string.hybrid)
                tvRadioButtonSelectedDesc.text =
                    resources.getString(R.string.your_tournament_will_be_held_on_only_as_hybrid_event)
                llOffline.beGone()
                llHybrid.beVisible()

                rbOnline.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.text_placeholder_color
                    )
                )
                rbOffline.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.text_placeholder_color
                    )
                )
                rbHybrid.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            }
        })

        tvFirstPrice.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))
        tvSecondPrice.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))
        tvThirdPrice.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))
        tvFourthPrice.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))
        tvFifthPrice.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))
        tvSixPrice.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))
    }

    /**
     * @desc method will call when tap on rvStep2Fields recyclerview from step2FieldsAdapter and set expanded true and expanded false
     */
    private fun onSte2FieldsItemClick(position: Int, editText: EditText) {
        val data = step2FieldsAdapter.get(position)
        step2FieldsAdapter.setExpand(data.step2Id)
        if (data.isExpanded) {
            Handler().postDelayed(Runnable {
                editText.requestFocus()
                editText.showSoftKeyboard(requireContext())
            }, 500)
        } else {
            Handler().postDelayed(Runnable {
                editText.clearFocus()
                requireActivity().hideKeyboard()
            }, 500)
        }
    }

    /**
     * @desc method will call when tap on rvOfline recyclerview from addVenueAdapter and remove venue item when click on remove button from addVenueAdapter
     */
    private fun onVenueItemRemoveClick(position: Int) {
        if (addVenueAdapter.getAll().size > 1) {
            val item = addVenueAdapter.getItem(position)
            addVenueAdapter.remove(item)
        }
    }

    /**
     * @desc method will call when tap on rvOfline recyclerview from addVenueAdapter and Open spinner for pic country for addVenueAdapter
     */
    private fun onVenueSelectCountryClick(
        position: Int,
        textView: TextView,
        regionTextView: TextView
    ) {
//        requireActivity().showSpinner(
//            resources.getString(R.string.select_country), textView,
//            countryList,
//            false
//        )

        requireActivity().showSpinner(
            resources.getString(R.string.select_country), textView,
            countryList,
            false, type = "country",
            onItemClick = {
                val data = it as CountriesModel.CountryModel
//                    val data = it as Spinner
                regionTextView.setText("")
//                selectedRegion = ""
//                selectedCountry = data.name
                countryStateList.clear()

                regionList.forEach {
                    if (data.id.toString().equals(it.countryId.toString(), true)) {
                        countryStateList.add(it)
                    }
                }
            })
    }

    /**
     * @desc method will call when tap on rvOfline recyclerview from addVenueAdapter and Open spinner for pic region picker for addVenueAdapter
     */
    private fun onVenueSelectRegionClick(position: Int, textView: TextView) {
//        requireActivity().showSpinner(
//            resources.getString(R.string.select_region), textView,
//            regionList,
//            true
//        )
        if (countryStateList.isNullOrEmpty()) {
            resources.getString(R.string.select_country_first_msg).showToast(requireContext())
        } else {
            requireActivity().showSpinner(
                resources.getString(R.string.select_region), textView,
                countryStateList,
                true, type = "state",
                onItemClick = {
//                    val data = it as StateModel.State
//                    selectedRegion = data.name
                })
        }

    }

    /**
     * @desc method will call when tap on rvSecifiedAllowedRegion recyclerview from selectedRegionsAdapter and remove Region item when click on remove button from selectedRegionsAdapter
     */
    private fun onItemRegionsRemoveClick(position: Int) {
        val item = selectedRegionsAdapter.get(position)
        selectedRegionsAdapter.remove(item)
        if (selectedRegionsAdapter.getAll()!!.isEmpty()) {
            switchSecifiedAllowedRegion.isChecked = false
        }
    }

    /**
     * @desc Manage sponsor baneer picker and sponsor logo picker on click and set position variable for last adapter banner position click
     *       If isforbanner is true than picker was opened for banner so set image in banner
     * @param imagePosition set on each click for set right image to right item of adapter
     * @param isForBanner set on each click for is opened for sponsor banner or sponsor image
     */
    private fun onimageSponsorClick(position: Int) {
        imagePosition = position
        isForBanner = false
        launchChooseProfileBottomSheet()
    }

    /**
     * @desc Manage sponsor baneer picker and sponsor logo picker on click and set position variable for last adapter banner position click
     *       If isforbanner is true than picker was opened for banner so set image in banner
     * @param imagePosition set on each click for set right image to right item of adapter
     * @param isForBanner set on each click for is opened for sponsor banner or sponsor image
     */
    private fun onimageSponsorBannerClick(position: Int) {
        imagePosition = position
        isForBanner = true
        launchChooseProfileBottomSheet()
    }

    /**
     * @desc method will call when tap on rvAddSponsor recyclerview from addSponsorAdapter and remove item when click on remove button from addSponsorAdapter
     */
    private fun onItemRemoveClick(position: Int) {
        val item = addSponsorAdapter.get(position)
        addSponsorAdapter.remove(item)
    }

    /**
     * @desc listen observer and receive the events of viewmodel
     * Also, Manage validation for next step and show snacbar for every validation if its not validated
     */
    private fun listenToViewModel() {
//      check isNextStepFormValid or not
        mViewModel.isNextStepFormValid.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                (activity as CreateTourmamentActivity).createTournamentPager.currentItem = 2
                saveData()
                isAbletoNext = true
            })

//      uploadFileSuccessResponse for each and every sponcer banner and set to correct position
        mViewModel.uploadFileSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                if (isForBanner) {
                    addSponsorAdapter.setSponsorBanner(it.data[0].location, imagePosition)
                } else {
                    addSponsorAdapter.setSponsorImage(it.data[0].location, imagePosition)
                }
//                imageUrlLocation = it.data[0].location
                requireActivity().makeSnackBar(
                    container,
                    it.message
                )
            })

//      uploadFileErrorResponse
        /*mViewModel.uploadFileErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                llSelectBanner.beVisible()
                imgSelectedBanner.beGone()
                requireActivity().makeSnackBar(
                    container,
                    "Image upload fail. Please try again."
                )
            })*/

//      validationLiveData and show snacbar for each validation
        mViewModel.validationLiveData.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                isAbletoNext = false
                when (it) {
                    0 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.select_price_type_error)
                        )
                    }
                    1 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.first_place_prize_error)
                        )
                    }
                    2 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.second_place_prize_error)
                        )
                    }
                    3 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.third_place_prize_error)
                        )
                    }
                    4 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.select_stage_error)
                        )
                    }
                    5 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.add_venue_error)
                        )
                    }
                    6 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.select_country_error)
                        )
                    }
                    7 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.select_region_error)
                        )
                    }
                    8 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.add_sponcer_error)
                        )
                    }
                    9 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.add_vanue_error)
                        )
                    }
                    10 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.part_number_not_valid)
                        )
                    }
                    11 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.fourth_place_prize_error)
                        )
                    }
                    12 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.fifth_place_prize_error)
                        )
                    }
                    13 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.sixth_place_prize_error)
                        )
                    }
                }
            })
    }

    /**
     * @desc this method is used for save data to local when click on next step.
     */
    fun saveData() {
        val sponcerList: MutableList<CreateTournament.Sponsor>? =
            ArrayList<CreateTournament.Sponsor>()

        for (i in addSponsorAdapter.getAll()) {
            val sponsor = CreateTournament.Sponsor()
            sponsor.sponsorName = i.sponorName
            sponsor.appStoreUrl = i.sponcorAppleStoreUrl
            sponsor.website = i.sponcorWebUrl
            sponsor.sponsorLogo = i.sponcerLogo
            sponsor.sponsorBanner = i.sponcerBanner
            sponsor.playStoreUrl = i.sponcorPlayStoreUrl
            sponcerList!!.add(sponsor)
        }


        val venueAddressList: MutableList<CreateTournament.VenueAddress>? =
            ArrayList<CreateTournament.VenueAddress>()

        for (i in addVenueAdapter.getAll()) {
            val vanue = CreateTournament.VenueAddress()
            vanue.venue = i.venue
            vanue.country = i.country
            vanue.region = i.region
            venueAddressList!!.add(vanue)
        }

        val regionsAllowedList: MutableList<String>? =
            ArrayList<String>()

        for (i in selectedRegionsAdapter.getAll()!!) {
            regionsAllowedList!!.add(i.title)
        }


        val createTournamentSaved: CreateTournament? =
            sharedPreferences.get<CreateTournament>("createTournamentSave")

        if (createTournamentSaved != null) {
            (requireActivity() as CreateTourmamentActivity).createTournamentSave =
                createTournamentSaved
        }

        (requireActivity() as CreateTourmamentActivity).createTournamentSave.apply {
            this.description =
                step2FieldsAdapter.getDataFromId(resources.getString(R.string.description))
            this.rules = step2FieldsAdapter.getDataFromId(resources.getString(R.string.rules))
//            this.criticalRules =
//                step2FieldsAdapter.getDataFromId(resources.getString(R.string.critical_rules))
//            this.faqs = step2FieldsAdapter.getDataFromId(resources.getString(R.string.faq))
//            this.schedule =
//                step2FieldsAdapter.getDataFromId(resources.getString(R.string.schedules))
            this.isPrize = switchPrize.isChecked
            this.sponsors = sponcerList!!
            this.venueAddress = venueAddressList!!
            this.regionsAllowed = (regionsAllowedList as ArrayList<String>?)!!
            this.isScreenshotRequired = switchScreenshotReq.isChecked
            this.isShowCountryFlag = switchShowCountryFlag.isChecked
//            this.maxParticipants = tvPartNumber.text.toString().trim().toInt()
            this.country = tvHybridSelectCountry.text.toString().trim()
            this.isParticipantsLimit = switchPart.isChecked
            this.prizeCurrency = prizeCurruncyType
            this.scoreReporting = socoreReportLocal

            this.venueAddressHybrid.stage = selectedStage
            this.venueAddressHybrid.region = selectedRegion
            this.venueAddressHybrid.venue = tvHybridAddVenue.text.toString().trim()
            this.venueAddressHybrid.country = selectedCountry

            this.prizeList.clear()
            (requireActivity() as CreateTourmamentActivity).createTournamentSave.prizeList.clear()

            if (tvFirstPrice.text!!.isNotEmpty()) {
//                this.firstPrize = tvFirstPrice.text.toString().toInt()
                var prizeDetail: CreateTournament.PrizeList = CreateTournament.PrizeList()

                prizeDetail.name = "1st"
                prizeDetail.value = tvFirstPrice.text.toString().toInt()
                this.prizeList.add(prizeDetail)
            }
            if (tvSecondPrice.text!!.isNotEmpty()) {
//                this.secondPrize = tvSecondPrice.text.toString().toInt()
                var prizeDetail: CreateTournament.PrizeList = CreateTournament.PrizeList()

                prizeDetail.name = "2nd"
                prizeDetail.value = tvSecondPrice.text.toString().toInt()
                this.prizeList.add(prizeDetail)


            }
            if (tvThirdPrice.text!!.isNotEmpty()) {
//                this.thirdPrize = tvThirdPrice.text.toString().toInt()
                var prizeDetail: CreateTournament.PrizeList = CreateTournament.PrizeList()

                prizeDetail.name = "3rd"
                prizeDetail.value = tvThirdPrice.text.toString().toInt()
                this.prizeList.add(prizeDetail)


            }

            if (tvFourthPrice.text!!.isNotEmpty()) {
                var prizeDetail: CreateTournament.PrizeList = CreateTournament.PrizeList()

                prizeDetail.name = "4th"
                prizeDetail.value = tvFourthPrice.text.toString().toInt()
                this.prizeList.add(prizeDetail)


            }
            if (tvFifthPrice.text!!.isNotEmpty()) {
                var prizeDetail: CreateTournament.PrizeList = CreateTournament.PrizeList()

                prizeDetail.name = "5th"
                prizeDetail.value = tvFifthPrice.text.toString().toInt()
                this.prizeList.add(prizeDetail)


            }
            if (tvSixPrice.text!!.isNotEmpty()) {
                var prizeDetail: CreateTournament.PrizeList = CreateTournament.PrizeList()
                prizeDetail.name = "6th"
                prizeDetail.value = tvSixPrice.text.toString().toInt()
                this.prizeList.add(prizeDetail)

            }

            if (rbOnline.isChecked) {
                this.tournamentType = "online"
            } else if (rbOffline.isChecked) {
                this.tournamentType = "offline"
            } else if (rbHybrid.isChecked) {
                this.tournamentType = "hybrid"
            }
        }

        sharedPreferences.put(
            "createTournamentSave",
            (requireActivity() as CreateTourmamentActivity).createTournamentSave
        )
    }

    /**
     * @desc this method is used for get data from local and if local data is available then set values in fields
     */
    fun refreshSaveData() {
        try {
            val createTournamentSaved: CreateTournament? =
                sharedPreferences.get<CreateTournament>("createTournamentSave")

            if (createTournamentSaved == null) {
                return
            }

            val sponcerList: MutableList<AddSponcer>? = ArrayList<AddSponcer>()

            for (i in createTournamentSaved.sponsors) {
                val sponsor = AddSponcer()
                sponsor.sponorName = i.sponsorName
                sponsor.sponcorAppleStoreUrl = i.appStoreUrl
                sponsor.sponcorWebUrl = i.website
                sponsor.sponcerLogo = i.sponsorLogo
                sponsor.sponcerBanner = i.sponsorBanner
                sponsor.sponcorPlayStoreUrl = i.playStoreUrl
                sponcerList!!.add(sponsor)
            }
            addSponsorAdapter.clear()
            addSponsorAdapter.addAll(sponcerList)

            val venueList: MutableList<AddVenue>? = ArrayList<AddVenue>()

            for (i in createTournamentSaved.venueAddress) {
                val vanue = AddVenue()
                vanue.venue = i.venue
                vanue.country = i.country
                vanue.region = i.region
                venueList!!.add(vanue)
            }
            addVenueAdapter.clear()
            addVenueAdapter.addAll(venueList!!)

            val regList: MutableList<Spinner>? = ArrayList<Spinner>()

            for (i in createTournamentSaved.regionsAllowed) {
                regList!!.add(Spinner(i))
            }


            selectedRegionsAdapter.clearAll()
            selectedRegionsAdapter.addAll(regList!!)

//            if (!regList.isEmpty()) {
//                switchSecifiedAllowedRegion.isChecked = true
//            }

            createTournamentSaved.apply {
                step2FieldsAdapter.setDataFromId(
                    resources.getString(R.string.description),
                    this.description
                )
                step2FieldsAdapter.setDataFromId(
                    resources.getString(R.string.rules),
                    this.rules
                )
//                step2FieldsAdapter.setDataFromId(
//                    resources.getString(R.string.critical_rules),
//                    this.criticalRules
//                )
//                step2FieldsAdapter.setDataFromId(
//                    resources.getString(R.string.faq),
//                    this.faqs
//                )
//                step2FieldsAdapter.setDataFromId(
//                    resources.getString(R.string.schedules),
//                    this.schedule
//                )
                switchScreenshotReq.isChecked = this.isScreenshotRequired
                switchShowCountryFlag.isChecked = this.isShowCountryFlag
                tvPartNumber.setText(this.maxParticipants.toString())
                partNumber = this.maxParticipants
                if (this.isParticipantsLimit) {
                    switchPart.isChecked = true
                    llparticipants.beVisible()

                } else {
                    switchPart.isChecked = false
                    llparticipants.beGone()
                }

                if (this.venueAddressHybrid.stage.isNotEmpty()) {
                    selectedStage = this.venueAddressHybrid.stage
                    tvHybridSelectStage.setText(this.venueAddressHybrid.stage)
                }
                if (this.venueAddressHybrid.region.isNotEmpty()) {
                    selectedRegion = this.venueAddressHybrid.region
                    tvHybridSelectRegion.setText(this.venueAddressHybrid.region)
                }
                if (this.venueAddressHybrid.country.isNotEmpty()) {
                    selectedCountry = this.venueAddressHybrid.country
                    tvHybridSelectCountry.setText(this.venueAddressHybrid.country)
                }
                if (this.venueAddressHybrid.venue.isNotEmpty()) {
                    tvHybridAddVenue.setText(this.venueAddressHybrid.venue)
                }

                if (!this.prizeCurrency.isFieldEmpty()) {
                    prizeCurruncyType = this.prizeCurrency
                    tvSelectPrize.setText(this.prizeCurrency)
                }

                switchPrize.isChecked = this.isPrize
                if (this.prizeList.isNotEmpty()) {
                    for (i in 0 until this.prizeList.size) {
                        when (i) {
                            0 -> {
                                tvFirstPrice.setText(this.prizeList[i].value.toString())
                            }
                            1 -> {
                                tvSecondPrice.setText(this.prizeList[i].value.toString())
                            }
                            2 -> {
                                tvThirdPrice.setText(this.prizeList[i].value.toString())
                            }
                            3 -> {
                                llForthPrice.visibility = View.VISIBLE
                                tvFourthPrice.setText(this.prizeList[i].value.toString())
                            }
                            4 -> {
                                llFifthPrice.visibility = View.VISIBLE
                                tvFifthPrice.setText(this.prizeList[i].value.toString())
                            }
                            5 -> {
                                llSixthPrice.visibility = View.VISIBLE
                                tvSixPrice.setText(this.prizeList[i].value.toString())
                            }
                        }
                    }
                }
                if (this.scoreReporting != 0) {
                    socoreReportLocal = this.scoreReporting

                    if (this.scoreReporting == 1) {
                        rbAdmins.isChecked = true
                    } else {
                        rbAdminsAndPlayer.isChecked = true
                    }
                }

                if (this.tournamentType.equals("online", true)) {
                    rbOnline.isChecked = true
                    tvRadioButtonSelectedTitle.text = resources.getString(R.string.online)
                    tvRadioButtonSelectedDesc.text =
                        resources.getString(R.string.your_tournament_will_be_held_on_only_as_online_event)
                    llOffline.beGone()
                    llHybrid.beGone()
                } else if (this.tournamentType.equals("offline", true)) {
                    rbOffline.isChecked = true
                    tvRadioButtonSelectedTitle.text = resources.getString(R.string.offline)
                    tvRadioButtonSelectedDesc.text =
                        resources.getString(R.string.your_tournament_will_be_held_on_only_as_offline_event)
                    llOffline.beVisible()
                    llHybrid.beGone()
                    if (addVenueAdapter.getAll().isEmpty()) {
                        val item = AddVenue()
                        addVenueAdapter.add(item)
                    }
                } else if (this.tournamentType.equals("hybrid", true)) {
                    rbHybrid.isChecked = true
                    tvRadioButtonSelectedTitle.text = resources.getString(R.string.hybrid)
                    tvRadioButtonSelectedDesc.text =
                        resources.getString(R.string.your_tournament_will_be_held_on_only_as_hybrid_event)
                    llOffline.beGone()
                    llHybrid.beVisible()
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * @desc this method is used for check validation is valid for next step or not
     */
    fun isAbleToNext() {
        mViewModel.onValidationForNextStep(
            switchPrize.isChecked,
            prizeCurruncyType,
            tvFirstPrice.text.toString().trim(),
            tvSecondPrice.text.toString().trim(),
            tvThirdPrice.text.toString().trim(),
            llForthPrice.visibility,
            llFifthPrice.visibility,
            llSixthPrice.visibility,
            tvFourthPrice.text.toString().trim(),
            tvFifthPrice.text.toString().trim(),
            tvSixPrice.text.toString().trim(),
            rbHybrid.isChecked,
            rbOnline.isChecked,
            rbOffline.isChecked,
            switchSponsors.isChecked,
            selectedStage,
            tvHybridAddVenue.text.toString().trim(),
            selectedCountry,
            selectedRegion,
            addSponsorAdapter.isValidated(),
            addVenueAdapter.isValidated(),
            switchPart.isChecked,
            partNumber
        )
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc Get file url from gallery and camera using intent and encoded to base64 string
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == AppConstants.TAKE_PHOTO) {
                mSelectedCameraImage?.apply {
                    if (data != null && data.hasExtra("forWhat")) {
                        data.getStringExtra("forWhat").showToast(requireContext())
                    }
                    val fileArray = JsonArray()
                    fileArray.add(this.encoder())
                    val jsonObject = JsonObject()
                    jsonObject.addProperty("path", "tournament")
                    jsonObject.add("files", fileArray)

                    launchProgressDialog()
                    mViewModel.uploadFiles(jsonObject)
//                    profile = this.encoder()
                }

            } else if (requestCode == AppConstants.IMAGE_CODE) {
                if (data == null)
                    return

                data.data?.apply {
                    mSelectedCameraImage = requireActivity().uriToImageFile(this)
                    mSelectedCameraImage?.apply {
                        val fileArray = JsonArray()
                        fileArray.add(this.encoder())
                        val jsonObject = JsonObject()
                        jsonObject.addProperty("path", "tournament")
                        jsonObject.add("files", fileArray)
                        launchProgressDialog()
                        mViewModel.uploadFiles(jsonObject)
                    }
                }
            }
        }
    }

    /**
     * @desc this method is used for onRequestPermissionsResult
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    /**
     * @desc this method is used for onPermissionsDenied
     */
    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            AppSettingsDialog.Builder(this).build().show()
        }
    }

    /**
     * @desc if permission granted from user when open gallery or camera for choose image
     */
    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
        if (requestCode == AppConstants.PERMISSION_CODE) {
            if (pos == 0) {
                chooseCamera(path = ::cameraPath)
            } else {
                chooseGallery()
            }
        }
    }

    /**
     * @desc temp camera file store in global file variable
     * @param file - temporary camera file
     */
    private fun cameraPath(file: File) {
        mSelectedCameraImage = file
    }

    /**
     * @desc this method will use choose media option(camera or gallery)
     * Display option inside bottom sheet
     */
    private fun launchChooseProfileBottomSheet() {
        bottomSheetDialogChooseMedia = BottomSheetDialog(requireContext())
        val viewChooseMedia = layoutInflater.inflate(R.layout.bottom_sheet_choose_option, null)
        bottomSheetDialogChooseMedia.setContentView(viewChooseMedia)
        val recyclerViewChooseMedia =
            viewChooseMedia.findViewById(R.id.recyclerViewChooseMedia) as RecyclerView
        recyclerViewChooseMedia.layoutManager = LinearLayoutManager(requireContext())
        val chooseMediaAdapter = ChooseMediaAdapter(
            resources.getStringArray(R.array.media_option),
            onChooseMediaClick = {
                pos = it
                when (it) {
                    0 -> {
                        chooseCamera(path = ::cameraPath)
                    }
                    1 -> {
                        chooseGallery()
                    }
                    else -> bottomSheetDialogChooseMedia.dismiss()
                }
                bottomSheetDialogChooseMedia.dismiss()
            }
        )
        recyclerViewChooseMedia.adapter = chooseMediaAdapter

        bottomSheetDialogChooseMedia.show()
    }

    /**
     * @desc launch camera for take image with check camera permission
     * Get file using file provide
     * @param path = temporary camera file
     *
     */
    private fun chooseCamera(path: (File) -> Unit = { _ -> }) {
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                // Ensure that there's a camera activity to handle the intent
                takePictureIntent.resolveActivity(requireContext().packageManager)?.also {
                    // Create the File where the photo should go
                    val photoFile: File? = try {
                        createImageFile()
                    } catch (ex: IOException) {
                        null
                    }
                    // Continue only if the File was successfully created
                    photoFile?.also {
                        path(photoFile)
                        val photoURI: Uri = FileProvider.getUriForFile(
                            requireContext(),
                            requireContext().packageName.plus(".provider"),
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        takePictureIntent.putExtra("forWhat", "banner")
                        startActivityForResult(
                            takePictureIntent,
                            AppConstants.TAKE_PHOTO
                        )
                    }
                }
            }
        } else {
            EasyPermissions.requestPermissions(
                this,
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    /**
     * @desc method will use create temporary file in local storage
     */
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File =
            requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        )
    }

    /**
     * @desc method will use launch gallery for choose profile
     */
    private fun chooseGallery() {
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            val pickIntent = Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            )
            pickIntent.type = "image/*"
            startActivityForResult(
                pickIntent, AppConstants.IMAGE_CODE
            )
        } else {
            EasyPermissions.requestPermissions(
                requireActivity(),
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }
}