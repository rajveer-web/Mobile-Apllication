package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

data class MemberList(
    var memberPosition: String = "",
    var memberName: String = "",
    var memberEmail: String = "",
    var memberUserName: String = "",
    var memberUserNameIsAvailable: Boolean = false,
    var memberInGameUserName: String = "",
    var memberInGameUserNameIsAvailable: Boolean = false,
    var memberPhoneCode: String = "",
    var memberPhoneNumber: String = "",
    var memberIsAutoPopulated: Boolean = false
)