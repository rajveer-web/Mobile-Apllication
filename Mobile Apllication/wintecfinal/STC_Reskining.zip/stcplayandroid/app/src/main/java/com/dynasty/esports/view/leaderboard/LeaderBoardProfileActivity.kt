package com.dynasty.esports.view.leaderboard

import android.content.IntentFilter
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.LeaderBoardProfileDataModel
import com.dynasty.esports.models.UserLeaderBoardProfileModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.viewmodel.LeaderBoardViewModel
import kotlinx.android.synthetic.main.activity_leader_board_profile.*
import kotlinx.android.synthetic.main.activity_leader_board_profile.toolbar
import kotlinx.android.synthetic.main.article_app_bar_layout.*
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import lecho.lib.hellocharts.gesture.ZoomType
import lecho.lib.hellocharts.model.*
import org.koin.androidx.viewmodel.ext.android.viewModel


class LeaderBoardProfileActivity : BaseActivity(),
    ConnectivityReceiver.ConnectivityReceiverListener {
    private var id: String = ""
    private var isDataLoaded=false
    private var leaderBoardProfileAdapter: LeaderBoardProfileAdapter?=null
    private var leaderBoardProfileList:MutableList<LeaderBoardProfileDataModel> = mutableListOf()
    private val mViewModel: LeaderBoardViewModel by viewModel()
    private var connectivityReceiver = ConnectivityReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leader_board_profile)
        getIntentData()
        setUpToolBar()
        initView()
        listenToViewModel()
    }


    /**
     * @desc set up toolbar with empty title
     */
    private fun setUpToolBar() {
        toolbar.title = ""
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }



    private fun initView() {
        recyclerViewLeaderBoardProfile.isNestedScrollingEnabled=false
        recyclerViewLeaderBoardProfile.layoutManager = GridLayoutManager(this, 2)
        leaderBoardProfileAdapter= LeaderBoardProfileAdapter(leaderBoardProfileList)
        recyclerViewLeaderBoardProfile.adapter=leaderBoardProfileAdapter
//        lineChartTournament.onValueTouchListener = ValueTouchListener()
    }

    private fun getIntentData() {
        intent.extras?.apply {
            id = this.getString("id").toString()
        }
    }

    private fun listenToViewModel() {
        mViewModel.fetchLeaderBoardSuccessResponse.observe(this, {
            linearLayoutProgressBar.beGone()
            isDataLoaded=true
            constraintLayoutUserDetail.beVisible()
            leaderBoardProfileList.clear()
            it.data?.apply {

                this.user?.apply {
                    if (!this.isNullOrEmpty()) {
                        this@LeaderBoardProfileActivity.loadImageFromServer(
                            this[0].profilePicture.toString(),
                            imageViewAvatar
                        )
                        textViewUserName.text = this[0].fullName
                        tvLeaderboardRegion.text = this[0].country
                    }

                }
                tvLeaderboardPointOne.text = this.firstPosition.toString()
                tvLeaderboardPointTwo.text = this.secondPosition.toString()
                tvLeaderboardPointThree.text = this.thirdPosition.toString()

                leaderBoardProfileList.add(
                    LeaderBoardProfileDataModel(
                        this.rank, resources.getString(
                            R.string.your_ranking
                        )
                    )
                )
                leaderBoardProfileList.add(
                    LeaderBoardProfileDataModel(
                        this.totalGameCount, resources.getString(
                            R.string.total_games
                        )
                    )
                )
                leaderBoardProfileList.add(
                    LeaderBoardProfileDataModel(
                        this.winCount, resources.getString(
                            R.string.number_of_win
                        )
                    )
                )
                leaderBoardProfileList.add(
                    LeaderBoardProfileDataModel(
                        this.awardDocCount, resources.getString(
                            R.string.trophy_total
                        )
                    )
                )
                leaderBoardProfileList.add(
                    LeaderBoardProfileDataModel(
                        this.lossCount, resources.getString(
                            R.string.number_of_lost
                        )
                    )
                )
                leaderBoardProfileList.add(
                    LeaderBoardProfileDataModel(
                        this.points, resources.getString(
                            R.string.total_points
                        )
                    )
                )
                leaderBoardProfileAdapter?.apply {
                    notifyDataSetChanged()
                }

                if(!this.gameStreakData.isNullOrEmpty()){
                    val values: MutableList<PointValue> = ArrayList()
                    for (j in 0 until this.gameStreakData.size) {
                        values.add(
                            PointValue(
                                gameStreakData[j].id!!.day!!.toFloat(),
                                gameStreakData[j].winCount!!.toFloat()
                            ).setLabel(getDateFromInt(gameStreakData[j].id!!).plus("\n").plus(resources.getString(R.string.game_streak)).plus(" ").plus(gameStreakData[j].winCount!!.toFloat()))
                        )
                    }

                    if(this.gameStreakData.size==1){
                        values.add(0,
                            PointValue(
                                gameStreakData[0].id!!.day!!.toFloat(),
                                0f
                            ).setLabel("")
                        )
                    }

                    //In most cased you can call data model methods in builder-pattern-like manner.

                    //In most cased you can call data model methods in builder-pattern-like manner.
                    val line: Line =
                        Line(values).setColor(ContextCompat.getColor(this@LeaderBoardProfileActivity,R.color.colorLine)).setCubic(true).setHasLabelsOnlyForSelected(
                            true)
                    val lines: MutableList<Line> = ArrayList()

                    lines.add(line)

                    val data = LineChartData()
                    data.lines = lines
                    val axisValue: MutableList<AxisValue> = mutableListOf()
                    for (i in 0..30) {
                        axisValue.add(i, AxisValue(i.toFloat()))
                    }

                    //  data = LineChartData(lines)


                    val axisX = Axis()
                    axisX.isAutoGenerated = false
                    axisX.values = axisValue
                    val axisY: Axis = Axis().setHasLines(true)

                    data.axisXBottom = axisX
                    //  data.axisYLeft = axisY


                    data.baseValue = Float.NEGATIVE_INFINITY

                    //  val chart = LineChartView(this)
//                    lineChartTournament.zoomType= ZoomType.HORIZONTAL


                    lineChartTournament.lineChartData = data
                }else{

                    lineChartTournament.beGone()
                }


            }
        })
        mViewModel.fetchLeaderBoardErrorResponse.observe(this, {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beGone()
            constraintLayoutUserDetail.beGone()
            constraintLayoutNoData.beVisible()
        })
    }

    private fun getDateFromInt(id: UserLeaderBoardProfileModel.Ids):String{
       return id.day.toString().plus("/").plus(id.month.toString()).plus("/").plus(id.year.toString()).convertDateToRequireDateFormat(AppConstants.DD_MM_YYYY_FORMAT,AppConstants.REQUIRED_TIME_FORMAT)

    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            unregisterReceiver(connectivityReceiver)
        }
    }

    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && !isDataLoaded) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoInternet.beGone()
            constraintLayoutUserDetail.beGone()
            constraintLayoutNoData.beGone()
            mViewModel.fetchLeaderBoardUserDetail(id)
        }else if(!isDataLoaded){
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }
}