package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class StepperFragmentDetailRequest (

    @field:SerializedName("url")
    var tournamentUrl: String? = null,

    @field:SerializedName("contactDetails")
    var contactDetails: String? = null,/*
    @field:SerializedName("participants")
    var addParticipants: String? = null,*/
    @field:SerializedName("youtubeVideoLink")
    var videoLink: String? = null,
    @field:SerializedName("facebookVideoLink")
    var fbLink: String? = null,
    @field:SerializedName("twitchVideoLink")
    var twitterLink: String? = null,
    @field:SerializedName("visibility")
    var visibility: String? = null,


    @field:SerializedName("isParticipantsLimit")
    var isPartitionLimit: Boolean? = null,
    @field:SerializedName("contactOption")
    var contactOption: String? = null
    )