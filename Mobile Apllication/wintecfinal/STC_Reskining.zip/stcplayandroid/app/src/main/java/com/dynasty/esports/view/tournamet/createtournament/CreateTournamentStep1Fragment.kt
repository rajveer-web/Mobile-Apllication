package com.dynasty.esports.view.tournamet.createtournament

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.provider.MediaStore
import android.text.InputFilter
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.constants.AppConstants.API_DATE_FORMAT
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.AddPlacementPoint
import com.dynasty.esports.models.CreateTournament
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.ChooseMediaAdapter
import com.dynasty.esports.viewmodel.CreateTournamentStep1ViewModel
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_create_tournament.*
import kotlinx.android.synthetic.main.fragment_create_tournament_step1.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import pub.devrel.easypermissions.AppSettingsDialog
import pub.devrel.easypermissions.EasyPermissions
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern
import kotlin.collections.ArrayList
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * @desc this is class will use for step 1 of create tournament
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CreateTournamentStep1Fragment : BaseFragment(), EasyPermissions.PermissionCallbacks,
    ConnectivityReceiver.ConnectivityReceiverListener {

    private val mViewModel: CreateTournamentStep1ViewModel by viewModel()
    private lateinit var selectGameAdapter: SelectGameAdapter
    private lateinit var selectPlatformAdapter: SelectPlatformAdapter
    private lateinit var addPlacementPointAdapter: AddPlacementPointAdapter
    private lateinit var bottomSheetDialogChooseMedia: BottomSheetDialog
    var isTournamentUrlValid: Boolean = false
    var tournamentTypeLocal: String? = ""
    var tournamentTeamFormat: String? = ""
    var matchFormatType: String = ""
    var selectedStage: String = ""
    var selectedNextStageFormate: String = ""
    var paidRegType: String = ""
    var checkinStrtDate: String? = ""
    var bracketSelectionTxt: String = ""
    var nextStagebracketSelectionTxt: String = ""
    var platformSelectedId: String = ""
    var isBannerSelected: Boolean = false
    var imageUrlLocation: String = ""
    var isAbletoNext: Boolean = false
    var tournamentTeamSize = 2
    var partNumber = 2
    var noOfRoundLocal = 1
    var placementPointsNumber = 2
    var teamPerGroup = 2
    var roundPerStage = 1
    var pointsPerKill = 1
    var winningTeamsPerGroup = 1
    var matchStages = 1
    var selectableDate = ""
    private var connectivityReceiver = ConnectivityReceiver()
    val handler = Handler()
    var maxPartError = false
    var noOfRoundRoundRobinError = false
    var noOfTeamsPerGroupError = false
    var winningTeamPerGroupError = false
    var numberOfRoundPerStageError = false
    var numberOfPlacementError = false
    var pointPerKillError = false
    var teamPerGroupWinningDivisibleError = false
    var tournamentSubstituteTeamSize = 1


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(
            R.layout.fragment_create_tournament_step1, container, false
        )
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    companion object {
        fun newInstance(type: String): Fragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = CreateTournamentStep1Fragment()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenToViewModel()
        initialize()
    }

    /**
     * @desc this method is used for initialize gamelist adapter and recyclerview
     *       set static data in spinner
     */
    private fun initialize() {
//      Gamelist Adapter initialition
        selectGameAdapter = SelectGameAdapter(onItemClick = ::onItemClick)
        selectPlatformAdapter = SelectPlatformAdapter(onItemClick = ::onSelectPlatformClick)
        addPlacementPointAdapter = AddPlacementPointAdapter()

        val tournamentTypeList = ArrayList<Spinner>()
        tournamentTypeList.add(Spinner("individual", resources.getString(R.string.one_vs_one)))
        tournamentTypeList.add(Spinner("team", resources.getString(R.string.team)))
        tvTurnamentUrl.text = BuildConfig.ARTICLE_PATH

        if (!(requireActivity() as CreateTourmamentActivity).isForEdit) {
//      tournamnet type spinner
            tvTournamentType.click {
                requireActivity().showSpinner(
                    resources.getString(R.string.tournament_type),
                    tvTournamentType,
                    tournamentTypeList,
                    false,
                    onItemClick = {
                        val list = it as Spinner
                        tournamentTypeLocal = list.ID
                        if (list.ID.equals("individual", true)) {
                            llTournamentTypeNumber.beGone()
                            tlTeamFormat.beGone()
                            substitute_switch.beGone()
                        } else {
                            tlTeamFormat.beVisible()
                            substitute_switch.beVisible()
                        }
                    }
                )
            }
        }

        val tournamentTeamFormatList = ArrayList<Spinner>()
        tournamentTeamFormatList.add(Spinner("dou", resources.getString(R.string.dou)))
        tournamentTeamFormatList.add(Spinner("squad", resources.getString(R.string.squad)))
        tournamentTeamFormatList.add(Spinner("xvsx", resources.getString(R.string.xvsx)))

//      tournamnet team format spinner
        tvTournamentTeamFormat.click {
            requireActivity().showSpinner(
                resources.getString(R.string.team_format),
                tvTournamentTeamFormat,
                tournamentTeamFormatList,
                false,
                onItemClick = {
                    val list = it as Spinner
                    tournamentTeamFormat = list.ID
                    if (list.ID.equals("xvsx", true)) {
                        llTournamentTypeNumber.beVisible()
                    } else {
                        llTournamentTypeNumber.beGone()
                    }
                }
            )
        }

        val matchFormateList = ArrayList<Spinner>()
        matchFormateList.add(Spinner("1", resources.getString(R.string.best_of_1)))
        matchFormateList.add(Spinner("3", resources.getString(R.string.best_of_3)))
        matchFormateList.add(Spinner("5", resources.getString(R.string.best_of_5)))
        matchFormateList.add(Spinner("7", resources.getString(R.string.best_of_7)))

//      matchformat spinner
        tvMatchFormateType.click {
            if (round_robin_bracket.isChecked) {
                requireActivity().showSpinner(
                    resources.getString(R.string.match_format),
                    tvMatchFormateType,
                    matchFormateList,
                    false,
                    onItemClick = {
                        val list = it as Spinner
                        matchFormatType = list.ID
                    })
            } else {
                requireActivity().showSpinner(
                    resources.getString(R.string.league_match_format),
                    tvMatchFormateType,
                    matchFormateList,
                    false,
                    onItemClick = {
                        val list = it as Spinner
                        matchFormatType = list.ID
                    })
            }
        }

        val stageList = ArrayList<Spinner>()
        stageList.add(Spinner("1", resources.getString(R.string.final_stage)))
        stageList.add(Spinner("2", resources.getString(R.string.quarter_stage)))
        stageList.add(Spinner("3", resources.getString(R.string.semi_final_stage)))

//      tvSelectStage spinner
        tvSelectStage.click {
            requireActivity().showSpinner(
                resources.getString(R.string.select_stage_),
                tvSelectStage,
                stageList,
                false,
                onItemClick = {
                    val list = it as Spinner
                    selectedStage = list.ID
                })
        }

        val selectedNextStageFormateList = ArrayList<Spinner>()
        selectedNextStageFormateList.add(Spinner("1", resources.getString(R.string.best_of_1)))
        selectedNextStageFormateList.add(Spinner("3", resources.getString(R.string.best_of_3)))
        selectedNextStageFormateList.add(Spinner("5", resources.getString(R.string.best_of_5)))
        selectedNextStageFormateList.add(Spinner("7", resources.getString(R.string.best_of_7)))

//      tvSelectStageMatchFormats spinner
        tvSelectStageMatchFormats.click {
            requireActivity().showSpinner(
                resources.getString(R.string.next_stage_match_formats),
                tvSelectStageMatchFormats,
                selectedNextStageFormateList,
                false,
                onItemClick = {
                    val list = it as Spinner
                    selectedNextStageFormate = list.ID
                })
        }

        val paidRegTypeList = ArrayList<Spinner>()
        paidRegTypeList.add(Spinner("1", "SAR"))


//      RegistartionType spinner
        tvpaidRegistartionType.click {
            requireActivity().showSpinner(
                resources.getString(R.string.paid_registartion_txt),
                tvpaidRegistartionType,
                paidRegTypeList,
                false,
                onItemClick = {
                    val list = it as Spinner
                    paidRegType = list.title
                })
        }

        val checkInStartList = ArrayList<Spinner>()
        checkInStartList.add(Spinner("1", resources.getString(R.string.minutes_30_prior)))
        checkInStartList.add(Spinner("2", resources.getString(R.string.hour_1_prior)))
        checkInStartList.add(Spinner("3", resources.getString(R.string.hour_2_prior)))
        checkInStartList.add(Spinner("4", resources.getString(R.string.hour_3_prior)))
        checkInStartList.add(Spinner("5", resources.getString(R.string.hour_4_prior)))
        checkInStartList.add(Spinner("6", resources.getString(R.string.hour_5_prior)))

//      checkin start time spinner
//      take a selcted date and time from above and do calculation for check in time
        tvCheckInStart.click {
            if (pick_date_edittext.text!!.isNotEmpty() && timePicker.text!!.isNotEmpty()) {
                requireActivity().showSpinner(
                    getString(R.string.check_in_start),
                    tvCheckInStart,
                    checkInStartList,
                    false,
                    onItemClick = {
                        val list = it as Spinner
                        checkinStrtDate = list.title

                        val dateAndTime =
                            pick_date_edittext.text.toString()
                                .trim() + " " + timePicker.text.toString().trim()
                        val date = convertStringToDate(
                            dateAndTime,
                            AppConstants.DATE_AND_TIME
                        )

                        val cal: Calendar = Calendar.getInstance()
                        cal.time = date
                        if (list.ID.equals("1", true)) {
                            cal.add(Calendar.MINUTE, -30)
                        } else if (list.ID.equals("2", true)) {
                            cal.add(Calendar.HOUR, -1)
                        } else if (list.ID.equals("3", true)) {
                            cal.add(Calendar.HOUR, -2)
                        } else if (list.ID.equals("4", true)) {
                            cal.add(Calendar.HOUR, -3)
                        } else if (list.ID.equals("5", true)) {
                            cal.add(Calendar.HOUR, -4)
                        } else if (list.ID.equals("6", true)) {
                            cal.add(Calendar.HOUR, -5)
                        }
                        val oneHourBack: Date = cal.time
                        val fmtOut = SimpleDateFormat(API_DATE_FORMAT)
                        checkinStrtDate = fmtOut.format(oneHourBack)
                    })
            } else {
                requireActivity().makeSnackBar(
                    container,
                    resources.getString(R.string.tournament_select_tournament_time_date)
                )
            }
        }

        ll_image_upload.click {
            mViewModel.llImageUpload()
        }

        timePicker.click {
            mViewModel.pickTimeEdittextClick()
        }

        pick_date_edittext.click {
            mViewModel.pickDateEdittextClick()
        }

        pick_end_date_edittext.click {
            mViewModel.pickEndDateEdittextClick()
        }

//      Checkurl button click
        llCheckUrl.click {
            mViewModel.checkValidation(editTournamentName.text.toString().trim())
        }

//        Gamelist adapter intilization
        rvGameList.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rvGameList.adapter = selectGameAdapter

//      Platformlist adapter intilization
        rvPlatFormList.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rvPlatFormList.adapter = selectPlatformAdapter

//      Platformlist adapter intilization
        rvInputPlacementPoint.layoutManager = LinearLayoutManager(context)
        rvInputPlacementPoint.adapter = addPlacementPointAdapter

//      select bracket radio button
        rgSelectBracket.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (single_bracket.isChecked) {
                bracketSelectionTxt = "single"
                llRoundRobin.beGone()
                llBattelRoyal.beGone()
                tlLeageMatchFormat.beVisible()
                llRRandBR.beGone()
                llNextStageBracketFormat.beGone()
                llMainAdvanceStage.beVisible()
                tlLeageMatchFormat.hint = resources.getString(R.string.league_match_format)
//                single_bracket.setTextColor(resources.getColor(R.color.white))
//                double_bracket.setTextColor(resources.getColor(R.color.black))
//                round_robin_bracket.setTextColor(resources.getColor(R.color.black))
//                battle_royale_bracket.setTextColor(resources.getColor(R.color.black))
            } else if (double_bracket.isChecked) {
                bracketSelectionTxt = "double"
                llRoundRobin.beGone()
                llBattelRoyal.beGone()
                tlLeageMatchFormat.beVisible()
                llRRandBR.beGone()
                llNextStageBracketFormat.beGone()
                llMainAdvanceStage.beVisible()
                tlLeageMatchFormat.hint = resources.getString(R.string.league_match_format)
//                single_bracket.setTextColor(resources.getColor(R.color.black))
//                double_bracket.setTextColor(resources.getColor(R.color.white))
//                round_robin_bracket.setTextColor(resources.getColor(R.color.black))
//                battle_royale_bracket.setTextColor(resources.getColor(R.color.black))
            } else if (round_robin_bracket.isChecked) {
                bracketSelectionTxt = "round_robin"
                llRoundRobin.beVisible()
                llBattelRoyal.beGone()
                tlLeageMatchFormat.beVisible()
                llRRandBR.beVisible()
                llNextStageBracketFormat.beVisible()
                llMainAdvanceStage.beGone()
                tlLeageMatchFormat.hint = resources.getString(R.string.match_format)
//                single_bracket.setTextColor(resources.getColor(R.color.black))
//                double_bracket.setTextColor(resources.getColor(R.color.black))
//                round_robin_bracket.setTextColor(resources.getColor(R.color.white))
//                battle_royale_bracket.setTextColor(resources.getColor(R.color.black))
            } else if (battle_royale_bracket.isChecked) {
                bracketSelectionTxt = "battle_royale"
                llRoundRobin.beGone()
                llBattelRoyal.beVisible()
                tlLeageMatchFormat.beGone()
                llRRandBR.beVisible()
                llNextStageBracketFormat.beGone()
                llMainAdvanceStage.beGone()
                tlLeageMatchFormat.hint = resources.getString(R.string.league_match_format)
//                single_bracket.setTextColor(resources.getColor(R.color.black))
//                double_bracket.setTextColor(resources.getColor(R.color.black))
//                round_robin_bracket.setTextColor(resources.getColor(R.color.black))
//                battle_royale_bracket.setTextColor(resources.getColor(R.color.white))
            }
            llparticipants.beVisible()
        })

//      next stage select bracket radio button
        rgSelectNextStageBracket.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (nextStageSingleBracket.isChecked) {
                nextStagebracketSelectionTxt = "single"
                llMainAdvanceStage.beVisible()
            } else if (nextStageDoubleBracket.isChecked) {
                nextStagebracketSelectionTxt = "double"
                llMainAdvanceStage.beVisible()
            }
        })

//        editTournamentName.keyListener = DigitsKeyListener.getInstance("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_")


//        editTournamentName.setRawInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
//      TournamentName textchangelistner for url is available or not
        editTournamentName.doAfterTextChanged {
            handler.removeCallbacks(runnableTeamUrlName)
//            val removeSpaceUrl = it.toString().replace(" ", "_")
            val regex: Pattern = Pattern.compile("[$&+,:;=\\\\?@#|/'<>.^*()%!-]")
            if (regex.matcher(it.toString()).find()) {
                tvTurnamentUrl.text = BuildConfig.ARTICLE_PATH.plus(it.toString().replace(" ", "_"))
                tvTurnamentUrl.setTextColor(ContextCompat.getColor(requireContext(), R.color.red))
                isTournamentUrlValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentName = it.toString()
            } else {
                tvTurnamentUrl.text = BuildConfig.ARTICLE_PATH.plus(it.toString().replace(" ", "_"))
                tvTurnamentUrl.setTextColor(ContextCompat.getColor(requireContext(), R.color.red))
                isTournamentUrlValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid = false
                (requireActivity() as CreateTourmamentActivity).tournamentName = it.toString()

                if (!it.toString().replace(" ", "_").isFieldEmpty()) {
                    handler.removeCallbacks(runnableTeamUrlName)
                    handler.postDelayed(runnableTeamUrlName, 1000)
                }
            }
        }

//      TournamentName textchangelistner for url is available or not
        paid_switch.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                ll_fee_edittext.beVisible()
            } else {
                ll_fee_edittext.beGone()
            }
        }

        switchTieBreakerPoints.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                llPointPerKill.beVisible()
            } else {
                llPointPerKill.beGone()
            }
        }

//      checkin switch for url is available or not
        check_in_switch.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                tlCheckInStart.beVisible()
            } else {
                tlCheckInStart.beGone()
            }
        }

        substitute_switch.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                llsubstituteMemberCount.beVisible()
            } else {
                llsubstituteMemberCount.beGone()
            }
        }

        switchAdvanceStage.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                llAdvanceStage.beVisible()
            } else {
                llAdvanceStage.beGone()
            }
        }
//      Minimum 1 Substitute member required in team
        tvTournamamentSubstituteMinus.click {
            if (tournamentSubstituteTeamSize > 1) {
                tournamentSubstituteTeamSize--
                editTournamamentSubstituteNumber.setText(tournamentSubstituteTeamSize.toString())
            }
        }

        //Maximum 10 Substitute member required in team
        tvTournamamentSubstitutePlus.click {
            if (tournamentSubstituteTeamSize <= 10) {
                tournamentSubstituteTeamSize++
                editTournamamentSubstituteNumber.setText(tournamentSubstituteTeamSize.toString())
            }
        }


        //     Do validation for Minimum 1 member required in team and team member is not empty.
        editTournamamentSubstituteNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                tvTurnamentSubstituteerror.beVisible()
                tvTurnamentSubstituteerror.setTextColor(resources.getColor(R.color.md_red_500))
                tvTurnamentSubstituteerror.text = getString(R.string.required_field)
                tournamentSubstituteTeamSize = 1
                editTournamamentSubstituteNumber.setText("1")
            } else {
                tournamentSubstituteTeamSize = it.toString().toInt()
                if (it.toString().toInt() < 1) {
                    tvTurnamentSubstituteerror.beVisible()
                    tvTurnamentSubstituteerror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvTurnamentSubstituteerror.text = getString(R.string.minimum_allowed_limit_is_1)
                } else if (it.toString().toInt() > 10) {
                    tvTurnamentSubstituteerror.beVisible()
                    tvTurnamentSubstituteerror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvTurnamentSubstituteerror.text =
                        getString(R.string.maximum_allowed_limit_is_10)
                } else {
                    tvTurnamentSubstituteerror.beGone()
                }
            }
        }


//      Minimum 2 member required in team
        tvTournamamentMinus.click {
            if (tournamentTeamSize > 2) {
                tournamentTeamSize--
                editTournamamentNumber.setText(tournamentTeamSize.toString())
            }
        }


//      Do validation for Minimum 2 member required in team and team member is not empty.
        editTournamamentNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                tvTurnamentNumbererror.beVisible()
                tvTurnamentNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                tvTurnamentNumbererror.text = getString(R.string.required_field)
                tournamentTeamSize = 2
                editTournamamentNumber.setText("2")
            } else {
                tournamentTeamSize = it.toString().toInt()
                if (it.toString().toInt() < 2) {
                    tvTurnamentNumbererror.beVisible()
                    tvTurnamentNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvTurnamentNumbererror.text = getString(R.string.minimum_allowed_limit_is_2)
                } else if (it.toString().toInt() > 10) {
                    tvTurnamentNumbererror.beVisible()
                    tvTurnamentNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvTurnamentNumbererror.text =
                        getString(R.string.maximum_allowed_limit_is_10)
                } else {
                    tvTurnamentNumbererror.beGone()
                }
            }
        }

//      add one unit in tournament number
        tvTournamamentPlus.click {
            tournamentTeamSize++
            editTournamamentNumber.setText(tournamentTeamSize.toString())
        }

//      Minimum 2 member required in team
        tvNumberOfPlacementMinus.click {
            if (placementPointsNumber > 2) {
                placementPointsNumber--
                editNumberOfPlacementNumber.setText(placementPointsNumber.toString())
            }
        }


//      add one unit in tournament number
        tvNumberOfPlacementPlus.click {
            if (placementPointsNumber < 10 && placementPointsNumber < teamPerGroup) {
                placementPointsNumber++
                editNumberOfPlacementNumber.setText(placementPointsNumber.toString())
            }
        }

        for (i in 1..2) {
            val item = AddPlacementPoint()
            item.id = i.toString()
            addPlacementPointAdapter.add(item)
        }


//      Do validation for Minimum 2 member required in team and team member is not empty.
        editNumberOfPlacementNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                numberOfPlacementError = true
                tvNumberOfPlacementError.beVisible()
                tvNumberOfPlacementError.setTextColor(resources.getColor(R.color.md_red_500))
                tvNumberOfPlacementError.text = getString(R.string.required_field)
                placementPointsNumber = 2
                editNumberOfPlacementNumber.setText("2")
            } else {

                if (it.toString().toInt() < 2) {
                    numberOfPlacementError = true
                    tvNumberOfPlacementError.beVisible()
                    tvNumberOfPlacementError.setTextColor(resources.getColor(R.color.md_red_500))
                    tvNumberOfPlacementError.text = getString(R.string.minimum_allowed_limit_is_2)
                } else if (it.toString().toInt() > teamPerGroup || it.toString().toInt() > 10) {
                    numberOfPlacementError = true
                    tvNumberOfPlacementError.beVisible()
                    if (it.toString().toInt() > 10) {
                        tvNumberOfPlacementError.setTextColor(resources.getColor(R.color.md_red_500))
                        tvNumberOfPlacementError.text =
                            getString(R.string.maximum_allowed_limit_is_10)
                    } else {
                        tvNumberOfPlacementError.setTextColor(resources.getColor(R.color.md_red_500))
                        tvNumberOfPlacementError.text =
                            getString(R.string.maximum_allowed_limit_is).plus(" " + teamPerGroup)
                    }
                } else {
                    placementPointsNumber = it.toString().toInt()
                    addPlacementPointAdapter.clear()
                    for (i in 1..placementPointsNumber) {
                        val item = AddPlacementPoint()
                        item.id = i.toString()
                        addPlacementPointAdapter.add(item)
                    }
                    numberOfPlacementError = false
                    tvNumberOfPlacementError.beGone()
                }
            }
        }

        //      Minimum 2 participant member required
        tvPartMinus.click {
            if (partNumber > 2) {
                partNumber--
                tvPartNumber.setText(partNumber.toString())
            }
        }

//      add one unit in part number
        tvPartPlus.click {
            if (partNumber < 100000) {
                partNumber++
                tvPartNumber.setText(partNumber.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and team member is not empty.
        editNoOfRoundNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                noOfRoundRoundRobinError = true
                tvNoOfRoundError.beVisible()
                tvNoOfRoundError.setTextColor(resources.getColor(R.color.md_red_500))
                tvNoOfRoundError.text = getString(R.string.required_field)
                noOfRoundLocal = 1
                editNoOfRoundNumber.setText("1")
            } else {
                noOfRoundLocal = it.toString().toInt()
                if (it.toString().toInt() < 1) {
                    noOfRoundRoundRobinError = true
                    tvNoOfRoundError.beVisible()
                    tvNoOfRoundError.setTextColor(resources.getColor(R.color.md_red_500))
                    tvNoOfRoundError.text = getString(R.string.minimum_allowed_limit_is_1)
                } else if (it.toString().toInt() > 2) {
                    noOfRoundRoundRobinError = true
                    tvNoOfRoundError.beVisible()
                    tvNoOfRoundError.setTextColor(resources.getColor(R.color.md_red_500))
                    tvNoOfRoundError.text =
                        getString(R.string.maximum_allowed_limit_is).plus(" 2")
                } else {
                    noOfRoundRoundRobinError = false
                    tvNoOfRoundError.beGone()
                }
            }
        }

        //      Minimum 2 participant member required
        tvNoOfRoundMinus.click {
            if (noOfRoundLocal > 1) {
                noOfRoundLocal--
                editNoOfRoundNumber.setText(noOfRoundLocal.toString())
            }
        }

//      add one unit in part number
        tvNoOfRoundPlus.click {
            if (noOfRoundLocal < 100000) {
                noOfRoundLocal++
                editNoOfRoundNumber.setText(noOfRoundLocal.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and part member is not empty.
        tvPartNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                tvPartNumbererror.beVisible()
                tvPartNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                tvPartNumbererror.text = getString(R.string.required_field)
                partNumber = 2
                tvPartNumber.setText("2")
                maxPartError = true
            } else {
                partNumber = it.toString().toInt()
                if (it.toString().toInt() < 2) {
                    maxPartError = true
                    tvPartNumbererror.beVisible()
                    tvPartNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvPartNumbererror.text = getString(R.string.minimum_allowed_limit_is_2)
                } else if (it.toString().toInt() > 1024) {
                    maxPartError = true
                    tvPartNumbererror.beVisible()
                    tvPartNumbererror.setTextColor(resources.getColor(R.color.md_red_500))
                    tvPartNumbererror.text = getString(R.string.maximum_allowed_limit_is_1024)
                } else {
                    maxPartError = false
                    tvPartNumbererror.beGone()
                }
                calculateTeamPerGroupError()

                var hasError = false

                val boolIsAnyError: MutableList<Boolean> = ArrayList()
                boolIsAnyError.add(maxPartError)
                boolIsAnyError.add(noOfTeamsPerGroupError)
                boolIsAnyError.add(winningTeamPerGroupError)
                boolIsAnyError.add(noOfRoundRoundRobinError)
                boolIsAnyError.add(teamPerGroupWinningDivisibleError)

                for (i in boolIsAnyError) {
                    if (i) {
                        hasError = true
                        break
                    }
                }

                if (!hasError) {
                    if (checkDivisionAndEqual()) {
                        val stages =
                            calculateStages(
                                partNumber,
                                teamPerGroup,
                                winningTeamsPerGroup,
                                1,
                                partNumber
                            )

                        editBrStageNumber.text = "" + stages
                    }
                }
            }
        }

        add_fee_edittext.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(10))

        initBattelRoyal()
    }

    private fun initBattelRoyal() {

        tvBrTeanPerGroupMinus.click {
            if (teamPerGroup > 2) {
                teamPerGroup--
                editBrTeanPerGroupNumber.setText(teamPerGroup.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and team member is not empty.
        editBrTeanPerGroupNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                noOfTeamsPerGroupError = true
                tvBrTeanPerGroupError.beVisible()
                tvBrTeanPerGroupError.setTextColor(resources.getColor(R.color.md_red_500))
                tvBrTeanPerGroupError.text = getString(R.string.required_field)
                teamPerGroup = 2
                editBrTeanPerGroupNumber.setText("2")
            } else {
                teamPerGroup = it.toString().toInt()
                calculateTeamPerGroupError()
                calculateWinningTeamPerGroup()

                var hasError = false

                val boolIsAnyError: MutableList<Boolean> = ArrayList()
                boolIsAnyError.add(maxPartError)
                boolIsAnyError.add(noOfTeamsPerGroupError)
                boolIsAnyError.add(winningTeamPerGroupError)
                boolIsAnyError.add(noOfRoundRoundRobinError)
                boolIsAnyError.add(teamPerGroupWinningDivisibleError)

                for (i in boolIsAnyError) {
                    if (i) {
                        hasError = true
                        break
                    }
                }

                if (!hasError) {
                    if (checkDivisionAndEqual()) {
                        val stages =
                            calculateStages(
                                partNumber,
                                teamPerGroup,
                                winningTeamsPerGroup,
                                1,
                                partNumber
                            )

                        editBrStageNumber.text = "" + stages
                    }
                }
            }
        }

//      add one unit in teamPerGroup
        tvBrTeanPerGroupPlus.click {
            teamPerGroup++
            editBrTeanPerGroupNumber.setText(teamPerGroup.toString())
        }


        tvBrNumberOfMatchesPerStageMinus.click {
            if (roundPerStage > 1) {
                roundPerStage--
                editBrNumberOfMatchesPerStageNumber.setText(roundPerStage.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and team member is not empty.
        editBrNumberOfMatchesPerStageNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                numberOfRoundPerStageError = true
                tvBrNumberOfMatchesPerStageError.beVisible()
                tvBrNumberOfMatchesPerStageError.setTextColor(resources.getColor(R.color.md_red_500))
                tvBrNumberOfMatchesPerStageError.text = getString(R.string.required_field)
                roundPerStage = 1
                editBrNumberOfMatchesPerStageNumber.setText("1")
            } else {
                roundPerStage = it.toString().toInt()
                if (it.toString().toInt() < 1) {
                    numberOfRoundPerStageError = true
                    tvBrNumberOfMatchesPerStageError.beVisible()
                    tvBrNumberOfMatchesPerStageError.setTextColor(resources.getColor(R.color.md_red_500))
                    tvBrNumberOfMatchesPerStageError.text =
                        getString(R.string.minimum_allowed_limit_is_1)
                } else if (it.toString().toInt() > 10) {
                    numberOfRoundPerStageError = true
                    tvBrNumberOfMatchesPerStageError.beVisible()
                    tvBrNumberOfMatchesPerStageError.setTextColor(resources.getColor(R.color.md_red_500))
                    tvBrNumberOfMatchesPerStageError.text =
                        getString(R.string.maximum_allowed_limit_is_10)
                } else {
                    numberOfRoundPerStageError = false
                    tvBrNumberOfMatchesPerStageError.beGone()
                }
                var hasError = false

                val boolIsAnyError: MutableList<Boolean> = ArrayList()
                boolIsAnyError.add(maxPartError)
                boolIsAnyError.add(noOfTeamsPerGroupError)
                boolIsAnyError.add(winningTeamPerGroupError)
                boolIsAnyError.add(noOfRoundRoundRobinError)
                boolIsAnyError.add(teamPerGroupWinningDivisibleError)

                for (i in boolIsAnyError) {
                    if (i) {
                        hasError = true
                        break
                    }
                }

                if (!hasError) {
                    if (checkDivisionAndEqual()) {
                        val stages =
                            calculateStages(
                                partNumber,
                                teamPerGroup,
                                winningTeamsPerGroup,
                                1,
                                partNumber
                            )

                        editBrStageNumber.text = "" + stages
                    }
                }

            }
        }

//      add one unit in teamPerGroup
        tvBrNumberOfMatchesPerStagePlus.click {
            roundPerStage++
            editBrNumberOfMatchesPerStageNumber.setText(roundPerStage.toString())
        }

        tvBrWinningTeamsPerGroupMinus.click {
            if (winningTeamsPerGroup > 1) {
                winningTeamsPerGroup--
                editBrWinningTeamsPerGroupNumber.setText(winningTeamsPerGroup.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and team member is not empty.
        editBrWinningTeamsPerGroupNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                winningTeamPerGroupError = true
                tvBrWinningTeamsPerGroupError.beVisible()
                tvBrWinningTeamsPerGroupError.setTextColor(resources.getColor(R.color.md_red_500))
                tvBrWinningTeamsPerGroupError.text = getString(R.string.required_field)
                winningTeamsPerGroup = 1
                editBrWinningTeamsPerGroupNumber.setText("1")
            } else {
                winningTeamsPerGroup = it.toString().toInt()
                calculateWinningTeamPerGroup()
                if (checkDivisionAndEqual()) {
                    val stages =
                        calculateStages(
                            partNumber,
                            teamPerGroup,
                            winningTeamsPerGroup,
                            1,
                            partNumber
                        )

                    editBrStageNumber.text = "" + stages
                }
            }
        }

//      add one unit in teamPerGroup
        tvBrWinningTeamsPerGroupPlus.click {
            winningTeamsPerGroup++
            editBrWinningTeamsPerGroupNumber.setText(winningTeamsPerGroup.toString())
        }

//      add one unit in teamPerGroup
        tvPointPerKillPlus.click {
            pointsPerKill++
            editPointPerKillNumber.setText(pointsPerKill.toString())
        }

        tvPointPerKillMinus.click {
            if (pointsPerKill > 2) {
                pointsPerKill--
                editPointPerKillNumber.setText(pointsPerKill.toString())
            }
        }

//      Do validation for Minimum 2 member required in team and team member is not empty.
        editPointPerKillNumber.doAfterTextChanged {
            if (it.isNullOrEmpty()) {
                pointPerKillError = true
                tvPointPerKillError.beVisible()
                tvPointPerKillError.setTextColor(resources.getColor(R.color.md_red_500))
                tvPointPerKillError.text = getString(R.string.required_field)
                pointsPerKill = 2
                editPointPerKillNumber.setText("2")
            } else {
                pointsPerKill = it.toString().toInt()
                if (it.toString().toInt() < 2) {
                    pointPerKillError = true
                    tvPointPerKillError.beVisible()
                    tvPointPerKillError.setTextColor(resources.getColor(R.color.md_red_500))
                    tvPointPerKillError.text = getString(R.string.minimum_allowed_limit_is_2)
                } else {
                    pointPerKillError = false
                    tvPointPerKillError.beGone()
                }
            }
        }
    }

    private fun calculateTeamPerGroupError() {
        if (teamPerGroup.toString().toInt() < 2) {
            noOfTeamsPerGroupError = true
            tvBrTeanPerGroupError.beVisible()
            tvBrTeanPerGroupError.setTextColor(resources.getColor(R.color.md_red_500))
            tvBrTeanPerGroupError.text = getString(R.string.minimum_allowed_limit_is_2)
        } else if (teamPerGroup.toString().toInt() > partNumber || teamPerGroup.toString()
                .toInt() > 10
        ) {
            noOfTeamsPerGroupError = true
            tvBrTeanPerGroupError.beVisible()
            tvBrTeanPerGroupError.setTextColor(resources.getColor(R.color.md_red_500))

            if (teamPerGroup.toString().toInt() > 10) {
                tvBrTeanPerGroupError.text =
                    getString(R.string.maximum_allowed_limit_is).plus(" 10")
            } else {
                if (partNumber != 0) {
                    tvBrTeanPerGroupError.text =
                        getString(R.string.maximum_allowed_limit_is).plus(" " + partNumber)
                }
            }
        } else {
            noOfTeamsPerGroupError = false
            tvBrTeanPerGroupError.beGone()
        }
    }

    private fun checkDivisionAndEqual(): Boolean {
        if (teamPerGroup > winningTeamsPerGroup) {
            if (teamPerGroup % winningTeamsPerGroup == 0 && teamPerGroup != winningTeamsPerGroup) {
                return true
            }
        }
        return false
    }

    private fun calculateWinningTeamPerGroup() {
        if (checkDivisionAndEqual()) {
            teamPerGroupWinningDivisibleError = false
            tvBrTeanPerGroupDivisibleError.beGone()
        } else {
            teamPerGroupWinningDivisibleError = true
            tvBrTeanPerGroupDivisibleError.beVisible()
        }

        if (winningTeamsPerGroup.toString().toInt() < 1) {
            winningTeamPerGroupError = true
            tvBrWinningTeamsPerGroupError.beVisible()
            tvBrWinningTeamsPerGroupError.setTextColor(resources.getColor(R.color.md_red_500))
            tvBrWinningTeamsPerGroupError.text =
                getString(R.string.minimum_allowed_limit_is_1)
        } else if (winningTeamsPerGroup.toString().toInt() > 10
        ) {
            winningTeamPerGroupError = true
            tvBrWinningTeamsPerGroupError.beVisible()
            tvBrWinningTeamsPerGroupError.setTextColor(resources.getColor(R.color.md_red_500))
            if (winningTeamsPerGroup.toString().toInt() > 10) {
                tvBrWinningTeamsPerGroupError.text =
                    getString(R.string.maximum_allowed_limit_is_10)
            }
        } else {
            winningTeamPerGroupError = false
            tvBrWinningTeamsPerGroupError.beGone()
        }
    }

    var nextStagePlayer = 1

    private fun calculateStages(
        totalPlayer: Int,
        noOfPlayerPerGroup: Int,
        noOfWinning: Int,
        noOfStage: Int,
        previousStagePlayer: Int
    ): Int {
        try {
            if (totalPlayer != noOfPlayerPerGroup) {
                createStage(previousStagePlayer, totalPlayer, noOfPlayerPerGroup, noOfWinning)
            }

            val inDouble: Double = nextStagePlayer.toDouble() / noOfPlayerPerGroup.toDouble()

            if (totalPlayer == noOfPlayerPerGroup) {
                return noOfStage
            } else return if (ceil(inDouble).roundToInt() <= 1) {
                noOfStage + 1
            } else if (ceil(inDouble).roundToInt() == 2) {
                noOfStage + 2
            } else {
                calculateStages(
                    nextStagePlayer,
                    noOfPlayerPerGroup,
                    noOfWinning,
                    noOfStage + 1,
                    previousStagePlayer
                )
            }
        } catch (e: Exception) {
            return 0
        }
    }

    private fun createStage(
        previousStagePlayer: Int,
        totalPlayer: Int,
        noOfPlayerPerGroup: Int,
        noOfWinning: Int
    ) {

        val inDouble = totalPlayer.toDouble() / noOfPlayerPerGroup.toDouble()

        nextStagePlayer = ceil(inDouble).roundToInt() * noOfWinning

        if (nextStagePlayer < previousStagePlayer) {
            // noOfPlayerPerGroup = noOfPlayerPerGroup + 1;
            nextStagePlayer =
                inDouble.roundToInt() * noOfWinning
        } else {
            createStage(previousStagePlayer, totalPlayer, noOfPlayerPerGroup, noOfWinning)
        }
    }

    /**
     * @desc method will call when tap on gamelist recyclerview from selectGameAdapter and set selected true and selected false
     */
    private fun onItemClick(position: Int) {
        val item = selectGameAdapter.getItem(position)
        selectGameAdapter.setSelected(item.id)
        selectPlatformAdapter.addAll(item.platform as MutableList<TournamentGameRes.Platform>)
        platformSelectedId = ""
        selectPlatformAdapter.clearSelection()
        setBracketFromGameList(item)
        refreshPlatformPlaceHolder()
    }

    private fun setBracketFromGameList(item: TournamentGameRes.Datum) {
        llBattelRoyal.beGone()
        llRoundRobin.beGone()
        bracketSelectionTxt = ""
        rgSelectBracket.clearCheck()
        llparticipants.beGone()

        if (item.bracketTypes!!.single) {
            single_bracket.beVisible()
        } else {
            single_bracket.beGone()
        }

        if (item.bracketTypes!!._double) {
            double_bracket.beVisible()
        } else {
            double_bracket.beGone()
        }
        if (item.bracketTypes!!.roundRobin) {
            round_robin_bracket.beVisible()
        } else {
            round_robin_bracket.beGone()
        }
        if (item.bracketTypes!!.battleRoyale) {
            battle_royale_bracket.beVisible()
        } else {
            battle_royale_bracket.beGone()
        }

    }

    /**
     * @desc method will call when tap on platformlist recyclerview from selectPlatformAdapter and set selected true and selected false
     */
    private fun onSelectPlatformClick(position: Int) {
        val item = selectPlatformAdapter.getItem(position)
        selectPlatformAdapter.setSelected(item.id)
        platformSelectedId = item.id
    }

    /**
     * @desc listen observer and receive the events of viewmodel
     * Also, Manage validation for next step and show snacbar for every validation if its not validated
     */
    private fun listenToViewModel() {
//      noInternetException handling for gamelist
        mViewModel.noInternetException.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            when (it) {
                "all" -> {
                    "all".showToast(requireActivity())
                }
                "gameList" -> {
                    rvGameList.beGone()
                    constraintLayoutNoInternet.beVisible()
                    llPlaceHolderNoData.beGone()
                    dismissProgressDialog()
                }
            }
        })

//      open picker for date selection
        mViewModel.datePickerObserver.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                if (it)
                    getDate(
                        pick_date_edittext,
                        AppConstants.YYYY_MM_DD_FORMAT_API,
                        isPast = false,
                        isFuture = true
                    )
            })

//      open picker for end date selection
        mViewModel.endDatePickerObserver.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                if (selectableDate.isNotEmpty()) {
                    if (it)
                        getFutureDate(
                            pick_end_date_edittext,
                            AppConstants.YYYY_MM_DD_FORMAT_API,
                            isPast = false
                        )
                } else {
                    requireActivity().makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_select_tournament_date)
                    )
                }
            })

//      open picker for time selection
        mViewModel.timePickerObserver.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                if (selectableDate.isNotEmpty()) {
                    getValidTime(
                        timePicker,
                        AppConstants.TIME_FORMAT_API,
                        is24HourView = false,
                    )
                } else {
                    requireActivity().makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_select_tournament_date)
                    )
                }
            })

//      check tournament url success responce
        mViewModel.checkUrlSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                debugE("checkUrlSuccessResponse", Gson().toJson(it))
                dismissProgressDialog()
                if (it.totals!!.count == 0) {
                    isTournamentUrlValid = true
                    (requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid = true
                    tvTurnamentUrl.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.tournament_color_title
                        )
                    )
                    //  tvTurnamentUrl.setTextColor(resources.getColor(R.color.join_tournament_green_color))
                    requireActivity().makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_url_is_valid)
                    )
                } else {
                    (requireActivity() as CreateTourmamentActivity).tournamentUrlIsValid = false
                    isTournamentUrlValid = false
//                    tvTurnamentUrl.setTextColor(resources.getColor(R.color.red))
                    tvTurnamentUrl.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.red
                        )
                    )
                    requireActivity().makeSnackBar(
                        container,
                        resources.getString(R.string.tournament_url_error)
                    )
                }
            })

//      check tournament url error responce
        mViewModel.checkUrlErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                debugE("checkUrlErrorResponse", Gson().toJson(it))
                dismissProgressDialog()

            })

//      Upload banner image file success responce
        mViewModel.uploadFileSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                llSelectBanner.beGone()
                imgSelectedBanner.beVisible()
                requireActivity().loadImageFromServer(
                    it.data[0].location,
                    imgSelectedBanner
                )
                imageUrlLocation = it.data[0].location
                isBannerSelected = true
                requireActivity().makeSnackBar(
                    container,
                    it.message
                )
            })

//      Upload banner image file error responce
        mViewModel.uploadFileErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                dismissProgressDialog()
                isBannerSelected = false
                llSelectBanner.beVisible()
                imgSelectedBanner.beGone()
                requireActivity().makeSnackBar(
                    container,
                    "Image upload fail. Please try again."
                )
            })

//      get game list data from api success responce
        mViewModel.gameListSuccessResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {

                debugE("gameListSuccessResponse", Gson().toJson(it))
                pbCreateTournamentStep1.beGone()
                selectGameAdapter.addAll(it.data as MutableList<TournamentGameRes.Datum>)

                if (selectGameAdapter.itemCount > 0) {
                    val item = selectGameAdapter.getItem(0)
                    selectGameAdapter.setSelected(item.id)
                    selectPlatformAdapter.addAll(item.platform as MutableList<TournamentGameRes.Platform>)
                    platformSelectedId = ""
                    selectPlatformAdapter.clearSelection()
                    setBracketFromGameList(item)
                    refreshPlatformPlaceHolder()
                }

                if (it.data.isNotEmpty()) {
                    rvGameList.beVisible()
                    constraintLayoutNoInternet.beGone()
                } else {
                    llPlaceHolderNoData.beVisible()
                    constraintLayoutNoInternet.beGone()
                    rvGameList.beGone()
                }
                dismissProgressDialog()

                if ((requireActivity() as CreateTourmamentActivity).isForEdit) {
                    fillEditData()
                } else {
                    val createTournamentSaved: CreateTournament? =
                        sharedPreferences.get<CreateTournament>("createTournamentSave")

                    if (createTournamentSaved != null) {
                        requireActivity().displayAlertDialog(cancelable = false,
                            desc = resources.getString(R.string.loadit_from_local_desc),
                            positiveText = resources.getString(R.string.loadit_from_saved_draft),
                            negativeText = resources.getString(R.string.loadit_from_create_new),
                            negativeClick = DialogInterface.OnClickListener { dialog, _ ->
                                dialog?.apply { dismiss() }
                                (requireActivity() as CreateTourmamentActivity).createTournamentSave =
                                    CreateTournament()
                                sharedPreferences.clearPreference("createTournamentSave")
                            },
                            positiveClick = DialogInterface.OnClickListener { dialog, _ ->
                                dialog?.apply {
                                    dismiss()
                                }
                                refreshSaveData()
                            })
                    }
                }
            })

//      get game list data from api error responce
        mViewModel.gameListErrorResponse.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                pbCreateTournamentStep1.beGone()
                dismissProgressDialog()
            })

        mViewModel.llImageUploadObserver.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                launchChooseProfileBottomSheet()
            })

//      check isNextStepFormValid or not
        mViewModel.isNextStepFormValid.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                (activity as CreateTourmamentActivity).createTournamentPager.currentItem = 1
                saveData()
                isAbletoNext = true
            })

//      validation for tournament url is valid or not
        mViewModel.iseditUrlNotEmpty.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                launchProgressDialog()
                val jsonObjectQuery = JsonObject()
                jsonObjectQuery.addProperty("url", tvTurnamentUrl.text.toString().trim())
                if ((requireActivity() as CreateTourmamentActivity).isForEdit) {
                    val jsonObjectNe = JsonObject()
                    jsonObjectNe.addProperty(
                        "\$ne",
                        (requireActivity() as CreateTourmamentActivity).tournamentId
                    )
                    jsonObjectQuery.add("_id", jsonObjectNe)
                }
                debugE("tvTurnamentUrl £", tvTurnamentUrl.text.toString().trim())
                debugE("jsonObjectQuery £", jsonObjectQuery.toString())

                mViewModel.checkUrlValidOrNot(jsonObjectQuery.toString())
            })

//      validationLiveData and show snacbar for incorrect value
        mViewModel.validationLiveData.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                isAbletoNext = false
                when (it) {
                    0 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_name_error)
                        )
                    }
                    1 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_url_error)
                        )
                    }
                    2 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_game_error)
                        )
                    }
                    3 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_type)
                        )
                    }
                    4 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_team_size_error)
                        )
                    }
                    5 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_date)
                        )
                    }
                    6 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_time)
                        )
                    }
                    7 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_bracket)
                        )
                    }
                    8 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_match_formate)
                        )
                    }
                    9 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_stage)
                        )
                    }
                    10 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_next_stage_match_format)
                        )
                    }
                    11 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_paid_registration_type)
                        )
                    }
                    12 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_enter_paid_registration_fees)
                        )
                    }
                    13 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_check_in_start_date)
                        )
                    }
                    14 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_banner)
                        )
                    }
                    15 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_name_error)
                        )
                    }
                    16 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_platform)
                        )
                    }
                    17 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_end_date)
                        )
                    }
                    18 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.please_enter_correct_details_in_batele_royale)
                        )
                    }
                    19 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.please_enter_input_placement_points)
                        )
                    }
                    20 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.please_enter_correct_value_in_max_participants)
                        )
                    }
                    21 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.please_enter_correct_details_in_round_robin)
                        )
                    }
                    22 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_team_format)
                        )
                    }
                    23 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.tournament_select_tournament_next_stage_bracket)
                        )
                    }

                    24 -> {
                        requireActivity().makeSnackBar(
                            container,
                            resources.getString(R.string.sunstitute_team_size_error)
                        )
                    }

                }
            })
    }

    private fun fillEditData() {
        val createTournamentSavedForEdit: CreateTournament = CreateTournament()

        partNumber =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).maxParticipants

        teamPerGroup =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfTeamInGroup

        winningTeamsPerGroup =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfWinningTeamInGroup

        createTournamentSavedForEdit.name =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).name
        createTournamentSavedForEdit.allowAdvanceStage =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).allowAdvanceStage
        createTournamentSavedForEdit.banner =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).banner!!

        createTournamentSavedForEdit.bracketType =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).bracketType!!

        createTournamentSavedForEdit.checkInEndDate =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).checkInEndDate!!

        if ((requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).checkInStartDate != null
        ) {
            createTournamentSavedForEdit.checkInStartDate =
                (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                    0
                ).checkInStartDate!!.convertDateToRequireDateFormat(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.DATE_AND_TIME
                )
        }

        createTournamentSavedForEdit.endDate =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).endDate!!.convertDateToRequireDateFormat(
                AppConstants.API_DATE_FORMAT,
                AppConstants.YYYY_MM_DD_FORMAT_API
            )

        createTournamentSavedForEdit.startDate =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).startDate!!.convertDateToRequireDateFormat(
                AppConstants.API_DATE_FORMAT,
                AppConstants.YYYY_MM_DD_FORMAT_API
            )

        createTournamentSavedForEdit.startTime =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).startTime!!

        createTournamentSavedForEdit.contactDetails =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).contactDetails!!

        createTournamentSavedForEdit.contactOn =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).contactOn!!

        createTournamentSavedForEdit.createdBy =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).createdBy!!

        createTournamentSavedForEdit.criticalRules =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).criticalRules!!

        createTournamentSavedForEdit.description =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).description!!

        createTournamentSavedForEdit.facebookVideoLink =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).facebookVideoLink!!

        createTournamentSavedForEdit.twitchVideoLink =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).twitchVideoLink!!

        createTournamentSavedForEdit.youtubeVideoLink =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).youtubeVideoLink!!

        createTournamentSavedForEdit.invitationLink =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).invitationLink!!

        createTournamentSavedForEdit.faqs =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).faqs!!

        createTournamentSavedForEdit.gameDetail =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.id!!

        val bracketTypesForEdit = TournamentGameRes.BracketTypes()

        bracketTypesForEdit._double =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.bracketTypes!!._double

        bracketTypesForEdit.roundRobin =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.bracketTypes!!.roundRobin

        bracketTypesForEdit.battleRoyale =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.bracketTypes!!.battleRoyale

        bracketTypesForEdit.simple =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.bracketTypes!!.simple

        bracketTypesForEdit.single =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.bracketTypes!!.single

        val gameItemForEdit = TournamentGameRes.Datum()

        gameItemForEdit.bracketTypes = bracketTypesForEdit

        gameItemForEdit.id =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.id!!

        gameItemForEdit.activeTournament =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.activeTournament

        gameItemForEdit.createdOn =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.createdOn

        gameItemForEdit.image =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.image!!

        gameItemForEdit.isTournamentAllowed =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.isTournamentAllowed

        gameItemForEdit.logo =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.logo

        gameItemForEdit.name =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.name

        gameItemForEdit.order =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.order

        createTournamentSavedForEdit.gameItem = gameItemForEdit

        createTournamentSavedForEdit.gameLogo =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.logo!!

        if (!(requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).checkInStartDate.isNullOrEmpty()
        ) {
            createTournamentSavedForEdit.isCheckInRequired = true
        }

        createTournamentSavedForEdit.isIncludeSponsor =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isIncludeSponsor

        createTournamentSavedForEdit.isKillPointRequired =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isKillPointRequired

        createTournamentSavedForEdit.participants =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).participants

        createTournamentSavedForEdit.sponsors =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).sponsors

        createTournamentSavedForEdit.regionsAllowed =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).regionsAllowed

        createTournamentSavedForEdit.gameName =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).gameDetail!!.name!!

        createTournamentSavedForEdit.bracketType =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).bracketType!!

        createTournamentSavedForEdit.isPaid =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isPaid

        createTournamentSavedForEdit.isPrize =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isPrize

        createTournamentSavedForEdit.isParticipantsLimit =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isParticipantsLimit

        createTournamentSavedForEdit.isScreenshotRequired =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isScreenshotRequired

        createTournamentSavedForEdit.isShowCountryFlag =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isShowCountryFlag

        createTournamentSavedForEdit.isSpecifyAllowedRegions =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).isSpecifyAllowedRegions

        createTournamentSavedForEdit.isallowSubstituteMember =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).allowSubstituteMember

        createTournamentSavedForEdit.maxParticipants =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).maxParticipants

        createTournamentSavedForEdit.name =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).name

        try {
            createTournamentSavedForEdit.nextStageMatchFormat =
                (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                    0
                ).stageBracketType.toInt()
        } catch (e: Exception) {
        }

        createTournamentSavedForEdit.noOfPlacement =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfPlacement

        createTournamentSavedForEdit.noOfRoundPerStage =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfRoundPerGroup


        createTournamentSavedForEdit.noOfTeamInGroup =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfTeamInGroup

        createTournamentSavedForEdit.noOfWinningTeamInGroup =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfWinningTeamInGroup

        createTournamentSavedForEdit.noOfRoundRR =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfRoundPerGroup

        createTournamentSavedForEdit.noOfSet =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).noOfSet

        createTournamentSavedForEdit.participantType =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).participantType!!

        createTournamentSavedForEdit.platform =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).platform!!

        createTournamentSavedForEdit.prizeCurrency =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).prizeCurrency!!

        createTournamentSavedForEdit.prizeList =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).prizeList

        createTournamentSavedForEdit.rules =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).rules!!

        createTournamentSavedForEdit.schedule =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).schedule!!

        createTournamentSavedForEdit.slug =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).slug!!

        createTournamentSavedForEdit.scoreReporting =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).scoreReporting

        createTournamentSavedForEdit.substituteMemberSize =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).substituteMemberSize

        createTournamentSavedForEdit.teamSize =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).teamSize

        createTournamentSavedForEdit.tournamentType =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).tournamentType!!

        createTournamentSavedForEdit.tournnamentStage =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).stageMatch

        createTournamentSavedForEdit.updatedBy =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).updatedBy!!

        createTournamentSavedForEdit.url =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).url!!

        createTournamentSavedForEdit.venueAddress =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).venueAddress

        createTournamentSavedForEdit.visibility =
            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
                0
            ).visibility

//        createTournamentSavedForEdit.noOfStages =
//            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
//                0
//            ).totalStage

//        createTournamentSavedForEdit.pointPerKill =
//            (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
//                0
//            ).kills

        val placementPointList: MutableList<AddPlacementPoint> = ArrayList()

        (requireActivity() as CreateTourmamentActivity).singleTournamentModel.data.get(
            0
        ).placementPoints.forEach {
            val addPlacementPoint = AddPlacementPoint(it.position!!, it.value!!)
            placementPointList.add(addPlacementPoint)
        }

        createTournamentSavedForEdit.placementPointList = placementPointList

        (requireActivity() as CreateTourmamentActivity).createTournamentSave =
            createTournamentSavedForEdit

        sharedPreferences.put(
            "createTournamentSave",
            (requireActivity() as CreateTourmamentActivity).createTournamentSave
        )

        refreshSaveData()
    }

    private fun refreshPlatformPlaceHolder() {
        if (rvPlatFormList.adapter!!.itemCount > 0) {
            llPlaceHolderNoPlatformData.beGone()
            rvPlatFormList.beVisible()
        } else {
            llPlaceHolderNoPlatformData.beVisible()
            rvPlatFormList.beGone()
        }
    }

    /**
     * @desc this method is used for check validation is valid for next step or not
     */
    fun isAbleToNext() {

        var battelRoyaleError: Boolean = false
        var roundRobinError: Boolean = false

        val boolBRList: MutableList<Boolean> = ArrayList()

        boolBRList.add(maxPartError)
        boolBRList.add(noOfTeamsPerGroupError)
        boolBRList.add(winningTeamPerGroupError)
        boolBRList.add(numberOfRoundPerStageError)
        boolBRList.add(numberOfPlacementError)
        boolBRList.add(pointPerKillError)
        boolBRList.add(teamPerGroupWinningDivisibleError)

        for (i in boolBRList) {
            if (i) {
                battelRoyaleError = true
                break
            }
        }


        val boolBBList: MutableList<Boolean> = ArrayList()
        boolBBList.add(maxPartError)
        boolBBList.add(noOfTeamsPerGroupError)
        boolBBList.add(winningTeamPerGroupError)
        boolBBList.add(noOfRoundRoundRobinError)
        boolBBList.add(teamPerGroupWinningDivisibleError)

        for (i in boolBBList) {
            if (i) {
                roundRobinError = true
                break
            }
        }

        mViewModel.onValidationForNextStep(
            editTournamentName.text.toString().trim(),
            isTournamentUrlValid,
            selectGameAdapter.isSelectedAtleastOne(), platformSelectedId,
            tournamentTypeLocal, tournamentTeamFormat, tournamentTeamSize,
            substitute_switch.isChecked, tournamentSubstituteTeamSize,
            pick_date_edittext.text.toString().trim(),
            timePicker.text.toString().trim(), pick_end_date_edittext.text.toString().trim(),
            bracketSelectionTxt,
            nextStagebracketSelectionTxt,
            matchFormatType,
            selectedStage,
            selectedNextStageFormate,
            switchAdvanceStage.isChecked,
            paid_switch.isChecked,
            paidRegType,
            add_fee_edittext.text.toString().trim(),
            check_in_switch.isChecked,
            checkinStrtDate!!,
            battelRoyaleError,
            roundRobinError,
            addPlacementPointAdapter.isValidated(), maxPartError
        )
    }

    /**
     * @desc this method is used for save data to local when click on next step.
     */
    fun saveData() {
        val createTournamentSaved: CreateTournament? =
            sharedPreferences.get<CreateTournament>("createTournamentSave")

        if (createTournamentSaved != null) {
            (requireActivity() as CreateTourmamentActivity).createTournamentSave =
                createTournamentSaved
        }

        (requireActivity() as CreateTourmamentActivity).createTournamentSave.apply {
            this.name = editTournamentName.text.toString().trim()
            this.url = tvTurnamentUrl.text.toString().trim()
            if (tournamentTypeLocal.equals("Team", true)) {
                this.participantType = "team"
            } else {
                this.participantType = "individual"
            }

            this.teamFormat = tournamentTeamFormat!!
            this.startDate = pick_date_edittext.text.toString().trim()
            this.endDate = pick_end_date_edittext.text.toString().trim()
            this.startTime = timePicker.text.toString().trim()
            if (bracketSelectionTxt.equals("single", false)) {
                this.bracketType = "single"
            } else if (bracketSelectionTxt.equals("double", false)) {
                this.bracketType = "double"
            } else if (bracketSelectionTxt.equals("round_robin", false)) {
                this.bracketType = "round_robin"
            } else if (bracketSelectionTxt.equals("battle_royale", false)) {
                this.bracketType = "battle_royale"
            }

            if (nextStagebracketSelectionTxt.equals("single", false)) {
                this.nextStageBracketType = "single"
            } else if (nextStagebracketSelectionTxt.equals("double", false)) {
                this.nextStageBracketType = "double"
            }


            this.isPaid = paid_switch.isChecked
            this.regFeeCurrency = paidRegType
            this.regFee = add_fee_edittext.text.toString().trim()
            this.teamSize = tournamentTeamSize
            if (!selectGameAdapter.getSelecedGameId().isFieldEmpty()) {
                this.gameDetail = selectGameAdapter.getSelecedGameId()
                this.gameName = selectGameAdapter.getSelecedGameName()
                this.gameLogo = selectGameAdapter.getSelecedGameLogo()
                this.gameItem = selectGameAdapter.getSelecedGameItem()
            }
            this.isCheckInRequired = check_in_switch.isChecked
            this.checkInStartDate = checkinStrtDate!!
            if (!imageUrlLocation.isFieldEmpty()) {
                this.banner = imageUrlLocation
            }
            if (!matchFormatType.isFieldEmpty()) {
                this.noOfSet = matchFormatType.toInt()
            }
            this.noOfPlacement = placementPointsNumber
            this.maxParticipants = partNumber
            this.noOfTeamInGroup = teamPerGroup
            this.noOfWinningTeamInGroup = winningTeamsPerGroup
            this.noOfRoundPerStage = roundPerStage
            this.noOfStages = editBrStageNumber.text.toString().toInt()
            this.noOfRoundRR = noOfRoundLocal

            this.isKillPointRequired = switchTieBreakerPoints.isChecked
            this.pointPerKill = pointsPerKill

            this.allowAdvanceStage = switchAdvanceStage.isChecked

            if (!addPlacementPointAdapter.getAll().isEmpty()) {
                this.placementPointList = addPlacementPointAdapter.getAll()
            }
            this.tournnamentStage = selectedStage
            if (!selectedNextStageFormate.isFieldEmpty()) {
                this.nextStageMatchFormat = selectedNextStageFormate.toInt()
            }
            this.platform = platformSelectedId

            this.isallowSubstituteMember = substitute_switch.isChecked
            if (this.isallowSubstituteMember)
                this.substituteMemberSize = editTournamamentSubstituteNumber.text.toString().toInt()
            else
                this.substituteMemberSize = 0

        }

        sharedPreferences.put(
            "createTournamentSave",
            (requireActivity() as CreateTourmamentActivity).createTournamentSave
        )
    }

    /**
     * @desc this method is used for get data from local and if local data is available then set values in fields
     */
    private fun refreshSaveData() {
        try {
            val createTournamentSaved: CreateTournament? =
                sharedPreferences.get<CreateTournament>("createTournamentSave")

            if (createTournamentSaved == null) {
                return
            }

            createTournamentSaved.apply {
                editTournamentName.setText(this.name)
                pick_date_edittext.setText(this.startDate)
                selectableDate = this.startDate
                pick_end_date_edittext.setText(this.endDate)
                timePicker.setText(this.startTime)
                check_in_switch.isChecked = this.isCheckInRequired
                paid_switch.isChecked = this.isPaid
                selectGameAdapter.setSelected(this.gameDetail)
                selectPlatformAdapter.addAll(this.gameItem!!.platform as MutableList<TournamentGameRes.Platform>)
                platformSelectedId = this.platform
                selectPlatformAdapter.setSelected(this.platform)
                tvCheckInStart.setText(this.checkInStartDate)
                checkinStrtDate = this.checkInStartDate
                substitute_switch.isChecked = this.isallowSubstituteMember
                editTournamamentSubstituteNumber.setText(this.substituteMemberSize.toString())

                refreshPlatformPlaceHolder()

                tvpaidRegistartionType.setText(this.regFeeCurrency)
                add_fee_edittext.setText(this.regFee)

                paidRegType = this.regFeeCurrency

                if (!this.banner.isFieldEmpty()) {
                    llSelectBanner.beGone()
                    imgSelectedBanner.beVisible()
                    requireActivity().loadImageFromServer(this.banner, imgSelectedBanner)
                }

                if (this.participantType.equals("team", true)) {
                    tournamentTypeLocal = "team"
                    tvTournamentType.setText(resources.getString(R.string.team))
                    tlTeamFormat.beVisible()
                    substitute_switch.beVisible()
                    llsubstituteMemberCount.beGone()
                } else {
                    tournamentTypeLocal = "individual"
                    tvTournamentType.setText(resources.getString(R.string.one_vs_one))
                    tlTeamFormat.beGone()
                    llTournamentTypeNumber.beGone()
                    substitute_switch.beGone()
                    llsubstituteMemberCount.beGone()
                }

                if (substitute_switch.isChecked) {
                    llsubstituteMemberCount.beVisible()
                } else {
                    llsubstituteMemberCount.beGone()
                }

                if (this.teamFormat.equals("dou", true)) {
                    tournamentTeamFormat = "dou"
                    tvTournamentTeamFormat.setText(resources.getString(R.string.dou))
                    llTournamentTypeNumber.beGone()
                } else if (this.teamFormat.equals("squad", true)) {
                    tournamentTeamFormat = "squad"
                    tvTournamentTeamFormat.setText(resources.getString(R.string.squad))
                    llTournamentTypeNumber.beGone()
                } else if (this.teamFormat.equals("xvsx", true)) {
                    tournamentTeamFormat = "xvsx"
                    tvTournamentTeamFormat.setText(resources.getString(R.string.xvsx))
                    if (this.participantType.equals("team", true)) {
                        llTournamentTypeNumber.beVisible()
                    }
                }

                if (this.bracketType.equals("single", true)) {
                    single_bracket.isChecked = true
                    double_bracket.isChecked = false
                    round_robin_bracket.isChecked = false
                    battle_royale_bracket.isChecked = false
                } else if (this.bracketType.equals("double", true)) {
                    single_bracket.isChecked = false
                    double_bracket.isChecked = true
                    round_robin_bracket.isChecked = false
                    battle_royale_bracket.isChecked = false
                } else if (this.bracketType.equals("round_robin", true)) {
                    single_bracket.isChecked = false
                    double_bracket.isChecked = false
                    round_robin_bracket.isChecked = true
                    battle_royale_bracket.isChecked = false
                } else if (this.bracketType.equals("battle_royale", true)) {
                    single_bracket.isChecked = false
                    double_bracket.isChecked = false
                    round_robin_bracket.isChecked = false
                    battle_royale_bracket.isChecked = true
                }

                if (this.nextStageBracketType.equals("single", true)) {
                    nextStageSingleBracket.isChecked = true
                    nextStageDoubleBracket.isChecked = false
                } else if (this.nextStageBracketType.equals("double", true)) {
                    nextStageSingleBracket.isChecked = false
                    nextStageDoubleBracket.isChecked = true
                }

                if (this.teamSize != 0) {
                    editTournamamentNumber.setText("" + this.teamSize)
                }

                if (this.noOfPlacement != 0) {
                    editNumberOfPlacementNumber.setText("" + this.noOfPlacement)
                }

                if (!this.placementPointList.isNullOrEmpty()) {
                    addPlacementPointAdapter.addAll(this.placementPointList)
                }

                if (this.maxParticipants != 0) {
                    tvPartNumber.setText("" + this.maxParticipants)
                }

                if (this.noOfTeamInGroup != 0) {
                    editBrTeanPerGroupNumber.setText("" + this.noOfTeamInGroup)
                }

                if (this.noOfWinningTeamInGroup != 0) {
                    editBrWinningTeamsPerGroupNumber.setText("" + this.noOfWinningTeamInGroup)
                }

                if (this.noOfRoundRR != 0) {
                    editNoOfRoundNumber.setText("" + this.noOfRoundRR)
                }

                if (this.noOfRoundPerStage != 0) {
                    editBrNumberOfMatchesPerStageNumber.setText("" + this.noOfRoundPerStage)
                }

                if (this.noOfStages != 0) {
                    editBrStageNumber.text = "" + this.noOfStages
                }

                if (this.isKillPointRequired) {
                    switchTieBreakerPoints.isChecked = true
                }

                if (this.pointPerKill != 0) {
                    editPointPerKillNumber.setText("" + this.pointPerKill)
                }

                if (this.noOfSet == 1) {
                    tvMatchFormateType.setText(resources.getString(R.string.best_of_1))
                    matchFormatType = "1"
                } else if (this.noOfSet == 3) {
                    tvMatchFormateType.setText(resources.getString(R.string.best_of_3))
                    matchFormatType = "3"
                } else if (this.noOfSet == 5) {
                    tvMatchFormateType.setText(resources.getString(R.string.best_of_5))
                    matchFormatType = "5"
                } else if (this.noOfSet == 7) {
                    tvMatchFormateType.setText(resources.getString(R.string.best_of_7))
                    matchFormatType = "7"
                }

                if (this.nextStageMatchFormat == 1) {
                    tvSelectStageMatchFormats.setText(resources.getString(R.string.best_of_1))
                    selectedNextStageFormate = "1"
                } else if (this.nextStageMatchFormat == 3) {
                    tvSelectStageMatchFormats.setText(resources.getString(R.string.best_of_3))
                    selectedNextStageFormate = "3"
                } else if (this.nextStageMatchFormat == 5) {
                    tvSelectStageMatchFormats.setText(resources.getString(R.string.best_of_5))
                    selectedNextStageFormate = "5"
                } else if (this.nextStageMatchFormat == 7) {
                    tvSelectStageMatchFormats.setText(resources.getString(R.string.best_of_7))
                    selectedNextStageFormate = "7"
                }

                if (this.tournnamentStage.equals("1")) {
                    tvSelectStage.setText(resources.getString(R.string.final_stage))
                    selectedStage = "1"
                } else if (this.tournnamentStage.equals("2")) {
                    tvSelectStage.setText(resources.getString(R.string.quarter_stage))
                    selectedStage = "2"
                } else if (this.tournnamentStage.equals("3")) {
                    tvSelectStage.setText(resources.getString(R.string.semi_final_stage))
                    selectedStage = "3"
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * @desc Get file url from gallery and camera using intent and encoded to base64 string
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == AppConstants.TAKE_PHOTO) {
                mSelectedCameraImage?.apply {
//                    if (data != null && data.hasExtra("forWhat")) {
//                        data.getStringExtra("forWhat").showToast(requireContext())
//                    }
                    val fileArray = JsonArray()
                    fileArray.add(this.encoder())
                    val jsonObject = JsonObject()
                    jsonObject.addProperty("path", "tournament")
                    jsonObject.add("files", fileArray)

                    launchProgressDialog()
                    mViewModel.uploadFiles(jsonObject)
                }

            } else if (requestCode == AppConstants.IMAGE_CODE) {
                if (data == null)
                    return

                data.data?.apply {
                    mSelectedCameraImage = requireActivity().uriToImageFile(this)
                    try {
                        mSelectedCameraImage?.apply {
                            val fileArray = JsonArray()
                            fileArray.add(this.encoder())
                            val jsonObject = JsonObject()
                            jsonObject.addProperty("path", "tournament")
                            jsonObject.add("files", fileArray)
                            launchProgressDialog()
                            mViewModel.uploadFiles(jsonObject)
                        }
                    } catch (e: Exception) {
                        "Something went wrong".showToast(requireContext())
                    }
                }
            }
        }
    }

    /**
     * @desc this method is used for onRequestPermissionsResult
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    /**
     * @desc this method is used for onPermissionsDenied
     */
    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            AppSettingsDialog.Builder(this).build().show()
        }
    }

    /**
     * @desc if permission granted from user when open gallery or camera for choose image
     */
    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
        if (requestCode == AppConstants.PERMISSION_CODE) {
            if (pos == 0) {
                chooseCamera(path = ::cameraPath)
            } else {
                chooseGallery()
            }
        }
    }

    /**
     * @desc temp camera file store in global file variable
     * @param file - temporary camera file
     */
    private fun cameraPath(file: File) {
        mSelectedCameraImage = file
    }

    /**
     * @desc this method will use choose media option(camera or gallery)
     * Display option inside bottom sheet
     */
    private fun launchChooseProfileBottomSheet() {
        bottomSheetDialogChooseMedia = BottomSheetDialog(requireContext())
        val viewChooseMedia = layoutInflater.inflate(R.layout.bottom_sheet_choose_option, null)
        bottomSheetDialogChooseMedia.setContentView(viewChooseMedia)
        val recyclerViewChooseMedia =
            viewChooseMedia.findViewById(R.id.recyclerViewChooseMedia) as RecyclerView
        recyclerViewChooseMedia.layoutManager = LinearLayoutManager(requireContext())
        val chooseMediaAdapter = ChooseMediaAdapter(
            resources.getStringArray(R.array.media_option),
            onChooseMediaClick = {
                pos = it
                when (it) {
                    0 -> {
                        chooseCamera(path = ::cameraPath)
                    }
                    1 -> {
                        chooseGallery()
                    }
                    else -> bottomSheetDialogChooseMedia.dismiss()
                }
                bottomSheetDialogChooseMedia.dismiss()
            }
        )
        recyclerViewChooseMedia.adapter = chooseMediaAdapter

        bottomSheetDialogChooseMedia.show()
    }

    /**
     * @desc launch camera for take image with check camera permission
     * Get file using file provide
     * @param path = temporary camera file
     *
     */
    private fun chooseCamera(path: (File) -> Unit = { _ -> }) {
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                // Ensure that there's a camera activity to handle the intent
                takePictureIntent.resolveActivity(requireContext().packageManager)?.also {
                    // Create the File where the photo should go
                    val photoFile: File? = try {
                        createImageFile()
                    } catch (ex: IOException) {
                        null
                    }
                    // Continue only if the File was successfully created
                    photoFile?.also {
                        path(photoFile)
                        val photoURI: Uri = FileProvider.getUriForFile(
                            requireContext(),
                            requireContext().packageName.plus(".provider"),
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        takePictureIntent.putExtra("forWhat", "banner")
                        startActivityForResult(
                            takePictureIntent,
                            AppConstants.TAKE_PHOTO
                        )
                    }
                }
            }
        } else {
            EasyPermissions.requestPermissions(
                this,
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    /**
     * @desc method will use create temporary file in local storage
     */
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File =
            requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        )
    }

    /**
     * @desc method will use launch gallery for choose profile
     */
    private fun chooseGallery() {
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            val pickIntent = Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            )
            pickIntent.type = "image/*"
            startActivityForResult(
                pickIntent, AppConstants.IMAGE_CODE
            )
        } else {
            EasyPermissions.requestPermissions(
                requireActivity(),
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    val runnableTeamUrlName = Runnable {
        if (editTournamentName.text.toString().trim({ it <= ' ' }).isEmpty()) {
            isTournamentUrlValid = false
        } else {
//            launchProgressDialog()
            val jsonObjectQuery = JsonObject()
            jsonObjectQuery.addProperty("url", tvTurnamentUrl.text.toString().trim())
            if ((requireActivity() as CreateTourmamentActivity).isForEdit) {
                val jsonObjectNe = JsonObject()
                jsonObjectNe.addProperty(
                    "\$ne",
                    (requireActivity() as CreateTourmamentActivity).tournamentId
                )
                jsonObjectQuery.add("_id", jsonObjectNe)
            }
            debugE("tvTurnamentUrl £", tvTurnamentUrl.text.toString().trim())
            debugE("jsonObjectQuery £", jsonObjectQuery.toString())
            mViewModel.checkUrlValidOrNot(jsonObjectQuery.toString())
        }
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     *       call api for get game list data
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && selectGameAdapter.getAll().isNullOrEmpty()) {
            constraintLayoutNoInternet.beGone()
            constraintLayoutNoInternet.beGone()
            llPlaceHolderNoData.beGone()
            pbCreateTournamentStep1.beVisible()
            rvGameList.beGone()
            mViewModel.getGameList()
        } else if (selectGameAdapter.getAll().isNullOrEmpty()) {
            rvGameList.beGone()
            llPlaceHolderNoData.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnableTeamUrlName)
        mViewModel.onDetach()
    }


    fun getDate(
        textViewDate: TextView,
        format: String,
        isPast: Boolean = false,
        isFuture: Boolean = false
    ) {
        val cal = Calendar.getInstance()
        val dateSetListener =
            DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                val simpleDateFormat = SimpleDateFormat(format, Locale.ROOT)
                textViewDate.text = simpleDateFormat.format(cal.time)
                selectableDate = simpleDateFormat.format(cal.time)
                pick_end_date_edittext.setText("")
//                selectableDate.showToast(requireContext())
            }
        textViewDate.click {
            val dialog = DatePickerDialog(
                requireContext(), dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )
            if (isFuture) {
                dialog.datePicker.minDate = System.currentTimeMillis() - 1000
            }
            if (isPast) {
                dialog.datePicker.maxDate = System.currentTimeMillis()
            }
            dialog.show()
        }
    }

    fun getFutureDate(
        textViewDate: TextView,
        format: String,
        isPast: Boolean = false
    ) {
        val cal = Calendar.getInstance()
        val dateSetListener =
            DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                val simpleDateFormat = SimpleDateFormat(format, Locale.ROOT)
                textViewDate.text = simpleDateFormat.format(cal.time)
//                selectableDate = simpleDateFormat.format(cal.time)
//                selectableDate.showToast(requireContext())
            }
        textViewDate.click {
            val dialog = DatePickerDialog(
                requireContext(), dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )


//            if (isFuture) {
            dialog.datePicker.minDate =
                parseTime(
                    selectableDate,
                    AppConstants.YYYY_MM_DD_FORMAT_API
                ).time + (1000 * 60 * 60 * 24)
//            }
            if (isPast) {
                dialog.datePicker.maxDate = System.currentTimeMillis()
            }
            dialog.show()
        }
    }

    fun getValidTime(
        textViewTime: TextView,
        format: String,
        is24HourView: Boolean = false,
    ) {
        val cal = Calendar.getInstance()
        val timeSetListener = TimePickerDialog.OnTimeSetListener { _, hour, minute ->
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)

            val date = parseTime(
                selectableDate + SimpleDateFormat(format, Locale.ROOT).format(cal.time),
                AppConstants.YYYY_MM_DD_FORMAT_API + AppConstants.TIME_FORMAT_API
            )


            val sdf = SimpleDateFormat("yyyy:MM:dd:HH:mm", Locale.ROOT)
            val currentDateandTime = sdf.format(Date())

            val dateOne = sdf.parse(currentDateandTime)
            val calendar = Calendar.getInstance()
            calendar.time = dateOne
            calendar.add(Calendar.HOUR, 1)

//            System.out.println("Time here " + calendar.time)

//            val oneHourAddedDate = Date()
//            oneHourAddedDate.time = System.currentTimeMillis() + 60 * 60 * 1000

            if (date.before(calendar.time)) {
                resources.getString(R.string.start_time_should_be_1_hour)
                    .showToast(requireContext())
                textViewTime.text = ""
            } else {
                textViewTime.text = SimpleDateFormat(format, Locale.ROOT).format(cal.time)
            }
//        date.convertDateToRequireDateFormat(
//            AppConstants.API_DATE_FORMAT,
//            AppConstants.REQUIRED_TIME_FORMAT
//        )
        }
        textViewTime.click {
            TimePickerDialog(
                requireContext(),
                R.style.MyDatePickerDialogTheme,
                timeSetListener,
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                is24HourView
            ).show()
        }
    }
}