package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.models.VerifyRequest
import com.dynasty.esports.models.VerifyResponse
import com.dynasty.esports.retrofit.RestInterface
import com.dynasty.esports.utils.Validator
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody

class ForgotPasswordMobileFragmentViewModel  constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val redirectEmailForgotPasswordObserver = MutableLiveData<Boolean>()
    val emailPhoneNotEmptyObserver = MutableLiveData<Boolean>()
    val confirmPasswordObserver = MutableLiveData<Boolean>()
    val phoneOrEmailVerificationSuccessResponse = MutableLiveData<ResponseBody>()
    val phoneOrEmailVerificationErrorResponse = MutableLiveData<ResponseBody>()
    val countryCodeObserver = MutableLiveData<Boolean>()
    val forgotPasswordResendOTPSuccessResponse = MutableLiveData<ResponseBody>()
    val forgotPasswordResendOTPErrorResponse = MutableLiveData<ResponseBody>()

    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()


    fun redirectEmailForgotPassword(){
        redirectEmailForgotPasswordObserver.postValue(true)
    }

/*
    fun checkPasswordNConfirmPassword(){
        confirmPasswordObserver.postValue(true)
    }
*/


    fun checkPasswordNConfirmPassword(password: String, confirmPass: String) {
        when {
            password.isFieldEmpty() -> validationLiveData.postValue(0)
            confirmPass.isFieldEmpty() -> validationLiveData.postValue(1)
            !Validator.isValidPassword(password) -> validationLiveData.postValue(2)
            !Validator.isValidPassword(confirmPass) -> validationLiveData.postValue(3)
            !Validator.isEquall(password,confirmPass) -> validationLiveData.postValue(4)
            else -> isFormValid.postValue(true)
        }
    }


    fun emailNPhonNotEmpty(){
        emailPhoneNotEmptyObserver.postValue(true)
    }

    fun emailOrMobileNosVerification(verifyRequest: ForgotPasswordRequest) {
        viewModelScope.launch(apiException("otp")+Dispatchers.Main) {
            val response = restInterface.emailPhoneerfication(verifyRequest)
            withContext(Dispatchers.Main) {
                when (response.code()) {
                    AppConstants.API_SUCCESS_CODE -> {
                        phoneOrEmailVerificationSuccessResponse.postValue(response.body())
                    }
                    else -> {
                        phoneOrEmailVerificationErrorResponse.postValue(response.errorBody())
                    }
                }
            }
        }

    }

    fun resetPasswordREsendOtp(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.resendOtp(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    forgotPasswordResendOTPSuccessResponse.postValue(response.body())
                }
                else -> {
                    forgotPasswordResendOTPErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun countryCodeClick(){
        countryCodeObserver.postValue(true)
    }

    fun onDetach() {
        viewModelScope.cancel()
    }

}