package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class PhoneVerificationRequest(
    @field: SerializedName("id")
    var id : String? = null,

    @field:SerializedName("phoneNumber")
    var phoneNo:String?= null,

    @field:SerializedName("type")
    var type:String?= null
)