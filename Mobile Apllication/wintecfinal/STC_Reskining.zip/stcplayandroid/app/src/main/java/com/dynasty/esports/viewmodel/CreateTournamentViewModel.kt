package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.CheckUrlRes
import com.dynasty.esports.models.SingleTournamentModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class CreateTournamentViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val btnNextClickObserver = MutableLiveData<Boolean>()
    val btnPrevClickObserver = MutableLiveData<Boolean>()

    val singleTournamentSuccessResponse = MutableLiveData<SingleTournamentModel>()
    val singleTournamentErrorResponse = MutableLiveData<ResponseBody>()

    fun btnNextClick() {
        btnNextClickObserver.postValue(true)
    }

    fun btnPrevClick() {
        btnPrevClickObserver.postValue(true)
    }

    fun getSingleTournament(id: String) {
        viewModelScope.launch(apiException("SingleTournament") + Dispatchers.Main) {

            val jsonObject = JsonObject()
            jsonObject.addProperty("_id", id)

            val response = restInterface.getSingleTournamentData(jsonObject.toString())

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    singleTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    singleTournamentErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * Clears the [ViewModel] when the [CreateTournament] is not visible to user.
     */

    fun onDetach() {
        viewModelScope.cancel()
    }
}
