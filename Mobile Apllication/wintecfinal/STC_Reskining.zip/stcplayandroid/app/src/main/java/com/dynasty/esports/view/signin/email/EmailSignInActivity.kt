package com.dynasty.esports.view.signin.email

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextPaint
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.text.style.ClickableSpan
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.SignInRequest
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.SocialLoginActivity
import com.dynasty.esports.view.forgot_password.ForgotPasswordMobileActivity
import com.dynasty.esports.view.phone_verification.PhoneNumVerificationActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.signup.email.EmailRegistrationActivity
import com.dynasty.esports.viewmodel.SignInViewModel
import kotlinx.android.synthetic.main.activity_email_sign_in.*
import kotlinx.android.synthetic.main.content_email_signin_screen.*
import kotlinx.android.synthetic.main.content_email_signin_screen.forgot_pssword_btn
import kotlinx.android.synthetic.main.content_email_signin_screen.rememberMe
import kotlinx.android.synthetic.main.content_email_signin_screen.social_login_fb
import kotlinx.android.synthetic.main.content_email_signin_screen.social_login_gPlus
import kotlinx.android.synthetic.main.content_email_signin_screen.social_login_twitter
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class EmailSignInActivity : SocialLoginActivity() {

    private val mViewModel: SignInViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_email_sign_in)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        initialise()
        listenToViewModel()
    }


//    fun registerFCMToken(){
//        // code here will register FCMToken
//
//        if(sharedPreferences.FCMToken.isNotEmpty()) {
//            val jsonObject = JsonObject()
//            jsonObject.addProperty("requestType", "register-push-notification")
//            jsonObject.addProperty("platform", "android")
//            jsonObject.addProperty("token", sharedPreferences.FCMToken)
//            mViewModel.registrationPushNotification(jsonObject)
//        }
//    }

//    listen to view model and manage the api
    private fun listenToViewModel() {



        mViewModel.fbLoginObserver.observe(this, Observer {
            fbLogin()
        })
        mViewModel.googleLoginObserver.observe(this, Observer {
            googleLogin()
        })
        mViewModel.redirectPhoneRegistrationObserver.observe(this, Observer {
            startActivityInline<EmailRegistrationActivity>()
        })
        mViewModel.redirectEmailRegistrationObserver.observe(this, Observer {
            startActivityInline<PhoneSignInActivity>()
            /*if (it) {
                finish()
            }*/
        })

        mViewModel.validationLiveData.observe(this, Observer {
            when (it) {
                0 -> {
                    makeSnackBar(
                        constraintLayoutSignEmail,
                        resources.getString(R.string.email_error)
                    )
                }
                1 -> {
                    makeSnackBar(
                        constraintLayoutSignEmail,
                        resources.getString(R.string.email_valid_error)
                    )
                }
                2 -> {
                    makeSnackBar(
                        constraintLayoutSignEmail,
                        resources.getString(R.string.mobile_number_error)
                    )
                }
            }
        })

        mViewModel.isLoginFormValid.observe(this, Observer {
            launchProgressDialog()
            val signInRequest = SignInRequest()
            signInRequest.email = signin_email.text.toString().trim()
            signInRequest.password = signin_password.text.toString().trim()
            signInRequest.type = "email"
            mViewModel.callPhoneOrEmailLoginAPI(signInRequest)
        })

        /*If user registers through social login or through email registration
        * user will receive this error code  : ER1001
        * Redirect it to Num verification screen*/
        mViewModel.loginSuccessResponse.observe(this, Observer {
            sharedPreferences.refreshToken=it.first
            if (rememberMe.isChecked) {
                sharedPreferences.isLogin = rememberMe.isChecked
            }
            if(it.second.code == "ER1001"){
                sharedPreferences.isLogin = false
                val bundle=Bundle()
                bundle.putString("type","login")
                bundle.putString("id",it.second.data.id)
                bundle.putBoolean("isEmail", true)
                startActivityInlineWithFinishAll<PhoneNumVerificationActivity>(bundle)
            }else{
                sharedPreferences.refreshToken=it.first
                sharedPreferences.accessToken = it.second.data.token
                registerFCMToken()
                commonViewModel.fetchUser()
            }

        })


        mViewModel.loginErrorResponse.observe(this, Observer {
            dismissProgressDialog()
            makeSnackBar(constraintLayoutSignEmail, it)
        })

        commonViewModel.userSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            if(sharedPreferences.id =="null" || sharedPreferences.id=="") {
                it.data?.apply {
                    sharedPreferences.isLoggedIn = true
                    sharedPreferences.id = this.id.toString()
                    sharedPreferences.put("user", this)
//                    startActivityInlineWithFinishAll<DashboardActivity>()
                    redirectToDashBoard(true)
                }
            }
        })

        commonViewModel.userErrorResponse.observe(this, Observer {
            dismissProgressDialog()
        })
    }

    var mTextWatcher: TextWatcher = object : TextWatcher {
        override fun beforeTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun onTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun afterTextChanged(editable: Editable) {
            // check Fields For Empty Values
            checkSignInFieldsForEmptyValues(
                null,
                signin_email,
                signin_password,
                signin_continue,
                isPhoneSignIn
            )
        }
    }

    // to initialise the view
    fun initialise() {
        login_email_privacy.makeSpannableString(
        this, resources.getString(R.string.login_privacy),
        0,
        resources.getString(R.string.login_privacy).length,
        object : ClickableSpan() {
            override fun onClick(widget: View) {
                widget.cancelPendingInputEvents()
                openUrlFromIntent()
            }

            override fun updateDrawState(ds: TextPaint) {
                ds.isUnderlineText = true
            }

        }, true
    )

 /*       signin_email.addTextChangedListener(mTextWatcher);
        signin_password.addTextChangedListener(mTextWatcher);
*/
        // run once to disable if empty
        //checkSignInFieldsForEmptyValues(null, signin_email, signin_password, signin_continue, false);

        signin_password.onRightDrawableClicked {
            if(showPassword){
                showPassword = false
                signin_password.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(baseContext,R.drawable.ic_baseline_visibility_off_24), null)
                signin_password.transformationMethod = PasswordTransformationMethod.getInstance()
            }else{
                showPassword = true
                signin_password.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(baseContext,R.drawable.ic_password_show), null)
                signin_password.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
        }

        emalSigInbottom_view.makeSpannableString(
            this,
            resources.getString(R.string.no_account_txt),
            if(LocaleHelper.getLanguage(this@EmailSignInActivity)=="en"){22}else{23},
            resources.getString(R.string.no_account_txt).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    mViewModel.phoneRegisterClick()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })

        social_login_fb.setOnClickListener {
            mViewModel.fbLoginClick()
        }


        social_login_twitter.setOnClickListener {
            // emailSignInContinue()
        }

        social_login_gPlus.setOnClickListener {
            mViewModel.googleLoginClick()
        }

        signin_phone_num.setOnClickListener {
            mViewModel.emailRegisterClick()
        }

        signin_continue.setOnClickListener {
            mViewModel.onValidationForEmailLogin(
                signin_email.text.toString().trim(),
                signin_password.text.toString().trim()
            )
        }

        forgot_pssword_btn.setOnClickListener {
            startActivityInline<ForgotPasswordMobileActivity>(finish = false)
            // Redirect to Forgot screen
            /* val i = Intent(this@EmailSignInActivity, EmailSignInActivity::class.java)
                 startActivity(i)      */
        }
    }

//    private fun emailSignInContinue() {
////        val emaild: String = emailId.text.toString()
////        val password : String = passwordValue.text.toString()
////        if(!emaild.isEmpty() && !password.isEmpty() ){
//        //API Call
//        //Pass checkbox value in api
//
////        }else{
////            Toast.makeText(this,"Please fill required fields", Toast.LENGTH_LONG).show()
////        }
//    }
//
//    private fun emailLogin(signInRequest: SignInRequest) {
//        // dialogBoxDisplay(true)
////        ApiClient.POST_INSTANCE.signIn(signInRequest)
////            .enqueue(object: Callback<SignInResponse> {
////                override fun onFailure(call: Call<SignInResponse>, t: Throwable) {
////                    dialogBoxDisplay(false)
////                    Log.e("dhaval",t.message)
////                    Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
////                }
////                override fun onResponse(call: Call<SignInResponse>, response: Response<SignInResponse>) {
////                    if(response.body() != null){
////                        if(response.body()?.message.equals("Account verified Successfully")){
////                            Log.d("Phone Signin token : ", response.body()?.data?.token)
////                            if(emailSignInRemember.isChecked){
////                                sharedPreferences.isLogin=emailSignInRemember.isChecked
////                               // sharedPreferences.accessToken=response.body()?.data?.token.toString()
////                            }
////                            sharedPreferences.accessToken=response.body()?.data?.token.toString()
////                            "Redirect to Dashboard screen ".showToast(this@EmailSignInActivity)
////                            val intent = Intent(applicationContext, DashboardActivity::class.java)
////                            intent.putExtra("token", response.body()?.data?.token)
////                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
////                            startActivity(intent)
////                        }else{
////                            if(response.body()?.code.equals("ER1001")){
////                                val intent = Intent(applicationContext, PhoneNumVerificationActivity::class.java)
////                                intent.putExtra("id", response.body()?.data?.id)
////                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
////                                startActivity(intent)
////                            }
////                            Toast.makeText(applicationContext,response.body()?.message,Toast.LENGTH_SHORT).show()
////                        }
////                        dialogBoxDisplay(false)
////                    }else{
////                        val jObjError = JSONObject(response.errorBody()!!.string())
////                        Log.d("Error : ",jObjError.getString("message"))
////                        dialogBoxDisplay(false)
////                        Toast.makeText(applicationContext,jObjError.getString("message"),Toast.LENGTH_SHORT).show()
////                    }
////                }
////            })
//    }

    override fun redirectToDashBoard(isRedirect: Boolean) {
        if (isRedirect){
            sharedPreferences.isLoggedIn = true
            val bundle=Bundle()
            bundle.putString("type",redirectType)
            val intent= Intent(AppConstants.NOTIFY_ACTION)
            intent.putExtras(bundle)
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
            killAllActivities()
        }
    }

    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }
}