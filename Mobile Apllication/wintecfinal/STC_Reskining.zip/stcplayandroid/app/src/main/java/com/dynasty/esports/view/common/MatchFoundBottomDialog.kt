package com.dynasty.esports.view.common


import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.MatchFindModel
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

import kotlinx.android.synthetic.main.custom_match_found_dialog.*


class MatchFoundBottomDialog : BottomSheetDialogFragment() {
    private var data: MatchFindModel.DataModel? = null

    override fun setupDialog(dialog: Dialog, style: Int) {
        val contentView: View = View.inflate(context, R.layout.custom_match_found_dialog, null)
        dialog.setContentView(contentView)
        isCancelable = false
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.custom_match_found_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data?.apply {
            this.profilePicture?.apply {
                requireContext().loadImageFromServer(this, imageViewUser)
            }
            textViewRegion.text=this.state?.let { it.plus(", ").plus(this.country) } ?: ""
            textViewUserName.text=this.fullName?.let { it } ?: ""
        }
        imageViewClose.click {
            dialog?.apply {
                dismiss()
            }
        }
        buttonPositive.click {
            dialog?.apply {
                dismiss()
            }

        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(DialogFragment.STYLE_NO_FRAME, R.style.AppBottomSheetDialogTheme);
        arguments?.apply {
            data = this.getParcelable("data")
        }
    }

    companion object {
        fun newInstance(data: MatchFindModel.DataModel): MatchFoundBottomDialog {
            val args = Bundle()
            args.putParcelable("data", data)
            val fragment = MatchFoundBottomDialog()
            fragment.arguments = args
            return fragment
        }
    }
}