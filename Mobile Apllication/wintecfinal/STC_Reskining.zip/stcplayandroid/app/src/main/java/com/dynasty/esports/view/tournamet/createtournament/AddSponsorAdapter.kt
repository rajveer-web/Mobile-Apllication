package com.dynasty.esports.view.tournamet.createtournament

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AddSponsorListItem2ndBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.AddSponcer

/**
 * @desc this is class will use for add sponsor item
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class AddSponsorAdapter constructor(
    private val onimageSponsorClick: (Int) -> Unit = { _ -> },
    private val onimageSponsorBannerClick: (Int) -> Unit = { _ -> },
    private val onItemRemoveClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<AddSponsorAdapter.MyViewHolder>() {

    class MyViewHolder(val binding: AddSponsorListItem2ndBinding) : RecyclerView.ViewHolder(binding.root)

    private var sponsorList: MutableList<AddSponcer> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val binding: AddSponsorListItem2ndBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.add_sponsor_list_item_2nd,
            parent,
            false
        )
        return MyViewHolder(binding)
    }

    /**
     * @desc sponsorList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return sponsorList.size
    }

    /**
     * @desc add data in ongoingList and notify adapter
     */
    fun addAll(sponcerList: MutableList<AddSponcer>?) {
        this.sponsorList.addAll(sponcerList!!)
        notifyDataSetChanged()
    }

    /**
     * @desc add item in sponsorList and notify adapter
     */
    fun add(item: AddSponcer) {
        sponsorList.add(item)
        notifyDataSetChanged()
    }

    /**
     * @desc remove item in sponsorList and notify adapter
     */
    fun remove(item: AddSponcer) {
        sponsorList.remove(item)
        notifyDataSetChanged()
    }

    /**
     * @desc get single item from position
     */
    fun get(position: Int): AddSponcer {
        return sponsorList[position]
    }

    /**
     * @desc get sponsorlist( main array list)
     */
    fun getAll(): MutableList<AddSponcer> {
        return sponsorList
    }

    /**
     * @desc clear or remove all data from sponsorlist( main array list)
     */
    fun clear() {
        sponsorList.clear()
        notifyDataSetChanged()
    }

    /**
     * @desc check validation in sponsor form
     */
    fun isValidated(): Boolean {
        for (i in sponsorList) {
            when {
                i.sponorName.isEmpty() -> {
                    return false
                }
                i.sponcerLogo.isEmpty() -> {
                    return false
                }
                i.sponcerBanner.isEmpty() -> {
                    return false
                }
            }
        }
        return true
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = sponsorList[position]

        holder.binding.addSponcer = data

//      add static counter in sponsor itemm
        holder.binding.tvSponcerNumber.text =
            holder.itemView.context.resources.getString(R.string.sponcer_name_1).plus(" ").plus(position + 1)

        if (data.sponcerLogo.isNotEmpty()) {
            holder.itemView.context.loadImageFromServer(
                data.sponcerLogo,
                holder.binding.imgSelectedSponcerLogo
            )
            holder.binding.llImgSponcerLogoPlace.beGone()
            holder.binding.imgSelectedSponcerLogo.beVisible()
        }else{
            holder.binding.llImgSponcerLogoPlace.beVisible()
            holder.binding.imgSelectedSponcerLogo.beGone()
        }

        if (data.sponcerBanner.isNotEmpty()) {
            holder.itemView.context.loadImageFromServer(
                data.sponcerBanner,
                holder.binding.imgSelectedSponcerBanner
            )
            holder.binding.llSelectSponcerBanner.beGone()
            holder.binding.imgSelectedSponcerBanner.beVisible()
        }

        holder.binding.imgRemove.click {
            onItemRemoveClick(position)
        }

        holder.binding.llimageSponsor.click {
            onimageSponsorClick(position)
        }

        holder.binding.llSponcerBannerUpload.click {
            onimageSponsorBannerClick(position)
        }
    }

    /**
     * @desc set sponsor image to specific sponsor item
     */
    fun setSponsorImage(imgUrl: String, position: Int) {
        for (indexView in 0 until sponsorList.size) {
            if (indexView == position) {
                sponsorList.get(indexView).sponcerLogo = imgUrl
            }
        }
        notifyDataSetChanged()
    }

    /**
     * @desc set sponsor banner to specific sponsor item
     */
    fun setSponsorBanner(imgUrl: String, position: Int) {
        for (indexView in 0 until sponsorList.size) {
            if (indexView == position) {
                sponsorList.get(indexView).sponcerBanner = imgUrl
            }
        }
        notifyDataSetChanged()
    }
}