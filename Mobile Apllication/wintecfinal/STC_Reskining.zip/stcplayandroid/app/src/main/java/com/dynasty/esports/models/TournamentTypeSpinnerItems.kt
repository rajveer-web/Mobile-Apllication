package com.dynasty.esports.models

import android.graphics.drawable.Drawable


data class TournamentTypeSpinnerItems (
    var text: String
)