package com.dynasty.esports.models

import com.bignerdranch.expandablerecyclerview.model.Parent
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class LeaderboardByGameModel {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("messageCode")
    @Expose
    var messageCode: String? = null

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: Data? = null

    class Data {
        @SerializedName("docs")
        @Expose
        var docs: List<Doc> = ArrayList<Doc>()

        @SerializedName("totalDocs")
        @Expose
        var totalDocs = 0

        @SerializedName("totalPages")
        @Expose
        var totalPages = 0

        @SerializedName("hasNextPage")
        @Expose
        var hasNextPage = false

        @SerializedName("hasPrevPage")
        @Expose
        var hasPrevPage = false

        @SerializedName("limit")
        @Expose
        var limit = 0

        @SerializedName("page")
        @Expose
        var page = 0

        @SerializedName("pagingCounter")
        @Expose
        var pagingCounter = 0

        @SerializedName("nextPage")
        @Expose
        var nextPage: Any? = null

        @SerializedName("prevPage")
        @Expose
        var prevPage: Any? = null
    }

    class Doc : Parent<DocChild> {
        @SerializedName("_id")
        @Expose
        var id: Id? = null

        @SerializedName("points")
        @Expose
        var points = ""

        @SerializedName("gamesCount")
        @Expose
        var gamesCount = ""

        @SerializedName("amountPrice")
        @Expose
        var amountPrice = ""

        @SerializedName("firstPosition")
        @Expose
        var firstPosition = ""

        @SerializedName("secondPosition")
        @Expose
        var secondPosition = ""

        @SerializedName("thirdPosition")
        @Expose
        var thirdPosition = ""

        @SerializedName("user")
        @Expose
        var user: List<User> = ArrayList()

        var leaderboardDataChild: ArrayList<DocChild> = ArrayList<DocChild>()

        override fun getChildList(): MutableList<DocChild> {
            return  leaderboardDataChild
        }

        override fun isInitiallyExpanded(): Boolean {
            return false
        }
    }

    class DocChild {
        @SerializedName("_id")
        @Expose
        var id: Id? = null

        @SerializedName("points")
        @Expose
        var points = ""

        @SerializedName("gamesCount")
        @Expose
        var gamesCount = ""

        @SerializedName("amountPrice")
        @Expose
        var amountPrice = ""

        @SerializedName("firstPosition")
        @Expose
        var firstPosition = ""

        @SerializedName("secondPosition")
        @Expose
        var secondPosition = ""

        @SerializedName("thirdPosition")
        @Expose
        var thirdPosition = ""

        @SerializedName("user")
        @Expose
        var user: List<User> = ArrayList()
    }

    class Id {
        @SerializedName("user")
        @Expose
        var user: String? = null
    }

    class User {
        @SerializedName("fullName")
        @Expose
        var fullName: String? = null

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String? = null

        @SerializedName("country")
        @Expose
        var country: String? = null

        @SerializedName("state")
        @Expose
        var state: String? = null
    }

}