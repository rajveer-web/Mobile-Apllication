package com.dynasty.esports.view.search

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CustomSearchFilterModel
import com.dynasty.esports.models.CustomSearchResultModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.models.TournamentSearchResultModel
import com.dynasty.esports.view.article.article_detail.ArticlesDetailActivity
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.viewmodel.SearchViewModel
import kotlinx.android.synthetic.main.activity_search.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*

/**
 * @desc this class will show search result, Filter result
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 13-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class SearchActivity : BaseActivity() {
    private val mViewModel: SearchViewModel by viewModel()
    private lateinit var searchOptionAdapter: SearchOptionAdapter
    private lateinit var searchFilterOptionAdapter: SearchFilterOptionAdapter
    private var gameList:MutableList<TournamentGameRes.Datum> = mutableListOf()
    private lateinit var searchResultAdapter: SearchResultAdapter
    private var filterOptionList: MutableList<CustomSearchFilterModel> = mutableListOf()
    private var searchResultList: MutableList<CustomSearchResultModel> = mutableListOf()
    private var tournamentResultList: MutableList<TournamentSearchResultModel> = mutableListOf()
    private var selectedType: String = ""
    private var isAllSelected = true
    private var timer = Timer()
    private val DELAY: Long = 800
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        makeFilterList()
        initView()
        listenToViewModel()
        mViewModel.getGameList()
        mViewModel.makeQueryParameter(editTextSearch.text.toString().trim(), filterOptionList, true)
    }

    /**
     * @desc make filter list options
     */
    private fun makeFilterList() {
        filterOptionList.add(
            CustomSearchFilterModel(
                key = resources.getString(R.string.sort_search),
                commonList = resources.getStringArray(R.array.sort_option).toMutableList(),
                selectedKey = resources.getStringArray(R.array.sort_option)[0],
                selectedName = resources.getStringArray(R.array.sort_option)[0]
            )
        )
        filterOptionList.add(
            CustomSearchFilterModel(
                key = resources.getString(R.string.category_search),
                commonList = resources.getStringArray(R.array.category_option).toMutableList(),
                selectedKey = resources.getStringArray(R.array.category_option)[0],
                selectedName = resources.getStringArray(R.array.category_option)[0]
            )
        )
        filterOptionList.add(
            CustomSearchFilterModel(
                key = resources.getString(R.string.game_search),
                selectedKey = "",
                selectedName = ""

            )
        )
        filterOptionList.add(
            CustomSearchFilterModel(
                key = resources.getString(R.string.platform_search),
                commonList = resources.getStringArray(R.array.platform_option).toMutableList(),
                selectedKey = resources.getStringArray(R.array.platform_option)[0],
                selectedName = resources.getStringArray(R.array.platform_option)[0]
            )
        )
        filterOptionList.add(
            CustomSearchFilterModel(
                key = resources.getString(R.string.region_search),
                regionList = resources.getStringArray(R.array.region_option).toMutableList(),
                selectedKey = resources.getStringArray(R.array.region_option)[1],
                selectedName = resources.getStringArray(R.array.region_option)[0]
            )
        )
    }

    /**
     * @desc initialize view
     */
    private fun initView() {
        recyclerViewFilter.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        searchFilterOptionAdapter =
            SearchFilterOptionAdapter(filterOptionList, onItemClick = ::onFilterItemClick)
        recyclerViewFilter.adapter = searchFilterOptionAdapter


        recyclerViewSearchOption.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        searchOptionAdapter = SearchOptionAdapter(
            resources.getStringArray(R.array.search_option),
            onItemClick = ::onOptionItemClick
        )
        recyclerViewSearchOption.adapter = searchOptionAdapter


        commonRecyclerView.layoutManager = LinearLayoutManager(this)
        searchResultAdapter = SearchResultAdapter(this,
            supportFragmentManager,
            searchResultList,
            tournamentResultList,
            onItemClick = ::onItemClick
        )
        commonRecyclerView.adapter = searchResultAdapter

        /**
         * @desc event occur while typing search text
         */
        editTextSearch.doAfterTextChanged {
            searchResultList.clear()
            tournamentResultList.clear()
            timer.cancel()
            timer = Timer()
            timer.schedule(object : TimerTask() {
                override fun run() {
                    mViewModel.makeQueryParameter(
                        editTextSearch.text.toString().trim(),
                        filterOptionList,
                        selectedType == ""
                    )
                }
            }, DELAY)
        }

        /**
         * @desc event occur while type on search option in keyboard
         */
        editTextSearch.setOnEditorActionListener(object : TextView.OnEditorActionListener {
            override fun onEditorAction(v: TextView?, actionId: Int, event: KeyEvent?): Boolean {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    this@SearchActivity.hideKeyboard()

                    mViewModel.makeQueryParameter(
                        editTextSearch.text.toString().trim(),
                        filterOptionList,
                        selectedType == ""
                    )
                    return true
                }
                return false
            }

        })
    }

    /**
     * @desc method will call article item click
     * @param id - article id
     */
    private fun onItemClick(id: String,type:Int) {
        if(type==0) {
            val bundle = Bundle()
            bundle.putString("id", id)
            startActivityInline<ArticlesDetailActivity>(bundle)
        }else{
            val videoClient = Intent(Intent.ACTION_VIEW)
            videoClient.data = Uri.parse(id)
            startActivity(videoClient)
        }
    }



    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make json object for API and un authorization.
     */
    private fun listenToViewModel() {

        mViewModel.makeQueryParameterGlobal.observe(this, Observer {
            tournamentResultList.clear()
            searchResultList.clear()
            mViewModel.getAllSearchResult(
                it.first,
                it.second.first,
                it.second.second.first,
                it.second.second.second.first, it.second.second.second.second, selectedType
            )
        })

        mViewModel.gameListSuccessResponse.observe(this, Observer {
            it?.data?.apply {
                if(!this.isNullOrEmpty()) {
                    gameList.addAll(this)
                    filterOptionList[2] = CustomSearchFilterModel(
                        key = resources.getString(R.string.game_search),
                        selectedKey = gameList[0].id,
                        selectedName = gameList[0].name.toString()
                    )
                    searchFilterOptionAdapter.notifyDataSetChanged()
                }
            }
        })

//        mViewModel.tournamentUpComingSuccessResponse.observe(this, Observer {
//
//            it?.data?.docs?.apply {
//                tournamentResultList.add(
//                    TournamentSearchResultModel(
//                        0,
//                        resources.getString(R.string.upcoming),
//                        this
//                    )
//                )
//            }
//            mViewModel.updateTournamentView(tournamentResultList)
//
//        })
//        mViewModel.tournamentOnGoingSuccessResponse.observe(this, Observer {
//
//
//            it?.data?.docs?.apply {
//                tournamentResultList.add(
//                    TournamentSearchResultModel(
//                        1,
//                        resources.getString(R.string.str_ongoing),
//                        this
//                    )
//                )
//            }
//           mViewModel.updateTournamentView(tournamentResultList)
//        })
//        mViewModel.tournamentCompleteSuccessResponse.observe(this, Observer {
//
//            it?.data?.docs?.apply {
//                tournamentResultList.add(
//                    TournamentSearchResultModel(
//                        2,
//                        resources.getString(R.string.str_complete),
//                        this
//                    )
//                )
//            }
//            mViewModel.updateTournamentView(tournamentResultList)
//        })

        mViewModel.updateTournamentView.observe(this, {
            tournamentResultList.clear()
            it?.first?.data?.docs?.apply {
                tournamentResultList.add(
                    TournamentSearchResultModel(
                        0,
                        resources.getString(R.string.upcoming),
                        this
                    )
                )
            }
            it?.second?.first?.data?.docs?.apply {
                tournamentResultList.add(
                    TournamentSearchResultModel(
                        1,
                        resources.getString(R.string.str_ongoing),
                        this
                    )
                )
            }

            it?.second?.second?.data?.docs?.apply {
                tournamentResultList.add(
                    TournamentSearchResultModel(
                        2,
                        resources.getString(R.string.str_complete),
                        this
                    )
                )
            }

            mViewModel.updateTournamentView(tournamentResultList)

        })

        mViewModel.updateTournamentList.observe(this, {
            linearLayoutProgressBar.beGone()
//            if (selectedType == "Tournament") {
                if(!checkKeyExists(resources.getString(R.string.tournament))) {
                    if (!tournamentResultList.isNullOrEmpty()) {
                        searchResultList.add(
                            0,
                            CustomSearchResultModel(
                                0,
                                resources.getString(R.string.tournament),
                                tournamentList = tournamentResultList
                            )
                        )
                    }
                }
//            } else {
//                if(!checkKeyExists(resources.getString(R.string.tournament))) {
//                    if (!tournamentResultList.isNullOrEmpty()) {
//                        searchResultList.add(
//                            0,
//                            CustomSearchResultModel(
//                                0,
//                                resources.getString(R.string.tournament),
//                                tournamentList = tournamentResultList
//                            )
//                        )
//                    }
//                }
//            }
            searchResultAdapter.notifyDataSetChanged()
        })

        mViewModel.articleSuccessResponse.observe(this, {
            linearLayoutProgressBar.beGone()
            if(!checkKeyExists(resources.getString(R.string.articles))) {
                it?.data?.apply {
                    searchResultList.add(
                        CustomSearchResultModel(
                            1,
                            resources.getString(R.string.articles),
                            articleList = this
                        )
                    )
                }
            }
            searchResultAdapter.notifyDataSetChanged()

        })

        mViewModel.videoSuccessResponse.observe(this, {
            linearLayoutProgressBar.beGone()
            if(!checkKeyExists(resources.getString(R.string.videos))) {
                it?.data?.apply {
                    searchResultList.add(
                        CustomSearchResultModel(
                            2,
                            resources.getString(R.string.videos),
                            videoList = this
                        )
                    )
                }
            }

            searchResultAdapter.notifyDataSetChanged()
        })



        mViewModel.noInternetException.observe(this, {
            linearLayoutProgressBar.beGone()
            if (isOnline()) {
                displayCustomAlertDialog(
                    resources.getString(R.string.something_wrong_try_again),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.retry),
                    positiveClick = {
                        it.dismiss()
                        mViewModel.makeQueryParameter(
                            editTextSearch.text.toString().trim(),
                            filterOptionList,
                            selectedType == ""
                        )
                    })
            } else {
                displayCustomAlertDialog(
                    resources.getString(R.string.no_internet_message),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.btn_ok),
                    positiveClick = {
                        it.dismiss()
                        if (searchResultList.isNullOrEmpty()) {
                            finish()
                        }
                    })
            }
        })

        mViewModel.timeOutException.observe(this, {
            linearLayoutProgressBar.beGone()
            displayCustomAlertDialog(
                resources.getString(R.string.timeout),
                isCancelable = false,
                positiveText = resources.getString(R.string.retry),
                positiveClick = {
                    it.dismiss()
                    mViewModel.makeQueryParameter(
                        editTextSearch.text.toString().trim(),
                        filterOptionList,
                        selectedType == ""
                    ) })
        })

    }

    private fun checkKeyExists(key: String):Boolean{
        searchResultList.forEach {
            if(it.key.toString().equals(key,true)){
                return true
            }
        }
        return false
    }

    /**
     * @desc method will call article item click
     * @param position - item position
     * @param customSearchFilterModel - filter model object
     * @param view - textview of filter text
     */
    private fun onFilterItemClick(
        position: Int,
        customSearchFilterModel: CustomSearchFilterModel,
        view: TextView
    ) {
        when (position) {
            0, 1, 3 -> {
                this.showSpinner(
                    customSearchFilterModel.key.toString(),
                    view,
                    customSearchFilterModel.commonList!!,
                    false,
                    "search",
                    onItemClick = {
                        filterOptionList[position].selectedKey = it.toString()
                        filterOptionList[position].selectedName = it.toString()
                        mViewModel.makeQueryParameter(
                            editTextSearch.text.toString().trim(),
                            filterOptionList
                        )
                    })
            }

            2 -> {
                this.showSpinner(
                    customSearchFilterModel.key.toString(),
                    view,
                    gameList,
                    false,
                    "game",
                    onItemClick = {
                        val data=it as TournamentGameRes.Datum
                        filterOptionList[position].selectedKey = data.id
                        filterOptionList[position].selectedName =data.name.toString()
                        mViewModel.makeQueryParameter(
                            editTextSearch.text.toString().trim(),
                            filterOptionList
                        )
                    })
            }
            4 -> {
                this.showSpinner(
                    customSearchFilterModel.key.toString(),
                    view,
                    customSearchFilterModel.regionList!!,
                    false,
                    "search",
                    onItemClick = {
                        filterOptionList[position].selectedKey = it.toString()
                        filterOptionList[position].selectedName = it.toString()
                        mViewModel.makeQueryParameter(
                            editTextSearch.text.toString().trim(),
                            filterOptionList
                        )
                    })
            }
        }
    }

    /**
     * @desc method will call when select option in recyclerview.
     * @param position - item position
     * @param title - option title
     */
    private fun onOptionItemClick(position: Int, title: String) {
        if (position == 0) {
            selectedType = ""
            isAllSelected = true
            recyclerViewFilter.beGone()
        } else {
            selectedType = title
            isAllSelected = false
            recyclerViewFilter.beGone()
        }
        mViewModel.makeQueryParameter(
            editTextSearch.text.toString().trim(),
            filterOptionList,
            selectedType == ""
        )
        searchOptionAdapter.updateSelectedPosition(position)
    }
}

