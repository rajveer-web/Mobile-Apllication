package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

class ArticlePostList(
    @SerializedName("postID")
    var postID: String? = null,

    @SerializedName("title")
    var title: String? = null,

    @SerializedName("company")
    var company: String? = null,

    @SerializedName("quarter")
    var quarter: String? = null,

    @SerializedName("year")
    var year: String? = null,

    @SerializedName("awardImage")
    var awardImage: String? = null,

    @SerializedName("awardImageThumb")
    var awardImageThumb: String? = null

)
