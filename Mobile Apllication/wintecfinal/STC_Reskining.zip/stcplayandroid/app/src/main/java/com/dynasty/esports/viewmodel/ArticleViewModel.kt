package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class ArticleViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
//    val articleTrendingResponse = MutableLiveData<HottestPostArticleModel>()
//    val articleAuthorResponse = MutableLiveData<ArticleAuthorsModel>()
//    val articlePostByGamesResponse = MutableLiveData<GamesModel>()
    val makeJsonForArticleData = MutableLiveData<Pair<Pair<JsonObject,JsonObject>,
            Pair<Pair<JsonObject,Pair<JsonObject,JsonObject>>,Pair<JsonObject,String>>>>()

//    val makeJsonForArticleData = MutableLiveData<Pair<JsonObject,JsonObject>>()
    val makeJsonForLatestArticleData = MutableLiveData<Pair<JsonObject,Pair<JsonObject,JsonObject>>>()

    val articleDataResponse = MutableLiveData<Pair<LatestArticleModel?,Pair<LatestArticleModel?,Pair<GamesModel?,Pair<VideosModel?,LatestTrendingModel?>>>>>()


    var hottestPostArticleModel: LatestArticleModel?=null
    var latestNewsModel: LatestArticleModel?=null
    var latestTrendingModel:LatestTrendingModel?=null
    var articleAuthorsModel: ArticleAuthorsModel?=null
    var gamesModel: GamesModel?=null
    var videosModel: VideosModel?=null

    /**
     * @desc Method will use for call API and get data for article tab[Article Trending post,Authors,Post Games,Latest Video]
     * @param jsonObjectVideo- video parameter json object
     */
    fun getAllArticles(jsonObjectVideo: String,gamesQuery:String,latestArticle:String,pagination:String,prefrense:String,newsArticle:String) {
        viewModelScope.launch(apiException("all")) {
            val latestTrendingPost = async { restInterface.latestTrendingPost() }
            val getTrendingPost = async { restInterface.articleTrendingPost(newsArticle,pagination,prefrense) }
       //     val getAuthorArticle = async { restInterface.authorArticle() }
            val getPostGames = async { restInterface.getGames(option = gamesQuery) }
            val getLatestVideo = async { restInterface.getLatestVideo(jsonObjectVideo) }
            val getLatestNews = async { restInterface.articleTrendingPost(latestArticle,pagination,prefrense) }
            if(getTrendingPost.await().code()==AppConstants.API_SUCCESS_CODE){
                hottestPostArticleModel=getTrendingPost.await().body()!!
            }

            if(latestTrendingPost.await().code()==AppConstants.API_SUCCESS_CODE){
                latestTrendingModel=latestTrendingPost.await().body()!!
            }

            if(getPostGames.await().code()==AppConstants.API_SUCCESS_CODE){
                gamesModel=getPostGames.await().body()!!
            }

            if(getLatestVideo.await().code()==AppConstants.API_SUCCESS_CODE){
                videosModel=getLatestVideo.await().body()!!
            }
//
            if(getLatestNews.await().code()==AppConstants.API_SUCCESS_CODE){
                latestNewsModel=getLatestNews.await().body()!!
            }

            articleDataResponse.postValue(Pair(hottestPostArticleModel,
                    Pair(latestNewsModel,
                    Pair(gamesModel,
                        Pair(videosModel,latestTrendingModel)))
            ))

//            articleTrendingResponse.postValue(getTrendingPost.await().body())
//            articleAuthorResponse.postValue(getAuthorArticle.await().body())
//            articlePostByGamesResponse.postValue(getPostGames.await().body())
//            latestVideoResponse.postValue(getLatestVideo.await().body())

        }

    }

    /**
     * @desc Method will use for create json object for video parameter.
     */
    fun makeJsonForVideoParameter(){

        val jsonObject = JsonObject()

        jsonObject.addProperty("page", 1)
        jsonObject.addProperty("limit", 5)
        jsonObject.addProperty("sort", "-updatedOn")


        val jsonObjectQuery = JsonObject()
        jsonObjectQuery.addProperty("page", 1)
        jsonObjectQuery.addProperty("limit", 7)


        val jsonObjectLatestArticle = JsonObject()
        jsonObjectLatestArticle.addProperty("articleStatus", "publish")
        jsonObjectLatestArticle.addProperty("category", "News")


        val jsonObjectPagination = JsonObject()
        val jsonObjectSort = JsonObject()
        jsonObjectSort.addProperty("createdDate",-1)
        jsonObjectPagination.addProperty("limit",7)
        jsonObjectPagination.add("sort",jsonObjectSort)

        val jsonObjectPrefernce = JsonObject()
        jsonObjectPrefernce.addProperty("prefernce", "")


        val jsonObjectNewsArticle = JsonObject()
        jsonObjectNewsArticle.addProperty("articleStatus", "publish")



        makeJsonForArticleData.postValue(Pair(Pair(jsonObject,jsonObjectQuery),
            Pair(Pair(jsonObjectLatestArticle,Pair(jsonObjectPagination,jsonObjectPrefernce)),
                Pair(jsonObjectNewsArticle,""))))



       // makeJsonForArticleData.postValue(Pair(jsonObject,jsonObjectQuery))
    }

    /**
     * @desc Method will use for create json object for video parameter.
     */
    fun makeJsonForArticleParameter(){
        //  pagination={"page":2,"limit":20,"sort":"-updatedOn","projection":["_id","title","description","youtubeUrl","thumbnailUrl","updatedOn"]}
        val jsonObjectLatestArticle = JsonObject()
        jsonObjectLatestArticle.addProperty("articleStatus", "publish")
        jsonObjectLatestArticle.addProperty("category", "News")


        val jsonObjectPagination = JsonObject()
        val jsonObjectSort = JsonObject()
        jsonObjectSort.addProperty("createdDate",-1)
        jsonObjectPagination.addProperty("limit",7)
        jsonObjectPagination.add("sort",jsonObjectSort)

        val jsonObjectPrefernce = JsonObject()
        jsonObjectPrefernce.addProperty("prefernce", "")



        makeJsonForLatestArticleData.postValue(Pair(jsonObjectLatestArticle,
            Pair(jsonObjectPagination,jsonObjectPrefernce)
        ))
    }



    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
