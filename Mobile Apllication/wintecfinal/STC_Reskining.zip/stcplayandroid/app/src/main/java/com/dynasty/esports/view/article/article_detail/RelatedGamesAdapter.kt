package com.dynasty.esports.view.article.article_detail


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterRelatedArticleBinding
import com.dynasty.esports.databinding.RowArticlePostBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.ArticlePostList
import com.dynasty.esports.models.GamesModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will handle list of related games
 * @author : Mahesh Vayak
 * @created : 11-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class RelatedGamesAdapter constructor(
    private var gamesList: MutableList<GamesModel.DataModel>,
    private val onItemClick: (String,String) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterRelatedArticleBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterRelatedArticleBinding> {
        val binding: AdapterRelatedArticleBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_related_article,
            parent,
            false
        )
        return BindingHolder(binding)

    }

    /**
     * @desc games array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return gamesList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterRelatedArticleBinding>,
        position: Int
    ) {
        val data=gamesList[holder.adapterPosition]
        holder.itemView.context.loadImageFromServer(data.logo.toString(),holder.binding.imageViewArticleBg)

        holder.binding.textViewArticleName.text=data.name?.let { it } ?: ""

        holder.binding.topcardview.click {
            onItemClick(data.id.toString(),data.name.toString())
        }
    }

}