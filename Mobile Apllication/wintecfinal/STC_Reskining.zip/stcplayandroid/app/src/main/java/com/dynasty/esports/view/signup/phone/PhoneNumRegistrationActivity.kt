
package com.dynasty.esports.view.signup.phone

import android.os.Bundle
import android.text.Editable
import android.text.TextPaint
import android.text.TextWatcher
import android.text.style.ClickableSpan
import android.view.View
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.Country
import com.dynasty.esports.models.LoginRequest
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.SocialLoginActivity
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.signup.email.EmailRegistrationActivity
import com.dynasty.esports.view.signup.password.CreatePasswordActivity
import com.dynasty.esports.viewmodel.SignUpViewModel
import kotlinx.android.synthetic.main.activity_phone_num_registration.*

import kotlinx.android.synthetic.main.content_phone_num_registration_screen.*
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.checkBox1
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.checkboxTxt
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.nickname
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.phone_nos
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.signup_continue
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.signup_email
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.signup_phone_num
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.social_login_fb
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.social_login_gPlus
import kotlinx.android.synthetic.main.content_phone_num_signin_screen.*
import kotlinx.android.synthetic.main.fragment_account.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class PhoneNumRegistrationActivity : SocialLoginActivity(), CountryCodePicker.Listener {
    private val mViewModel: SignUpViewModel by viewModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_num_registration)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        initialize()
        listenToViewModel()
    }


    var mTextWatcher: TextWatcher = object : TextWatcher {
        override fun beforeTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun onTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun afterTextChanged(editable: Editable) {
            // check Fields For Empty Values
            checkRegisterFieldsForEmptyValues(
                country_code ,
                phone_nos,
                nickname,
                signup_continue,
                checkBox1.isChecked,
                true
            )
        }
    }

    // initialise the view
    private fun initialize() {
        /*country_code.addTextChangedListener(mTextWatcher);
        phone_nos.addTextChangedListener(mTextWatcher);
        nickname.addTextChangedListener(mTextWatcher);
        checkBox1.click {
            checkRegisterFieldsForEmptyValues(country_code, phone_nos, nickname, signup_continue, checkBox1.isChecked, true);
        }*/

        getDate(editTextDob, AppConstants.DD_MM_YYYY_FORMAT, true, false,yearValidation = true, updateTextValue = {
            val selectedYear= it.split("/")[2]
            val yearDiff= getCurrentYears()-selectedYear.toInt()
            if(yearDiff in 10..17){
                llcheckBoxParentalConsent.beVisible()
            }else{
                llcheckBoxParentalConsent.beGone()
            }
            editTextDob.setText(it)
        })
        checkboxTxt.makeSpannableString(
            this, resources.getString(R.string.privacy_policy),
            if (LocaleHelper.getLanguage(this@PhoneNumRegistrationActivity) == "en") {
                1
            } else {
                5
            },
            resources.getString(R.string.privacy_policy).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    widget.cancelPendingInputEvents()
                    openUrlFromIntent()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            }, true
        )

//        country_code.setText(getBaseCountryDialCode())

        bottom_view.makeSpannableString(this, resources.getString(R.string.already_have_acct),
            if (LocaleHelper.getLanguage(this@PhoneNumRegistrationActivity) == "en") {
                25
            } else {
                23
            }, resources.getString(R.string.already_have_acct).length, object : ClickableSpan() {
                override fun onClick(widget: View) {
                    startActivityInline<PhoneSignInActivity>(finish = true)
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }
            })

        country_code.click {
            mViewModel.countryCodeClick()
        }

        social_login_fb.click {
            mViewModel.fbLoginClick()
        }

        social_login_gPlus.click {
            mViewModel.googleLoginClick()
        }

        signup_continue.click {
            // Signup button click
            mViewModel.onValidationForPhoneRegistration(
                nickname.text.toString().trim(),
                country_code.text.toString().trim(),
                phone_nos.text.toString().trim(),
                signup_email.text.toString().trim(),
                editTextDob.text.toString().trim(),
                checkBox1.isChecked,
                checkBoxParentalConsent.isChecked,
                llcheckBoxParentalConsent.visibility==View.VISIBLE
            )
        }

        signup_phone_num.click {
            startActivityInline<EmailRegistrationActivity>()
        }

    }

    // to liten view model and manage the api
    private fun listenToViewModel() {
        mViewModel.countryCodeObserver.observe(this, Observer {
            displayCountryCodeDialog()
        })

        mViewModel.fbLoginObserver.observe(this, Observer {
            fbLogin()
        })
        mViewModel.googleLoginObserver.observe(this, Observer {
            googleLogin()
        })

        mViewModel.validationLiveData.observe(this, Observer {
            when (it) {
                0 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.nickname_error)
                    )
                }
                1 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.mobile_code_error)
                    )
                }
                2 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.mobile_number_error)
                    )
                }
                7 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.mobile_number_not_valid_error)
                    )
                }
                3 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.error_msg_invalid_email)
                    )
                }
                4 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.error_dob)
                    )
                }
                5 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.policy_error)
                    )
                }
                6 -> {
                    makeSnackBar(
                        constraintLayoutSignUpPhone,
                        resources.getString(R.string.parental_consent_error)
                    )
                }
            }
        })

        mViewModel.isRegistrationFormValid.observe(this, Observer {



            val bundle = Bundle()
            bundle.putString("fullname", nickname.text.toString().trim())
            bundle.putString("email", signup_email.text.toString().trim())
            bundle.putString("phoneNumber", country_code.text.toString().trim().plus(phone_nos.text.toString().trim().removeZeroFormNumber()))
            bundle.putString("dob", editTextDob.text.toString().convertDateToRequireDateFormat(AppConstants.DD_MM_YYYY_FORMAT, "YYYY/MM/dd"))
            startActivityInline<CreatePasswordActivity>(bundle = bundle)
        })

    }

    override fun onCountryChosen(country: Country) {
        country_code.setText("+".plus(country.phoneCode))
    }

    override fun redirectToDashBoard(isRedirect: Boolean) {
        if (isRedirect)
            startActivityInlineWithFinishAll<DashboardActivity>()
    }

    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }
/*
    override fun onStart() {
        super.onStart()
        googleSignInHelper!!.onStart()
    }
*/

/*    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

         googleSignInHelper!!.onActivityResult(requestCode, resultCode, data);
        //--------------------------------Google login--------------------------------------//

        if (requestCode == RC_SIGN_IN) {
            val result = Auth.GoogleSignInApi.getSignInResultFromIntent(data)
           // handleSignInResult(result)
        }
    }

    override fun onConnectionFailed(p0: ConnectionResult) {
        Log.d("bett", "onConnectionFailed:" + p0);

    }*/

//    GoogleSignInAuth
/*    override fun OnGSignInSuccess(googleSignInAccount: GoogleSignInAccount?) {
        if (googleSignInAccount != null) {
            Log.d("Google Name ", googleSignInAccount.givenName +" " + googleSignInAccount.familyName)
            Log.d("Google Email ", googleSignInAccount.email )
            Log.d("Google id ", googleSignInAccount.id)
            Log.d("Google id ", googleSignInAccount.idToken)
        }
    }*/

    /*override fun OnGSignInError(error: String?) {

    }*/
}