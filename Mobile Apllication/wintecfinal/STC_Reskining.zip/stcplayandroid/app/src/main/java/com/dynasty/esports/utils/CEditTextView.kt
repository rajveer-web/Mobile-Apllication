package com.dynasty.esports.utils

import android.content.Context
import android.text.InputFilter
import android.text.Spanned
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import com.dynasty.esports.extenstion.regularFont


/**
 * @desc this class will handle edittext properties
 * @author : Mahesh Vayak
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CEditTextView : AppCompatEditText {

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context) : super(context) {
        init()
    }

    fun init() {
        if (!isInEditMode) {
            try {
                filters = arrayOf<InputFilter>(EmojiExcludeFilter())
                typeface = context.regularFont()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }

    private class EmojiExcludeFilter : InputFilter {
        override fun filter(
            source: CharSequence,
            start: Int,
            end: Int,
            dest: Spanned,
            dstart: Int,
            dend: Int
        ): CharSequence? {
            for (i in start until end) {
                val type = Character.getType(source[i])
                if (type == Character.SURROGATE.toInt() || type == Character.OTHER_SYMBOL.toInt()) {
                    return ""
                }
            }
            return null
        }
    }

}