package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.LoginRequest
import com.dynasty.esports.models.RegisterResponse
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.retrofit.RestInterface
import com.dynasty.esports.utils.Validator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class CreatePasswordViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()
    val fbLoginObserver = MutableLiveData<Boolean>()
    val googleLoginObserver = MutableLiveData<Boolean>()
    val redirectPhoneObserver = MutableLiveData<Boolean>()
    val signUpSuccessResponse = MutableLiveData<RegisterResponse>()
    val signUpErrorResponse = MutableLiveData<ResponseBody>()



    fun onValidationCreatePassword(password: String, confirmPass: String) {
        when {
            password.isFieldEmpty() -> validationLiveData.postValue(0)
            confirmPass.isFieldEmpty() -> validationLiveData.postValue(1)
            !Validator.isValidPassword(password) -> validationLiveData.postValue(2)
            !Validator.isValidPassword(confirmPass) -> validationLiveData.postValue(3)
            !Validator.isEquall(password,confirmPass) -> validationLiveData.postValue(4)
            else -> isFormValid.postValue(true)
        }
    }


    fun fbLoginClick() {
        fbLoginObserver.postValue(true)
    }

    fun googleLoginClick() {
        googleLoginObserver.postValue(true)
    }

    fun redirectPhoneSignIn() {
        redirectPhoneObserver.postValue(true)
    }


    fun signUpAPI(loginRequest: LoginRequest) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.registerUser(loginRequest)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    signUpSuccessResponse.postValue(response.body())
                }
                else -> {
                    signUpErrorResponse.postValue(response.errorBody())
                }
            }

        }

    }


    /**
     * Clears the [ViewModel] when the [SignInActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
