package com.dynasty.esports.view.search


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.RowArticlePostBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.SearchArticleModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.utils.LocaleHelper

/**
 * @desc this is class will use to show search article
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SearchArticlePostAdapter constructor(
    private var articleList: MutableList<SearchArticleModel.DataModel>,
    private val onItemClick: (String) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<RowArticlePostBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<RowArticlePostBinding> {
        val binding: RowArticlePostBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.row_article_post,
            parent,
            false)
        return BindingHolder(binding)
    }

    /**
     * @desc article array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return articleList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<RowArticlePostBinding>,
        position: Int) {
        val data = articleList[holder.adapterPosition]

//        data.authorDetails?.apply {
//            holder.binding.textViewUserName.text=this.fullName?.let {
//                it
//            } ?: "-"
//
//            this.profilePicture?.apply {
//                holder.itemView.context.loadImageFromServer(this,holder.binding.imageViewUser)
//            }
//        }
        holder.binding.imageViewUser.beGone()
        holder.binding.textViewUserName.beGone()

        holder.binding.textViewDateTitle.text = data.game?.let {
            it.plus(" | ").plus(
                data.createdDate.toString().convertDateToRequireDateFormat(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.APP_DATE_FORMAT
                )
            )
        }

        if (LocaleHelper.getLanguage(holder.binding.root.context) == "en") {
            holder.binding.textViewAbout.text =  data.title?.english?.let { it } ?: ""
        }else{
            holder.binding.textViewAbout.text = if(data.title?.malay.isNullOrEmpty())  data.title?.english?.let { it } ?: "" else  data.title?.malay?.let { it } ?: ""
        }



        data.image?.apply {
            holder.itemView.context.loadImageFromServer(this, holder.binding.imageViewBackground)
        }

        holder.binding.topcardview.setOnClickListener {
            onItemClick(data.id!!)
        }

    }

}