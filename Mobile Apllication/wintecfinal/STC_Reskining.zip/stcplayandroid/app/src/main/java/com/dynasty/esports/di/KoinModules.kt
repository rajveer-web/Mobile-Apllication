package com.dynasty.esports.di

import android.content.Context
import android.content.SharedPreferences
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.R
import com.dynasty.esports.retrofit.AuthorizationChatInterceptor
import com.dynasty.esports.retrofit.AuthorizationInterceptor
import com.dynasty.esports.retrofit.ChatInterface
import com.dynasty.esports.retrofit.RestInterface
import com.dynasty.esports.viewmodel.*
import okhttp3.OkHttpClient
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.qualifier.named
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

val applicationModule = module {
    single<SharedPreferences> {
        androidContext().getSharedPreferences(
            androidContext().getString(R.string.app_name),
            Context.MODE_PRIVATE
        )
    }
}

val viewModelModule = module {
    viewModel { CommonViewModel(get()) }
    viewModel { ChatViewModel(get(), get()) }
    viewModel { BracketViewModel(get()) }
    viewModel { SignInViewModel(get()) }
    viewModel { SignUpViewModel(get()) }
    viewModel { CreatePasswordViewModel(get()) }
    viewModel { PhoneNumberVerificationViewModel(get()) }
    viewModel { OTPVerificationViewModel(get()) }
    viewModel { ArticleViewModel(get()) }
    viewModel { OnBoardingViewModel(get()) }
    viewModel { CreateTournamentViewModel(get()) }
    viewModel { CreateTournamentStep1ViewModel(get()) }
    viewModel { CreateTournamentStep2ViewModel(get()) }
    viewModel { CreateTournamentStep3ViewModel(get()) }
    viewModel { EsportsViewModel(get()) }
    viewModel { ArticleDetailViewModel(get()) }
    viewModel { ForgotPasswordViewModel(get()) }
    viewModel { ForgotPasswordMobileFragmentViewModel(get()) }
    viewModel { ViewAllArticleViewModel(get()) }
    viewModel { BasicInfoViewModel(get()) }
    viewModel { TransactionHistoryViewModel(get()) }
    viewModel { BookmarkViewModel(get()) }
    viewModel { ContentViewModel(get()) }
    viewModel { CreatedAndJoinedTournamentViewModel(get()) }
    viewModel { PublishTournamentViewModel(get()) }
    viewModel { AccountViewModel(get()) }
    viewModel { ManagedTournamentViewModel(get()) }
    viewModel { InboxViewModel(get()) }
    viewModel { SearchViewModel(get()) }
    viewModel { JoinTournamentViewModel(get()) }
    viewModel { HomeViewModel(get()) }
    viewModel { UpcomingTournamentViewModel(get()) }
    viewModel { OngoingTournamentViewModel(get()) }
    viewModel { UpcomingParticipantsViewModel(get()) }
    viewModel { TournamentDetailViewModel(get()) }
    viewModel { ArticleVideoViewModel(get()) }
    viewModel { ManagedTournamentDiscussionViewModel(get()) }
    viewModel { StreamViewModel(get()) }
    viewModel { LeaderBoardViewModel(get()) }
    viewModel { GameTabViewModel(get()) }

}


val appModule = module {
//    single {
//        createWebService<RestInterface>(
//            okHttpClient = get(),
//            baseUrl = BuildConfig.PATH_URL
//        )
//    }

    single<Retrofit>(named("live")) {
        Retrofit.Builder()
            .client(get())
            .addConverterFactory(GsonConverterFactory.create())
            .addConverterFactory(ScalarsConverterFactory.create())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .baseUrl(BuildConfig.PATH_URL)
            .build()
    }

    single<Retrofit>(named("chat")) {
        Retrofit.Builder()
            .client(makeHttpClientChat())
            .addConverterFactory(GsonConverterFactory.create())
            .addConverterFactory(ScalarsConverterFactory.create())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .baseUrl(BuildConfig.CHAT_PATH_URL)
            .build()
    }



    single {

        val httpClient = OkHttpClient()

        OkHttpClient.Builder()
            .also {
                it.addInterceptor(AuthorizationInterceptor(httpClient))
            }
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }
}


fun makeHttpClientChat(): OkHttpClient {
    val httpClient = OkHttpClient()

    return OkHttpClient.Builder()
        .also {
            it.addInterceptor(AuthorizationChatInterceptor(httpClient))
        }
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
}

val moreRetrosModule = module {
    single { get<Retrofit>(named("live")).create(RestInterface::class.java) }
    single { get<Retrofit>(named("chat")).create(ChatInterface::class.java) }
}


//fun createHttpClient(): OkHttpClient {
//    val client = OkHttpClient.Builder()
//    client.readTimeout(5 * 60, TimeUnit.SECONDS)
//    return client.build()
//}

/* function to build our Retrofit service */
inline fun <reified T> createWebService(
    okHttpClient: OkHttpClient,
    baseUrl: String
): T {
    val retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .addConverterFactory(GsonConverterFactory.create())
        .addConverterFactory(ScalarsConverterFactory.create())
        .client(okHttpClient)
        .build()
    return retrofit.create(T::class.java)
}


/**
 * List of all modules.
 */
val mainAppModules = listOf(
    appModule,
    applicationModule,
    viewModelModule,
    moreRetrosModule
)