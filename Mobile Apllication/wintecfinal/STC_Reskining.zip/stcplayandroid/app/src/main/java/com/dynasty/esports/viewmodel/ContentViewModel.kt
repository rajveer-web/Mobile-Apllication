package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.ContentUserPrefModel
import com.dynasty.esports.models.ProfileContentModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 17-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ContentViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
    val contentSuccessResponse = MutableLiveData<ProfileContentModel>()
   // val contentErrorResponse = MutableLiveData<ResponseBody>()
    val contentPrefSuccessResponse = MutableLiveData<ContentUserPrefModel>()
    val contentPrefErrorResponse = MutableLiveData<ResponseBody>()
    val makeJsonObjectObserver = MutableLiveData<JsonObject>()
    val updateContentErrorResponse = MutableLiveData<ResponseBody>()
    val updateContentSuccessResponse = MutableLiveData<ResponseBody>()

    /**
     * @desc Method will handle contents API success and failure
     */
    fun getContentAndPreference() {
        viewModelScope.launch(apiException("all")) {
            val fetchContentPreference = async { restInterface.fetchContentUserPref() }
            val fetchContent = async { restInterface.fetchContent() }

            when(fetchContentPreference.await().code()){
                AppConstants.API_SUCCESS_CODE->{
                    contentPrefSuccessResponse.postValue(fetchContentPreference.await().body())
                    contentSuccessResponse.postValue(fetchContent.await().body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE->{
                    unAuthorizationException.postValue(true)
                }
                else ->{
                    contentPrefErrorResponse.postValue(fetchContentPreference.await().errorBody())
                }
            }



        }

    }

//    fun fetchContent() {
//        viewModelScope.launch(apiException("content") + Dispatchers.Main) {
//            val response = restInterface.fetchContent()
//            when (response.code()) {
//                AppConstants.API_SUCCESS_CODE -> {
//                    contentSuccessResponse.postValue(response.body())
//                }
//                AppConstants.API_UNAUTHENTICATED_CODE -> {
//                    unAuthorizationException.postValue(true)
//                }
//                else -> {
//                    contentErrorResponse.postValue(response.errorBody())
//                }
//            }
//        }
//
//    }
//
//
//    fun fetchContentPref() {
//        viewModelScope.launch(apiException("pref") + Dispatchers.Main) {
//            val response = restInterface.fetchContentUserPref()
//            when (response.code()) {
//                AppConstants.API_SUCCESS_CODE -> {
//                    contentPrefSuccessResponse.postValue(response.body())
//                }
//                AppConstants.API_UNAUTHENTICATED_CODE -> {
//                    unAuthorizationException.postValue(true)
//                }
//                else -> {
//                    contentPrefErrorResponse.postValue(response.errorBody())
//                }
//            }
//        }
//
//    }

    /**
     * @desc Method will handle update user content API success and failure
     * @param jsonObject - pass jsonobject for update user content API
     */
    fun updateContentPref(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("update") + Dispatchers.Main) {
            val response = restInterface.updateContentUserPref(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateContentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    updateContentErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     * @desc Method will create content preference.
     * @param jsonObject - pass json object for update user content API
     */
    fun makeJsonForPref(
        chooseGame: MutableList<String>,
        gamePlatform: MutableList<String>,
        gameCenter: MutableList<String>,
        gameContent: MutableList<String>
    ) {
        val jsonObjectRoot = JsonObject()
        val jsonArrayChooseGame = JsonArray()
        val jsonArrayGamePlatform = JsonArray()
        val jsonArrayGameCenter = JsonArray()
        val jsonArrayGameContent = JsonArray()
        chooseGame.forEach {
            jsonArrayChooseGame.add(it)
        }
        gamePlatform.forEach {
            jsonArrayGamePlatform.add(it)
        }
        gameCenter.forEach {
            jsonArrayGameCenter.add(it)
        }
        gameContent.forEach {
            jsonArrayGameContent.add(it)
        }
        jsonObjectRoot.add("game", jsonArrayChooseGame)
        jsonObjectRoot.add("genre", jsonArrayGameCenter)
        jsonObjectRoot.add("prefer", jsonArrayGameContent)
        jsonObjectRoot.add("platform", jsonArrayGamePlatform)
        makeJsonObjectObserver.postValue(jsonObjectRoot)

    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }


}
