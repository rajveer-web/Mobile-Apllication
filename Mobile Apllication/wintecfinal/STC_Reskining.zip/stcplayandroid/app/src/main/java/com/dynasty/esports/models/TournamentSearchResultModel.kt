package com.dynasty.esports.models

import java.lang.Character.toString

data class TournamentSearchResultModel(
    val type:Int?=null,
    val title:String?=null,
    val tournamentList:MutableList<SearchTournamentModel.DocModel>?=null

)