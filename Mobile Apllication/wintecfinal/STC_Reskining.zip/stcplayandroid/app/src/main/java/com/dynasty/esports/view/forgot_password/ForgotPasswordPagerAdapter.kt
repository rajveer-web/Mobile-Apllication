package com.dynasty.esports.view.forgot_password

import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ForgotPasswordPagerAdapter (fm: FragmentManager) : FragmentPagerAdapter(fm)  {

    var mCurrentPage: ForgotPasswordPageFragment? = null

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> ForgotPasswordFragment.newInstance()
            1 -> VerificationFragment.newInstance()
            2 -> ChangePasswordFragment.newInstance()
            3 -> SuccessfullyResetPasswordFragment.newInstance()
            else -> null
        }!!
    }

    override fun setPrimaryItem(
        container: ViewGroup,
        position: Int,
        `object`: Any
    ) {
        super.setPrimaryItem(container, position, `object`)
        mCurrentPage = `object` as ForgotPasswordPageFragment
    }

    override fun getCount(): Int {
        return 4
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return "Page $position"
    }

    fun getCurrentPage(): ForgotPasswordPageFragment? {
        return mCurrentPage
    }
}