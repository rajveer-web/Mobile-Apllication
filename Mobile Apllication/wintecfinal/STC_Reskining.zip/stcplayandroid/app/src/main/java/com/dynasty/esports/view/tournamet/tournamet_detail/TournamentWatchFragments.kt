package com.dynasty.esports.view.tournamet.tournamet_detail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.models.CreateTournamentResponse
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.view.common.BaseFragment
import kotlinx.android.synthetic.main.watch_recycler_view.*

class TournamentWatchFragments : BaseFragment() {

    private lateinit var gameItem: TournamentDetailRes

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.watch_recycler_view, container, false)
    }

    companion object {
        fun newInstance(gameItem: TournamentDetailRes): Fragment {
            val args = Bundle()
            args.putParcelable("data", gameItem)
            val fragment = TournamentWatchFragments()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
    }

    fun initialise(){

        arguments?.apply {
            gameItem = this.getParcelable<TournamentDetailRes>("data")!!
        }

        watch_recyclerview.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        watch_recyclerview.addItemDecoration(
            TournamentWatchAdapter.VerticalSpaceItemDecoration(
                48
            )
        )

        if(gameItem.data!!.stream.size > 0){
            watch_recyclerview.adapter =
                TournamentWatchAdapter(
                    gameItem.data!!.stream,
                    object :
                        TournamentWatchAdapter.OnItemClickListener {
                        override fun onItemClick(stream: TournamentDetailRes.Stream) {
                            onVideoClick(stream.videoUrl?.providerName!!.plus(stream.videoUrl?.channelName))
                        }
                    })
        }else{
            watch_recyclerview.visibility = View.GONE
            watch_no_data_display_txt.visibility = View.VISIBLE
        }
    }

    private fun onVideoClick(url: String) {
        val videoClient = Intent(Intent.ACTION_VIEW)
        videoClient.data = Uri.parse(url)
        requireActivity().startActivity(videoClient)
    }

}