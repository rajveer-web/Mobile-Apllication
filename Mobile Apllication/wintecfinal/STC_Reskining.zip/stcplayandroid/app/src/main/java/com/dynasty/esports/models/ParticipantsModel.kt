package com.dynasty.esports.models

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


class ParticipantsModel {

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: MutableList<DataModel>? = null

    @SerializedName("message")
    @Expose
    val message: String? = null

    @SerializedName("totals")
    @Expose
    val totals: TotalsModel? = null


    @Parcelize
    class DataModel :Parcelable {
        @SerializedName("teamMembers")
        @Expose
        val teamMembers: MutableList<TeamPlayers>? = null

        @SerializedName("seed")
        @Expose
        var seed: Int? = null

        @SerializedName("createdOn")
        @Expose
        val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        val updatedOn: String? = null

        @SerializedName("checkedIn")
        @Expose
        val checkedIn: Boolean? = null

        @SerializedName("isApproved")
        @Expose
        val isApproved: Boolean? = null

        @SerializedName("status")
        @Expose
        val status: Int? = null

        @SerializedName("participantStatus")
        @Expose
        val participantStatus: String? = null

        @SerializedName("matchWin")
        @Expose
        val matchWin: Int? = null

        @SerializedName("matchLoss")
        @Expose
        val matchLoss: Int? = null

        @SerializedName("matchTie")
        @Expose
        val matchTie: Int? = null

        @SerializedName("_id")
        @Expose
        val id: String? = null

        @SerializedName("logo")
        @Expose
        val logo: String = ""

        @SerializedName("teamName")
        @Expose
        val teamName: String? = null

        @SerializedName("name")
        @Expose
        val name: String? = null

        @SerializedName("phoneNumber")
        @Expose
        val phoneNumber: String? = null

        @SerializedName("email")
        @Expose
        val email: String? = null

        @SerializedName("tournamentUsername")
        @Expose
        val tournamentUsername: String? = null

        @SerializedName("inGamerUserId")
        @Expose
        val inGamerUserId: String? = null

        @SerializedName("participantType")
        @Expose
        val participantType: String? = null

        @SerializedName("tournamentId")
        @Expose
        val tournamentId: String? = null

        @SerializedName("userId")
        @Expose
        val userId: String? = null

        @SerializedName("__v")
        @Expose
        val v: Int? = null

        /*@SerializedName("teamMembers")
        @Expose
        var teamMembers: Boolean? = null*/

    }
}