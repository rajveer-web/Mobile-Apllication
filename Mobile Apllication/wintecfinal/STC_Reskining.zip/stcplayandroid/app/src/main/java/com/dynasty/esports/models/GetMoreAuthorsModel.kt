package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class GetMoreAuthorsModel {

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: MutableList<DataModel>? = null

    @SerializedName("message")
    @Expose
    val message: String? = null

    class DataModel {
        @SerializedName("authorName")
        @Expose
         val authorName: String? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("isAuthor")
        @Expose
         val isAuthor: Boolean? = null

        @SerializedName("isInfluencer")
        @Expose
         val isInfluencer: Boolean? = null

        @SerializedName("articleCount")
        @Expose
         val articleCount: Int? = null

        @SerializedName("profilePicture")
        @Expose
         val profilePicture: String? = null
    }
}