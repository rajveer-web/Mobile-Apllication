package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TitleModel{
    @SerializedName("english")
    @Expose
    val english: String? = null

    @SerializedName("malay")
    @Expose
    val malay: String? = null
}
