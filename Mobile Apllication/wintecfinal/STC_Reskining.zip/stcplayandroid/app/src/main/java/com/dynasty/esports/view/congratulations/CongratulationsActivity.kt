package com.dynasty.esports.view.congratulations

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.dynasty.esports.R
import kotlinx.android.synthetic.main.activity_congratulations.*

class CongratulationsActivity : AppCompatActivity() {

    private lateinit var username: TextView
    private lateinit var homeButton: Button
    private lateinit var nextButton: Button

    var bundle: Bundle? = null
    var email: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_congratulations)

        initialise()
    }

    fun initialise(){
        bundle = intent.extras
        email = bundle?.getString("email")

        username = account_created
        username.text = email
        homeButton = home_btn
        nextButton = next_btn

        homeButton.setOnClickListener {

        }

        nextButton.setOnClickListener {

        }
    }
}