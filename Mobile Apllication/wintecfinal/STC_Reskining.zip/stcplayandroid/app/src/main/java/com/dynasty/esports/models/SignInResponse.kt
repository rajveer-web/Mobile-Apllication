package com.dynasty.esports.models

data class SignInResponse (
    val message:String,
    val data: DataResponse,
val code :String)