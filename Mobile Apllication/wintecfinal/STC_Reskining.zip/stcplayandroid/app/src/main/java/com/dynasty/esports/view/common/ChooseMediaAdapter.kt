package com.dynasty.esports.view.common

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterChooseMediaBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.utils.BindingHolder


class ChooseMediaAdapter constructor(
    private val titleArrayList: Array<String>,
    private val onChooseMediaClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterChooseMediaBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterChooseMediaBinding> {
        val inflater = LayoutInflater.from(parent.context)
        val binding: AdapterChooseMediaBinding =
            DataBindingUtil.inflate(inflater, R.layout.adapter_choose_media, parent, false)
        return BindingHolder(binding)
    }

    override fun onBindViewHolder(holder: BindingHolder<AdapterChooseMediaBinding>, position: Int) {
        holder.binding.textViewTitle.text = titleArrayList[position]
//        if(position==titleArrayList.size - 1) {
//            holder.binding.textViewTitle.setTextColor()
//        }
        holder.binding.linearLayoutChooseMedia.click {
            onChooseMediaClick(position)
        }
    }

    override fun getItemCount(): Int {
        return titleArrayList.size
    }


}
