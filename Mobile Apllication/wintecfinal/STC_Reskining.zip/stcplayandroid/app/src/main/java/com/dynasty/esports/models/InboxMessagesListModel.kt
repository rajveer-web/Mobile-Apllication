package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class InboxMessagesListModel {
    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null


    class DataModel{
        @SerializedName("seen")
        @Expose
         val seen: Boolean? = null

        @SerializedName("status")
        @Expose
         val status: Int? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("sentBy")
        @Expose
         val sentBy: String? = null

        @SerializedName("senderDetails")
        @Expose
         val senderDetails: SenderDetailsModel? = null

        @SerializedName("toUser")
        @Expose
         val toUser: String? = null

        @SerializedName("subject")
        @Expose
         val subject: String? = null

        @SerializedName("message")
        @Expose
         val message: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("createdAt")
        @Expose
         val createdAt: String? = null

        @SerializedName("updatedAt")
        @Expose
         val updatedAt: String? = null

        @SerializedName("parentId")
        @Expose
         val parentId: String? = null

    }

    class SenderDetailsModel{
        @SerializedName("phoneisVerified")
        @Expose
         val phoneisVerified: Boolean? = null

        @SerializedName("emailisVerified")
        @Expose
         val emailisVerified: Boolean? = null

        @SerializedName("Status")
        @Expose
         val status: Int? = null


        @SerializedName("firstLogin")
        @Expose
         val firstLogin: Int? = null

        @SerializedName("isAuthor")
        @Expose
         val isAuthor: Int? = null

        @SerializedName("isInfluencer")
        @Expose
         val isInfluencer: Int? = null

        @SerializedName("isVerified")
        @Expose
         val isVerified: Int? = null


        @SerializedName("rating")
        @Expose
         val rating: Int? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("accountType")
        @Expose
         val accountType: String? = null

        @SerializedName("fullName")
        @Expose
         val fullName: String? = null

        @SerializedName("password")
        @Expose
         val password: String? = null

        @SerializedName("phoneNumber")
        @Expose
         val phoneNumber: String? = null

        @SerializedName("email")
        @Expose
         val email: String? = null

        @SerializedName("profilePicture")
        @Expose
         val profilePicture: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
         val updatedBy: String? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("text")
        @Expose
         val text: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("accountDetail")
        @Expose
         val accountDetail: String? = null

        @SerializedName("accountId")
        @Expose
         val accountId: String? = null

        @SerializedName("phoneOTP")
        @Expose
         val phoneOTP: Int? = null

        @SerializedName("phoneOTPexp")
        @Expose
         val phoneOTPexp: String? = null

        @SerializedName("accessLevel")
        @Expose
         val accessLevel: MutableList<String>? = null

        @SerializedName("country")
        @Expose
         val country: String? = null

        @SerializedName("gender")
        @Expose
         val gender: String? = null

        @SerializedName("martialStatus")
        @Expose
         val martialStatus: String? = null

        @SerializedName("postalCode")
        @Expose
         val postalCode: String? = null

        @SerializedName("profession")
        @Expose
         val profession: String? = null

        @SerializedName("state")
        @Expose
         val state: String? = null

        @SerializedName("shortBio")
        @Expose
         val shortBio: String? = null

        @SerializedName("parentalStatus")
        @Expose
         val parentalStatus: String? = null

        @SerializedName("dob")
        @Expose
         val dob: Any? = null

    }


}