package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName


data class BracketData (
    @SerializedName("data")
    val data : BracketInnerData?,
    @SerializedName("message")
    val message: String?,
    @SerializedName("success")
    val success: Boolean?
)