package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.DiscussionComment
import com.dynasty.esports.models.DiscussionPostCommentModel
import com.dynasty.esports.models.PostCommentModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class ManagedTournamentDiscussionViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    //val tournamentCheckInErrorResponse = MutableLiveData<ResponseBody>()
    val discussionSuccessResponse = MutableLiveData<DiscussionComment>()
    val discussionErrorResponse = MutableLiveData<ResponseBody>()
    val updateUI = MutableLiveData<MutableList<DiscussionComment.DataModel>>()
    val discussionPostCommentSuccessResponse = MutableLiveData<DiscussionPostCommentModel>()
    val discussionPostCommentErrorResponse = MutableLiveData<ResponseBody>()

    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val makeJsonObjectForPostDiscussion = MutableLiveData<JsonObject>()
    val makeJsonObjectForDiscussion = MutableLiveData<Pair<String, JsonObject>>()

    val postCommentSuccessResponse = MutableLiveData<Pair<String, DiscussionPostCommentModel>>()
    val postCommentErrorResponse = MutableLiveData<Pair<String, ResponseBody>>()

    val likeCommentSuccessResponse = MutableLiveData<Pair<ResponseBody, String>>()
    val likeCommentErrorResponse = MutableLiveData<Pair<ResponseBody, String>>()
    /**
     * @desc Method will use for get discussion comments for tournament
     * @param userId- logged in use id
     * @param tournamentId- tournament id
     */
    fun fetchDiscussions(userId: String, tournamentId: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getDiscussionComment(userId, tournamentId)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    discussionSuccessResponse.postValue(response.body())
                }
                else -> {
                    discussionErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }




    /**
     * @desc Method will use for post comment
     * @param type- comment type ["post", "replies_comment"]
     * @param jsonObject-article comment jsonobject
     */
    fun postComment(type: String, commentJson: JsonObject) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
            val response = restInterface.postDiscussionComment(commentJson)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    postCommentSuccessResponse.postValue(Pair(type, response.body()!!))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    postCommentErrorResponse.postValue(Pair(type, response.errorBody()!!))
                }
            }

        }
    }

    /**
     * @desc Method will use for like comment and article
     * @param type- like type  ["article", "comment"]
     * @param jsonObject-comment or article like jsonobject
     */
    fun likeCommentAndArticle(jsonObject: JsonObject, type: String) {

        viewModelScope.launch(apiException("comment") + Dispatchers.IO) {
            val response = restInterface.likeArticleAndComment(jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    likeCommentSuccessResponse.postValue(Pair(response.body()!!, type))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    likeCommentErrorResponse.postValue(Pair(response.errorBody()!!, type))
                }
            }

        }
    }


    /**
     * @desc Method will use for update like comment and article
     * @param type- like type  ["article", "comment"]
     * @param id- article id
     * @param jsonObject-comment or article like jsonobject
     */
    fun updateLikeComment(id: String, jsonObject: JsonObject, type: String) {
        viewModelScope.launch(apiException("comment") + Dispatchers.IO) {
            val response = restInterface.updateLikeArticleAndComment(id, jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    likeCommentSuccessResponse.postValue(Pair(response.body()!!, type))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    likeCommentErrorResponse.postValue(Pair(response.errorBody()!!, type))
                }
            }
        }
    }

    /**
     * @desc Method will use for check form validation
     * @param comment- post comment string
     */
    fun checkValidation(comment: String) {
        when {
            comment.isFieldEmpty() -> validationLiveData.postValue(0)
            else -> isFormValid.postValue(true)
        }
    }

    fun makeJsonForPostDiscussion(text: String, userId: String, gameId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("comment", text)
        jsonObject.addProperty("userId", userId)
        jsonObject.addProperty("objectId", gameId)
        jsonObject.addProperty("objectType", "tournament")
        makeJsonObjectForPostDiscussion.postValue(jsonObject)
    }

    /**
     *@desc method will call when get success from API and pass data to UI
     */
    fun updateUI(data: MutableList<DiscussionComment.DataModel>) {
        updateUI.postValue(data)
    }

    /**
     * @desc Method will use to create json object for like and comment article
     * @param id- article id
     * @param userId -  logged in user id
     * @param type - type ["article" ,"comment"]
     */
    fun makeJsonObjectForLikeComment(id: String, userId: String, type: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("objectId", id)
        jsonObject.addProperty("objectType", type)
        jsonObject.addProperty("type", 1)
        jsonObject.addProperty("userId", userId)
        jsonObject.addProperty("createdBy", userId)
        makeJsonObjectForDiscussion.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for update like and comment article
     * @param type- like and comment types ["updateLikeArticle","updateLikeComment"]
     * @param likeType - like Type ["0" ,"1"]
     */
    fun makeJsonObjectForUpdateLike(type: String, likeType: Int) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("type", likeType)
        makeJsonObjectForDiscussion.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for replies comment.
     * @param type- comment type ["replies_comment"]
     * @param text - comment text
     * @param id - article id
     * @param userId - logged in user id
     */
    fun makeJsonObjectForRepliesComment(type: String, text: String, id: String, userId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("comment", text)
        jsonObject.addProperty("userId", userId)
        jsonObject.addProperty("objectId", id)
        jsonObject.addProperty("objectType", "comment")
        makeJsonObjectForDiscussion.postValue(Pair(type, jsonObject))
    }


    /**
     * Clears the [ViewModel] when the [Fragment or Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
