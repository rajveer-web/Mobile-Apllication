package com.dynasty.esports.view.search

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterArticlesDataBinding
import com.dynasty.esports.databinding.AdapterTournamentSearchBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.CustomSearchResultModel
import com.dynasty.esports.models.TournamentSearchResultModel
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.view.esport.OngoingTournamentFragment
import com.dynasty.esports.view.esport.UpcomingTournamentFragment

/**
 * @desc this class will use to show search result
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class SearchResultAdapter
    (
    private var context: Context,
    private var fragmentManager: FragmentManager,
    private var searchResultList: MutableList<CustomSearchResultModel>,
    private var tournamentResultList: MutableList<TournamentSearchResultModel>,
    private val onItemClick: (String, Int) -> Unit = { _, _ -> },
    private val onViewAllItemClick: (String, Int) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    /**
     *@desc This ViewHolder should be constructed with a new View that can represent the items
     * of the given type.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: AdapterTournamentSearchBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_tournament_search,
                        parent,
                        false
                    )
                return ViewHolderTournament(binding)
            }
            else -> {
                val binding: AdapterArticlesDataBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_articles_data,
                        parent,
                        false
                    )
                return ViewHolderArticleAndVideo(binding)
            }

        }
    }

    /**
     * @desc search result array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return searchResultList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return searchResultList[position].key!!
    }


    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderTournament).bind(searchResultList[position])
            }
            else -> {
                (holder as ViewHolderArticleAndVideo).bind(searchResultList[position])
            }
        }
    }

    /**
     * @desc this call will use tournament data
     */
    inner class ViewHolderTournament(private var binding: AdapterTournamentSearchBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(customSearchResultModel: CustomSearchResultModel) {
            /*  val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
                  customSearchResultModel.tournamentList?.forEach {
                      fragmentList.add(
                          Pair(
                              SearchTournamentFragment.newInstance(it.tournamentList!!,it.title.toString()),
                              it.title.toString()
                          )
                      )
              }*/
            binding.textViewTitle.text = customSearchResultModel.title.toString().toUpperCase()
            /* val commonPagerAdapter = CommonPagerAdapter(fragmentList, fragmentManager)
             binding.viewPagerTournament.adapter = commonPagerAdapter
             binding.viewPagerTournament.isNestedScrollingEnabled = false*/


            val adapter = TournamentOptionSpinnerAdapter(context, tournamentResultList)
            binding.tabLayoutTournament.adapter = adapter
            binding.tabLayoutTournament.onItemSelectedListener =
                object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>?,
                        view: View?,
                        position: Int,
                        id: Long
                    ) {
                        val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
                        customSearchResultModel.tournamentList?.forEach {
                            when(position)
                             {
                                0 ->   fragmentList.add(
                                    Pair(
                                        UpcomingTournamentFragment.newInstance(),
                                        context.resources.getString(R.string.upcoming)
                                    )
                                )

                                1->fragmentList.add(

                                    Pair(
                                        OngoingTournamentFragment.newInstance(),
                                        context.resources.getString(R.string.ongoing)
                                    )
                                )

                                /*2->fragmentList.add(

                                    Pair(
                                        OngoingTournamentFragment.newInstance(),
                                        context.resources.getString(R.string.ongoing)
                                    )
                                )*/
                            }

                        }

                        val commonPagerAdapter = CommonPagerAdapter(fragmentList, fragmentManager)
                        binding.viewPagerTournament.adapter = commonPagerAdapter
                        binding.viewPagerTournament.isNestedScrollingEnabled = false

                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {
                        TODO("Not yet implemented")
                    }

                }


//            binding.viewPagerTournament.addOnPageChangeListener(object : ViewPager.OnPageChangeListener{
//                override fun onPageScrolled(
//                    position: Int,
//                    positionOffset: Float,
//                    positionOffsetPixels: Int
//                ) {
//
//                }
//
//                override fun onPageSelected(position: Int) {
//                    binding.viewPagerTournament.reMeasureCurrentPage(position)
//                }
//
//                override fun onPageScrollStateChanged(state: Int) {
//
//                }
//
//            })
        }


    }

    /**
     * @desc this call will use article data
     */
    inner class ViewHolderArticleAndVideo(private var binding: AdapterArticlesDataBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(customSearchResultModel: CustomSearchResultModel) {
            binding.textViewTitle.text = customSearchResultModel.title.toString().toUpperCase()
            binding.recyclerViewArticleTypes.layoutManager =
                LinearLayoutManager(binding.root.context, LinearLayoutManager.HORIZONTAL, false)
            binding.btnViewAll.beGone()
            if (customSearchResultModel.key == 1) {
                binding.btnViewAll.click {
                    onViewAllItemClick("", 0)
                }
                val searchArticlePostAdapter =
                    SearchArticlePostAdapter(customSearchResultModel.articleList!!, onItemClick = {
                        onItemClick(it, 0)
                    })
                binding.recyclerViewArticleTypes.adapter = searchArticlePostAdapter
                if (customSearchResultModel.articleList.isNullOrEmpty()) {
                    binding.recyclerViewArticleTypes.beGone()
//                    binding.btnViewAll.beGone()
                    binding.textViewNoData.beVisible()
                } else {
                    binding.recyclerViewArticleTypes.beVisible()
//                    binding.btnViewAll.beVisible()
                    binding.textViewNoData.beGone()
                }

            } else {
                binding.btnViewAll.click {
                    onViewAllItemClick("", 1)
                }

                val searchArticlePostAdapter =
                    SearchVideoAdapter(customSearchResultModel.videoList!!, onItemClick = {
                        onItemClick(it, 1)
                    })
                binding.recyclerViewArticleTypes.adapter = searchArticlePostAdapter
                if (customSearchResultModel.videoList.isNullOrEmpty()) {
                    binding.recyclerViewArticleTypes.beGone()

                    binding.textViewNoData.beVisible()
                } else {
                    binding.recyclerViewArticleTypes.beVisible()

                    binding.textViewNoData.beGone()
                }

            }


        }


    }


}