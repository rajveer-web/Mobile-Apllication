package com.dynasty.esports.view.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.HomeAdapterPostTrendingBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.GamesModel
import com.dynasty.esports.utils.BindingHolder

class HomeArticlePostGamesAdapter constructor(
    private var postGamesList: MutableList<GamesModel.DataModel>,
    private val onItemClick: (String,String) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<HomeAdapterPostTrendingBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<HomeAdapterPostTrendingBinding> {
        val binding: HomeAdapterPostTrendingBinding =
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.home_adapter_post_trending,
                parent,
                false
            )
        return BindingHolder(binding)

    }

    override fun getItemCount(): Int {
        return postGamesList.size
    }


    override fun onBindViewHolder(holder: BindingHolder<HomeAdapterPostTrendingBinding>, position: Int) {
        val data = postGamesList[holder.adapterPosition]
        data.image?.apply {
            holder.itemView.context.loadImageFromServer(this, holder.binding.imageViewBackground)
        }

        holder.binding.topcardview.click {
            onItemClick(data.id.toString(), data.name.toString())
        }
        holder.binding.textViewGameName.text = data.name?.let {
            it
        } ?: ""

    }
}

