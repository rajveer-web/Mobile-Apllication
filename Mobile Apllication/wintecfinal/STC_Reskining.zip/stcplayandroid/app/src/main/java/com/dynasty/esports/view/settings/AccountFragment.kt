package com.dynasty.esports.view.settings

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.otp_verification.OTPVerificationActivity
import com.dynasty.esports.viewmodel.AccountViewModel
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.FacebookSdk
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import kotlinx.android.synthetic.main.fragment_account.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will show search tournament list
 * @author : Mahesh Vayak
 * @created : 25-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class AccountFragment : BaseFragment() {
    lateinit var gso: GoogleSignInOptions
    val mViewModel: AccountViewModel by viewModel() // inject view model
    lateinit var mGoogleSignInClient: GoogleSignInClient
    val RC_SIGN_IN: Int = 1
    var loginType = ""

    private var mCallbackManager: CallbackManager? = null
    private var isEdit = false
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        /**
         *  Initialize view and facebook sdk and callback factory
         */
        FacebookSdk.sdkInitialize(requireContext())
        mCallbackManager = CallbackManager.Factory.create()
        LoginManager.getInstance().registerCallback(mCallbackManager,
            object : FacebookCallback<LoginResult?> {
                override fun onSuccess(loginResult: LoginResult?) {
                    loginResult?.apply {
                        requireActivity().runOnUiThread {
                            loginType = "FACEBOOK"
                            mViewModel.makeJsonForAddSocial(
                                loginResult.accessToken.token.toString(),
                                loginType
                            )
                        }
                    }

                }

                override fun onCancel() {
                    "Login Cancel".showToast(requireActivity())
                }

                override fun onError(exception: FacebookException) {

                    resources.getString(R.string.some_thing_went_wrong)
                        .showToast(requireActivity())
                }
            })

        /**
         *  Initialize google sign in options
         */
        gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        mGoogleSignInClient = GoogleSignIn.getClient(requireActivity(), gso)

        return inflater.inflate(R.layout.fragment_account, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        enableDisableView()
        listenToPref()

        textViewEdit.click {
            isEdit = true
            enableDisableView()
        }
        buttonCancel.click {
            isEdit = false
            enableDisableView()
        }

        imageViewFb.click {
            fbLogin()
        }

        imageViewGoogle.click {
            googleLogin()
        }

        buttonSave.click {
            mViewModel.checkFormValidation(editTextEmail.text.toString().trim())
        }

        listenToViewModel()

    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make json object for API and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.validationLiveData.observe(viewLifecycleOwner, Observer {
            when(it){
                0->{
                    requireActivity().makeSnackBar(constraintLayoutAccount,resources.getString(R.string.email_error))
                }
                1->{
                    requireActivity().makeSnackBar(constraintLayoutAccount,resources.getString(R.string.email_valid_error))
                }
            }

        })

        mViewModel.isFormValid.observe(viewLifecycleOwner, Observer {
            if(it){
                mViewModel.makeJsonForUpdateEmail(editTextEmail.text.toString().trim())
            }
        })

        mViewModel.jsonObjectForUpdateEmail.observe(viewLifecycleOwner, Observer {
            launchProgressDialog()
            mViewModel.updateUser(it)
        })

        mViewModel.updateUserSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            val bundle=Bundle()
            bundle.putString("email",editTextEmail.text.toString().trim())
            bundle.putString("type","email")
            bundle.putBoolean("isAccount",true)
            startActivityFromFragmentWithBundleCode<OTPVerificationActivity>(bundle,AppConstants.REFRESH_CODE)
        })

        mViewModel.updateUserErrorResponse.observe(viewLifecycleOwner, Observer {
            it.string().getMessageFromObject("message").showToast(requireContext())
            dismissProgressDialog()
        })

        mViewModel.jsonObjectForAddSocial.observe(viewLifecycleOwner, Observer {
            launchProgressDialog()
            mViewModel.addSocial(it)
        })

        mViewModel.addSocialSuccessResponse.observe(viewLifecycleOwner, Observer {
            commonViewModel.fetchUser()
        })
        mViewModel.addSocialErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            it.string().getMessageFromObject("message").showToast(requireContext())
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
        })

        commonViewModel.userSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            it?.data?.apply {
                sharedPreferences.id = this.id.toString()
                sharedPreferences.put("user", this)
            }
            listenToPref()
        })

        commonViewModel.userErrorResponse.observe(viewLifecycleOwner, Observer {
             it.string().getMessageFromObject("message").showToast(requireContext())
            dismissProgressDialog()
        })

        commonViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
        })

    }

    /**
     * @desc This method for listen shared preference data and display data
     */
    private fun listenToPref() {
        val data = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        data?.apply {
            textViewEdit.beVisible()
            buttonSave.beGone()
            buttonCancel.beGone()
            editTextEmail.beGone()
            textViewEmail.beVisible()

            if (this.phoneisVerified!!) {
                this.phoneNumber?.apply {
                    editTextPhone.text = this
                }
            }

            if (this.emailisVerified!!) {
                this.email?.apply {
                    textViewEmail.text=this
                    editTextEmail.setText(this)
                }
            }

            this.identifiers?.apply {
               this.forEach {
                   if(it.idenType=="FACEBOOK"){
                       imageViewFb.alpha=0.5f
                       imageViewFb.isEnabled=false
                   }else if(it.idenType=="GOOGLE"){
                       imageViewGoogle.alpha=0.5f
                       imageViewGoogle.isEnabled=false
                   }
               }
            }

        }
    }

    /**
     * @desc method will call when tap google signin option.
     */
    private fun googleLogin() {
        val signInIntent: Intent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        /**
         * @desc get callback from facebook and google
         */
        mCallbackManager?.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            data?.apply {
                val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(this)
                handleSignInResult(task)
            }

        }else if(requestCode==AppConstants.REFRESH_CODE){
            data?.apply {
                launchProgressDialog()
                commonViewModel.fetchUser()
            }
        }

    }

    /**
     * @desc get handler google signin result account.
     * @param task - google signin account response
     */
    private fun handleSignInResult(task: Task<GoogleSignInAccount>) {
        try {
            val account: GoogleSignInAccount = task.getResult(ApiException::class.java)!!
            val scope = "oauth2:" + Scopes.EMAIL + " " + Scopes.PROFILE
            AsyncTask.execute {
                account.account?.apply {
                    val token = GoogleAuthUtil.getToken(requireContext(), this, scope)
                    requireActivity().runOnUiThread {
                        loginType = "GOOGLE"
                        mViewModel.makeJsonForAddSocial(token, loginType)
                    }
                }
            }
        } catch (e: ApiException) {
            e.printStackTrace()
        }
    }

    /**
     * @desc this method will call when tap on fb icon
     * launch facebook popup for login
     */
    private fun fbLogin() {
        LoginManager.getInstance().logInWithReadPermissions(this, listOf("email", "public_profile"))
    }

    /**
     * @desc this method will use for enable and disable view.
     */
    private fun enableDisableView() {
        if (!isEdit) {
            textViewEdit.beVisible()
            editTextEmail.beGone()
            textViewEmail.beVisible()
            buttonSave.beGone()
            constraintLayoutAccountDetail.forEachChildView { it.isEnabled = false }
            buttonCancel.beGone()
        } else {
            textViewEmail.beGone()
            textViewEdit.beGone()
            editTextEmail.beVisible()
            buttonSave.beVisible()
            buttonCancel.beVisible()
            constraintLayoutAccountDetail.forEachChildView { it.isEnabled = true }
        }
    }


}