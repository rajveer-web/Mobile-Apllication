package com.dynasty.esports.view.forgot_password

import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.getMessageFromObject
import com.dynasty.esports.extenstion.hideKeyboard
import com.dynasty.esports.extenstion.makeSnackBar
import com.dynasty.esports.extenstion.showToast
import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.models.LoginRequest
import com.dynasty.esports.utils.Validator
import com.dynasty.esports.viewmodel.ForgotPasswordMobileFragmentViewModel
import kotlinx.android.synthetic.main.activity_create_password.*
import kotlinx.android.synthetic.main.content_create_password_screen.*
import kotlinx.android.synthetic.main.fragment_change_password.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ChangePasswordFragment : ForgotPasswordPageFragment() {
    lateinit var mRequest: ForgotPasswordRequest
    var cnfirmPassword = false
    val mViewModel: ForgotPasswordMobileFragmentViewModel by viewModel()

    fun displayReceivedData(message: ForgotPasswordRequest) {
//        txtData.setText("Data received: $message")
        Log.d("Data Received : ", "yipeee $message forgotpass 2 data")
        mRequest.phoneNumber =  message.phoneNumber
        mRequest.type = message.type
        mRequest.phoneOTP = message.phoneOTP
        mRequest.email = message.email
        mRequest.emailOTP = message.emailOTP
    }

    override fun getPageType(): ForgotPasswordMobileActivity.ForgotPasswordWizardPageType {
        return ForgotPasswordMobileActivity.ForgotPasswordWizardPageType.CHANGE_PASSWORD
    }

    override fun onNextButtonClick() {
        mViewModel.checkPasswordNConfirmPassword(new_password_edit_text.text.toString().trim(),
            new_confirm_password_edit_text.text.toString().trim())
    }

    override fun shouldEnableButton(): Boolean {
        TODO("Not yet implemented")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_change_password, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            ChangePasswordFragment()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenToViewModel()
        initialise()
    }

    private fun listenToViewModel() {

        mViewModel.validationLiveData.observe(requireActivity(), Observer {
            when (it) {
                0 -> {
                    requireActivity().makeSnackBar(
                        constraintLayoutForgotChangePassword,
                        resources.getString(R.string.create_password_error)
                    )
                }
                1 -> {
                    requireActivity().makeSnackBar(constraintLayoutForgotChangePassword, resources.getString(R.string.confirm_passsword_error))
                }
                2 -> {
                    requireActivity().hideKeyboard()
                    Validator.PASSWORD_POLICY.showToast(requireActivity())
                }
                3 -> {
                    requireActivity().hideKeyboard()
                    Validator.PASSWORD_POLICY.showToast(requireActivity())
                }
                4 -> {
                    requireActivity(). hideKeyboard()
                    requireActivity().makeSnackBar(constraintLayoutForgotChangePassword, resources.getString(R.string.passwrd_not_matching))
                }
            }
        })

        mViewModel.isFormValid.observe(requireActivity(), {
            launchProgressDialog()
            mRequest.apply {
                this.phoneNumber = mRequest.phoneNumber
                this.email = mRequest.email
                this.type = "update"
                this.phoneOTP = mRequest.phoneOTP
                this.emailOTP =  mRequest.emailOTP
                this.password = new_confirm_password_edit_text.text.toString()
            }
            mForgotPasswordWizard!!.sendDataToSuccessfulFragment(mRequest)
            mViewModel.emailOrMobileNosVerification(mRequest)
        })

        mViewModel.confirmPasswordObserver.observe(viewLifecycleOwner, {
            if(new_password_edit_text.text.toString() == new_confirm_password_edit_text.text.toString()){
                mRequest.apply {
                    this.phoneNumber = mRequest.phoneNumber
                    this.email = mRequest.email
                    this.type = "update"
                    this.phoneOTP = mRequest.phoneOTP
                    this.emailOTP =  mRequest.emailOTP
                    this.password = new_confirm_password_edit_text.text.toString()
                }
                mForgotPasswordWizard!!.sendDataToSuccessfulFragment(mRequest)
                mViewModel.emailOrMobileNosVerification(mRequest)
             //   mForgotPasswordWizard!!.nextPage()
            }else{
                resources.getString(R.string.passwrd_not_matching).showToast(requireContext())
//                Toast.makeText(
//                    context,

//                    ,
//                    Toast.LENGTH_SHORT
//                ).show()
            }
        })

        mViewModel.phoneOrEmailVerificationSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            mForgotPasswordWizard!!.nextPage()
            it.string().getMessageFromObject("message").showToast(requireContext())
        })

        mViewModel.phoneOrEmailVerificationErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            it.string().getMessageFromObject("message").showToast(requireContext())

        })
    }

    private fun initialise() {
        mRequest = ForgotPasswordRequest()

        new_password_edit_text.onRightDrawableClicked {
            if(showPassword){
                showPassword = false
                new_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(requireContext(),R.drawable.ic_baseline_visibility_off_24), null)
                new_password_edit_text.transformationMethod = PasswordTransformationMethod.getInstance()
            }else{
                showPassword = true
                new_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(requireContext(),R.drawable.ic_password_show), null)
                new_password_edit_text.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
        }

        new_confirm_password_edit_text.onConfirmDrawableClicked {
            if(cnfirmPassword){
                cnfirmPassword = false
                new_confirm_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(requireContext(),R.drawable.ic_baseline_visibility_off_24), null)
                new_confirm_password_edit_text.transformationMethod = PasswordTransformationMethod.getInstance()
            }else{
                cnfirmPassword = true
                new_confirm_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(requireContext(),R.drawable.ic_password_show), null)
                new_confirm_password_edit_text.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
        }
    }
}