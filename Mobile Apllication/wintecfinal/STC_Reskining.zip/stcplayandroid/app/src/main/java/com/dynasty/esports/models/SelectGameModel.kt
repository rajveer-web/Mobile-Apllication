package com.dynasty.esports.models

import android.widget.ImageView
import com.google.gson.annotations.SerializedName

data class SelectGameModel(
    @field:SerializedName("gameName")
    var gameName: String? = null,

    @field:SerializedName("gameImage")
    //var gameImage : ImageView? = null
    var gameImage: Int? = null,

    var isSelected: Boolean = false

)