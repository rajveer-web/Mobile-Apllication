package com.dynasty.esports.view.esport

import android.graphics.Rect
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.HottestPostArticleModel
import kotlinx.android.synthetic.main.select_game_list_item.view.*

class HottestGameAdapter (var listOfGame: MutableList<HottestPostArticleModel.DataModel>, var listener: OnItemClickListener) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var listOfGames : MutableList<HottestPostArticleModel.DataModel>
    var listenerr : OnItemClickListener

    init {
        this.listOfGames = listOfGame
        this.listenerr = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SelectGameViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.select_game_list_item, parent, false)
        )
    }

    override fun getItemCount(): Int = listOfGames.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val gameViewHolder = viewHolder as SelectGameViewHolder
        gameViewHolder.bindView(listOfGames[position],listenerr)
    }

    fun setGameList(listOfMovies: List<HottestPostArticleModel.DataModel>/*,  listener : View.OnClickListener*/) {
        listOfGames = listOfMovies.toMutableList()
        notifyDataSetChanged()
    }

    fun addMoreData(listOfMovies: List<HottestPostArticleModel.DataModel>) {
        this.listOfGames.addAll(listOfMovies)
        notifyDataSetChanged()
    }

    class SelectGameViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(
            gameModel: HottestPostArticleModel.DataModel,
            listenerr: OnItemClickListener
        ) {
            itemView.game_name.text = gameModel.game
            itemView.context.loadImageFromServer(gameModel.image.toString(),itemView.game_image)
//            Glide.with(itemView.context).load(gameModel.image!!).into(itemView.game_image)
            itemView.setOnClickListener {
                listenerr.onItemClick(gameModel.game)
            }
        }
    }

    class VerticalSpaceItemDecoration(private val verticalSpaceHeight: Int) : RecyclerView.ItemDecoration() {
        override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView,
                                    state: RecyclerView.State) {
            outRect.bottom = verticalSpaceHeight
        }
    }

    interface OnItemClickListener {
        fun onItemClick(gameName: String?)
    }
}