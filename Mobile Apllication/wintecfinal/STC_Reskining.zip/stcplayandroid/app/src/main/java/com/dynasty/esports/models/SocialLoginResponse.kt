package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class SocialLoginResponse(
    @field:SerializedName("data")
    val data : SocialDataResponse? = null,
    @field:SerializedName("message")
    val message :String? = null,
    @field:SerializedName("code")
    val code:String? =null
)
