package com.dynasty.esports.view.bookmark

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.BookmarkModel
import com.dynasty.esports.view.article.article_detail.ArticlesDetailActivity
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.BookmarkViewModel
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will use for display bookmark article and videos
 * @author : Mahesh Vayak
 * @created : 27-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BookmarkArticleVideoFragment : BaseFragment() {
    private val mViewModel: BookmarkViewModel by viewModel() // inject bookmark view model
    private var videoList: MutableList<BookmarkModel.VideoBookMark> =
        mutableListOf() // define video list array
    private var articleList: MutableList<BookmarkModel.ArticleBookmark> =
        mutableListOf() // define article list array
    private var type: String = ""
    private var articleAdapter: ArticleBookmarkAdapter? = null // define article adapter
    private var videoAdapter: VideoBookmarkAdapter? = null // define video adapter
    private var position: Int = -1
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.recycler_progress_bar_view, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        listenToViewModel()
    }

    /**
     * @desc listen observer that will receive the events
     * Manage API success and failure,Internet connectivity and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.deleteBookMarkSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            if (type == "video") {
                videoList.removeAt(position)
                videoAdapter?.apply {
                    this.notifyItemRemoved(position)
                }
                notifyVideoNoDataView()
            } else {
                articleList.removeAt(position)
                articleAdapter?.apply {
                    this.notifyItemRemoved(position)
                }
                notifyArticleNoDataView()
            }

        })
        mViewModel.deleteBookMarkErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            displayCustomAlertDialog(
                it.string().getMessageFromObject("message"),
                isCancelable = false,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })
        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it)
                logOut()
        })
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            if (requireActivity().isOnline()) {
                displayCustomAlertDialog(
                    resources.getString(R.string.something_wrong_try_again),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.btn_ok),
                    positiveClick = {
                        it.dismiss()
                    })
            } else {
                displayCustomAlertDialog(
                    resources.getString(R.string.no_internet_message),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.btn_ok),
                    positiveClick = {
                        it.dismiss()
                    })
            }
        })

        mViewModel.makeQueryParameterForBookMark.observe(viewLifecycleOwner, Observer {
            launchProgressDialog()
            mViewModel.deleteBookmark(it)
        })
    }

    /**
     * @desc This method will call from Bookmark fragment when get articles from API.
     * And assign article array to adapter
     * @param articleList - Articles array list
     */
    fun notifyArticle(articleList: MutableList<BookmarkModel.ArticleBookmark>) {
        linearLayoutProgressBar.beGone()
        this.articleList.addAll(articleList)
        articleAdapter = ArticleBookmarkAdapter(this.articleList, onDeleteItemClick = { position ->
            displayCustomAlertDialog(
                title = resources.getString(R.string.delete),
                desc = resources.getString(R.string.delete_bookmark_msg),
                positiveText = resources.getString(R.string.delete),
                negativeText = resources.getString(android.R.string.cancel),
                positiveClick = {
                    it.dismiss()
                    type = "article"
                    this.position = position
                    mViewModel.makeQueryParameter("articleId", articleList[position].id.toString())

                },
                negativeClick = {
                    it.dismiss()
                })

        }, onItemClick = ::onArticleClick)
        commonRecyclerView.adapter = articleAdapter
        notifyArticleNoDataView()
    }

    private fun onArticleClick(id: String, position: Int) {
        this.position = position
        val bundle = Bundle()
        bundle.putString("id", id)
        bundle.putBoolean("isBookMarkDeleted", false)
        startActivityFromFragmentWithBundleCode<ArticlesDetailActivity>(
            bundle,
            AppConstants.REFRESH_CODE
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (AppConstants.REFRESH_CODE == requestCode) {
            data?.apply {
                articleList.removeAt(position)
                articleAdapter?.apply {
                    notifyDataSetChanged()
                }
                notifyArticleNoDataView()
            }
        }
    }

    /**
     * @desc This method will call from Bookmark fragment when get videos from API.
     * And assign videos array to adapter
     * @param videoList - Video articles array list
     */
    fun notifyVideo(videoList: MutableList<BookmarkModel.VideoBookMark>) {
        linearLayoutProgressBar.beGone()
        this.videoList.addAll(videoList)
        videoAdapter = VideoBookmarkAdapter(this.videoList, onDeleteItemClick = { position ->
            displayCustomAlertDialog(
                title = resources.getString(R.string.delete),
                desc = resources.getString(R.string.delete_bookmark_msg),
                positiveText = resources.getString(R.string.delete),
                negativeText = resources.getString(android.R.string.cancel),
                positiveClick = {
                    it.dismiss()
                    type = "video"
                    this.position = position
                    mViewModel.makeQueryParameter(
                        "videoLibraryId",
                        videoList[position].id.toString()
                    )

                },
                negativeClick = {
                    it.dismiss()
                })

        }, onItemClick = {
            val videoClient = Intent(Intent.ACTION_VIEW)
            videoClient.data = Uri.parse(it)
            requireActivity().startActivity(videoClient)
        })
        commonRecyclerView.adapter = videoAdapter
        notifyVideoNoDataView()

    }

    fun notifyVideoNoDataView() {
        linearLayoutProgressBar.beGone()
        if (this.videoList.isNullOrEmpty()) {
            constraintLayoutNoData.beVisible()
            commonRecyclerView.beGone()
        } else {
            commonRecyclerView.beVisible()
            constraintLayoutNoData.beGone()
        }

    }

    fun notifyArticleNoDataView() {
        linearLayoutProgressBar.beGone()
        if (this.articleList.isNullOrEmpty()) {
            constraintLayoutNoData.beVisible()
            commonRecyclerView.beGone()
        } else {
            commonRecyclerView.beVisible()
            constraintLayoutNoData.beGone()
        }
    }

    /**
     * @desc This method will call from Bookmark fragment when get internet connectivity from receiver.
     * Manage UI base on internet connection
     * @param isInternet - (true/false internet connection)
     */
    fun notifyInternet(isInternet: Boolean) {
        if (isInternet) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
        } else {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }

    /**
     * @desc This method will call from Bookmark fragment when get error from API.
     */
    fun notifyError() {
        linearLayoutProgressBar.beGone()
        constraintLayoutNoData.beGone()
        constraintLayoutErrorView.beVisible()
        constraintLayoutNoInternet.beGone()

    }

    /**
     * @desc make fragment instance and pass data in arguments
     */
    companion object {
        fun newInstance(type: String): Fragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = BookmarkArticleVideoFragment()
            fragment.arguments = args
            return fragment
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }
}

