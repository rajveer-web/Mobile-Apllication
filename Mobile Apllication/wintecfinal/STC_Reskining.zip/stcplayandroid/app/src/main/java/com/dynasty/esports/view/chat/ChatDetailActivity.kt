package com.dynasty.esports.view.chat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.widget.doAfterTextChanged
import androidx.core.widget.doOnTextChanged
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.application.DynastyApplication
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ChatMessageListModel
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.viewmodel.ChatViewModel
import com.dynasty.esports.viewmodel.CommonViewModel
import kotlinx.android.synthetic.main.activity_chat_detail.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.json.JSONObject
import org.koin.androidx.viewmodel.ext.android.viewModel

class ChatDetailActivity : BaseActivity(), ConnectivityReceiver.ConnectivityReceiverListener {
    private lateinit var msgReceiver: NodeReceiver
    private var messageList: MutableList<ChatMessageListModel> = mutableListOf()
    private var connectivityReceiver = ConnectivityReceiver()// define connection receiver
    private val mViewModel: ChatViewModel by viewModel()
    private var chatDetailAdapter: ChatDetailAdapter? = null
    private var matchID: String = ""
    private var tournamentID: String = ""
    private var loginUserModel: UserModel.UserData? = null
    private var mHandler: Handler? = null
    private val TYPING_TIME_OUT = 800

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_detail)
        loginUserModel = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        val intentFilter = IntentFilter()
        intentFilter.addAction(AppConstants.NOTIFY_START_TYPING)
        intentFilter.addAction(AppConstants.NOTIFY_START_TYPING)
        intentFilter.addAction(AppConstants.NOTIFY_RECEIVE_MESSAGE)
        msgReceiver = NodeReceiver()
        LocalBroadcastManager.getInstance(this@ChatDetailActivity).registerReceiver(msgReceiver, intentFilter)
        mHandler = Handler()
        getNewData()
        initView()
        listenToViewModel()
    }

    private fun getNewData() {
        intent?.apply {
            this.extras?.apply {
                matchID = this.getString("matchId").toString()
                tournamentID = this.getString("tournamentId").toString()
            }
        }
    }

    private fun initView() {
        imageViewBack.click {
            onBackPressed()
        }

        linearLayoutProgressBar.beGone()
        commonRecyclerView.layoutManager = LinearLayoutManager(this)
        chatDetailAdapter = ChatDetailAdapter(messageList)
        commonRecyclerView.adapter = chatDetailAdapter

        editTextMessage.doAfterTextChanged {
            if (editTextMessage.text.toString().trim() == "") {
                buttonSubmit.alpha = 0.5f
                buttonSubmit.isEnabled = false
            } else {
                buttonSubmit.alpha = 1f
                buttonSubmit.isEnabled = true
            }
//            Handler(Looper.myLooper()).postDelayed({
                (this.application as DynastyApplication).socketEmit(
                    "stopTyping",
                    makeJsonObjectForTyping()
                )
//            },2000)

        }

        editTextMessage.doOnTextChanged { text, start, before, count ->
            if (count > 0) {
                Log.d("Hello",matchID)
                (this.application as DynastyApplication).socketEmit(
                    "typing",
                    makeJsonObjectForTyping()
                );
            } else {
                (this.application as DynastyApplication).socketEmit(
                    "stopTyping",
                    makeJsonObjectForTyping()
                )
            }
        }


        buttonSubmit.click {
            Log.d("Hello",convertTimeStamp(getCurrentDateTime()).toString())
            val jsonObject = JSONObject()
            jsonObject.put("matchid", matchID)
            jsonObject.put("tournamentid", tournamentID)
            jsonObject.put("fullName", loginUserModel?.fullName)
            jsonObject.put("userid", loginUserModel?.id)
            jsonObject.put("msg", editTextMessage.text.toString().trim())
            jsonObject.put("messagetype", "text")
            jsonObject.put("updatedAt", convertTimeStamp(getCurrentDateTime()))
            (this.application as DynastyApplication).sendMessage(jsonObject)
            editTextMessage.setText("")
            (this.application as DynastyApplication).socketEmit(
                "stopTyping",
                makeJsonObjectForTyping()
            )
        }
    }


    private fun listenToViewModel() {
        mViewModel.chatListSuccessResponse.observe(this, {
            messageList.clear()
            messageList.addAll(it)
            chatDetailAdapter?.apply {
                notifyDataSetChanged()
                commonRecyclerView.scrollToPosition(messageList.size - 1)
            }

        })

        mViewModel.chatListErrorResponse.observe(this, {

        })

        mViewModel.unAuthorizationException.observe(this, {

        })

        mViewModel.noInternetException.observe(this, {

        })
    }

    var typingRunnable = Runnable { textViewTyping.text="" }

    internal inner class NodeReceiver : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {

            try {

                if (intent.action!!.equals(AppConstants.NOTIFY_START_TYPING, ignoreCase = true)) {
                    mHandler?.removeCallbacks(typingRunnable)
                    val result = intent.getStringExtra("data").toString()
                    textViewTyping.text=result.getMessageFromObject("fullName").plus(" ").plus(resources.getString(R.string.typing))
                  //  textViewTyping.beVisible()
                    mHandler?.postDelayed(typingRunnable, TYPING_TIME_OUT.toLong())
                }
                if (intent.action!!.equals(AppConstants.NOTIFY_STOP_TYPING, ignoreCase = true)) {
                    mHandler?.removeCallbacks(typingRunnable)
//                    runOnUiThread {
                      //  textViewTyping.text=""
//                    }
                }
                if (intent.action!!.equals(AppConstants.NOTIFY_RECEIVE_MESSAGE, ignoreCase = true)) {
                    val result = intent.getStringExtra("data").toString()
                    val chatMessageListModel = ChatMessageListModel()
                    chatMessageListModel.fullName = result.getMessageFromObject("fullName")
                    chatMessageListModel.matchid = result.getMessageFromObject("matchid")
                    chatMessageListModel.tournamentid = result.getMessageFromObject("tournamentid")
                    chatMessageListModel.userid = result.getMessageFromObject("userid")
                    chatMessageListModel.msg = result.getMessageFromObject("msg")
                    chatMessageListModel.messagetype = result.getMessageFromObject("messagetype")
                    chatMessageListModel.updatedAt = getDateFromTimestamp(result.getMessageFromObject("updatedAt").toLong())
                    messageList.add(messageList.size, chatMessageListModel)
                    chatDetailAdapter?.apply {
                        notifyDataSetChanged()
                        commonRecyclerView.scrollToPosition(messageList.size - 1)
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onDestroy() {
        try {
            (this.application as DynastyApplication).socketEmit("matchDisconnected", matchID)
            LocalBroadcastManager.getInstance(applicationContext)
                .unregisterReceiver(msgReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }

    // Register receiver for check internet connection
    override fun onResume() {
        super.onResume()
        registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    // Unregister receiver for internet connection
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            unregisterReceiver(connectivityReceiver)
        }
    }

    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected) {
            (this.application as DynastyApplication).socketEmit("matchConnected", matchID)
            if (messageList.isNullOrEmpty()) {
                mViewModel.getAllChatList(matchID)
            }
        } else {

        }
    }

    private fun makeJsonObjectForTyping(): JSONObject {
        Log.d("Hello",matchID)
        val jsonObject = JSONObject()
        jsonObject.put("matchid", matchID)
        jsonObject.put("fullName", loginUserModel?.fullName)
        jsonObject.put("userid", loginUserModel?.id)
        return jsonObject
    }


}