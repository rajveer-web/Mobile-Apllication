package com.dynasty.esports.view.article.article_section

import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.isOnline
import com.dynasty.esports.models.VideosModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.utils.RecyclerViewLoadMoreScroll
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.viewmodel.ArticleVideoViewModel
import kotlinx.android.synthetic.main.activity_view_videos.*
import kotlinx.android.synthetic.main.article_app_bar_layout.*
import kotlinx.android.synthetic.main.article_app_bar_layout.toolbar
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ViewAllVideoActivity : BaseActivity(), ConnectivityReceiver.ConnectivityReceiverListener {
    private val mViewModel: ArticleVideoViewModel by viewModel() // inject video viewmodel
    private var isLoadedAllItems: Boolean = false
    private var videoList: MutableList<VideosModel.DocModel> =
        mutableListOf() // define bracket list
    private lateinit var scrollListener: RecyclerViewLoadMoreScroll
    private var connectivityReceiver = ConnectivityReceiver()
    var page = 1
    lateinit var articleVideoAdapter: ArticleVideoAdapter
    private lateinit var layoutManager: LinearLayoutManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_videos)
        initView()
        setUpToolBar()
        listenToViewModel()
    }


    /**
     * @desc set up toolbar with empty title
     */
    private fun setUpToolBar() {
        toolbar.title = resources.getString(R.string.all_videos)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }


    /**
     * @desc Initialize view and assign bracket adapter to recyclerview
     */
    private fun initView() {
        layoutManager = LinearLayoutManager(this)
        commonRecyclerView.layoutManager = layoutManager
        articleVideoAdapter = ArticleVideoAdapter(videoList,onItemClick = ::onVideoClick)
        commonRecyclerView.adapter = articleVideoAdapter
        scrollListener = RecyclerViewLoadMoreScroll(layoutManager)
        setLoadMoreListener()

    }

    /**
     * @desc method will call when tap on video article from article adapter and redirect to youtube
     * @param url article video url
     */
    private fun onVideoClick(url: String) {
        val videoClient = Intent(Intent.ACTION_VIEW)
        videoClient.data = Uri.parse(url)
        startActivity(videoClient)
    }


    /**
     * @desc Identify need to load more data or not.
     */
    private fun setLoadMoreListener() {
        scrollListener.setOnLoadMoreListener(object :
            RecyclerViewLoadMoreScroll.OnLoadMoreListener {
            override fun onLoadMore() {
                if (!isLoadedAllItems) {
                    onLoadMoreBracket()
                }
            }
        })
        commonRecyclerView.addOnScrollListener(scrollListener)
    }

    /**
     * @desc remove dummy view in array list and show progress bar
     */
    private fun onLoadMoreBracket() {
        val model = VideosModel.DocModel()
        model.isLoadMore = true
        videoList.add(model)
        commonRecyclerView.post {
            articleVideoAdapter.apply {
                notifyItemInserted(videoList.size - 1)
            }
            mViewModel.makeJsonForVideoParameter(page)
        }
    }

    /**
     * @desc remove dummy view from array list and hide progress bar
     */
    private fun stopLoadMore() {
        scrollListener.setLoaded()
        videoList.removeAt(videoList.size - 1)
        commonRecyclerView.post {
            articleVideoAdapter.apply {
                notifyDataSetChanged()
            }
        }

    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make jsonobject for API and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.makeJsonForArticleData.observe(this, Observer {
            mViewModel.getAllArticleVideos(it.toString())
        })

        mViewModel.latestVideoSuccessResponse.observe(this, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()

            it?.data?.apply {

                if (!videoList.isNullOrEmpty()) {
                    stopLoadMore()
                }
                if (!this.hasNextPage!!) {
                    isLoadedAllItems = true
                }

                this.docs?.apply {
                    videoList.addAll(this)
                }
                if (page == 1 && videoList.isEmpty()) {
                    constraintLayoutNoData.beVisible()
                    commonRecyclerView.beGone()
                } else {
                    articleVideoAdapter.notifyDataSetChanged()
                    this@ViewAllVideoActivity.page += 1
                }
            }

        })
        mViewModel.latestVideoErrorResponse.observe(this, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
        })


        mViewModel.noInternetException.observe(this, Observer {
            if (isOnline()) {
                if (!videoList.isNullOrEmpty()) {
                    displayCustomAlertDialog(
                        resources.getString(R.string.something_wrong_try_again),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.retry),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForVideoParameter(page)
                        })
                }
            } else {
                if (!videoList.isNullOrEmpty()) {
                    displayCustomAlertDialog(
                        resources.getString(R.string.no_internet_message),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.retry),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForVideoParameter(page)
                        })
                }
            }
        })
        mViewModel.unAuthorizationException.observe(this, Observer {
            if (it) {
                mViewModel.onDetach()
                logOut()
            }
        })

    }


    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc UnRegister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && videoList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beGone()
            constraintLayoutErrorView.beGone()
            mViewModel.makeJsonForVideoParameter(page)
        } else if (videoList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutErrorView.beGone()
        }
    }
}