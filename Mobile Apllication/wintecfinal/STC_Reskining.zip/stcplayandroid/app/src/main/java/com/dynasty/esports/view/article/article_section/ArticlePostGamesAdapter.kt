package com.dynasty.esports.view.article.article_section


import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterPostTrendingBinding
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.RowAuthorListArticleBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.ArticleAuthorsModel
import com.dynasty.esports.models.GamesModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.view.common.LoadingViewHolder
import kotlin.concurrent.thread

/**
 * @desc this is class will handle list of article author
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ArticlePostGamesAdapter constructor(
    private var postGamesList: MutableList<GamesModel.DataModel>,
    private val onItemClick: (String,String) -> Unit = { _,_ -> }) :     RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: AdapterPostTrendingBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_post_trending,
                        parent,
                        false
                    )
                return ViewHolderGames(binding)
            }
            else -> {
                val binding: ItemLoadMoreBinding =
                    DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
                return LoadingViewHolder(binding)
            }

        }
    }



    override fun getItemCount(): Int {
        return postGamesList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (postGamesList[position].isLoadMore) {
            1
        } else {
            0
        }
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderGames).bind(postGamesList[position])
            }
            else -> {
                (holder as LoadingViewHolder).progressBar.isIndeterminate = true
            }
        }
    }


    /**
     *@desc This call use for display Video data
     */
    inner class ViewHolderGames(private var binding: AdapterPostTrendingBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: GamesModel.DataModel) {

            data.logo?.apply {
                itemView.context.loadImageFromServer(
                    this,
                    binding.imageViewBackground
                )
            }


            binding.topcardview.click {
                onItemClick(data.id.toString(),data.name.toString())
            }
            binding.textViewGameName.text=data.name?.let {
                it
            } ?: ""
        }

    }

}