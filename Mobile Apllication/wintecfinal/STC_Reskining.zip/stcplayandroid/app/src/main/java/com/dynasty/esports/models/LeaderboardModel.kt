package com.dynasty.esports.models

import com.bignerdranch.expandablerecyclerview.model.Parent
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class LeaderboardModel {

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("data")
    @Expose
    var data: Data? = null

    class Data {
        @SerializedName("leaderboardData")
        @Expose
        var leaderboardData: List<LeaderboardDatum> = ArrayList<LeaderboardDatum>()
    }


    class LeaderboardDatum : Parent<LeaderboardDatumChild> {
        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("userId")
        @Expose
        var userId: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String? = null

        @SerializedName("country")
        @Expose
        var country: String = ""

        @SerializedName("points")
        @Expose
        var points = ""

        @SerializedName("firstPosition")
        @Expose
        var firstPosition = ""

        @SerializedName("secondPosition")
        @Expose
        var secondPosition = ""

        @SerializedName("thirdPosition")
        @Expose
        var thirdPosition = ""

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("__v")
        @Expose
        var v = 0

        var leaderboardDataChild: ArrayList<LeaderboardDatumChild> = ArrayList<LeaderboardDatumChild>()

        override fun getChildList(): List<LeaderboardDatumChild> {
            return leaderboardDataChild
        }

        override fun isInitiallyExpanded(): Boolean {
            return false
        }


    }

    class LeaderboardDatumChild {
        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("userId")
        @Expose
        var userId: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String? = null

        @SerializedName("country")
        @Expose
        var country: Any? = ""

        @SerializedName("points")
        @Expose
        var points = ""

        @SerializedName("firstPosition")
        @Expose
        var firstPosition = ""

        @SerializedName("secondPosition")
        @Expose
        var secondPosition = ""

        @SerializedName("thirdPosition")
        @Expose
        var thirdPosition = ""

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("__v")
        @Expose
        var v = 0
    }


}