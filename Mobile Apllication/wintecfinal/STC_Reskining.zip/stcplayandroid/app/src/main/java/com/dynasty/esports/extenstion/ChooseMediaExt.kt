package com.dynasty.esports.extenstion

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.webkit.MimeTypeMap.getFileExtensionFromUrl
import android.widget.ImageView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.view.common.ChooseMediaAdapter
import com.google.android.material.bottomsheet.BottomSheetDialog
import de.hdodenhof.circleimageview.CircleImageView
import pub.devrel.easypermissions.EasyPermissions
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*


val perms = arrayOf(
    Manifest.permission.WRITE_EXTERNAL_STORAGE,
    Manifest.permission.READ_EXTERNAL_STORAGE,
    Manifest.permission.CAMERA
)
var pos = -1
var mSelectedCameraImage: File? = null

private lateinit var bottomSheetDialogChooseMedia: BottomSheetDialog

fun cameraPath(file: File) {
    mSelectedCameraImage = file
}

fun Activity.launchChooseProfileBottomSheet() {
    bottomSheetDialogChooseMedia = BottomSheetDialog(this)
    val viewChooseMedia = layoutInflater.inflate(R.layout.bottom_sheet_choose_option, null)
    bottomSheetDialogChooseMedia.setContentView(viewChooseMedia)
    val recyclerViewChooseMedia =
        viewChooseMedia.findViewById(R.id.recyclerViewChooseMedia) as RecyclerView
    recyclerViewChooseMedia.layoutManager = LinearLayoutManager(this)
    val chooseMediaAdapter = ChooseMediaAdapter(
        resources.getStringArray(R.array.media_option),
        onChooseMediaClick = {
            pos = it
            when (it) {
                0 -> {
                    this.chooseCamera(path = ::cameraPath)
                }
                1 -> {
                    this.chooseGallery()
                }
                else -> bottomSheetDialogChooseMedia.dismiss()
            }
            bottomSheetDialogChooseMedia.dismiss()
        }
    )
    recyclerViewChooseMedia.adapter = chooseMediaAdapter

    // bottomSheetDialogChooseMedia.setBackgroundResource(sharedPreferences)

    bottomSheetDialogChooseMedia.show()
}


fun Activity.chooseCamera(path: (File) -> Unit = { _ -> }) {
    if (EasyPermissions.hasPermissions(this, *perms)) {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Ensure that there's a camera activity to handle the intent
            takePictureIntent.resolveActivity(packageManager)?.also {
                // Create the File where the photo should go
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    null
                }
                // Continue only if the File was successfully created
                photoFile?.also {
                    path(photoFile)
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        this.packageName.plus(".fileprovider"),
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    this.startActivityForResult(
                        takePictureIntent,
                        AppConstants.TAKE_PHOTO
                    )
                }
            }
        }
    } else {
        EasyPermissions.requestPermissions(
            this,
            resources.getString(R.string.need_camera_file_permission),
            AppConstants.PERMISSION_CODE,
            *perms
        )
    }
}


private fun Context.createImageFile(): File {
    // Create an image file name
    val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
    val storageDir: File = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
    return File.createTempFile(
        "JPEG_${timeStamp}_", /* prefix */
        ".jpg", /* suffix */
        storageDir /* directory */
    )
}


fun Context.chooseGallery() {
    if (EasyPermissions.hasPermissions(this, *perms)) {
        val pickIntent = Intent(
            Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
        pickIntent.type = "image/*"
        (this as Activity).startActivityForResult(
            pickIntent, AppConstants.IMAGE_CODE
        )
    } else {
        EasyPermissions.requestPermissions(
            (this as Activity),
            resources.getString(R.string.need_camera_file_permission),
            AppConstants.PERMISSION_CODE,
            *perms
        )
    }
}

fun Context.createTemporaryFile(ext: String): File {
    val tempDir = File(this.cacheDir.path)
    if (!tempDir.exists()) {
        tempDir.mkdirs()
    }
    return File.createTempFile(tempDir.name, ext, tempDir)
}


fun Context.uriToImageFile(uri: Uri): File? {
    val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
    val cursor = contentResolver.query(uri, filePathColumn, null, null, null)
    if (cursor != null) {
        if (cursor.moveToFirst()) {
            val columnIndex = cursor.getColumnIndex(filePathColumn[0])
            val filePath = cursor.getString(columnIndex)
            cursor.close()
            return File(filePath)
        }
        cursor.close()
    }
    return null
}



fun File.isFileEmpty(): Boolean {
    return this.length() == 0.toLong()
}

fun selectedFileImage(imagePath: String, size: Float): File? {
    return if (calculateFileSize(imagePath) < size) {
        File(imagePath)
    } else {
        null
    }
}

private fun calculateFileSize(path: String): Float {
    val file = File(path)
    val fileSizeInKB = file.length() / 1024
    // Convert the KB to MegaBytes (1 MB = 1024 KBytes)
    val fileSizeInMB = fileSizeInKB / 1024
    return fileSizeInMB.toFloat()
}

//fun makeMedia(name: String, prefix: String, file: File): MultipartBody.Part {
//    val requestBody = RequestBody.create(MediaType.parse(prefix), file)
//    return MultipartBody.Part.createFormData(name, file.name, requestBody)
//}

fun Context.deleteCache() {
    try {
        val dir = this.cacheDir
        deleteDir(dir)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun deleteDir(dir: File?): Boolean {
    if (dir != null && dir.isDirectory) {
        val children = dir.list()
        for (i in children.indices) {
            val success = deleteDir(File(dir, children[i]))
            if (!success) {
                return false
            }
        }
        return dir.delete()
    } else return if (dir != null && dir.isFile) {
        dir.delete()
    } else {
        false
    }
}


@SuppressLint("Recycle")
fun Context.getPath(uri: Uri): String? {
    val projection = arrayOf(MediaStore.Video.Media.DATA)
    val cursor = contentResolver.query(uri, projection, null, null, null)
    return if (cursor != null) {
        val index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
        cursor.moveToFirst()
        cursor.getString(index)
    } else
        null
}

fun getMimeType(url: String): String? {
    var type: String? = null
    val extension = getFileExtensionFromUrl(url)
    if (extension != null) {
        type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
    }
    return type
}

fun String.removeExtension(): String {
    return if (this.indexOf(".") > 0) {
        this.substring(0, this.lastIndexOf("."))
    } else {
        this
    }

}


fun Context.getRealPathFromURI(contentUri: Uri): String {
    return try {


        val projection = arrayOf(MediaStore.Video.Media.DATA)
        val cursor = (this as Activity).managedQuery(contentUri, projection, null, null, null)
        val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        cursor.moveToFirst()
        cursor.getString(columnIndex)
    } catch (e: Exception) {
        contentUri.path.toString()
    }
}

fun changeExtension(file: File, extension: String): File {
    var filename = file.name

    if (filename.contains(".")) {
        filename = filename.substring(0, filename.lastIndexOf('.'))
    }
    filename += ".$extension"

    file.renameTo(File(file.parentFile, filename))
    return file
}


fun resolveBitmapOrientation(bitmapFile: File): Int {
    var exif: ExifInterface? = null
    exif = ExifInterface(bitmapFile.absolutePath)

    return exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
}

fun rotateBitmap(bitmap: Bitmap, photoPath: String): Bitmap {

    val ei = ExifInterface(photoPath)
    val orientation = ei.getAttributeInt(
        ExifInterface.TAG_ORIENTATION,
        ExifInterface.ORIENTATION_UNDEFINED
    )

    val rotatedBitmap: Bitmap?
    rotatedBitmap = when (orientation) {


        ExifInterface.ORIENTATION_ROTATE_90 -> {
            rotateBitmap(bitmap, ExifInterface.ORIENTATION_ROTATE_90)
        }

        ExifInterface.ORIENTATION_ROTATE_180 -> {
            rotateBitmap(bitmap, ExifInterface.ORIENTATION_ROTATE_180)
        }

        ExifInterface.ORIENTATION_ROTATE_270 -> {
            rotateBitmap(bitmap, ExifInterface.ORIENTATION_ROTATE_270)
        }

        ExifInterface.ORIENTATION_NORMAL -> {
            rotateBitmap(bitmap, ExifInterface.ORIENTATION_ROTATE_90)
        }

        else -> {
            bitmap
        }

    }
    return rotatedBitmap!!
}

fun File.loadLocalImage(context: Context, imageView: CircleImageView) {
    Glide.with(context)
        .load(this.absolutePath)
        .into(imageView)
}

fun File.loadLocalImage(context: Context, imageView: ImageView) {
    Glide.with(context)
        .load(this.absolutePath)
        .into(imageView)
}

fun rotateBitmap(bitmap: Bitmap, orientation: Int): Bitmap? {
    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1F, 1F)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180F)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> {
            matrix.setRotate(180F)
            matrix.postScale(-1F, 1F)
        }
        ExifInterface.ORIENTATION_TRANSPOSE -> {
            matrix.setRotate(90F)
            matrix.postScale(-1F, 1F)
        }
        ExifInterface.ORIENTATION_ROTATE_90 -> {
            matrix.setRotate(90F)
        }
        ExifInterface.ORIENTATION_TRANSVERSE -> {
            matrix.setRotate(-90F)
            matrix.postScale(-1F, 1F)
        }
        ExifInterface.ORIENTATION_ROTATE_270 -> {
            matrix.setRotate(-90F)
            matrix.postScale(-1F, 1F)
        }
        else -> return bitmap
    }

    return try {
        val rotatedBitmap =
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        bitmap.recycle()
        rotatedBitmap
    } catch (e: Exception) {
        null
    }
}
