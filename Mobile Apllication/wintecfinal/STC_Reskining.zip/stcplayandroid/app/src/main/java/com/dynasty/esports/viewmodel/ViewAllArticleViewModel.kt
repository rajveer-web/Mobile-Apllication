package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.ArticleAuthorsModel
import com.dynasty.esports.models.GamesModel
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.models.LatestArticleModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ViewAllArticleViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
    val hottestPostSuccessResponse = MutableLiveData<HottestPostArticleModel>()
    val hottestPostErrorResponse = MutableLiveData<ResponseBody>()

    val trendingPostSuccessResponse = MutableLiveData<LatestArticleModel>()
    val trendingPostErrorResponse = MutableLiveData<ResponseBody>()

    val postByGamesArticleSuccessResponse = MutableLiveData<HottestPostArticleModel>()
    val postByGamesArticleErrorResponse = MutableLiveData<ResponseBody>()

    val authorSuccessResponse = MutableLiveData<ArticleAuthorsModel>()
      val authorErrorResponse = MutableLiveData<ResponseBody>()

    val gamesSuccessResponse = MutableLiveData<GamesModel>()
    //  val gamesErrorResponse = MutableLiveData<ResponseBody>()

    val validationLiveData = MutableLiveData<Int>()
    val updateHeaderUI = MutableLiveData<MutableList<HottestPostArticleModel.DataModel>>()

    val makeJsonObjectForTrendingPost = MutableLiveData<Pair<JsonObject, Pair<JsonObject,JsonObject>>>()
    val makeJsonObjectMorePostGame = MutableLiveData<Pair<JsonObject, JsonObject>>()
    val makeJsonObjectForPostByGame = MutableLiveData<Pair<Boolean, JsonObject>>()
    val makeJsonObjectForPaginationPostByGame = MutableLiveData<JsonObject>()

    /**
     * @desc Method will handle hottest post API success and failure
     */
    fun getAllHottestPortSlider() {
        viewModelScope.launch(apiException("post") + Dispatchers.Main) {
            val response = restInterface.getHottestPost()
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    hottestPostSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    hottestPostErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle post by games post API success and failure
     */
    fun getGames(jsonObject: String) {
        viewModelScope.launch(apiException("game") + Dispatchers.Main) {
            val response = restInterface.getGames(option = jsonObject)
            withContext(Dispatchers.Main) {
                when (response.code()) {
                    AppConstants.API_SUCCESS_CODE -> {
                        gamesSuccessResponse.postValue(response.body())
                    }
                    AppConstants.API_UNAUTHENTICATED_CODE -> {
                        unAuthorizationException.postValue(true)
                    }
//                    else -> {
//                        gamesErrorResponse.postValue(response.errorBody())
//                    }
                }
            }
        }
    }

    /**
     * @desc Method will handle trending post API success and failure
     * @param query - pass query parameter
     *  @param option - pass option parameter
     */
    fun getMoreTrendingPost(query: String, option: String,pref:String) {
        viewModelScope.launch(apiException("main") + Dispatchers.Main) {
            val response = restInterface.articleTrendingPost(query, option,pref)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    trendingPostSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    trendingPostErrorResponse.postValue(response.errorBody())
                }

            }
        }
    }

    /**
     * @desc Method will handle trending post by games API success and failure
     * @param query - pass query parameter
     */
    fun getMoreTrendingPostByGames(query: String) {
        viewModelScope.launch(apiException("main") + Dispatchers.Main) {
            val response = restInterface.getMoreTrendingPostByGames(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    postByGamesArticleSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    postByGamesArticleErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle authors API success and failure
     */
    fun getMoreAuthor(page: Int,limit:Int) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getMoreAuthor(page,limit)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    authorSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                    else -> {
                        authorErrorResponse.postValue(response.errorBody())
                    }
            }

        }
    }

    /**
     * @desc Method will handle get more games API success and failure
     * @param query - pass query parameter
     * @param option - pass option parameter
     */
    fun getMoreGames(query: String, option: String) {
        viewModelScope.launch(apiException("main") + Dispatchers.Main) {
            val response = restInterface.getGames(query, option)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gamesSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
//                    else -> {
//                        gamesErrorResponse.postValue(response.errorBody())
//                    }
            }

        }
    }

    /**
     * @desc Method will invoked updateheaderUI observer and pass data
     * @param data - pass header data array
     */
    fun updateHeaderUISlider(data: MutableList<HottestPostArticleModel.DataModel>?) {
        updateHeaderUI.postValue(data)
    }

    /**
     * 0@desc Method will use for create trending post jsonobject
     */
    fun makeJsonForTrendingPost(page:Int,limit: Int) {
//        val jsonObjectQuery = JsonObject()
//        jsonObjectQuery.addProperty("articleStatus", "publish")
//
//        val jsonObjectPagination = JsonObject()
//        val jsonObjectViews = JsonObject()
//        jsonObjectViews.addProperty("createdDate", -1)
//        jsonObjectPagination.add("sort", jsonObjectViews)
//        jsonObjectPagination.addProperty("limit", limit)
//        jsonObjectPagination.addProperty("page", page)

        val jsonObjectLatestArticle = JsonObject()
        jsonObjectLatestArticle.addProperty("articleStatus", "publish")


        val jsonObjectPagination = JsonObject()
        val jsonObjectSort = JsonObject()
        jsonObjectSort.addProperty("createdDate",-1)
        jsonObjectPagination.addProperty("page",page)
        jsonObjectPagination.addProperty("limit",limit)
        jsonObjectPagination.add("sort",jsonObjectSort)

        val jsonObjectPrefernce = JsonObject()
        jsonObjectPrefernce.addProperty("prefernce", "")

        makeJsonObjectForTrendingPost.postValue(Pair(jsonObjectLatestArticle, Pair(jsonObjectPagination,jsonObjectPrefernce)))
    }
    /**
     * @desc Method will use for post by games
     */
    fun makeJsonForPostByGames() {
        val jsonObjectQuery = JsonObject()
        jsonObjectQuery.addProperty("limit", 6)
        makeJsonObjectForPaginationPostByGame.postValue(jsonObjectQuery)
    }

    /**
     * @desc Method will use for post by games
     */
    fun makeJsonForMorePostByGames(page: Int,limit: Int) {
        val jsonObjectQuery = JsonObject()
        val jsonObjectOption = JsonObject()
        val jsonObjectViews = JsonObject()
        jsonObjectViews.addProperty("activeTournament", -1)
        jsonObjectOption.add("sort", jsonObjectViews)
        jsonObjectOption.addProperty("limit", limit)
        jsonObjectOption.addProperty("page", page)
        //
        makeJsonObjectMorePostGame.postValue(Pair(jsonObjectQuery, jsonObjectOption))
    }


    /**
     * @desc Method will use for create post by games jsonobject
     * @param id - game id
     * @param isGame - check request for game object or not
     */
    fun makeJsonObjectForPostByGame(id: String, isGame: Boolean) {
        val jsonObjectQuery = JsonObject()
        if (isGame) {
            jsonObjectQuery.addProperty("gameDetails", id)
            jsonObjectQuery.addProperty("articleStatus", "publish")
        } else {
            jsonObjectQuery.addProperty("author", id)
        }
            makeJsonObjectForPostByGame.postValue(Pair(isGame, jsonObjectQuery))

    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }


}
