package com.dynasty.esports.view.esport

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.BannerModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.models.TournamentListRes
import com.dynasty.esports.utils.CMButtonView
import com.dynasty.esports.utils.LocaleHelper

class EsportsPageAdapter constructor(
    private val context: Context,
    private val hottestPostList: MutableList<TournamentListRes.Doc>,
    private val onItemClick: (String) -> Unit = {_ -> }
) : PagerAdapter() {


    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val itemView = inflater.inflate(R.layout.adapter_esports_banner, null)
        val textViewTitle = itemView.findViewById<TextView>(R.id.gameNameTitle)
        val textViewDescription = itemView.findViewById<TextView>(R.id.dateNtime)
        val imageViewSlider = itemView.findViewById<ImageView>(R.id.imgUpcoming)
        val joinTournamnetButton = itemView.findViewById<CMButtonView>(R.id.join_button)
        val player_txt = itemView.findViewById<TextView>(R.id.tvParticiPantJoind)
        val data = hottestPostList[position]

        // context.loadImageFromServer(data.bannerFileUrl.toString(), imageViewSlider)
        joinTournamnetButton.click {
            onItemClick(data.id)
        }

        if (data.banner.isNullOrEmpty()) {
            data.gameDetail!!.image.apply {
                if (this.isNotEmpty()) {
                    itemView.context.loadImageFromServer(
                        this,
                        imageViewSlider
                    )
                }
            }
        } else {
            data.banner?.apply {
                if (this.isNotEmpty()) {
                    itemView.context.loadImageFromServer(
                        this,
                        imageViewSlider
                    )
                }
            }
        }


        textViewTitle.text = data.name
        textViewDescription.text = data.startDate!!.convertDateToRequireDateFormat(
            AppConstants.API_DATE_FORMAT,
            AppConstants.REQUIRED_TIME_FORMAT
        ) + ", " + data.startTime


        /* if (LocaleHelper.getLanguage(context) == "en") {
             textViewTitle.text = data.name?.english?.let { it } ?: ""
         } else {
             textViewTitle.text = if(data.name?.malay.isNullOrEmpty())  data.title?.english?.let { it } ?: ""  else  data.title?.malay?.let { it } ?: ""
         }
 */

        /* if (LocaleHelper.getLanguage(context) == "en") {
             textViewDescription.text =  data.subTitle?.english?.let { it } ?: ""
         } else {
             textViewDescription.text = if(data.subTitle?.malay.isNullOrEmpty())  data.subTitle?.english?.let { it } ?: "" else  data.subTitle?.malay?.let { it } ?: ""
         }*/


        val vp = container as ViewPager
        vp.addView(itemView, 0)
        return itemView
    }

    /**
     * @desc hottest post array size count.
     * @return int- array size
     */
    override fun getCount(): Int {
        return hottestPostList.size
    }

    /**
     * @desc Remove a page for the given position.
     */
    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {

        val vp = container as ViewPager
        val view = `object` as View
        vp.removeView(view)
    }


    /**
     * @desc Return current slider title
     * @return String- title
     */
    /* fun getTitleFromPos(position: Int): String {
         return hottestPostList[position].title?.english.toString()
     }*/
}