package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class TeamListDetail (
    @SerializedName("teamName")
    var teamName: String? = null,

    @SerializedName("teamIcon")
    var teamIcon: Int? = null,

    @SerializedName("teamPlayersCount")
    var teamPlayersCount: String? = null,

    @SerializedName("teamPlayersLit")
    var teamPlayersLit: ArrayList<String>? = null

/*    @SerializedName("teamPlayersLit")
    var teamPlayersLit: ArrayList<TeamPlayers>? = null*/
    )