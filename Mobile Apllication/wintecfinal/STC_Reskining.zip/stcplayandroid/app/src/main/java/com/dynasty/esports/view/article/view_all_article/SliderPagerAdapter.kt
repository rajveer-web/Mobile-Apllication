package com.dynasty.esports.view.article.view_all_article


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.utils.LocaleHelper

/**
 * @desc this is class will handle hottest post slider data
 * @author : Mahesh Vayak
 * @created : 21-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SliderPagerAdapter constructor(
    private val context: Context,
    private val hottestPostList: MutableList<HottestPostArticleModel.DataModel>,
    private val onItemClick: (String) -> Unit = { _ -> }
) : PagerAdapter() {


    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val itemView = inflater.inflate(R.layout.row_article_slider, null)
        val textViewTitle = itemView.findViewById<TextView>(R.id.textViewTitle)
        val textViewDescription = itemView.findViewById<TextView>(R.id.textViewSubTitle)
        val imageViewSlider = itemView.findViewById<ImageView>(R.id.imageViewBanner)
        val viewSlider = itemView.findViewById<View>(R.id.viewSlider)
        val data = hottestPostList[position]

        context.loadImageFromServer(data.image.toString(), imageViewSlider)

        if (LocaleHelper.getLanguage(context) == "en") {
            textViewTitle.text = data.title?.english?.let { it } ?: ""
        } else {
            textViewTitle.text = if(data.title?.malay.isNullOrEmpty()) data.title?.english?.let { it } ?: "" else data.title?.malay?.let { it } ?: ""
        }


        if (LocaleHelper.getLanguage(context) == "en") {
            textViewDescription.text = data.shortDescription?.english?.let { it } ?: ""
        } else {
            textViewDescription.text = if(data.shortDescription?.malay.isNullOrEmpty())  data.shortDescription?.english?.let { it } ?: "" else  data.shortDescription?.malay?.let { it } ?: ""
        }

        viewSlider.click {
            onItemClick(data.id!!)
        }

        val vp = container as ViewPager
        vp.addView(itemView, 0)
        return itemView
    }

    /**
     * @desc hottest post array size count.
     * @return int- array size
     */
    override fun getCount(): Int {
        return hottestPostList.size
    }

    /**
     * @desc Remove a page for the given position.
     */
    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {

        val vp = container as ViewPager
        val view = `object` as View
        vp.removeView(view)
    }

    /**
     * @desc Return current slider title
     * @return String- title
     */
    fun getTitleFromPos(position: Int): String {
        return hottestPostList[position].title?.english.toString()
    }
}