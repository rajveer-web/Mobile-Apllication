package com.dynasty.esports.view.basic_info

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CountriesModel
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.models.StateModel
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.ChooseMediaAdapter
import com.dynasty.esports.view.profile.ProfileFragment
import com.dynasty.esports.viewmodel.BasicInfoViewModel
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.android.synthetic.main.fragment_mybasicinfo.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import pub.devrel.easypermissions.AppSettingsDialog
import pub.devrel.easypermissions.EasyPermissions
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * @desc this class will display basic info of login user
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BasicInfoFragment : BaseFragment(), EasyPermissions.PermissionCallbacks,
    EasyPermissions.RationaleCallbacks {
    private val mViewModel: BasicInfoViewModel by viewModel()  // inject basic info view model
    private var countryList: MutableList<CountriesModel.CountryModel> =
        mutableListOf() // define country list
    private var stateList: MutableList<StateModel.State> = mutableListOf() // define state list
    private var countryStateList: MutableList<StateModel.State> =
        mutableListOf() // define specific country state list
    private var fullName: String = ""

    //    private var maritalStatus: String = ""
//    private var employmentStatus: String = ""
    private var profile: String = ""
    private var genderStatus: String = ""

    //    private var parentalStatus: String = ""
    private var country: String = ""
    private var state: String = ""
    private var dob: String = ""
    private var postalCode: String = ""
    private var bio: String = ""
    private var msg: String = ""
    private var selectedCountryISO = ""
    private var position = -1
    private var mSelectedCameraImage: File? = null
    private lateinit var bottomSheetDialogChooseMedia: BottomSheetDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_mybasicinfo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        countryList.addAll(requireContext().jsonToClass<CountriesModel>(R.raw.countries).countries!!) // read country json file and save data in list.
        stateList.addAll(requireContext().jsonToClass<StateModel>(R.raw.states).states!!) // read state json file and save data in list.
        initView()
        listenToViewModel()
        viewClickListener()
    }

    /**
     * @desc Initialize view
     */
    private fun initView() {
        buttonSave.beGone()
        buttonCancel.beGone()
        requireActivity().getDate(
            textViewDOB,
            AppConstants.DD_MM_YYYY_FORMAT,
            isPast = true,
            updateTextValue = {
                textViewDOB.text = it
            })
        editTextUserName.background = null
        constraintLayoutBasicInfo.forEachChildView {
            it.isEnabled = false
        }
        cardViewHeader.forEachChildView { it.isEnabled = false }

        listenToPref()
    }

    /**
     * @desc Assign callback to view and make view clickable.
     */
    private fun viewClickListener() {
        textViewMaritalStatus.click {
            val maritalStatusList = ArrayList<Spinner>()
            maritalStatusList.add(Spinner("1", resources.getString(R.string.str_single)))
            maritalStatusList.add(Spinner("2", resources.getString(R.string.str_married)))
            maritalStatusList.add(Spinner("3", resources.getString(R.string.prefer_not_to_say)))
            mViewModel.updateSpinnerValueAndUI(1, maritalStatusList)
        }
        textViewEmploymentStatus.click {
            val employmentList = ArrayList<Spinner>()
            employmentList.add(Spinner("1", resources.getString(R.string.str_student)))
            employmentList.add(Spinner("2", resources.getString(R.string.str_full_time)))
            employmentList.add(Spinner("3", resources.getString(R.string.str_part_time)))
            employmentList.add(Spinner("4", resources.getString(R.string.str_retired)))
            employmentList.add(Spinner("5", resources.getString(R.string.str_not_working)))
            employmentList.add(Spinner("6", resources.getString(R.string.prefer_not_to_say)))
            mViewModel.updateSpinnerValueAndUI(2, employmentList)
        }
        textViewGender.click {
            val genderList = ArrayList<Spinner>()
            genderList.add(Spinner("1", resources.getString(R.string.str_male)))
            genderList.add(Spinner("2", resources.getString(R.string.str_female)))
            genderList.add(Spinner("3", resources.getString(R.string.prefer_not_to_say)))
            mViewModel.updateSpinnerValueAndUI(3, genderList)
        }
//        textViewParentalStatus.click {
//            val maritalStatusList = ArrayList<Spinner>()
//            maritalStatusList.add(Spinner("1", resources.getString(R.string.parent)))
//            maritalStatusList.add(Spinner("2", resources.getString(R.string.not_parent)))
//            maritalStatusList.add(Spinner("3", resources.getString(R.string.prefer_not_to_say)))
//            mViewModel.updateSpinnerValueAndUI(4, maritalStatusList)
//        }
        editTextCountry.click {
            requireActivity().showSpinner(
                resources.getString(R.string.str_country),
                editTextCountry, countryList, true, type = "country", onItemClick = {
                    val data = it as CountriesModel.CountryModel
                    if (selectedCountryISO != "" && selectedCountryISO != data.id.toString()) {
                        countryStateList.clear()
                        editTextState.text = ""
                    }
                    selectedCountryISO = data.id.toString()
                    countryStateList.clear()
                    stateList.forEach {
                        if (data.id.toString() == it.countryId.toString()) {
                            countryStateList.add(it)
                        }
                    }
                }
            )
        }
        editTextState.click {
            if (countryStateList.isNullOrEmpty()) {
                resources.getString(R.string.select_country_first_msg).showToast(requireContext())
            } else {
                requireActivity().showSpinner(
                    resources.getString(R.string.region_search),
                    editTextState, countryStateList, true, type = "state", onItemClick = {

                    }
                )
            }
        }
        imageViewUser.click {
            launchChooseProfileBottomSheet()
        }
        textViewEdit.click {
            textViewEdit.beGone()
            editTextUserName.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.round_corner)
            cardViewHeader.forEachChildView {
                it.isEnabled = true
            }
            constraintLayoutBasicInfo.forEachChildView {
                it.isEnabled = true
            }
            buttonSave.beVisible()
            buttonCancel.beVisible()
        }
        buttonSave.click {
            mViewModel.checkValidationForm(
                editTextUserName.text.toString().trim(),

                editTextCountry.text.toString().trim(),
                editTextState.text.toString().trim(),
                editTextPostalCode.text.toString().trim()
            )

        }
        buttonCancel.click {
            disableView()
        }
    }

    /**
     * @desc method will use disable all views
     */
    private fun disableView() {
        editTextUserName.background = null
        textViewEdit.beVisible()
        cardViewHeader.forEachChildView { it.isEnabled = false }
        constraintLayoutBasicInfo.forEachChildView { it.isEnabled = false }
        buttonSave.beGone()
        buttonCancel.beGone()
    }

    /**
     * @desc This method for listen shared preference data and display data
     */
    private fun listenToPref() {
        val data = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        data.apply {
            this.fullName?.apply {
                this@BasicInfoFragment.fullName = this
                editTextUserName.setText(this)
            }
            progressBarProfile.progress = this.progress?.let { it } ?: 0
            textViewProfileCompletion.text = this.progress?.let {
                it.toString().plus("%")
            } ?: "0%"

            this.isInfluencer?.apply {
                if (this == 0) {
                    imageViewInfluencer.beVisible()
                    textViewInfluencer.beVisible()
                } else {
                    imageViewInfluencer.beGone()
                    textViewInfluencer.beGone()
                }
            }

            this.isVerified?.apply {
                if (this == 0) {
                    imageViewUser.borderWidth = 6
                    imageViewVerify.beVisible()
                } else {
                    imageViewUser.borderWidth = 0
                    imageViewVerify.beGone()
                }
            }
            this.organizerRating?.apply {
                if (this.toInt() == 0) {
                    tvorganizerrate.beGone()
                    rating.beGone()
                } else {
                    rating.rating = this.toFloat()
                }

            }
            this.accountDetail?.apply {
                textViewPoint.text = this.reward?.let { it.toString() } ?: "0"
            }
            this.profilePicture?.apply {
                requireActivity().loadImageFromServer(this, imageViewUser)
            }

//            this.martialStatus?.apply {
//                this@BasicInfoFragment.maritalStatus = this
//                textViewMaritalStatus.text = this
//            }
            this.gender?.apply {
                this@BasicInfoFragment.genderStatus = this
                textViewGender.text = this
            }

//            this.profession?.apply {
//                this@BasicInfoFragment.employmentStatus = this
//                textViewEmploymentStatus.text = this
//            }

            this.dob?.apply {
                this@BasicInfoFragment.dob = this.convertDateToRequireDateFormat(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.DD_MM_YYYY_FORMAT
                )
                textViewDOB.text = this@BasicInfoFragment.dob
            }

//            this.parentalStatus?.apply {
//                this@BasicInfoFragment.parentalStatus = this
//                textViewParentalStatus.text = this
//            }
//
//            this.parentalStatus?.apply {
//                this@BasicInfoFragment.parentalStatus = this
//                textViewParentalStatus.text = this
//            }

            this.country?.apply {
                this@BasicInfoFragment.country = this
                editTextCountry.text = this
            }
            this.state?.apply {
                this@BasicInfoFragment.state = this
                editTextState.text = this
            }
            this.postalCode?.apply {
                this@BasicInfoFragment.postalCode = this
                editTextPostalCode.setText(this)
            }
            this.shortBio?.apply {
                this@BasicInfoFragment.bio = this
                editTextBio.setText(this)
            }
        }

    }

    /**
     * @desc listen observe and observer that will receive the events
     * and Manage API success and failure,Internet connectivity,check validation and un authorization,
     */
    private fun listenToViewModel() {
        mViewModel.validationLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                1 -> {
                    requireContext().makeSnackBar(
                        constraintLayoutBasicInfoParent,
                        resources.getString(R.string.enter_name_error)
                    )
                }
                2 -> {
                    requireContext().makeSnackBar(
                        constraintLayoutBasicInfoParent,
                        resources.getString(R.string.select_marital_status)
                    )
                }
                3 -> {
                    requireContext().makeSnackBar(
                        constraintLayoutBasicInfoParent,
                        resources.getString(R.string.select_country_error)
                    )
                }
                4 -> {
                    requireContext().makeSnackBar(
                        constraintLayoutBasicInfoParent,
                        resources.getString(R.string.select_region_error)
                    )
                }
                5 -> {
                    requireContext().makeSnackBar(
                        constraintLayoutBasicInfoParent,
                        resources.getString(R.string.enter_postal_code)
                    )
                }
            }
        })
        mViewModel.isFormValid.observe(viewLifecycleOwner, Observer {
            if (textViewDOB.text != resources.getString(R.string.dd_mm_yyyy)) {
                dob = textViewDOB.text.toString()
                    .convertDateToRequireDateFormat(AppConstants.DD_MM_YYYY_FORMAT, "YYYY/MM/dd")
            }
            makeJsonForUserUpdate()
        })
        mViewModel.makeJsonForUpdateUser.observe(viewLifecycleOwner, {
            launchProgressDialog()
            mViewModel.updateUser(it)
        })

        mViewModel.updateUserSuccessResponse.observe(viewLifecycleOwner, {
            msg = it.string().getMessageFromObject("message")
            commonViewModel.fetchUser()
        })

        mViewModel.updateUserErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            showMessageDialog(it.string().getMessageFromObject("message"))
        })

        commonViewModel.userErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            showMessageDialog(it.string().getMessageFromObject("message"))
        })

        commonViewModel.userSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            disableView()
            it?.apply {
                sharedPreferences.id = this.data?.id.toString()
                sharedPreferences.put("user", this.data)
                listenToPref()
            }
            showMessageDialog(msg)
        })

        mViewModel.updateSpinnerItem.observe(viewLifecycleOwner, Observer {
            requireActivity().showSpinner(
                resources.getString(R.string.gender),
                textViewGender,
                it.second,
                false,
                onItemClick = { it1 ->
                    val data = it1 as Spinner
                    when (it.first) {
                        3 -> {
                            genderStatus = data.title
                        }
                    }
                }
            )
        })


        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer { type ->
            dismissProgressDialog()
            if (requireActivity().isOnline()) {
                displayCustomAlertDialog(
                    resources.getString(R.string.something_wrong_try_again),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.retry),
                    positiveClick = {
                        it.dismiss()
                        if (type == "update") {
                            makeJsonForUserUpdate()
                        } else {
                            launchProgressDialog()
                            commonViewModel.fetchUser()
                        }
                    })
            } else {
                displayCustomAlertDialog(
                    resources.getString(R.string.no_internet_message),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.btn_ok),
                    positiveClick = {
                        it.dismiss()
                    })
            }
        })

    }

    /**
     * @desc request to view model for create json object for update user using parameter
     */
    private fun makeJsonForUserUpdate() {
        mViewModel.makeJsonForUpdateUser(
            editTextUserName.text.toString(),
            profile,
            genderStatus,
            dob,
            editTextCountry.text.toString(),
            editTextState.text.toString(),
            editTextPostalCode.text.toString(),
            editTextBio.text.toString()
        )
    }

    /**
     * @desc Get file url from gallery anf camera using intent and encoded to base64 string
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == AppConstants.TAKE_PHOTO) {
                mSelectedCameraImage?.apply {
                    requireActivity().loadImageFromServer(
                        "file://".plus(this.absolutePath),
                        imageViewUser
                    )
                    profile = this.encoder()
                }

            } else if (requestCode == AppConstants.IMAGE_CODE) {
                if (data == null)
                    return

                data.data?.apply {
                    mSelectedCameraImage = requireActivity().uriToImageFile(this)
                    mSelectedCameraImage?.apply {
                        requireActivity().loadImageFromServer(
                            "file://".plus(this.absolutePath),
                            imageViewUser
                        )
                        profile = this.encoder()
                    }
                }


            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    /**
     * @desc Create fragment instance
     */
    companion object {
        fun newInstance() = ProfileFragment()
    }

    /**
     * @desc Create fragment instance
     */
    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            AppSettingsDialog.Builder(this).build().show()
        }
    }

    /**
     * @desc if permission granted from user when open gallery or camera for choose image
     */
    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
        if (requestCode == AppConstants.PERMISSION_CODE) {
            if (position == 0) {
                chooseCamera(path = ::cameraPath)
            } else {
                chooseGallery()
            }
        }
    }


    /**
     * @desc temp camera file store in global file variable
     * @param file - temporary camera file
     */
    private fun cameraPath(file: File) {
        mSelectedCameraImage = file
    }

    /**
     * @desc this method will use choose media option(camera or gallery)
     * Display option inside bottom sheet
     */
    private fun launchChooseProfileBottomSheet() {
        bottomSheetDialogChooseMedia = BottomSheetDialog(requireContext())
        val viewChooseMedia = layoutInflater.inflate(R.layout.bottom_sheet_choose_option, null)
        bottomSheetDialogChooseMedia.setContentView(viewChooseMedia)
        val recyclerViewChooseMedia =
            viewChooseMedia.findViewById(R.id.recyclerViewChooseMedia) as RecyclerView
        recyclerViewChooseMedia.layoutManager = LinearLayoutManager(requireContext())
        val chooseMediaAdapter = ChooseMediaAdapter(
            resources.getStringArray(R.array.media_option),
            onChooseMediaClick = {
                position = it
                when (it) {
                    0 -> {
                        chooseCamera(path = ::cameraPath)
                    }
                    1 -> {
                        chooseGallery()
                    }
                    else -> bottomSheetDialogChooseMedia.dismiss()
                }
                bottomSheetDialogChooseMedia.dismiss()
            }
        )
        recyclerViewChooseMedia.adapter = chooseMediaAdapter

        bottomSheetDialogChooseMedia.show()
    }

    /**
     * @desc launch camera for take image with check camera permission
     * Get file using file provide
     * @param path = temporary camera file
     *
     */
    private fun chooseCamera(path: (File) -> Unit = { _ -> }) {
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                // Ensure that there's a camera activity to handle the intent
                takePictureIntent.resolveActivity(requireContext().packageManager)?.also {
                    // Create the File where the photo should go
                    val photoFile: File? = try {
                        createImageFile()
                    } catch (ex: IOException) {
                        null
                    }
                    // Continue only if the File was successfully created
                    photoFile?.also {
                        path(photoFile)
                        val photoURI: Uri = FileProvider.getUriForFile(
                            requireContext(),
                            requireContext().packageName.plus(".provider"),
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        startActivityForResult(
                            takePictureIntent,
                            AppConstants.TAKE_PHOTO
                        )
                    }
                }
            }
        } else {
            EasyPermissions.requestPermissions(
                this,
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    /**
     * @desc method will use create temporary file in local storage
     */
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File =
            requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        )
    }


    /**
     * @desc method will use launch gallery for choose profile
     */
    private fun chooseGallery() {
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            val pickIntent = Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            )
            pickIntent.type = "image/*"
            startActivityForResult(
                pickIntent, AppConstants.IMAGE_CODE
            )
        } else {
            EasyPermissions.requestPermissions(
                requireActivity(),
                resources.getString(R.string.need_camera_file_permission),
                AppConstants.PERMISSION_CODE,
                *perms
            )
        }
    }

    /**
     * @desc method use for show alert dialog to a display message
     * @param msg - the message to be displayed
     */
    private fun showMessageDialog(msg: String) {
        displayCustomAlertDialog(
            msg,
            isCancelable = false,
            positiveText = resources.getString(R.string.btn_ok),
            positiveClick = {
                it.dismiss()
            })
    }

    override fun onRationaleDenied(requestCode: Int) {

    }

    override fun onRationaleAccepted(requestCode: Int) {

    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

}
