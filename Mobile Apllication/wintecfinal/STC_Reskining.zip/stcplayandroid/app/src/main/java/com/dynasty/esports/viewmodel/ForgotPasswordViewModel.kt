package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import com.dynasty.esports.retrofit.RestInterface

class ForgotPasswordViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val countryCodeObserver = MutableLiveData<Boolean>()

    val btnNextClickObserver = MutableLiveData<Boolean>()

    fun btnNextClick() {
        btnNextClickObserver.postValue(true)
    }

    fun countryCodeClick(){
        countryCodeObserver.postValue(true)
    }


}