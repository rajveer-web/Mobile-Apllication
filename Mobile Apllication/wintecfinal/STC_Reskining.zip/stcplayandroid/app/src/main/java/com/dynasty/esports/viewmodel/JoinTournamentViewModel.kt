package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.*
import okhttp3.ResponseBody

class JoinTournamentViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val joinTournamentSubmitObserver = MutableLiveData<Boolean>()
    val joinTournamentCancleObserver = MutableLiveData<Boolean>()

    val checkTeamUrlClickObserver = MutableLiveData<Boolean>()

    val isTeamNameNotEmptyObserver = MutableLiveData<Boolean>()

    val validationLiveData = MutableLiveData<Int>()
    val isNextStepFormValid = MutableLiveData<Boolean>()

    val checkTeamNameSuccessResponse = MutableLiveData<ParticipantSearchRes>()
    val checkTeamNameErrorResponse = MutableLiveData<ResponseBody>()

    val countryCodeObserver = MutableLiveData<Boolean>()

    val joinTournamentSuccessResponse = MutableLiveData<ResponseBody>()
    val joinTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val updateJoinTournamentSuccessResponse = MutableLiveData<ResponseBody>()
    val updateJoinTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val alreadyJoinTournamentSuccessResponse = MutableLiveData<JoinedEditTournamentModel>()
    val alreadyJoinTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val fetchTournamentDetailSuccessResponse = MutableLiveData<TournamentDetailRes>()
    val fetchTournamentDetailErrorResponse = MutableLiveData<ResponseBody>()

    val isCaptainUserNameValidSuccessResponse = MutableLiveData<ParticipantSearchRes>()
    val isCaptainUserNameValidErrorResponse = MutableLiveData<ResponseBody>()

    val isCaptainUserGameNameValidSuccessResponse = MutableLiveData<ParticipantSearchRes>()
    val isCaptainUserGameNameValidErrorResponse = MutableLiveData<ResponseBody>()

    val isMemberUserNameValidSuccessResponse = MutableLiveData<ParticipantSearchRes>()
    val isMemberUserNameValidErrorResponse = MutableLiveData<ResponseBody>()

    val isMemberUserGameNameValidSuccessResponse = MutableLiveData<ParticipantSearchRes>()
    val isMemberUserGameNameValidErrorResponse = MutableLiveData<ResponseBody>()


    fun checkTeamUrlValidOrNot(field: String, text: String, tournamentId: String, pid: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.checkParticipantSearch(field, text, tournamentId, pid)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    checkTeamNameSuccessResponse.postValue(response.body())
                }
                else -> {
                    checkTeamNameErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun checkUserNameValid(field: String, text: String, tournamentId: String, pid: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.checkParticipantSearch(field, text, tournamentId, pid)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    isCaptainUserNameValidSuccessResponse.postValue(response.body())
                }
                else -> {
                    isCaptainUserNameValidErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun checkGameUserNameValid(field: String, text: String, tournamentId: String, pid: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.checkParticipantSearch(field, text, tournamentId, pid)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    isCaptainUserGameNameValidSuccessResponse.postValue(response.body())
                }
                else -> {
                    isCaptainUserGameNameValidErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    fun checkMemberUserNameValid(field: String, text: String, tournamentId: String, pid: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
//            val response = restInterface.checkParticipant(jsonObject.toString())
            val response = restInterface.checkParticipantSearch(field, text, tournamentId, pid)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    isMemberUserNameValidSuccessResponse.postValue(response.body())
                }
                else -> {
                    isMemberUserNameValidErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun checkMemberGameUserNameValid(
        field: String,
        text: String,
        tournamentId: String,
        pid: String
    ) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.checkParticipantSearch(field, text, tournamentId, pid)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    isMemberUserGameNameValidSuccessResponse.postValue(response.body())
                }
                else -> {
                    isMemberUserGameNameValidErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun onValidationForNextStep(
        isForTeam: Boolean,
        editTeamName: String,
        isTeamNameValid: Boolean,
        selectedLogoEncoded: String,
        editJoinCaptainName: String,
        editJoinCaptainMail: String,
        editJoinCaptainUserName: String,
        editJoinCaptainUserGameName: String,
        isMobileAutoPopulate: Boolean,
        editjoinCaptainPhonecode: String,
        editjoinCaptainPhoneNumber: String,
        isCaptainUserNameValid: Boolean,
        isCaptainUserGameNameValid: Boolean,
        isMemberValidated: Boolean
    ) {
        when {
            isForTeam && editTeamName.isFieldEmpty() -> validationLiveData.postValue(0)
            isForTeam && !isTeamNameValid -> validationLiveData.postValue(1)
            selectedLogoEncoded.isFieldEmpty() -> validationLiveData.postValue(2)
            editJoinCaptainName.isFieldEmpty() -> validationLiveData.postValue(3)
            editJoinCaptainMail.isFieldEmpty() -> validationLiveData.postValue(4)
            !editJoinCaptainMail.isEmailValid() -> validationLiveData.postValue(5)
            editJoinCaptainUserName.isFieldEmpty() -> validationLiveData.postValue(6)
            !isCaptainUserNameValid -> validationLiveData.postValue(7)
            editJoinCaptainUserGameName.isFieldEmpty() -> validationLiveData.postValue(8)
            !isCaptainUserGameNameValid -> validationLiveData.postValue(9)
            !isMobileAutoPopulate && editjoinCaptainPhonecode.isFieldEmpty() -> validationLiveData.postValue(
                10
            )
            !isMobileAutoPopulate && editjoinCaptainPhoneNumber.isFieldEmpty() -> validationLiveData.postValue(
                11
            )
            !isMemberValidated -> validationLiveData.postValue(12)
            else -> isNextStepFormValid.postValue(true)
        }
    }

    //   Api call for join tournament
    fun joinTournament(jsonObject: JsonObject, partId: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.joinTournament(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    joinTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    joinTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    //   Api call for join tournament
    fun updateJoinTournament(jsonObject: JsonObject, partId: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.updateJoinTournament(partId, jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    updateJoinTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    updateJoinTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun getAlreadyJoinTournamentData(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.getJoinTournamentData(jsonObject.toString())

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    alreadyJoinTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    alreadyJoinTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    fun fetchTournamentDetail(tournamentId: String, sort: String, type: String) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getTournamentDetails(tournamentId)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchTournamentDetailSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchTournamentDetailErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun checkValidation(editUrl: String) {
        when {
            editUrl.isFieldEmpty() -> validationLiveData.postValue(0)
            else -> isTeamNameNotEmptyObserver.postValue(true)
        }
    }

    fun countryCodeClick() {
        countryCodeObserver.postValue(true)
    }

    fun checkTeamUrlClick() {
        checkTeamUrlClickObserver.postValue(true)
    }

    fun joinTournamentSubmitClick() {
        joinTournamentSubmitObserver.postValue(true)
    }

    fun joinTournamentCancelClick() {
        joinTournamentCancleObserver.postValue(true)
    }

    /**
     * Clears the [ViewModel] when the [CreateTournamentActivity] is not visible to user.
     */
    fun onDetach() {
//        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
