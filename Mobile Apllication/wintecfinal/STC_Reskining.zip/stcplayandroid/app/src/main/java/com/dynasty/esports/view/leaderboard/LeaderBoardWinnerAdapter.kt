package com.dynasty.esports.view.leaderboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.LeaderboardWinnerListItemBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.extenstion.nullSafeNA
import com.dynasty.esports.models.LeaderboardByGameModel
import com.dynasty.esports.models.LeaderboardModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use for select game in CreateTournamentStep1Fragment
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class LeaderBoardWinnerAdapter constructor(
    private val onItemClick: (String) -> Unit = { _ -> })  :
    RecyclerView.Adapter<BindingHolder<LeaderboardWinnerListItemBinding>>() {
    private var winnerList: MutableList<LeaderboardByGameModel.Doc> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int): BindingHolder<LeaderboardWinnerListItemBinding> {
        val binding: LeaderboardWinnerListItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.leaderboard_winner_list_item,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    /**
     * @desc gameList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return winnerList.size
    }

    /**
     * @desc get gameList( main array list)
     */
    fun getAll(): MutableList<LeaderboardByGameModel.Doc>? {
        return winnerList
    }

    /**
     * @desc clear gamelist, add list in gameList and notify adapter
     */
    fun addAll(gameList_: ArrayList<LeaderboardByGameModel.Doc>) {
        winnerList.clear()
        winnerList.addAll(gameList_)
        notifyDataSetChanged()
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents and to reflect the item at the given position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<LeaderboardWinnerListItemBinding>,
        position: Int
    ) {
        val data = winnerList[position]
        holder.binding.tvLeaderBoardWinnerPrice.text = nullSafeNA(data.points)
        when (position) {
            0 -> {
                holder.binding.tvLeaderBoardWinnerRank.text = "1st"
            }
            1 -> {
                holder.binding.tvLeaderBoardWinnerRank.text = "2nd"
            }
            2 -> {
                holder.binding.tvLeaderBoardWinnerRank.text = "3rd"
            }
        }

        holder.binding.linearLayoutWinnerDashboard.click {
            onItemClick(data.id?.user.toString())
        }

        holder.binding.tvLeaderBoardWinnerPrice.text = data.amountPrice
        holder.binding.tvLeaderBoardWinnerGames.text = data.gamesCount

        if (data.user.isNotEmpty()) {
            holder.binding.tvLeaderBoardWinnerName.text = nullSafeNA(data.user[0].fullName)
            if (!data.user[0].profilePicture!!.isFieldEmpty()) {
                holder.binding.root.context.loadImageFromServer(
                    data.user[0].profilePicture!!,
                    holder.binding.imgLeaderBoardWinner
                )
            } else {
                holder.binding.imgLeaderBoardWinner.setImageResource(R.mipmap.leaderboard_asset_1)
            }
        }
    }

    /**
     * @desc get single item from position
     */
    fun getItem(position: Int): LeaderboardByGameModel.Doc {
        return this.winnerList[position]
    }
}