package com.dynasty.esports.utils

import android.content.Context
import android.util.AttributeSet
import androidx.core.content.ContextCompat
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.lightFont
import com.dynasty.esports.extenstion.mediumFont
import com.google.android.material.button.MaterialButton

/**
 * @desc this class will handle textview properties
 * @author : Mahesh Vayak
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CLButtonView : MaterialButton {

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    ) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context) : super(context) {
        init()
    }

    fun init() {

        if (!isInEditMode) {
            try {
                typeface = context.lightFont()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }

}