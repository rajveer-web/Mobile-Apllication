package com.dynasty.esports.view.search


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterRelatedArticleBinding
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.SearchVideoModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use to show search videos
 * @author : Mahesh Vayak
 * @created : 25-08-2020
 * @modified : 25-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SearchVideoAdapter constructor(
    private var videoList: MutableList<SearchVideoModel.DataModel>,
    private val onItemClick: (String) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterRelatedArticleBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterRelatedArticleBinding> {
        val binding: AdapterRelatedArticleBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_related_article,
            parent,
            false
        )

        return BindingHolder(binding)

    }

    /**
     * @desc article array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return videoList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterRelatedArticleBinding>,
        position: Int) {
        val data = videoList[holder.adapterPosition]
        holder.binding.root.context.loadImageFromServer(data.thumbnailUrl.toString(),holder.binding.imageViewArticleBg)

        holder.binding.textViewArticleName.text= data.game

        holder.binding.imageViewPlay.beVisible()


        holder.binding.topcardview.setOnClickListener {
            onItemClick(data.youtubeUrl.toString())
        }

    }

}