package com.dynasty.esports.models

data class PlatformModel(
    var key:String,
    var icon:Int,
    var title:String
)