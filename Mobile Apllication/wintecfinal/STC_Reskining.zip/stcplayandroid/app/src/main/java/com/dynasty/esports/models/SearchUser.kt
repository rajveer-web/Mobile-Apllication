package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SearchUser {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("success")
    @Expose
    var success: Boolean? = null

    @SerializedName("data")
    @Expose
    var data: List<Datum> = ArrayList<Datum>()

    @SerializedName("totals")
    @Expose
    var totals: Totals? = null


    class Datum {
        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("fullName")
        @Expose
        var fullName: String? = null

        @SerializedName("phoneNumber")
        @Expose
        var phoneNumber: String? = null

        @SerializedName("email")
        @Expose
        var email: String? = null

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String? = null
    }

    class Totals {
        @SerializedName("count")
        @Expose
        var count: Int? = null
    }
}