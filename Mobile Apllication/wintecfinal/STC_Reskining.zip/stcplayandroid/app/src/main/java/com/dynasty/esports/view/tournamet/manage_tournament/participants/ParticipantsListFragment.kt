package com.dynasty.esports.view.tournamet.manage_tournament.participants

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beInVisible
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.ParticipantsModel
import com.dynasty.esports.models.TeamPlayers
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.UpcomingParticipantsViewModel
import kotlinx.android.synthetic.main.fragment_participants_list.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*

class ParticipantsListFragment : BaseFragment() {
    private var participantsList: ArrayList<ParticipantsModel.DataModel> = arrayListOf()
    private lateinit var tournamentParticipantsAdapter: ParticipantsListAdapter
    private var type: Int = -1
    private var bracketType: String = ""
    private var tournamentType: String = ""
    private val mViewModel: UpcomingParticipantsViewModel by viewModel()
    private var mParentListener: OnParticipantsFragmentInteractionListener? = null
    private var id: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            type = this.getInt("type")
            participantsList.addAll(this.getParcelableArrayList("data")!!)
            bracketType = this.getString("bracketType").toString()
            tournamentType = this.getString("tournamentType").toString()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mParentListener = if (parentFragment is OnParticipantsFragmentInteractionListener) {
            parentFragment as OnParticipantsFragmentInteractionListener?
        } else {
            throw RuntimeException("The parent fragment must implement OnChildFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        mParentListener = null
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_participants_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        listenToViewModel()


    }

    @SuppressLint("SetTextI18n")
    private fun initView() {
        if (bracketType == "individual") {
            frameLayoutTeam.beGone()
            frameLayoutParticipants.beVisible()
            recyclerViewParticipants.layoutManager = LinearLayoutManager(requireContext())
            tournamentParticipantsAdapter = ParticipantsListAdapter(
                tournamentType,
                type,
                onItemClick = ::onItemClick
            )
            recyclerViewParticipants.adapter = tournamentParticipantsAdapter
            tournamentParticipantsAdapter.addAll(participantsList)
        } else {
            frameLayoutParticipants.beGone()
            frameLayoutTeam.beVisible()
            commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
            tournamentParticipantsAdapter = ParticipantsListAdapter(
                tournamentType,
                type,
                onItemClick = ::onTeamClick
            )
            commonRecyclerView.adapter = tournamentParticipantsAdapter
            tournamentParticipantsAdapter.addAll(participantsList)
        }


        if (participantsList.isNullOrEmpty()) {
            when (type) {
                0 -> {
                    textViewNoData.beVisible()
                    textViewNoData.text = resources.getString(R.string.no_participant_approved)
                }
                1 -> {
                    textViewNoData.beVisible()
                    textViewNoData.text = resources.getString(R.string.no_participant_rejected)
                }
                2 -> {
                    textViewNoData.beVisible()
                    textViewNoData.text = resources.getString(R.string.no_participant_pending)
                }
            }
        }
    }

    private fun listenToViewModel() {
        mViewModel.makeJsonObjectForParticipantsQuery.observe(viewLifecycleOwner, {
            launchProgressDialog()
            mViewModel.updateStatusParticipants(id, it)
        })

        mViewModel.updateParticipantsSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            mParentListener?.apply {
                notifyParticipant(true)
            }
        })


        mViewModel.updateParticipantsErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })

        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })


    }

    private fun onItemClick(position: Int) {
        id = participantsList[position].id.toString()
        if (tournamentType == "upcoming") {
            when (type) {
                0 -> {
                    displayCustomAlertDialog(resources.getString(R.string.rejected_participant),
                        isCancelable = true,
                        isCloseShow = true,
                        positiveText = resources.getString(R.string.reject_),
                        negativeText = resources.getString(R.string.str_cancel),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForParticipantsStatus("rejected")
                        },
                        negativeClick = {
                            it.dismiss()
                        }, onCloseClick = {
                            it.dismiss()
                        })
                }
                1 -> {
                    displayCustomAlertDialog(resources.getString(R.string.approve_participant),
                        desc = resources.getString(R.string.approve_participant_msg),
                        isCancelable = true,
                        isCloseShow = true,
                        positiveText = resources.getString(R.string.approve_),
                        negativeText = resources.getString(R.string.str_cancel),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForParticipantsStatus("approved")
                        },
                        onCloseClick = {
                            it.dismiss()
                        },
                        negativeClick = {
                            it.dismiss()
                        })
                }
                2 -> {
                    displayCustomAlertDialog(resources.getString(R.string.approve_reject_participant),
                        desc = resources.getString(R.string.approve_reject_msg),
                        isCancelable = true,
                        isCloseShow = true,
                        positiveText = resources.getString(R.string.approve_),
                        negativeText = resources.getString(R.string.reject_),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForParticipantsStatus("approved")
                        },
                        onCloseClick = {
                            it.dismiss()
                        },
                        negativeClick = {
                            it.dismiss()
                            mViewModel.makeJsonForParticipantsStatus("rejected")
                        })
                }
            }
        }
    }

    private fun onTeamClick(position: Int) {

        if (tournamentType == "ongoing" || tournamentType == "upcoming") {
            if (tournamentType == "ongoing")
                linearLayoutStatus.beInVisible()
            else
                linearLayoutStatus.beVisible()
            frameLayoutTeam.beGone()
            frameLayoutParticipants.beVisible()
            val data = participantsList[position]
            id = data.id.toString()
            val teamList: MutableList<TeamPlayers> = mutableListOf()
            val teamPlayers = TeamPlayers()
            teamPlayers.name = data.name
            teamPlayers.email = data.email
            teamPlayers.inGamerUserId = data.inGamerUserId
            teamPlayers.tournamentUsername = data.tournamentUsername
            teamPlayers.teamLogo = data.logo
            teamList.addAll(data.teamMembers!!)
            teamList.add(0, teamPlayers)

            recyclerViewParticipants.layoutManager = LinearLayoutManager(requireContext())
            val participantsMembersAdapter = ParticipantsMembersAdapter(type)
            recyclerViewParticipants.adapter = participantsMembersAdapter
            participantsMembersAdapter.addAll(teamList)



            when (type) {
                0 -> {
                    buttonApprove.beGone()
                }
                1 -> {
                    buttonReject.beGone()
                }
                2 -> {
                    buttonApprove.beVisible()
                    buttonCancel.beVisible()
                    buttonReject.beVisible()
                }
            }
        } else {
            buttonApprove.beGone()
            buttonCancel.beGone()
            buttonReject.beGone()
        }


        buttonCancel.click {
            linearLayoutStatus.beGone()
            frameLayoutTeam.beVisible()
            frameLayoutParticipants.beGone()
        }

        buttonApprove.click {
            mViewModel.makeJsonForParticipantsStatus("approved")
        }

        buttonReject.click {
            mViewModel.makeJsonForParticipantsStatus("rejected")
        }

    }


    interface OnParticipantsFragmentInteractionListener {
        fun notifyParticipant(isUpdate: Boolean)
    }

    companion object {
        fun newInstance(
            type: Int,
            data: MutableList<ParticipantsModel.DataModel>,
            bracketType: String,
            tournamentType: String
        ): Fragment {
            val args = Bundle()
            args.putInt("type", type)
            args.putString("bracketType", bracketType)
            args.putString("tournamentType", tournamentType)
            args.putParcelableArrayList("data", data as ArrayList<out Parcelable>)
            val fragment = ParticipantsListFragment()
            fragment.arguments = args
            return fragment
        }
    }
}

