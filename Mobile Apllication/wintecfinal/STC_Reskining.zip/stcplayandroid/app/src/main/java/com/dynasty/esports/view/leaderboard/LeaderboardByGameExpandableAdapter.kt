package com.dynasty.esports.view.leaderboard

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.bignerdranch.expandablerecyclerview.ChildViewHolder
import com.bignerdranch.expandablerecyclerview.ExpandableRecyclerAdapter
import com.bignerdranch.expandablerecyclerview.ParentViewHolder
import com.bignerdranch.expandablerecyclerview.model.Parent
import com.dynasty.esports.R
import com.dynasty.esports.databinding.LeaderboardChildItemBinding
import com.dynasty.esports.databinding.LeaderboardParentItemBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.LeaderboardByGameModel
import com.dynasty.esports.models.LeaderboardModel
import com.facebook.FacebookSdk.getApplicationContext


class LeaderboardByGameExpandableAdapter constructor(
    private var context: Context?,
    groups: List<LeaderboardByGameModel.Doc>?,
    private val onItemClick: (String) -> Unit = { _ -> }
) :
    ExpandableRecyclerAdapter<LeaderboardByGameModel.Doc, LeaderboardByGameModel.DocChild, LeaderboardByGameExpandableAdapter.GrpViewHolder, LeaderboardByGameExpandableAdapter.ItemViewHolder>(
        groups as MutableList<LeaderboardByGameModel.Doc>
    ) {

    private var mInflater: LayoutInflater? = null
    private var mEventListener: EventListener? = null
    private var animationUp: Animation? = null
    private var animationDown: Animation? = null

    init {
        parentList.clear()
        parentList.addAll(groups!!)
        mInflater = LayoutInflater.from(context)
        animationUp = AnimationUtils.loadAnimation(context, R.anim.slide_up)
        animationDown = AnimationUtils.loadAnimation(context, R.anim.slide_down)
    }

    fun getAll(): List<LeaderboardByGameModel.Doc?>? {
        return parentList
    }

    fun getMenuItem(position: Int): LeaderboardByGameModel.Doc? {
        return parentList[position]
    }

    fun getMenuSubItem(position: Int, child: Int): LeaderboardByGameModel.DocChild? {
        return parentList[position].childList.get(child)
    }

    fun addAll(groups: List<LeaderboardByGameModel.Doc?>?) {
//        parentList.clear()
        parentList.addAll(groups!!)
        notifyParentDataSetChanged(false)
    }

    fun clear() {
        parentList.clear()
        notifyParentDataSetChanged(false)
    }

    override fun onCreateParentViewHolder(
        parentViewGroup: ViewGroup,
        viewType: Int
    ): GrpViewHolder {
        val categoryView: View =
            mInflater!!.inflate(R.layout.leaderboard_parent_item, parentViewGroup, false)
        return GrpViewHolder(categoryView)
    }

    override fun onCreateChildViewHolder(childViewGroup: ViewGroup, viewType: Int): ItemViewHolder {
        val subCategoryView: View =
            mInflater!!.inflate(R.layout.leaderboard_child_item, childViewGroup, false)
        return ItemViewHolder(subCategoryView)
    }

    override fun onBindParentViewHolder(
        recipeViewHolder: GrpViewHolder, parentPosition: Int,
        recipe: LeaderboardByGameModel.Doc
    ) {
        /*if (parentPosition == 0) {
            recipeViewHolder.parentBinding.viewBorder.setVisibility(View.GONE)
        }
        recipeViewHolder.parentBinding.tvCategoryName.setTextColor(context!!.resources.getColor(R.color.black))*/

        recipeViewHolder.bind(recipe)
    }

    override fun onBindChildViewHolder(
        ingredientViewHolder: ItemViewHolder,
        parentPosition: Int, childPosition: Int,
        ingredient: LeaderboardByGameModel.DocChild
    ) {


        ingredientViewHolder.bind(ingredient)


    }

    fun getItem(position: Int): LeaderboardByGameModel.Doc? {
        return parentList[position]
    }


    class GrpViewHolder(itemView: View?) : ParentViewHolder<Parent<Any?>, Any?>(itemView!!) {
        var parentBinding: LeaderboardParentItemBinding?
        fun bind(datum: LeaderboardByGameModel.Doc) {
            parentBinding!!.tvLeaderboardRank.text = (parentAdapterPosition + 1).toString()
            if (datum.user.isNotEmpty()) {
                parentBinding!!.tvPlayerName.text = datum.user[0].fullName
                if (!datum.user[0].profilePicture!!.isFieldEmpty()) {
                    parentBinding!!.root.context.loadImageFromServer(
                        datum.user[0].profilePicture!!,
                        parentBinding!!.imgLeaderBoard
                    )
                } else {
                    parentBinding!!.imgLeaderBoard.setImageResource(R.mipmap.leaderboard_asset_1)
                }
            }

            itemView.click {
                if (isExpanded) {
                    parentBinding!!.viewSelectedLine.beGone()
                    parentBinding!!.imgLeaderBoardExpand.setImageDrawable(
                        ContextCompat.getDrawable(
                            itemView.context,
                            R.drawable.ic_baseline_arrow_right_24
                        )
                    )
                    parentBinding!!.container.setBackgroundColor(
                        itemView.context.resources.getColor(
                            R.color.internal_app_bg_color
                        )
                    )
                    parentBinding!!.imgLeaderBoardExpand.animate().rotationBy(-90F).setDuration(500)
                        .start()
                    collapseView()
                } else {
                    parentBinding!!.viewSelectedLine.beVisible()
                    parentBinding!!.imgLeaderBoardExpand.setImageDrawable(
                        ContextCompat.getDrawable(
                            itemView.context,
                            R.drawable.ic_baseline_arrow_right_24
                        )
                    )
                    parentBinding!!.container.setBackgroundColor(
                        itemView.context.resources.getColor(
                            R.color.internal_app_bg_color
                        )
                    )
                    parentBinding!!.imgLeaderBoardExpand.animate().rotationBy(90F).setDuration(500)
                        .start()
                    expandView()
                }

            }
        }

        init {
            parentBinding = DataBindingUtil.bind(itemView!!)
        }
    }


  inner  class ItemViewHolder(itemView: View?) : ChildViewHolder<Any?>(itemView!!) {
        var childBinding: LeaderboardChildItemBinding?
        fun bind(item: LeaderboardByGameModel.DocChild) {
            if (item.user.isNotEmpty()) {
                if (item.user[0].country != null) {
                    childBinding!!.tvLeaderboardRegion.text = nullSafeNA("" + item.user[0].country)
                } else {
                    childBinding!!.tvLeaderboardRegion.text =
                        itemView.resources.getString(R.string.empty_desc)
                }

            }
            childBinding!!.tvLeaderboardPoints.text = nullSafeNA(item.points)
            childBinding!!.tvLeaderboardPointOne.text = nullSafeNA(item.firstPosition)
            childBinding!!.tvLeaderboardPointTwo.text = nullSafeNA(item.secondPosition)
            childBinding!!.tvLeaderboardPointThree.text = nullSafeNA(item.thirdPosition)
            childBinding!!.linearLayoutLeaderBoard.click {
                onItemClick(item.id?.user.toString())
            }
        }

        init {
            childBinding = DataBindingUtil.bind(itemView!!)
        }
    }

    interface EventListener {
        fun OnMenuClick(parentPosition: Int, childPosition: Int)
    }

    fun setEventListener(eventlistener: EventListener?) {
        mEventListener = eventlistener
    }
}