package com.dynasty.esports.models

data class RegisterResponse(
    val message:String,
    val data: DataResponse)
