package com.dynasty.esports.view.esport

import android.graphics.Rect
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dynasty.esports.R
import com.dynasty.esports.models.SelectGameModel
import kotlinx.android.synthetic.main.select_game_list_item.view.*

class LattestArticleAdapter(var listOfGame: MutableList<SelectGameModel>, var listener: OnItemClickListener) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var listOfGames : MutableList<SelectGameModel>
    var listenerr : OnItemClickListener

    init {
        this.listOfGames = listOfGame
        this.listenerr = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SelectGameViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.select_game_list_item, parent, false)
        )
    }

    override fun getItemCount(): Int = listOfGames.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val gameViewHolder = viewHolder as SelectGameViewHolder
        gameViewHolder.bindView(listOfGames[position],listenerr)
    }

    fun setGameList(listOfMovies: List<SelectGameModel>/*,  listener : View.OnClickListener*/) {
        listOfGames = listOfMovies.toMutableList()
        notifyDataSetChanged()
    }

    fun addMoreData(listOfMovies: List<SelectGameModel>) {
        this.listOfGames.addAll(listOfMovies)
        notifyDataSetChanged()
    }

    class SelectGameViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(
            gameModel: SelectGameModel,
            listenerr: OnItemClickListener
        ) {
            itemView.game_name.text = gameModel.gameName
//            Glide.with(itemView.context).load(gameModel.gameImage!!).into(itemView.game_image)
            itemView.setOnClickListener {
                listenerr.onItemClick(gameModel.gameName)
            }
        }
    }

    class VerticalSpaceItemDecoration(private val verticalSpaceHeight: Int) : RecyclerView.ItemDecoration() {
        override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView,
                                    state: RecyclerView.State) {
            outRect.bottom = verticalSpaceHeight
        }
    }

    interface OnItemClickListener {
        fun onItemClick(gameName: String?)
    }
}