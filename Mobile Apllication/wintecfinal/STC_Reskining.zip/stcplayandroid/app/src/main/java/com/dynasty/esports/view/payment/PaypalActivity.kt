package com.dynasty.esports.view.payment

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.debugE
import com.dynasty.esports.view.common.BaseActivity
import kotlinx.android.synthetic.main.activity_webview_paypal.*

open class PaypalActivity : BaseActivity() {

    var paymentLink = ""
    var frequency = ""
    var paymentType = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_webview_paypal)

//        initBack()
        initIntentParams()
        init()
    }

    private fun initIntentParams() {
        try {
            if (intent.extras != null) {
                if (intent.extras!!.containsKey("paymentLink")) {
                    paymentLink = intent.getStringExtra("paymentLink")!!
                }
                if (intent.extras!!.containsKey("frequency")) {
                    frequency = intent.getStringExtra("frequency")!!
                }
                if (intent.extras!!.containsKey("paymentType")) {
                    paymentType = intent.getStringExtra("paymentType")!!
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun init() {
//        setTitleText("Payment")

        mWebView.setWebViewClient(object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                debugE("url", url)
            }

            override fun onLoadResource(view: WebView, url: String) {
                super.onLoadResource(view, url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (url.contains("paymentStatus=DONE")) {
                    setResult(Activity.RESULT_OK, Intent().putExtra("frequency", frequency).putExtra("paymentType", paymentType))
                    finish()
                } else if (url.contains("paymentStatus=cancelled")) {
                    setResult(Activity.RESULT_CANCELED)
                    finish()
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return super.shouldOverrideUrlLoading(view, request)
            }
        })

        mWebView.loadUrl(paymentLink)
    }


}