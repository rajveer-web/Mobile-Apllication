package com.dynasty.esports.view.tournamet.createtournament

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.Step2FieldsListItemBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.Step2Fields
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.*

/**
 * @desc this class will use for fields like desc, critical rules, rules etc in CreateTournamentStep2Fragment
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class Step2FieldsAdapter constructor(
    private val onItemClick: (Int, EditText) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<Step2FieldsAdapter.MyViewHolder>() {

    class MyViewHolder(val binding: Step2FieldsListItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    private var Step2FieldList: MutableList<Step2Fields> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val binding: Step2FieldsListItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.step2_fields_list_item,
            parent,
            false
        )
        return MyViewHolder(binding)
    }

    /**
     * @desc this method is used for expand child item from main view
     */
    fun setExpand(id: String) {
        for (gameItem in Step2FieldList) {
            if (gameItem.step2Id.equals(id, true)) {
                gameItem.isExpanded = !gameItem.isExpanded
            }
//            gameItem.isExpanded = gameItem.step2Id.equals(id, true)
        }
        notifyDataSetChanged()
    }

    /**
     * @desc this method will return single item from given id.
     */
    fun getDataFromId(id: String): String {
        for (gameItem in Step2FieldList) {
            if (gameItem.step2Id.equals(id, true)) {
                return gameItem.step2Child
            }
        }
        return ""
    }

    /**
     * @desc this method is used for set item data from given id
     * @param id is item id.
     * @param value set value in given id.
     */
    fun setDataFromId(id: String, value: String) {
        for (gameItem in Step2FieldList) {
            if (gameItem.step2Id.equals(id, true)) {
                gameItem.step2Child = value
            }
        }
    }

    /**
     * @desc Step2FieldList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return Step2FieldList.size
    }

    /**
     * @desc add list in gameList and notify adapter
     */
    fun addAll(sponcerList: MutableList<Step2Fields>?) {
        this.Step2FieldList.addAll(sponcerList!!)
        notifyDataSetChanged()
    }

    /**
     * @desc remove item from Step2FieldList as per given item
     */
    fun remove(item: Step2Fields) {
        Step2FieldList.remove(item)
        notifyDataSetChanged()
    }

    /**
     * @desc get single item from position
     */
    fun get(position: Int): Step2Fields {
        return Step2FieldList[position]
    }

    /**
     * @desc get Step2FieldList( main array list)
     */
    fun getAll(): MutableList<Step2Fields> {
        return Step2FieldList
    }

    /**
     * @desc clear or remove Step2FieldList and notify adapter
     */
    fun clear() {
        Step2FieldList.clear()
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = Step2FieldList[position]
        holder.binding.stepFields = data

        holder.binding.tvStep2Parent.text = nullSafeNA(data.step2Id)
        holder.binding.editFieldsDesc.hint = nullSafeNA(data.step2ParantTitle)

        if (data.isExpanded) {
            holder.binding.llFieldsParent.setBackgroundColor(
                holder.itemView.context.resources.getColor(
                    R.color.background_color
                )
            )
            holder.binding.tvStep2Parent.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_color))
            holder.binding.llFieldsChild.beVisible()
            holder.binding.imgFieldsDescExpand.setImageDrawable(
                holder.itemView.context.getDrawable(
                    R.drawable.ic_baseline_remove_circle_outline_24
                )
            )
        } else {
            holder.binding.tvStep2Parent.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_color))
            holder.binding.llFieldsChild.beGone()
            holder.binding.llFieldsParent.setBackgroundColor(
                holder.itemView.context.resources.getColor(
                    R.color.background_color
                )
            )
            holder.binding.imgFieldsDescExpand.setImageDrawable(
                holder.itemView.context.getDrawable(
                    R.drawable.ic_baseline_add_circle_outline_24
                )
            )
            holder. binding.root.context.updateTintColor(R.color.internal_app_bg_color, holder.binding.imgFieldsDescExpand)

        }

        holder.binding.llFieldsParent.click {
            onItemClick(position, holder.binding.editFieldsDesc)
        }
    }
}