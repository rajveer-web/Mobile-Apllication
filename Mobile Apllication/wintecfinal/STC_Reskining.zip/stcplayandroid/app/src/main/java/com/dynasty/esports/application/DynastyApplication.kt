package com.dynasty.esports.application

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.res.Resources
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.akexorcist.localizationactivity.core.LocalizationApplicationDelegate
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.di.mainAppModules
import com.dynasty.esports.extenstion.chatAccessToken
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.utils.LocaleHelper.onAttach
import com.github.nkzawa.socketio.client.Ack
import com.github.nkzawa.socketio.client.IO
import com.github.nkzawa.socketio.client.Socket
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.gson.JsonObject
import org.json.JSONArray
import org.json.JSONObject
import org.koin.android.ext.android.inject
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.logger.Level
import java.util.*


/**
 * @desc this is application class
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class DynastyApplication : Application() {
    private val localizationDelegate = LocalizationApplicationDelegate()
    var socket: Socket? = null

    val sharedPreferences: SharedPreferences by inject()

    override fun onCreate() {
        super.onCreate()

        FirebaseCrashlytics.getInstance()
        /**
         * it's injection framework of kotlin
         * Written in pure Kotlin using functional resolution only: no proxy, no code generation, no reflection
         */
        startKoin {
            androidLogger(Level.INFO)
            // Android context
            androidContext(this@DynastyApplication)
            // modules
            modules(mainAppModules)

        }
    }

    fun connectSocket() {
        try {
            if (socket != null && socket!!.connected()) {
                return
            }
            if (sharedPreferences.chatAccessToken != "null" && sharedPreferences.chatAccessToken != "") {
                socket = IO.socket(BuildConfig.CHAT_PATH_URL)
            }
            socket?.apply {
                this.on(Socket.EVENT_CONNECT) {
                    Log.e("TTT", "Connection Established with " + socket!!.id() + "..!")
                }.on(Socket.EVENT_DISCONNECT) {
                    Log.e("TTT", "Connection Disconnected..!")

                    //FOR RE-CONNECT SOCKET...
                    this.connect()
                }.on(Socket.EVENT_CONNECT_ERROR) { args ->
                    Log.e("TTT", "Connection Error..!" + args[0].toString())

                    //FOR RE-CONNECT SOCKET...
                    this.connect()
                }.on(Socket.EVENT_CONNECT_TIMEOUT) {
                    Log.e("TTT", "Connection Timeout..!")

                    //FOR RE-CONNECT SOCKET...
                    this.connect()
                }.on("notifyTyping") {
                    LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(
                        Intent(AppConstants.NOTIFY_START_TYPING).putExtra(
                            "data",
                            it[0].toString()
                        )
                    )
                    Log.e("Hello", "Typing....")
                }.on("notifyStopTyping") {
                    LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(
                        Intent(AppConstants.NOTIFY_STOP_TYPING).putExtra(
                            "data",
                            it[0].toString()
                        )
                    )
                    Log.e("Hello", "Stop Typing....")
                }.on("received") {
                    LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(
                        Intent(AppConstants.NOTIFY_RECEIVE_MESSAGE).putExtra(
                            "data",
                            it[0].toString()
                        )
                    )

                }
            }
            socket?.connect()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    fun socketEmit(event:String,value: JSONObject){
        try {
            if (isSocketConnected()) {
                socket?.apply {
                    this.emit(event, value)
                }
            }
        }catch (e:Exception){
            e.printStackTrace()
        }
    }


    fun socketEmit(event:String,value: String){
        try {
            if (isSocketConnected()) {
                socket?.apply {
                    this.emit(event, value)
                }
            }
        }catch (e:Exception){
            e.printStackTrace()
        }
    }

//
//    fun connectWithMatch(matchId: String) {
//        if (isSocketConnected()) {
//            socket?.apply {
//                this.emit("matchConnected", matchId)
//            }
//        }
//    }
//
//    fun disConnectWithMatch(matchId: String) {
//        if (isSocketConnected()) {
//            socket?.apply {
//                this.emit("matchDisconnected", matchId)
//            }
//        }
//    }
//
//    fun startTyping(matchId: String) {
//        if (isSocketConnected()) {
//            socket?.apply {
//                this.emit("typing", matchId)
//            }
//        }
//    }
//
//    fun stopTyping(matchId: String) {
//        if (isSocketConnected()) {
//            socket?.apply {
//                this.emit("stopTyping", matchId)
//            }
//        }
//    }

    fun sendMessage(messageObject: JSONObject) {
        if (isSocketConnected()) {
            socket?.apply {
                this.emit("new-message", messageObject,object : Ack{
                    override fun call(vararg args: Any?) {
                        Log.d("Hello",args.toString())
                    }

                })
            }
        }
    }

    fun disconnect() {
        try {
            socket?.apply {
                this.disconnect()
                this.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun isSocketConnected(): Boolean {
        return socket!!.connected()
    }


    // Assign context to Local Helper class for language
    override fun attachBaseContext(newBase: Context?) {
        val language = Resources.getSystem().configuration.locale.language
        newBase?.apply {
            if (LocaleHelper.getLanguage(this).isNullOrEmpty()) {
                if (!checkLanguage(language)) {
                    onAttach(this, "en")
                    localizationDelegate.setDefaultLanguage(this, Locale.ENGLISH)
                    super.attachBaseContext(localizationDelegate.attachBaseContext(this))
                    // super.attachBaseContext(onAttach(this))
                } else {
                    onAttach(this, language)
                    localizationDelegate.setDefaultLanguage(this, language)
                    super.attachBaseContext(localizationDelegate.attachBaseContext(this))
                }
            } else {

                localizationDelegate.setDefaultLanguage(
                    this,
                    LocaleHelper.getLanguage(this).toString()
                )
                super.attachBaseContext(localizationDelegate.attachBaseContext(this))
            }
        }


    }


    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localizationDelegate.onConfigurationChanged(this)
    }

    override fun getApplicationContext(): Context {
        return localizationDelegate.getApplicationContext(super.getApplicationContext())
    }

    private fun checkLanguage(language: String): Boolean {
        return when (language) {
            "en", "ms" -> {
                true
            }
            else -> {
                false
            }
        }
    }
}