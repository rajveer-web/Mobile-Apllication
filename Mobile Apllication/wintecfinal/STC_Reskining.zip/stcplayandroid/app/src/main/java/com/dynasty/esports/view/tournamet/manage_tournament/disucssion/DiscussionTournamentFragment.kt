package com.dynasty.esports.view.tournamet.manage_tournament.disucssion

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.DiscussionComment
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.tournamet.tournamet_detail.DiscussionCommentAdapter
import com.dynasty.esports.viewmodel.ManagedTournamentDiscussionViewModel
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_article_detail.*
import kotlinx.android.synthetic.main.fragment_discussion_tournament.*
import kotlinx.android.synthetic.main.fragment_discussion_tournament.imageViewUser
import kotlinx.android.synthetic.main.fragment_upcoming_discussion.*


import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.json.JSONObject
import org.koin.androidx.viewmodel.ext.android.viewModel

class DiscussionTournamentFragment : BaseFragment(),
    ConnectivityReceiver.ConnectivityReceiverListener {
    lateinit var loginUserModel: UserModel.UserData
    lateinit var discussionCommentAdapter: DiscussionCommentAdapter
    private var discussionList: MutableList<DiscussionComment.DataModel> = mutableListOf()
    private val mViewModel: ManagedTournamentDiscussionViewModel by viewModel()
    private var connectivityReceiver = ConnectivityReceiver() // define connectivity receiver
    private var id: String = ""
    private var positionComment: Int = 0
    private var gameID:String =""
    private var replayCommentPosition: Int = 0
    private var commentsLikeID: String = ""
    private var isReplyLikeComment: Boolean = false
    private var tournamentType:String=""
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_discussion_tournament, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            id = this.getString("id").toString()
            gameID=this.getString("gameID").toString()
            tournamentType=this.getString("tournamentType").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loginUserModel =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        initView()
        listenToViewModel()
    }

    private fun initView() {
        commonRecyclerView.layoutManager=LinearLayoutManager(requireContext())
        discussionCommentAdapter = DiscussionCommentAdapter(discussionList,  onReplyClick = ::onReplayClick,
            onLikeClick = ::onLikeComment,
            postReplyComment = ::onPostReplayComment)
        commonRecyclerView.adapter = discussionCommentAdapter
        requireActivity().loadImageFromServer(loginUserModel.profilePicture.toString(),imageViewUser)

        if(tournamentType=="past"){
            imageViewUser.beGone()
            CMEditTextView.beGone()
            buttonSubmit.beGone()
        }

        buttonSubmit.click {
            mViewModel.checkValidation(CMEditTextView.text.toString())
        }
    }

    private fun onLikeComment(position: Int, id: String, type: Int, likeId: String,
                              isReplyComment: Boolean,
                              replyPosition: Int) {

        positionComment = if (replyPosition != -1) {
            replayCommentPosition = position
            replyPosition
        } else {
            position
        }

        isReplyLikeComment = isReplyComment
        if (type == -1) {
            mViewModel.makeJsonObjectForLikeComment(id, sharedPreferences.id, "comment")
        } else {
            commentsLikeID = likeId
            mViewModel.makeJsonObjectForUpdateLike("updateLikeComment", if (type == 1) 0 else 1)
        }
    }

    /**
     * @desc method will call when tap on post comment button from comment adapter
     * @param comment comment message
     * @param position adapter click item position
     */
    private fun onPostReplayComment(comment: String, position: Int) {
        replayCommentPosition = position - 1
        mViewModel.makeJsonObjectForRepliesComment(
            "replies_comment",
            comment,
            discussionList[replayCommentPosition].id.toString(),
            sharedPreferences.id
        )
    }


    private fun onReplayClick(position: Int) {

//        if(articleCommentAdapter.getReplyPosition()!=-1){
//            if(position!=articleCommentAdapter.getReplyPosition()) {
//                articleCommentAdapter.addReplayView(position)
//            }
//        }else {
        discussionCommentAdapter.addReplayView(position)
//        }
    }

    private fun listenToViewModel() {
        mViewModel.isFormValid.observe(viewLifecycleOwner, {
            mViewModel.makeJsonForPostDiscussion(CMEditTextView.text.toString(),sharedPreferences.id,id)
        })

        mViewModel.makeJsonObjectForPostDiscussion.observe(viewLifecycleOwner,{
            launchProgressDialog()
            mViewModel.postComment("post",it)
        })

        mViewModel.validationLiveData.observe(viewLifecycleOwner, Observer {
            if (it == 0) {
                resources.getString(R.string.enter_comment_error).showToast(requireContext())
            }
        })

        mViewModel.makeJsonObjectForDiscussion.observe(viewLifecycleOwner, Observer {
            when (it.first) {
                "post", "replies_comment" -> {
                    launchProgressDialog()
                    mViewModel.postComment(it.first, it.second)
                }
                "comment" -> {
                    launchProgressDialog()
                    mViewModel.likeCommentAndArticle(it.second, it.first)
                }
                "updateLikeComment" -> {
                    launchProgressDialog()
                    mViewModel.updateLikeComment(commentsLikeID, it.second, "comment")
                }

            }
        })

        mViewModel.postCommentSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()
            when (it.first) {
                "post" -> {
                    textViewNoData.beGone()
                    CMEditTextView.setText("")
                    discussionList.add(it.second.data!!)
                    discussionCommentAdapter.notifyItemInserted(discussionList.size - 1)
                }
                else -> {
                    discussionList[replayCommentPosition].replies?.add(it.second.data!!)
                    discussionCommentAdapter.notifyItemChanged(replayCommentPosition)
                    discussionCommentAdapter.removeReplayView(replayCommentPosition + 1)
                }
            }
        })

        mViewModel.postCommentErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            it.second.string().getMessageFromObject("message")
                .showToast(requireActivity())

        })

        mViewModel.discussionSuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()
            it?.data?.apply {


                    discussionList.clear()
                    discussionList.addAll(this)

                    if(discussionList.isNullOrEmpty()){
                        constraintLayoutNoData.beVisible()
                        commonRecyclerView.beGone()
                    }else{
                        discussionCommentAdapter.notifyDataSetChanged()
                    }

            }
        })

        mViewModel.likeCommentSuccessResponse.observe(requireActivity(), Observer {
            dismissProgressDialog()
            if (it.second == "comment") {
                if (isReplyLikeComment) {
                    val comment = discussionList[positionComment].replies?.get(replayCommentPosition)!!
                    if (comment.type != -1) {
                        if (comment.type == 0) {
                            comment.type = 1
                            comment.totalLikes?.apply {
                                comment.totalLikes = this + 1
                            }
                        } else {
                            comment.type = 0
                            comment.totalLikes?.apply {
                                comment.totalLikes = this - 1
                            }
                        }
                    } else {
                        val linkedId =
                            JSONObject(it.first.string()).getJSONObject("data").getString("likeId")
                        comment.type = 1
                        comment.totalLikes = 1
                        comment.likeId = linkedId
                    }
                    discussionList[positionComment].replies?.set(replayCommentPosition, comment)

                    discussionCommentAdapter.notifyItemChanged(positionComment)

                } else {
                    val comment = discussionList[positionComment]
                    if (comment.type != -1) {
                        if (comment.type == 0) {
                            comment.type = 1
                            comment.totalLikes?.apply {
                                comment.totalLikes = this + 1
                            }
                        } else {
                            comment.type = 0
                            comment.totalLikes?.apply {
                                comment.totalLikes = this - 1
                            }
                        }
                    } else {
                        val linkedId =
                            JSONObject(it.first.string()).getJSONObject("data").getString("likeId")

                        comment.type = 1
                        comment.totalLikes = 1
                        comment.likeId = linkedId

                    }
                    discussionList[positionComment] = comment
                    discussionCommentAdapter.notifyItemChanged(positionComment)
                }

            }
        })

        mViewModel.likeCommentErrorResponse.observe(requireActivity(), Observer {
            dismissProgressDialog()
        })





        mViewModel.discussionErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
        })
        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it) {
                mViewModel.onDetach()
                logOut()
            }
        })
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beVisible()
        })

        mViewModel.timeOutException.observe(requireActivity(), Observer {
            displayCustomAlertDialog(resources.getString(R.string.timeout),isCancelable = false,positiveText = resources.getString(R.string.retry),positiveClick = {
                it.dismiss()
            })
        })
    }

    companion object {
        fun newInstance(id: String,gameID:String,  tournamentType:String): Fragment {
            val args = Bundle()
            args.putString("id", id)
            args.putString("tournamentType",tournamentType)
            args.putString("gameID", gameID)
            val fragment = DiscussionTournamentFragment()
            fragment.arguments = args
            return fragment
        }
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc UnRegister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && discussionList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beGone()
            constraintLayoutErrorView.beGone()
            mViewModel.fetchDiscussions(loginUserModel.id!!, id)
        } else if (discussionList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutErrorView.beGone()
        }
    }

}