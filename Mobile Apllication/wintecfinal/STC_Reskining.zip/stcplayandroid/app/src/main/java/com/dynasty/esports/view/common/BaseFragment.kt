package com.dynasty.esports.view.common

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.utils.*
import com.dynasty.esports.view.chat.ChatListActivity
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.viewmodel.CommonViewModel
import com.google.android.material.button.MaterialButton
import com.marcoscg.dialogsheet.DialogSheet
import de.hdodenhof.circleimageview.CircleImageView
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this is base calls of all fragments and in this call manage common things which need in more than one fragment.
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
open class BaseFragment : Fragment() {
    val sharedPreferences: SharedPreferences by inject()
    lateinit var progressDialog: Dialog
    var showPassword = false
    val commonViewModel: CommonViewModel by viewModel()

    //  val localizationDelegate = LocalizationApplicationDelegate()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        showProgressDialog()
    }

    override fun onAttach(context: Context) {
        super.onAttach(LocaleHelper.onAttach(context))
    }

    fun EditText.onConfirmDrawableClicked(onClicked: (view: EditText) -> Unit) {
        showPassword = true
        this.setOnTouchListener { v, event ->
            var hasConsumed = false
            if (v is EditText) {
                if (event.x >= v.width - v.totalPaddingRight) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onClicked(this)
                    }
                    hasConsumed = true
                }
            }
            hasConsumed
        }
    }

    fun EditText.onRightDrawableClicked(onClicked: (view: EditText) -> Unit) {
        showPassword = true
        this.setOnTouchListener { v, event ->
            var hasConsumed = false
            if (v is EditText) {
                if (event.x >= v.width - v.totalPaddingRight) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onClicked(this)
                    }
                    hasConsumed = true
                }
            }
            hasConsumed
        }
    }


    /**
     *@desc create progress dialog for doing api call or heavy task on main thread
     *@return Dialog
     */
    private fun showProgressDialog(isCancelable: Boolean = false): Dialog {
        progressDialog = Dialog(requireActivity())
        progressDialog.setContentView(R.layout.progress_dialog_view)
        progressDialog.setCancelable(isCancelable)
        progressDialog.window?.setBackgroundDrawable(ColorDrawable(0))
        return progressDialog
    }

    /**
     *@desc show progress dialog when doing api call or heavy task on main thread
     */
    open fun launchProgressDialog() {
        if (::progressDialog.isInitialized && progressDialog != null && !progressDialog.isShowing)
            progressDialog.show()
    }

    /**
     * Hide progress bar when doing api call or heavy task on main thread
     */
    fun dismissProgressDialog() {
        if (::progressDialog.isInitialized && progressDialog != null && progressDialog.isShowing) {
            progressDialog.dismiss()
        }
    }

    /**
     *@desc Show country picker dialog
     */
    fun displayCountryCodeDialog() {
        CountryCodePicker.showDialog(parentFragmentManager)
    }

    /**
     *@desc this method will use for when refresh token expired and tap on logout option.
     */
    fun logOut() {
        dismissProgressDialog()
        displayCustomAlertDialog(title = resources.getString(R.string.session_expired),
            isCancelable = false,
            positiveText = resources.getString(R.string.btn_ok),
            positiveClick = {
                it.dismiss()
                sharedPreferences.clear()
                sharedPreferences.isAppOpenFirstTime = true
                startActivityFinishAllFromFragment<PhoneSignInActivity>()

            })

    }

    /**
     *@desc Custom Alert dialog for show dialog in the app when need.
     *@param string title - the title to be displayed
     *@param string desc - the desc to be displayed
     *@param Bool isCancelable- set dialog is cancelable or not.
     *@param Bool isCloseShow- need to show close icon or not.
     *@param Bool isButtonShow- need to show cancel button or not.
     *@param String positiveText- positive text to be displayed
     *@param Unit positiveClick- assign positive button click
     *@param String negativeText- negative text to be displayed
     *@param Unit onCloseClick- assign Close icon click
     *
     */
    fun displayCustomAlertDialog(
        title: String = "",
        desc: String = "",
        isCancelable: Boolean = true,
        isCloseShow: Boolean = false,
        isButtonShow: Boolean = true,
        positiveText: String = "",
        positiveClick: (Dialog) -> Unit = { _ -> },
        negativeText: String? = "",
        negativeClick: (Dialog) -> Unit = { _ -> },
        onCloseClick: (Dialog) -> Unit = { _ -> }
    ) {
        val alertLayout: View = layoutInflater.inflate(R.layout.custom_dialog_view, null)
        val textViewTitle: TextView = alertLayout.findViewById(R.id.textViewTitle)
        val textViewDesc: TextView = alertLayout.findViewById(R.id.textViewDescription)
        val buttonPositive: MaterialButton = alertLayout.findViewById(R.id.buttonPositive)
        val buttonNegative: MaterialButton = alertLayout.findViewById(R.id.buttonNegative)
        val constraintLayoutButton: ConstraintLayout =
            alertLayout.findViewById(R.id.constraintLayoutButton)
        val imageViewClose: ImageView = alertLayout.findViewById(R.id.imageViewClose)

        val alertDialogBuilder = AlertDialog.Builder(requireContext())
        alertDialogBuilder.setTitle("")
        alertDialogBuilder.setView(alertLayout)
        alertDialogBuilder.setCancelable(isCancelable)
        val dialog: AlertDialog = alertDialogBuilder.create()
        if (title == "") {
            textViewTitle.beGone()
        } else {
            textViewTitle.beVisible()
        }
        if (desc == "") {
            textViewDesc.beInVisible()
        } else {
            textViewDesc.beVisible()
        }
        if (positiveText == "") {
            buttonPositive.beGone()
        }

        if (negativeText == "") {
            buttonNegative.beGone()
        }


        if (isCloseShow) {
            imageViewClose.beVisible()
        }

        if (isButtonShow) {
            constraintLayoutButton.beVisible()
        } else {
            constraintLayoutButton.beGone()
        }
        buttonNegative.text = negativeText
        buttonPositive.text = positiveText
        textViewTitle.text = title
        textViewDesc.text = desc

        buttonPositive.click {
            positiveClick(dialog)
        }
        buttonNegative.click {
            negativeClick(dialog)
        }


        imageViewClose.click {
            onCloseClick(dialog)
        }
        dialog.show()


    }

    fun displayAnnouncemnetDialog(
        title: String = "",
        desc: String = "",
        isCancelable: Boolean = true,
        isCloseShow: Boolean = false,
        isButtonShow: Boolean = true,
        isIconImg: String = "",
        isBckImg: String = "",

        positiveText: String = "",
        positiveClick: () -> Unit = { -> },
        negativeText: String? = "",
        negativeClick: (Dialog) -> Unit = { _ -> },
        onCloseClick: (Dialog) -> Unit = { _ -> }
    ) {
        val dialogSheet = DialogSheet(requireContext(), false)
        dialogSheet.setView(R.layout.custom_announcement_dialog)
        dialogSheet.setRoundedCorners(true)
        val inflatedView = dialogSheet.inflatedView
        val buttonPositive = inflatedView?.findViewById<CLButtonView>(R.id.buttonPositive)
        val buttonNegative = inflatedView?.findViewById<CLButtonView>(R.id.buttonNegative)
        val textViewTitle = inflatedView?.findViewById<CMTextView>(R.id.textViewTitle)
        val textViewDesc = inflatedView?.findViewById<CRTextView>(R.id.textViewDescription)
        val imageViewClose = inflatedView?.findViewById<ImageView>(R.id.imageViewClose)
        val imageViewIcon = inflatedView?.findViewById<ImageView>(R.id.imgIcon)
        val imageViewBck = inflatedView?.findViewById<ImageView>(R.id.imageViewBackground)
        val constraintLayoutButton: ConstraintLayout? =
            inflatedView?.findViewById(R.id.constraintLayoutButton)

        if (title == "") {
            textViewTitle?.beGone()
        } else {
            textViewTitle?.beVisible()
        }
        if (desc == "") {
            textViewDesc?.beInVisible()
        } else {
            textViewDesc?.beVisible()
        }
        if (positiveText == "") {
            buttonPositive?.beGone()
        }
        if (negativeText == "") {
            buttonNegative?.beGone()
        }
        if (isCloseShow) {
            imageViewClose?.beVisible()
        }

        if (isIconImg == "") {
            imageViewIcon?.beGone()
        } else {
            imageViewIcon?.beVisible()
            imageViewIcon?.let { requireActivity().loadImageFromServer(isIconImg, it) }
        }

        if (isBckImg == "") {
            imageViewBck?.beGone()
        } else {
            imageViewBck?.beVisible()
            imageViewBck?.let { requireActivity().loadImageFromServer(isBckImg, it) }
        }

        if (isButtonShow) {
            constraintLayoutButton?.beVisible()
        } else {
            constraintLayoutButton?.beGone()
        }

        buttonNegative?.text = negativeText
        buttonPositive?.text = positiveText
        textViewTitle?.text = title
        textViewDesc?.text = desc

        buttonPositive?.setOnClickListener {
            dialogSheet.dismiss()
            positiveClick()
        }
        buttonNegative?.setOnClickListener {
            Toast.makeText(requireContext(), "Negs", Toast.LENGTH_SHORT).show()
        }
        imageViewClose?.setOnClickListener {
            dialogSheet.dismiss()
        }

        dialogSheet.show()
    }

    fun displayMatchmakingDialog(
        title: String,
        description: String
    ) {

        val dialogSheet = DialogSheet(requireContext(), false)
        dialogSheet.setView(R.layout.custom_match_making_dialog)
        dialogSheet.setCancelable(false)
        dialogSheet.setRoundedCorners(true)
        val inflatedView = dialogSheet.inflatedView
        val linearLayout = inflatedView?.findViewById<LinearLayout>(R.id.ll_background)
        val imageViewClose = inflatedView?.findViewById<ImageView>(R.id.imageViewClose)
        val textViewTitle = inflatedView?.findViewById<CMTextView>(R.id.textViewTitle)
        val textViewDiscription = inflatedView?.findViewById<CMTextView>(R.id.textViewDescription)
        val circularImageViewProfile =
            inflatedView?.findViewById<CircleImageView>(R.id.ivmatchmaking);
        val textViewProfileName = inflatedView?.findViewById<CMTextView>(R.id.textViewProfileName);
        val textViewProfileAddress =
            inflatedView?.findViewById<CMTextView>(R.id.textViewProfileAddress)
        val positiveButtonContinue = inflatedView?.findViewById<CMButtonView>(R.id.btn_continue)
        val progressBar = inflatedView?.findViewById<ProgressBar>(R.id.progressBar);
        val positiveButtonChat = inflatedView?.findViewById<CMButtonView>(R.id.btn_chat)

        textViewTitle?.text = title
        textViewDiscription?.text = description

        positiveButtonContinue?.setOnClickListener(View.OnClickListener {
            textViewTitle?.text = resources.getString(R.string.mm_title1)
            textViewDiscription?.text = resources.getString(R.string.mm_decription1)
            positiveButtonContinue?.visibility = View.GONE
            progressBar?.visibility = View.VISIBLE
        })

        imageViewClose?.setOnClickListener(View.OnClickListener
        {
            dialogSheet.dismiss()
        })
        Handler().postDelayed(Runnable
        {
            progressBar?.progress = 100

            linearLayout?.visibility = View.GONE
            progressBar?.visibility = View.GONE
            positiveButtonContinue?.visibility = View.GONE
            textViewDiscription?.visibility = View.GONE

            circularImageViewProfile?.visibility = View.VISIBLE
            textViewTitle?.text = resources.getString(R.string.mm_title3)
            textViewProfileName?.visibility = View.VISIBLE
            textViewProfileAddress?.visibility = View.VISIBLE
            textViewProfileName?.text = resources.getString(R.string.mm_matchName)

            textViewProfileAddress?.text = resources.getString(R.string.mm_matchAddress)
            positiveButtonChat?.visibility = View.VISIBLE



            imageViewClose?.setBackgroundResource(R.drawable.ic_close)


        }, 6000)


        positiveButtonChat?.setOnClickListener(View.OnClickListener
        {
            Toast.makeText(requireContext(), "Lets Chat", Toast.LENGTH_LONG).show()
            startActivityFromFragment<ChatListActivity>()
            dialogSheet.dismiss()
        })

        dialogSheet.show()

    }

    fun redirectToWebsite(redirectionUrl: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(redirectionUrl)
        startActivity(intent)
    }

    }
