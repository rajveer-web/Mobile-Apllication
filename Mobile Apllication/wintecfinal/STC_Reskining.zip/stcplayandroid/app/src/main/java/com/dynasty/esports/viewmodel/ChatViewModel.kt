package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.ChatMessageListModel
import com.dynasty.esports.models.MatchFindModel
import com.dynasty.esports.models.MatchsListModel
import com.dynasty.esports.retrofit.ChatInterface
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class ChatViewModel constructor(
    private val restInterface: RestInterface,
    private val chatInterface: ChatInterface
) : BaseViewModel() {


    val chatLogOutSuccessResponse = MutableLiveData<ResponseBody>()
    val chatLogOutErrorResponse = MutableLiveData<ResponseBody>()


    val chatLoginSuccessResponse = MutableLiveData<ResponseBody>()
    val chatLoginErrorResponse = MutableLiveData<ResponseBody>()

    val chatListSuccessResponse = MutableLiveData<MutableList<ChatMessageListModel>>()
    val chatListErrorResponse = MutableLiveData<ResponseBody>()

    val findMatchSuccessResponse = MutableLiveData<MatchFindModel>()
    val findMatchErrorResponse = MutableLiveData<ResponseBody>()

    val makeJsonObjectForChatLogin = MutableLiveData<JsonObject>()
    val makeJsonObjectForChatLogOut = MutableLiveData<JsonObject>()


    val matchListSuccessResponse = MutableLiveData<MutableList<MatchsListModel>>()
    val matchListErrorResponse = MutableLiveData<ResponseBody>()

    fun chatLogin(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = chatInterface.loginChat(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    chatLoginSuccessResponse.postValue(response.body())
                }
                else -> {
                    chatLoginErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    fun getAllMatches(userId: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = chatInterface.getMatchList(userId)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    matchListSuccessResponse.postValue(response.body())
                }
                else -> {
                    matchListErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    fun getAllChatList(id: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = chatInterface.getChatList(id)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    chatListSuccessResponse.postValue(response.body())
                }
                else -> {
                    chatListErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    fun findMatch(id:String){
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.findMatch(id)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    findMatchSuccessResponse.postValue(response.body())
                }
                else -> {
                    findMatchErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun chatLogout(jsonObj: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = chatInterface.logOutChat(jsonObj)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    chatLogOutSuccessResponse.postValue(response.body())
                }
                else -> {
                    chatLogOutErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

    fun makeJsonForChatLogin(phone: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("phone_number", phone)
        jsonObject.addProperty("password", "")
        jsonObject.addProperty("type", "withoutpassword")
        makeJsonObjectForChatLogin.postValue(jsonObject)
    }


    fun makeJsonForChatLogOut(token: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("token", token)
        makeJsonObjectForChatLogOut.postValue(jsonObject)
    }

}