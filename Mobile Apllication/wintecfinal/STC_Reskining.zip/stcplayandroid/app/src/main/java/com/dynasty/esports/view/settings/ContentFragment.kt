package com.dynasty.esports.view.settings

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.getMessageFromObject
import com.dynasty.esports.extenstion.isOnline
import com.dynasty.esports.models.ContentUserPrefModel
import com.dynasty.esports.models.CustomContentModel
import com.dynasty.esports.models.PlatformModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.ContentViewModel
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will display content data
 * @author : Mahesh Vayak
 * @created : 24-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ContentFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    private val mViewModel: ContentViewModel by viewModel()
    private val platformList: MutableList<PlatformModel> = mutableListOf()
    private lateinit var contentAdapter: ContentAdapter
    private var customContentList: MutableList<CustomContentModel> = mutableListOf()
    private var contentPref: ContentUserPrefModel.DataModel? = null
    private var connectivityReceiver = ConnectivityReceiver()

    override fun onCreateView(inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?): View? {
        /**
         * add platform option in array list
         */
        platformList.add(
            PlatformModel(
                "mobile",
                R.drawable.ic_mobile,
                resources.getString(R.string.mobile_platform)
            )
        )
        platformList.add(
            PlatformModel(
                "desktop",
                R.drawable.ic_desktop,
                resources.getString(R.string.desktop_platform)
            )
        )
        platformList.add(
            PlatformModel(
                "console",
                R.drawable.ic_console_icom,
                resources.getString(R.string.consol_platform)
            )
        )
        return inflater.inflate(R.layout.recycler_progress_bar_view, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * @desc Initialize view
         */
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        contentAdapter = ContentAdapter(customContentList, onSaveItemClick = ::onSaveItemClick)
        commonRecyclerView.adapter = contentAdapter
        listenToViewModel()

    }

    /**
     * @desc Method will call when tap Save option from adapter
     * @param chooseGameList : selected game  ids
     * @param gameCenterList : selected game center ids
     * @param gameContentList : selected game contents ids
     * @param gamePlatformList : selected game platforms ids
     */
    private fun onSaveItemClick(
        chooseGameList: MutableList<String>,
        gameCenterList: MutableList<String>,
        gameContentList: MutableList<String>,
        gamePlatformList: MutableList<String>
    ) {
        mViewModel.makeJsonForPref(
            chooseGameList,
            gamePlatformList,
            gameCenterList,
            gameContentList
        )

    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make json object for API and un authorization.
     */
    private fun listenToViewModel() {

        mViewModel.makeJsonObjectObserver.observe(viewLifecycleOwner, Observer {
            launchProgressDialog()
            mViewModel.updateContentPref(it)
        })

        mViewModel.updateContentSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            displayCustomAlertDialog(
                it.string().getMessageFromObject("message"),
                isCancelable = false,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })

        mViewModel.updateContentErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            displayCustomAlertDialog(
                it.string().getMessageFromObject("message"),
                isCancelable = false,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })

        mViewModel.contentSuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()

            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beVisible()
            it?.apply {
                this.data?.apply {
                    customContentList.add(CustomContentModel(1))
                    customContentList.add(
                        CustomContentModel(
                            2,
                            resources.getString(R.string.choose_your_game),
                            chooseGamesList = this.game
                        )
                    )
                    customContentList.add(
                        CustomContentModel(
                            3,
                            resources.getString(R.string.choose_platform),
                            platformsList = platformList
                        )
                    )
                    customContentList.add(
                        CustomContentModel(
                            4,
                            resources.getString(R.string.choose_game_center),
                            gameCenterList = this.genre
                        )
                    )
                    customContentList.add(
                        CustomContentModel(
                            5,
                            resources.getString(R.string.choose_content),
                            contentCenterList = this.prefer
                        )
                    )
                    customContentList.add(CustomContentModel(6))
                    contentAdapter.let {
                        contentPref?.apply {
                            it.updatedUserPref(this)
                        } ?: it.notifyDataSetChanged()
                    }

                }
            }
        })

        mViewModel.contentPrefSuccessResponse.observe(viewLifecycleOwner, Observer {
            it?.apply {
                this.data?.apply {
                    contentPref = this
                }
            }
        })

        mViewModel.contentPrefErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beVisible()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beGone()
        })

        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it)
                logOut()
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            dismissProgressDialog()
            if (requireActivity().isOnline()) {
                if (it == "all") {
                    linearLayoutProgressBar.beGone()
                    constraintLayoutErrorView.beVisible()
                    constraintLayoutNoInternet.beGone()
                    commonRecyclerView.beGone()
                } else {
                    displayCustomAlertDialog(
                        resources.getString(R.string.something_wrong_try_again),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.btn_ok),
                        positiveClick = {
                            it.dismiss()
                        })
                }
            } else {
                if (it != "all") {
                    displayCustomAlertDialog(
                        resources.getString(R.string.no_internet_message),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.btn_ok),
                        positiveClick = {
                            it.dismiss()
                        })
                }
            }
        })

    }


    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }


    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && customContentList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beGone()
            mViewModel.getContentAndPreference()
        } else if (customContentList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beVisible()
            commonRecyclerView.beGone()
        }
    }
}