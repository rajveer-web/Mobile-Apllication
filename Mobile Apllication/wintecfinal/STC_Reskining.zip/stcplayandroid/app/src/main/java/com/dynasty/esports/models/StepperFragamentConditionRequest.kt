package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class StepperFragamentConditionRequest (
    @field:SerializedName("priceAmt1")
    var priceAmt1: String? = null,

    @field:SerializedName("priceAmt2")
    var priceAmt2: String? = null,

    @field:SerializedName("priceAmt3")
    var priceAmt3: String? = null,

    @field:SerializedName("selectCurrency")
    var selectCurrency: String? = null,

    @field:SerializedName("sponsorName")
    var sponsorName: String? = null,

    @field:SerializedName("webUrl")
    var webUrl: String? = null,

    @field:SerializedName("appStoreUrl")
    var appStoreUrl: String? = null,


    @field:SerializedName("playStoreUrl")
    var playStoreUrl: String? = null,

    /*Tournament typeis remaining*/

    @field:SerializedName("screenshot")
    var screenshot: Boolean? = null,


    @field:SerializedName("countryFlag")
    var countryFlag: Boolean? = null  ,

    @field:SerializedName("scoreReporting")
    var scoreReporting: Int? = null,

    @field:SerializedName("tournamentType")
    var tournamentType: String? = null,
    @field:SerializedName("maxParticipants")
    var participationLimit: Int? = null

)