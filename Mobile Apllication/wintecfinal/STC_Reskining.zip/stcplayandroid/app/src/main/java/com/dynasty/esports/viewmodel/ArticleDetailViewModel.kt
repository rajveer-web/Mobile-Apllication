package com.dynasty.esports.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class ArticleDetailViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    // define MutableLiveData for emit observer
    val articleDetailSuccessResponse = MutableLiveData<ArticleDetailModel>()
    val articleDetailErrorResponse = MutableLiveData<ResponseBody>()
    val articleViewUpdateSuccessResponse = MutableLiveData<ResponseBody>()
    val articleCommentSuccessResponse = MutableLiveData<ArticleCommentModel>()
    val checkBookMarkSuccessResponse = MutableLiveData<ResponseBody>()
    val checkBookMarkErrorResponse = MutableLiveData<ResponseBody>()
    val articleDetailUIResponse = MutableLiveData<ArticleDetailModel.DataModel>()

    val postCommentSuccessResponse = MutableLiveData<Pair<String, PostCommentModel>>()
    val postCommentErrorResponse = MutableLiveData<Pair<String, ResponseBody>>()

    val likeCommentSuccessResponse = MutableLiveData<Pair<ResponseBody, String>>()
    val likeCommentErrorResponse = MutableLiveData<Pair<ResponseBody, String>>()

    val addBookMarkSuccessResponse = MutableLiveData<ResponseBody>()
    val addBookMarkErrorResponse = MutableLiveData<ResponseBody>()

    val deleteBookMarkSuccessResponse = MutableLiveData<ResponseBody>()
    val deleteBookMarkErrorResponse = MutableLiveData<ResponseBody>()

    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val getDiscussionCommentListPostSuccessResponse = MutableLiveData<DiscussionComment>()
    val getDiscussionCommentListPostErrorResponse = MutableLiveData<ResponseBody>()
    val discussionPostCommentSuccessResponse = MutableLiveData<DiscussionPostCommentModel>()
    val discussionPostCommentErrorResponse = MutableLiveData<ResponseBody>()
    val postCommentDiscussionSuccessResponse = MutableLiveData<Pair<String, DiscussionPostCommentModel>>()

    val makeJsonObjectForArticleDetail = MutableLiveData<Pair<JsonObject, JsonObject>>()
    val makeQueryParameterForBookMark = MutableLiveData<HashMap<String, String>>()

    //  val makeJsonObjectForLikeArticle= MutableLiveData<Pair<String,JsonObject>>()
    val makeJsonObjectForArticle = MutableLiveData<Pair<String, JsonObject>>()
    val makeJsonObjectForRelatedArticle =
        MutableLiveData<Pair<JsonObject, JsonObject>>()

    val relatedArticleSuccessResponse = MutableLiveData<HottestPostArticleModel>()


    /**
     * @desc Method will use for call API for article detail(Article Details,Comments,Likes )
     * @param id-article id
     * @param jsonObject-article detail jsonobject
     * @param userId-login user id
     * @param query- query for check bookmark
     */
    fun getAllArticles(id: String, jsonObject: JsonObject, userId: String, query: String) {
        viewModelScope.launch(apiException("all")) {
            val articleDetailResponse = async { restInterface.getArticleDetail(id) }
            val updateViewResponse = async { restInterface.updateArticleViews(id, jsonObject) }
            val getArticleCommentAndLikes = async { restInterface.getArticleComment(id, userId) }
            val checkBookmark = async { restInterface.checkBookMark(query, "articleBookmarks") }

            if (articleDetailResponse.await().code() == AppConstants.API_SUCCESS_CODE) {
                articleDetailSuccessResponse.postValue(articleDetailResponse.await().body())
            }

            if (updateViewResponse.await().code() == AppConstants.API_SUCCESS_CODE) {
                articleViewUpdateSuccessResponse.postValue(updateViewResponse.await().body())
            }

            if (getArticleCommentAndLikes.await().code() == AppConstants.API_SUCCESS_CODE) {
                articleCommentSuccessResponse.postValue(getArticleCommentAndLikes.await().body())
            }

            if (checkBookmark.await().code() == AppConstants.API_SUCCESS_CODE) {
                checkBookMarkSuccessResponse.postValue(checkBookmark.await().body())
            } else {
                checkBookMarkErrorResponse.postValue(checkBookmark.await().errorBody())
            }
        }
    }

    /**
     * @desc Method will handle for get realted articles
     * @param query - pass query parameter
     */
    fun fetchRelatedArticles(query: String, option: String) {
        viewModelScope.launch(apiException("related") + Dispatchers.Main) {
            val response = restInterface.getMoreTrendingPost(query, option)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    relatedArticleSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
//                else -> {
//                    trendingPostErrorResponse.postValue(response.errorBody())
//                }
            }
        }
    }

    /**
     * @desc Method will use for post comment
     * @param type- comment type ["post", "replies_comment"]
     * @param jsonObject-article comment jsonobject
     */
    fun postComment(type: String, commentJson: JsonObject) {
        viewModelScope.launch(apiException("comment") + Dispatchers.Main) {
            val response = restInterface.postArticleComment(commentJson)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    postCommentSuccessResponse.postValue(Pair(type, response.body()!!))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    postCommentErrorResponse.postValue(Pair(type, response.errorBody()!!))
                }
            }

        }
    }


    /**
     * @desc Method will use for post comment
     * @param type- comment type ["post", "replies_comment"]
     * @param jsonObject-article comment jsonobject
     */
    fun postCommentDiscussion(type: String, commentJson: JsonObject) {
        viewModelScope.launch(apiException("comment") + Dispatchers.Main) {
            val response = restInterface.postDisComment(commentJson)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    postCommentDiscussionSuccessResponse.postValue(Pair(type, response.body()!!))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    postCommentErrorResponse.postValue(Pair(type, response.errorBody()!!))
                }
            }

        }
    }

    /**
     * @desc Method will use for like comment and article
     * @param type- like type  ["article", "comment"]
     * @param jsonObject-comment or article like jsonobject
     */
    fun likeCommentAndArticle(jsonObject: JsonObject, type: String) {

        viewModelScope.launch(apiException("comment") + Dispatchers.IO) {
            val response = restInterface.likeArticleAndComment(jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    likeCommentSuccessResponse.postValue(Pair(response.body()!!, type))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    likeCommentErrorResponse.postValue(Pair(response.errorBody()!!, type))
                }
            }

        }
    }

    /**
     * @desc Method will use for update like comment and article
     * @param type- like type  ["article", "comment"]
     * @param id- article id
     * @param jsonObject-comment or article like jsonobject
     */
    fun updateLikeComment(id: String, jsonObject: JsonObject, type: String) {
        viewModelScope.launch(apiException("comment") + Dispatchers.IO) {
            val response = restInterface.updateLikeArticleAndComment(id, jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    likeCommentSuccessResponse.postValue(Pair(response.body()!!, type))
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    likeCommentErrorResponse.postValue(Pair(response.errorBody()!!, type))
                }
            }
        }
    }

    /**
     * @desc Method will use for add article in bookmark
     * @param jsonObject- bookmark json object.
     */
    fun addBookMark(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("bookmark") + Dispatchers.Main) {
            val response = restInterface.addBookMark(jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    addBookMarkSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    addBookMarkErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * @desc Method will use for delete article in bookmark
     * @param articleId- article id
     */
    fun deleteBookMark(queryMap: Map<String,String>) {
        viewModelScope.launch(apiException("bookmark") + Dispatchers.Main) {
            val response = restInterface.deleteBookMark(queryMap)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    deleteBookMarkSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    deleteBookMarkErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

//    fun updateViews(id:String,jsonObject: JsonObject) {
//        viewModelScope.launch(exceptionHandler) {
//            val response = restInterface.updateArticleViews(id,jsonObject)
//
//            withContext(Dispatchers.Main) {
//                when (response.code()) {
//                    AppConstants.API_SUCCESS_CODE -> {
//                        articleViewUpdateSuccessResponse.postValue(response.body())
//                    }
//                    else -> {
//
//                        articleViewUpdateErrorResponse.postValue(response.errorBody())
//                    }
//                }
//            }
//        }
//    }

    /**
     * @desc Method will use for get discussion comments for tournament
     * @param userId- logged in use id
     * @param tournamentId- tournament id
     */
    fun getDiscussionComment(userId: String, tournamentId: String) {
        viewModelScope.launch(apiException("trending") + Dispatchers.Main) {
            val response = restInterface.getDiscussionComment(userId, tournamentId)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    getDiscussionCommentListPostSuccessResponse.postValue(response.body())
                }
                else -> {
                    getDiscussionCommentListPostErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will use for post new comment in discussion
     * @param commentJson- json object for post comment
     */
    fun discussionPostComment(commentJson: JsonObject) {
        viewModelScope.launch(apiException("comment") + Dispatchers.Main) {
            val response = restInterface.postDiscussionComment(commentJson)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    discussionPostCommentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    discussionPostCommentErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * @desc Method will use for update article detail UI
     * @param dataModel- pass article data model
     */
    fun updateArticleUI(dataModel: ArticleDetailModel.DataModel) {
        articleDetailUIResponse.postValue(dataModel)
    }

    /**
     * @desc Method will use for check form validation
     * @param comment- post comment string
     */
    fun checkValidation(comment: String) {
        when {
            comment.isFieldEmpty() -> validationLiveData.postValue(0)
            else -> isFormValid.postValue(true)
        }
    }


    /**
     * @desc Method will use for create query parameter for delete bookmar
     * @param key- key (article/video)
     * @param id - article id
     */
    fun makeQueryParameter(key: String, id: String) {
        val hashMap:HashMap<String,String> = hashMapOf()
        hashMap[key] = id
        makeQueryParameterForBookMark.postValue(hashMap)
    }

    /**
     * @desc Method will use for create article detail json object for pass API request
     * @param id- article id
     * @param userId - logged in user id
     */
    fun makeJsonObjectForArticleDetail(id: String, userId: String) {
        val jsonObjectViews = JsonObject()
        jsonObjectViews.addProperty("views", 1)
        val jsonObjectRoot = JsonObject()
        jsonObjectRoot.add("\$inc", jsonObjectViews)

        val jsonObjectQuery = JsonObject()
        jsonObjectQuery.addProperty("userId", userId)
        jsonObjectQuery.addProperty("articleBookmarks", id)
        makeJsonObjectForArticleDetail.postValue(Pair(jsonObjectRoot, jsonObjectQuery))
    }

    /**
     * @desc Method will use to create json object for like and comment article
     * @param id- article id
     * @param userId -  logged in user id
     * @param type - type ["article" ,"comment"]
     */
    fun makeJsonObjectForLikeComment(id: String, userId: String, type: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("objectId", id)
        jsonObject.addProperty("objectType", type)
        jsonObject.addProperty("type", 1)
        jsonObject.addProperty("userId", userId)
        jsonObject.addProperty("createdBy", userId)
        makeJsonObjectForArticle.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for update like and comment article
     * @param type- like and comment types ["updateLikeArticle","updateLikeComment"]
     * @param likeType - like Type ["0" ,"1"]
     */
    fun makeJsonObjectForUpdateLike(type: String, likeType: Int) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("type", likeType)
        makeJsonObjectForArticle.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for post comment.
     * @param type- comment type ["post"]
     * @param text - comment text
     * @param id - article id
     * @param userId - logged in user id
     */
    fun makeJsonObjectForPostComment(type: String, text: String, id: String, userId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("comment", text)
        jsonObject.addProperty("userId", userId)
        jsonObject.addProperty("objectId", id)
        jsonObject.addProperty("objectType", "article")
        makeJsonObjectForArticle.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for replies comment.
     * @param type- comment type ["replies_comment"]
     * @param text - comment text
     * @param id - article id
     * @param userId - logged in user id
     */
    fun makeJsonObjectForRepliesComment(type: String, text: String, id: String, userId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("comment", text)
        jsonObject.addProperty("userId", userId)
        jsonObject.addProperty("objectId", id)
        jsonObject.addProperty("objectType", "comment")
        makeJsonObjectForArticle.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for add bookmark
     * @param type- comment type ["addBookMark"]
     * @param articleId - article id
     */
    fun makeJsonObjectForAddBookMark(type: String, articleId: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("articleId", articleId)
        makeJsonObjectForArticle.postValue(Pair(type, jsonObject))
    }

    /**
     * @desc Method will use to create json object for related articles
     * @param type- comment type ["addBookMark"]
     * @param articleId - article id
     */
    fun makeJsonObjectForRelatedArticles(type: String, tags: MutableList<String>, id: String) {
        val jsonObjectRoot = JsonObject()

        val jsonArrayTemp = JsonArray()
        tags.forEach {
            jsonArrayTemp.add(it)
        }
        val jsonArrayRoot = JsonArray()
        val jsonObjectTags = JsonObject()
        val jsonObjectIn = JsonObject()
        jsonObjectIn.add("\$in", jsonArrayTemp)

        val jsonObjectGame = JsonObject()
        jsonObjectTags.add("tags", jsonObjectIn)
        jsonObjectGame.addProperty("gameDetails", id)

        jsonArrayRoot.add(jsonObjectTags)
        jsonArrayRoot.add(jsonObjectGame)
        jsonObjectRoot.add("\$or", jsonArrayRoot)

        val jsonObjectSort = JsonObject()
        jsonObjectSort.addProperty("views", -1)

        val jsonObjectOption = JsonObject()
        jsonObjectOption.addProperty("limit", 4)
        jsonObjectOption.add("sort", jsonObjectSort)



        makeJsonObjectForRelatedArticle.postValue(Pair(jsonObjectRoot,jsonObjectOption))
    }

    /**
     * Clears the [ViewModel] when the [Fragment or Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }


}
