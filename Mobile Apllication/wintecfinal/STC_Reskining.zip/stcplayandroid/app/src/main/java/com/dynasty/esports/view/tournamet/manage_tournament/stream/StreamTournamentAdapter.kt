package com.dynasty.esports.view.tournamet.manage_tournament.stream


import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterTournamentStreamBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.ManageTournamentModel
import com.dynasty.esports.utils.BindingHolder


class StreamTournamentAdapter(
    private var streamList: MutableList<ManageTournamentModel.StreamModel>,
    private val onItemClick: (String) -> Unit = { _ -> },
    private val onDeleteItemClick: (Int) -> Unit = { _ -> },
    private val onEditItemClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterTournamentStreamBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterTournamentStreamBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_tournament_stream,
                parent,
                false
            )
        )

    }

    override fun getItemCount(): Int {
        return streamList.size
    }


    @SuppressLint("SetJavaScriptEnabled")
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterTournamentStreamBinding>,
        position: Int
    ) {
        val data = streamList[position]
        holder.binding.textViewTitle.text = data.title?.let { it } ?: "-"
        holder.binding.textViewDescription.text = data.description?.let { it } ?: "-"
        holder.binding.cardViewTournament.click {
           // onItemClick(data.videoUrl?.providerName.plus(data.videoUrl?.channelName))
            onItemClick(switch(data.type.toString(), data.videoUrl?.channelName.toString()))
        }
        holder.binding.imageViewDelete.click {
            onDeleteItemClick(position)
        }

        holder.binding.imageViewEdit.click {
            onEditItemClick(position)
        }
//        var path = switch(data.type.toString(), data.videoUrl?.channelName.toString())
//        Log.d("TTT", "path: " + path)
//        var finalUrl =
//            "<html><body><iframe allowfullscreen=\"true\" webkitallowfullscreen=\"true\" mozallowfullscreen=\"true\" src=\"$path\"></iframe></body></html>"
//        Log.d("TTT", "finalUrl: " + finalUrl)

        //holder.binding.webViewVideo.loadUrl(path)
//        holder.binding.webViewVideo.loadData(finalUrl, "text/html", "UTF-8")
//        holder.binding.webViewVideo.webViewClient = WebViewClient()
//        holder.binding.webViewVideo.settings.javaScriptEnabled = true
//        holder.binding.webViewVideo.settings.setSupportZoom(true)
    }

    private fun switch(type: String, channelName: String): String {
        var path = ""
        when {
            type.equals("YOUTUBE", true) -> {
                path = "https://www.youtube.com/embed/${channelName}"
            }
            type.equals("SMASHCAST", true) -> {
                path = "https://www.smashcast.tv/#!/embed/${channelName}"
            }
            type.equals("MOBCRUSH", true) -> {
                path = "https://www.mobcrush.com/${channelName}/embed"
            }
            type.equals("TWITCH", true) -> {
                path = "https://player.twitch.tv/?channel=${channelName}&parent=twitch.tv"
            }
            type.equals("FACEBOOK", true) -> {
                path = "https://www.facebook.com/video/embed?video_id=${channelName.split('/').reversed()[0]}"
            }
            else ->{
                path = "http://stc-1237359093.me-south-1.elb.amazonaws.com/web-view/custom-streaming?channelName=${channelName}"
            }
        }
        return path
    }

}