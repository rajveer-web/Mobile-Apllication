package com.dynasty.esports.view.article.view_all_article

import android.content.IntentFilter
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.constants.ArticleConstant
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ArticleAuthorsModel
import com.dynasty.esports.models.GamesModel
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.models.LatestArticleModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.article.article_detail.ArticlesDetailActivity
import com.dynasty.esports.view.article.article_detail.RelatedGamesAdapter
import com.dynasty.esports.view.article.article_section.ArticleAuthorAdapter
import com.dynasty.esports.view.article.article_section.ArticlePostGamesAdapter
import com.dynasty.esports.view.article.article_section.LatestArticleAndNewsAdapter
import com.dynasty.esports.view.article.article_section.TrendingPostAdapter
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.viewmodel.ViewAllArticleViewModel
import com.google.android.material.appbar.AppBarLayout
import kotlinx.android.synthetic.main.activity_view_all_articles.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import kotlin.math.abs

/**
 * @desc this class will show all articles and post by games
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ViewAllArticlesActivity : BaseActivity(), ConnectivityReceiver.ConnectivityReceiverListener {
    private lateinit var relatedVideoAdapter: RelatedGamesAdapter // define related video adapter
    private var trendingPostAdapter: LatestArticleAndNewsAdapter? = null // define trending post adapter
    private var gameArticleAdapter: TrendingPostAdapter? = null // define trending post adapter
    private var articleAuthorAdapter: ArticleAuthorAdapter? = null // define article author adapter
    private var articlePostGamesAdapter: ArticlePostGamesAdapter? =
        null // define post by games  adapter
    private var authorList: MutableList<ArticleAuthorsModel.DataModel> = mutableListOf()
    private var gamesList: MutableList<GamesModel.DataModel> = mutableListOf()
    private var trendingPostList: MutableList<LatestArticleModel.DocModel> = mutableListOf()
    private var gamesArticleListList: MutableList<HottestPostArticleModel.DataModel> = mutableListOf()
    private var sliderPagerAdapter: SliderPagerAdapter? =
        null // define hottest post slider  adapter
    private val mViewModel: ViewAllArticleViewModel by viewModel()  // inject viewall viewmodel class
    private var connectivityReceiver = ConnectivityReceiver() // initialize connection receiver
    private var limit = 10
    private var page = 1
    private var type: Int? = null
    private var title: String = ""
    private var isGame: Boolean = false
    private var id: String = ""
    private var paginatedRV: FrameLayout? = null
    private var isDataLoaded = false
    private var gridLayoutManager: GridLayoutManager? = null
    private var isLoadMoreData = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_all_articles)
        getIntentData()
        initView()
        viewClickListener()
        listenToViewModel()
    }

    /**
     * @desc get data from intent
     */
    private fun getIntentData() {
        intent.extras?.apply {
            isGame = this.getBoolean("isGame")
            id = this.getString("id").toString()
            type = this.getInt("type")
            title = this.getString("title").toString()
        }
    }

    /**
     * @desc this method will use for initialize view and assign adapter to recyclerview and other some operations.
     */
    private fun initView() {
        gridLayoutManager = GridLayoutManager(this, 2)

//        gridLayoutManager?.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//            override fun getSpanSize(position: Int): Int {
//                when (type) {
//                    ArticleConstant.CONST_POST_BY_AUTHOR -> {
//                        return if (authorList[position].isLoadMore) {
//                            2
//                        } else {
//                            1
//                        }
//                    }
//                    ArticleConstant.CONST_POST_BY_GAMES -> {
//                        return if (gamesList[position].isLoadMore) {
//                            2
//                        } else {
//                            1
//                        }
//                    }
//                    ArticleConstant.CONST_TRENDING_POST -> {
//                        return if (trendingPostList[position].isLoadMore) {
//                            2
//                        } else {
//                            1
//                        }
//                    }
//                }
//                return 1
//            }
//        }
        recyclerViewArticle.layoutManager = gridLayoutManager
        ViewCompat.setNestedScrollingEnabled(recyclerViewArticle, false)
//        recyclerViewArticle.isNestedScrollingEnabled = false
        recyclerViewArticle.isFocusable = false
        //    constraintLayoutPostByGames.background = getGradientColor()
        recyclerViewRelatedVideo.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerViewRelatedVideo.isNestedScrollingEnabled = false
        recyclerViewRelatedVideo.isFocusable = false
        collapsingToolbar.setCollapsedTitleTypeface(mediumFont())
        textViewArticleName.text = title

        nestedScrollViewArticle.viewTreeObserver?.addOnScrollChangedListener {
            //If the paginated rv is not calculated already

            if (paginatedRV == null) {
                //Get the parent holder
                val holder = nestedScrollViewArticle.getChildAt(0) as ViewGroup
                //Loop through all children of parent holder


                for (i in 0 until holder.childCount) {
                    //Pull the pagination recyclerview child
                    if (holder.getChildAt(i).id == frameLayoutArticle.id) {
                        paginatedRV = holder.getChildAt(i) as FrameLayout
                        break
                    }

                }
            }
            paginatedRV?.let {
                val bottomStart = it.bottom - 300
                if ((nestedScrollViewArticle.height + nestedScrollViewArticle.scrollY) in bottomStart..it.bottom) {
                    if (isLoadMoreData) {
                        progressBarLoadMore.beVisible()
                        loadMoreData()
                    }
                }


            }

        }

        when (type) {
            ArticleConstant.CONST_LATEST_ARTICLE -> {
                if (id == "null") {
                    mViewModel.makeJsonForTrendingPost(page, limit)
                } else {
                    //   mViewModel.makeJsonObjectForPostByGame(id, isGame)
                }
            }
            ArticleConstant.CONST_POST_BY_AUTHOR -> {
                mViewModel.getMoreAuthor(page, limit)
            }
            ArticleConstant.CONST_POST_BY_GAMES -> {
                mViewModel.makeJsonForMorePostByGames(page, limit)
            }
        }

        if (type != ArticleConstant.CONST_POST_BY_GAMES) {
            mViewModel.makeJsonForPostByGames()
        } else {
            constraintLayoutPostByGames.beGone()
            btnViewAll.beGone()
        }

    }

    private fun loadMoreData() {

        isLoadMoreData = false
        when (type) {
            ArticleConstant.CONST_POST_BY_AUTHOR -> {
                onLoadMoreAuthor()
            }
            ArticleConstant.CONST_POST_BY_GAMES -> {
                onLoadMoreGames()
            }
            ArticleConstant.CONST_LATEST_ARTICLE -> {
                onLoadMoreTrendingPost()

            }
        }

    }

    /**
     * @desc this method use for assign listener and view click
     */
    private fun viewClickListener() {
        ivback.click {
            onBackPressed()
        }

        btnViewAll.click {
            val bundle = Bundle()
            bundle.putString("title", resources.getString(R.string.post_by_games))
            bundle.putInt("type", ArticleConstant.CONST_POST_BY_GAMES)
            startActivityInline<ViewAllArticlesActivity>(bundle)
        }
    }

    /**
     * @desc listen observer and observer that will receive the events
     * and Manage API success and failure,Internet connectivity, make API json request and un authorization,
     */
    private fun listenToViewModel() {
        mViewModel.makeJsonObjectMorePostGame.observe(this, {
            mViewModel.getMoreGames(it.first.toString(), it.second.toString())
        })

        mViewModel.makeJsonObjectForPaginationPostByGame.observe(this, Observer {
            mViewModel.getGames(it.toString())
        })

        mViewModel.makeJsonObjectForPostByGame.observe(this, {
//            if (it.first) {
//                mViewModel.getMoreTrendingPostByGames(it.second.toString())
//            } else {
            mViewModel.getMoreTrendingPostByGames(it.second.toString())
//            }
        })

        mViewModel.makeJsonObjectForTrendingPost.observe(this, {
            mViewModel.getMoreTrendingPost(
                it.first.toString(),
                it.second.first.toString(),
                it.second.second.toString()
            )
        })

        mViewModel.unAuthorizationException.observe(this, {
            if (it) {
                mViewModel.onDetach()
                logOut()
            }
        })
        mViewModel.postByGamesArticleSuccessResponse.observe(this, {
            progressBarLoader.beGone()
            it.data?.apply {


                if (!this.isNullOrEmpty()) {
                    if (gamesArticleListList.isEmpty()) {
                        gamesArticleListList.addAll(this)
                        gameArticleAdapter = TrendingPostAdapter(
                            gamesArticleListList,
                            onItemClick = ::onArticleClick
                        )
                        recyclerViewArticle.adapter = gameArticleAdapter

                    } else {
                        isLoadMoreData = true
                        stopLoadMore()
                        gamesArticleListList.addAll(this)
                        gameArticleAdapter?.apply {
                            notifyDataSetChanged()
                        }
                    }
                    page += 1
                } else {
                    isLoadMoreData = false
                    stopLoadMore()
                }


            }
        })

        mViewModel.postByGamesArticleErrorResponse.observe(this, {
            if (!gamesArticleListList.isNullOrEmpty()) {
                stopLoadMore()
            } else {
                progressBarLoader.beGone()
                textViewNoData.text = resources.getString(R.string.some_thing_went_wrong)
                textViewNoData.beVisible()
            }
        })


        mViewModel.trendingPostSuccessResponse.observe(this, {
            progressBarLoader.beGone()
            it.data?.docs?.apply {


                if (!this.isNullOrEmpty()) {
                    if (trendingPostList.isEmpty()) {
                        trendingPostList.addAll(this)
                        trendingPostAdapter = LatestArticleAndNewsAdapter(
                            trendingPostList,
                            onItemClick = ::onArticleClick
                        )
                        recyclerViewArticle.adapter = trendingPostAdapter

                    } else {
                        isLoadMoreData = true
                        stopLoadMore()
                        trendingPostList.addAll(this)
                        trendingPostAdapter?.apply {
                            notifyDataSetChanged()
                        }
                    }
                    page += 1
                } else {
                    isLoadMoreData = false
                    stopLoadMore()
                }


            }
        })

        mViewModel.trendingPostErrorResponse.observe(this, {
            if (!trendingPostList.isNullOrEmpty()) {
                stopLoadMore()
            } else {
                progressBarLoader.beGone()
                textViewNoData.text = resources.getString(R.string.some_thing_went_wrong)
                textViewNoData.beVisible()
            }
        })


        mViewModel.authorSuccessResponse.observe(this, {
            progressBarLoader.beGone()

            it?.data?.apply {
                if (!this.isNullOrEmpty()) {
                    if (authorList.isEmpty()) {
                        authorList.addAll(this)
                        articleAuthorAdapter =
                            ArticleAuthorAdapter(authorList, onItemClick = ::onAuthorClick)
                        recyclerViewArticle.adapter = articleAuthorAdapter

                    } else {
                        isLoadMoreData = true
                        stopLoadMore()
                        authorList.addAll(this)
                        articleAuthorAdapter?.apply {
                            notifyDataSetChanged()
                        }
                    }
                    page += 1
                } else {
                    isLoadMoreData = false
                    stopLoadMore()
                }
            }

        })

//        mViewModel.trendingPostErrorResponse.observe(this, Observer {
//
//        })
//
        mViewModel.authorErrorResponse.observe(this, {
            if (authorList.isNotEmpty()) {
                stopLoadMore()
                isLoadMoreData = true
            }
        })
//
//        mViewModel.gamesErrorResponse.observe(this, Observer {
//
//        })

        mViewModel.gamesSuccessResponse.observe(this, {
            if (type != ArticleConstant.CONST_POST_BY_GAMES) {
                relatedVideoAdapter =
                    RelatedGamesAdapter(it.data!!, onItemClick = ::onRelatedGameClick)
                recyclerViewRelatedVideo.adapter = relatedVideoAdapter
            } else {
                progressBarLoader.beGone()
                it?.data?.apply {
                    if (!this.isNullOrEmpty()) {
                        if (gamesList.isEmpty()) {
                            gamesList.addAll(this)
                            articlePostGamesAdapter =
                                ArticlePostGamesAdapter(
                                    gamesList,
                                    onItemClick = ::onPostByGameItemClick
                                )
                            recyclerViewArticle.adapter = articlePostGamesAdapter

                        } else {
                            isLoadMoreData = true
                            stopLoadMore()
                            gamesList.addAll(this)
                            articlePostGamesAdapter?.apply {
                                notifyDataSetChanged()
                            }
                        }
                        page += 1
                    } else {
                        isLoadMoreData = false
                        stopLoadMore()
                    }
                }
            }
        })


        mViewModel.hottestPostSuccessResponse.observe(this, {
            isDataLoaded = true
            mViewModel.updateHeaderUISlider(it.data)

        })

        /**
         * @desc get data from Observer and display it.
         */
        mViewModel.updateHeaderUI.observe(this, {

            coordinatorLayoutArticleViewAll.beVisible()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beGone()
            sliderPagerAdapter = SliderPagerAdapter(this, it, onItemClick = { id ->
                val bundle = Bundle()
                bundle.putString("id", id)
                startActivityInline<ArticlesDetailActivity>(bundle)
            })
            viewPagerSlider.adapter = sliderPagerAdapter

            appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
                when {
                    abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                        // Collapsed
                        collapsingToolbar.title = title
                    }
                    else -> {
                        collapsingToolbar.title = ""
                        // Expanded
                    }
                }
            })
        })

        mViewModel.hottestPostErrorResponse.observe(this, {
            isDataLoaded = false
            coordinatorLayoutArticleViewAll.beVisible()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beGone()
//            constraintLayoutErrorView.beVisible()
        })


        mViewModel.noInternetException.observe(this, {
            if (isOnline()) {
                if (it == "main") {
                    coordinatorLayoutArticleViewAll.beGone()
                    linearLayoutProgressBar.beGone()
                    constraintLayoutNoInternet.beGone()
                    constraintLayoutErrorView.beVisible()
                }
            }

        })


    }

    /**
     * @desc method will call when tap on author and display all articles of author
     * @param id author id
     * @param title author title
     */
    private fun onAuthorClick(id: String, title: String) {
        val bundle = Bundle()
        bundle.putString("id", id)
        bundle.putBoolean("isGame", false)
        bundle.putString("title", title)
        bundle.putInt("type", ArticleConstant.CONST_LATEST_ARTICLE)
        startActivityInline<ViewAllArticlesActivity>(bundle)
    }

    /**
     * @desc method will call when tap on game item and display all articles of game
     * @param id game id
     * @param title game title
     */
    private fun onRelatedGameClick(id: String, title: String) {
        val bundle = Bundle()
        bundle.putString("id", id)
        bundle.putBoolean("isGame", true)
        bundle.putString("title", title)
        bundle.putInt("type", ArticleConstant.CONST_LATEST_ARTICLE)
        startActivityInline<ViewAllArticlesActivity>(bundle)
    }

    /**
     * @desc method will call when tap on article item and redirect to article detail screen.
     * @param id article id
     */
    private fun onArticleClick(id: String) {
        val bundle = Bundle()
        bundle.putString("id", id)
        startActivityInline<ArticlesDetailActivity>(bundle)
    }

    /**
     * @desc method will call when tap on post by game item and display all articles of game
     * @param id game id
     * @param title game title
     */
    private fun onPostByGameItemClick(id: String, title: String) {
        val bundle = Bundle()
        bundle.putString("id", id)
        bundle.putBoolean("isGame", true)
        bundle.putString("title", title)
        bundle.putInt("type", ArticleConstant.CONST_LATEST_ARTICLE)
        startActivityInline<ViewAllArticlesActivity>(bundle)
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && !isDataLoaded) {
            coordinatorLayoutArticleViewAll.beGone()
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beGone()
            mViewModel.getAllHottestPortSlider()
        } else if (!isDataLoaded) {
            coordinatorLayoutArticleViewAll.beGone()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beVisible()
            constraintLayoutErrorView.beGone()
        }
    }

    /**
     * @desc Register receiver for check internet connection
     */
    override fun onResume() {
        super.onResume()
        registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }


    /**
     * @desc Unregister receiver for check internet connection
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    private fun onLoadMoreGames() {
        mViewModel.makeJsonForMorePostByGames(page, limit)
//        val model = GamesModel.DataModel()
//        model.isLoadMore = true
//        gamesList.add(model)
//        recyclerViewArticle.post {
//            articlePostGamesAdapter?.apply {
//                notifyItemInserted(gamesList.size - 1)
//            }
//            mViewModel.makeJsonForMorePostByGames(page, limit)
//
//        }
    }


    private fun stopLoadMoreGames() {
        gamesList.removeAt(gamesList.size - 1)
        recyclerViewArticle.post {
            articlePostGamesAdapter?.apply {
                notifyDataSetChanged()
            }
        }

    }

    private fun onLoadMoreAuthor() {
        mViewModel.getMoreAuthor(page, limit)
//        val model = ArticleAuthorsModel.DataModel()
//        model.isLoadMore = true
//        authorList.add(model)
//        recyclerViewArticle.post {
//            articleAuthorAdapter?.apply {
//                notifyItemInserted(authorList.size - 1)
//            }
//            mViewModel.getMoreAuthor(page, limit)
//        }
    }


    private fun stopLoadMoreAuthor() {

        authorList.removeAt(authorList.size - 1)
        recyclerViewArticle.post {
            articleAuthorAdapter?.apply {
                notifyDataSetChanged()
            }
        }

    }

    private fun onLoadMoreTrendingPost() {
        mViewModel.makeJsonForTrendingPost(page, limit)
//        val model = HottestPostArticleModel.DataModel()
//        model.isLoadMore = true
//        trendingPostList.add(model)
//        recyclerViewArticle.post {
//            trendingPostAdapter?.apply {
//                notifyItemInserted(trendingPostList.size - 1)
//            }
//            mViewModel.makeJsonForTrendingPost(page,limit)
//        }
    }


    private fun stopLoadMore() {
        progressBarLoadMore.beGone()
//        trendingPostList.removeAt(trendingPostList.size - 1)
//        recyclerViewArticle.post {
//            trendingPostAdapter?.apply {
//                notifyDataSetChanged()
//            }
//        }

    }


}