package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class SearchVideoModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    @SerializedName("totals")
    @Expose
     val totals: TotalsModel? = null

    class DataModel{
        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("views")
        @Expose
         val views: Int? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("youtubeUrl")
        @Expose
         val youtubeUrl: String? = null

        @SerializedName("description")
        @Expose
         val description: TitleModel? = null

        @SerializedName("tags")
        @Expose
         val tags: MutableList<String>? = null

        @SerializedName("platforms")
        @Expose
         val platforms: MutableList<String>? = null

        @SerializedName("genres")
        @Expose
         val genres: MutableList<String>? = null

        @SerializedName("game")
        @Expose
         val game: String? = null

        @SerializedName("category")
        @Expose
         val category: String? = null

        @SerializedName("thumbnailUrl")
        @Expose
         val thumbnailUrl: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("fullText")
        @Expose
         val fullText: String? = null

    }

}