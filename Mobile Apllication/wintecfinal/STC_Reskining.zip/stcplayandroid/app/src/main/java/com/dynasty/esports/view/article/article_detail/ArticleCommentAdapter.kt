package com.dynasty.esports.view.article.article_detail


import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterArticleCommentBinding
import com.dynasty.esports.databinding.ReplayCommentLayoutBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ArticleCommentModel
import com.dynasty.esports.models.UserModel
import org.koin.core.KoinComponent
import org.koin.core.inject

/**
 * @desc this is class will handle list of article comments
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ArticleCommentAdapter constructor(
    private var commentList: MutableList<ArticleCommentModel.ArticleComment>,
    private val onReplyClick: (Int) -> Unit = { _ -> },
    private val postReplyComment: (String, Int) -> Unit = { _, _ -> },
    private val onLikeClick: (Int, String, Int, String, Boolean, Int) -> Unit = { _, _, _, _, _, _ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), KoinComponent {
    val sharedPreferences: SharedPreferences by inject()
    private var loginUserModel: UserModel.UserData? = null
    private var replyPosition = -1
    private var commentReplayAdapter: CommentReplayAdapter? = null

    /**
     * @desc get user detail from local storage
     */
    init {
        if (sharedPreferences.checkUserLoggedInOrNot())
            loginUserModel = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
    }

    fun updateUserData(){
        if (sharedPreferences.checkUserLoggedInOrNot())
            loginUserModel = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData

        notifyDataSetChanged()
    }
    /**
     *@desc This ViewHolder should be constructed with a new View that can represent the items
     * of the given type.
     */
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> {
                val binding: AdapterArticleCommentBinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.context),
                    R.layout.adapter_article_comment,
                    parent,
                    false
                )
                ArticleCommentHolder(binding)
            }
            else -> {
                val binding: ReplayCommentLayoutBinding =
                    DataBindingUtil.inflate(inflater, R.layout.replay_comment_layout, parent, false)
                ReplayViewHolder(binding)
            }
        }
    }

    /**
     * @desc comment array size count.
     * @return int- size of array
     */
    override fun getItemCount(): Int {
        return commentList.size
    }

    /**
     * @desc method will use for manage comment UI and reply comment UI.Also, pass object to ArticleCommentHolder
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ArticleCommentHolder).bind(commentList[holder.adapterPosition])
            }
            1 -> {
                (holder as ReplayViewHolder).bind()
            }
        }
    }

    /**
     * @desc Return the view type of the item at <code>position</code> for the purposes
     * of view recycling.
     */
    override fun getItemViewType(position: Int): Int {
        return if (commentList[position].isReply) {
            1
        } else {
            0
        }
    }

    /**
     * @desc class use for show reply comment UI and handle components
     * @param binding -Reply comment layout binder
     */
    inner class ReplayViewHolder(private var binding: ReplayCommentLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind() {
            loginUserModel?.apply {
                binding.root.context.loadImageFromServer(
                    this.profilePicture.toString(),
                    binding.imageViewUser
                )
                binding.textView.text = this.fullName.toString()
            }
            binding.editTextComment.setText("")
            binding.buttonReply.click {
                if (!binding.editTextComment.text.toString().trim().isFieldEmpty()) {
                    postReplyComment(
                        binding.editTextComment.text.toString().trim(),
                        adapterPosition
                    )
                } else {
                    binding.root.context.resources.getString(R.string.enter_comment_error)
                        .showToast(binding.root.context)
                }

            }
            binding.buttonCancel.click {
                removeReplyView(adapterPosition)
            }
        }
    }


    /**
     * @desc class use for display comment data and handle view.
     * @param binding -Article Comment layout binder
     */
    inner class ArticleCommentHolder(private var binding: AdapterArticleCommentBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(articleCommentModel: ArticleCommentModel.ArticleComment) {
            articleCommentModel.userDetails?.apply {
                binding.textViewUserName.text = this.fullName?.let { it } ?: ""
                binding.root.context.loadImageFromServer(
                    this.profilePicture.toString(),
                    binding.imageViewUser
                )
            }

            binding.textViewUserComment.text = articleCommentModel.comment?.let { it } ?: ""

            binding.textViewDate.text = articleCommentModel.createdOn?.getTimeAgo(
                AppConstants.API_DATE_FORMAT,
                AppConstants.REQUIRED_TIME_FORMAT
            )

            articleCommentModel.totalLikes?.apply {
                binding.textViewLike.text = this.toString()
            }

            if (articleCommentModel.type == 1) {
                binding.root.context.updateTintColor(R.color.colorAccent, binding.imageViewLike)
            } else {
                binding.root.context.updateTintColor(
                    R.color.black,
                    binding.imageViewLike
                )
            }

            binding.imageViewLike.click {
                onLikeClick(
                    adapterPosition, articleCommentModel.id.toString(),
                    articleCommentModel.type!!, articleCommentModel.likeId.toString(), false, -1
                )
            }

            binding.recyclerViewReplay.layoutManager = LinearLayoutManager(binding.root.context)
            commentReplayAdapter = CommentReplayAdapter(
                articleCommentModel.replies!!,
                onLikeClick = { position: Int, id: String, type: Int, likeID: String ->
                    onLikeClick(
                        position, id,
                        type, likeID, true, adapterPosition
                    )

                })
            binding.recyclerViewReplay.adapter = commentReplayAdapter

            if (articleCommentModel.replies.isNullOrEmpty()) {
                binding.textViewShowReply.beGone()
            } else {
                binding.textViewShowReply.beVisible()
            }


            if (articleCommentModel.isViewVisible) {
                binding.textViewShowReply.text =
                    binding.root.context.resources.getString(R.string.hide_replies)
                binding.recyclerViewReplay.beVisible()

            } else {
                articleCommentModel.isViewVisible = false
                binding.textViewShowReply.text =
                    binding.root.context.resources.getString(R.string.show_replay)
                binding.recyclerViewReplay.beGone()
            }

            binding.textViewShowReply.click {
                if (binding.recyclerViewReplay.visibility == View.GONE) {
                    articleCommentModel.isViewVisible = true
                    binding.textViewShowReply.text =
                        binding.root.context.resources.getString(R.string.hide_replies)
                    binding.recyclerViewReplay.beVisible()
                } else {
                    articleCommentModel.isViewVisible = false
                    binding.textViewShowReply.text =
                        binding.root.context.resources.getString(R.string.show_replay)
                    binding.recyclerViewReplay.beGone()
                }
            }

            binding.textViewReplay.click {
                if (replyPosition != -1) {
                    if (replyPosition != adapterPosition + 1) {
                        removeReplyView(replyPosition)
                        onReplyClick(adapterPosition + 1)
                    }
                } else {
                    onReplyClick(adapterPosition + 1)
                }
            }


        }
    }

    /**
     * @desc add dummy object in array for show progress bar
     * @param position - position of comment list
     */
    fun addReplyView(position: Int) {
        replyPosition = position
        val model = ArticleCommentModel.ArticleComment()
        model.isReply = true
        commentList.add(position, model)
        notifyItemInserted(position)
    }

    /**
     * @desc remove dummy object in array for hide progress bar
     * @param position - position of comment list
     */
    fun removeReplyView(position: Int) {
        replyPosition = -1
        commentList.removeAt(position)
        notifyItemRemoved(position)
    }


}
