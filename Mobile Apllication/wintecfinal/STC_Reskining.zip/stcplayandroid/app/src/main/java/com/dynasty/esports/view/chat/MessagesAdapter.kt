package com.dynasty.esports.view.chat


import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterChatReceiverBinding
import com.dynasty.esports.databinding.AdapterChatSenderBinding

import com.dynasty.esports.models.InboxModel
import org.koin.core.KoinComponent
import org.koin.core.inject

/**
 * @desc this is class will be display inbox data
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class MessagesAdapter(
    private var chatList: MutableList<InboxModel>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), KoinComponent {
    val sharedPreferences: SharedPreferences by inject()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> {
                val binding: AdapterChatReceiverBinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.context),
                    R.layout.adapter_chat_receiver,
                    parent,
                    false
                )
                ReceiverViewHolder(binding)
            }
            else -> {
                val binding: AdapterChatSenderBinding =
                    DataBindingUtil.inflate(inflater, R.layout.adapter_chat_sender, parent, false)
                SenderViewHolder(binding)
            }
        }

    }

    /**
     * @desc inboxList array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return 10
    }

    override fun getItemViewType(position: Int): Int {
        return if (position % 2 == 0) {

            1
        } else {
            0
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

    }

    inner class ReceiverViewHolder(private var binding: AdapterChatReceiverBinding) :
        RecyclerView.ViewHolder(binding.root) {


    }

    inner class SenderViewHolder(private var binding: AdapterChatSenderBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }


}