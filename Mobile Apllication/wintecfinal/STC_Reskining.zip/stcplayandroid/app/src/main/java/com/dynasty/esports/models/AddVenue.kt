package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

data class AddVenue(
    var venue: String = "",
    var country: String = "",
    var region: String = ""
)