package com.dynasty.esports.view.tournamet.tournamet_detail


import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterArticleCommentBinding
import com.dynasty.esports.databinding.ReplayCommentLayoutBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.DiscussionComment
import com.dynasty.esports.models.UserModel
import org.koin.core.KoinComponent
import org.koin.core.inject

//row_article_post
class DiscussionCommentAdapter constructor(
    private var commentList: MutableList<DiscussionComment.DataModel>,
    private val onReplyClick: (Int) -> Unit = { _ -> },
    private val onLikeClick: (Int, String, Int, String, Boolean, Int) -> Unit = { _, _, _, _, _, _ -> },
    private val postReplyComment: (String, Int) -> Unit = { _, _ -> }
) :  RecyclerView.Adapter<RecyclerView.ViewHolder>(), KoinComponent {

    private var commentReplayAdapter: DiscussionCommentReplayAdapter? = null
    val sharedPreferences: SharedPreferences by inject()
    private var loginUserModel:  UserModel.UserData? = null
    private var replyPosition=-1
    init {
        if (sharedPreferences.checkUserLoggedInOrNot())
            loginUserModel = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
    }

    fun updateUserData(){
        if (sharedPreferences.checkUserLoggedInOrNot())
            loginUserModel = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData

        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> {
                val binding: AdapterArticleCommentBinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.context),
                    R.layout.adapter_article_comment,
                    parent,
                    false)
                DiscussionCommentHolder(binding)
            }
            else -> {
                val binding: ReplayCommentLayoutBinding =
                    DataBindingUtil.inflate(inflater, R.layout.replay_comment_layout, parent, false)
                ReplayViewHolder(binding)
            }
        }
    }

    override fun getItemCount(): Int {
        return commentList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (commentList[position].isReply) {
            1
        } else {
            0
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0->{
                (holder as DiscussionCommentHolder).bind(commentList[holder.adapterPosition])
            }
            1->{
                (holder as ReplayViewHolder).bind()
            }
        }
    }

    inner class ReplayViewHolder(private var binding: ReplayCommentLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(){
            loginUserModel?.apply {
                binding.root.context.loadImageFromServer(this.profilePicture.toString(),binding.imageViewUser)
                binding.textView.text=this.fullName.toString()
            }
            binding.editTextComment.setText("")
            binding.buttonReply.click {
                if (!binding.editTextComment.text.toString().trim().isFieldEmpty()) {
                    postReplyComment(
                        binding.editTextComment.text.toString().trim(),
                        adapterPosition
                    )
                } else {
                    binding.root.context.resources.getString(R.string.enter_comment_error)
                        .showToast(binding.root.context)
                }
            }
            binding.buttonCancel.click {
                removeReplayView(adapterPosition)
            }
        }
    }


    inner class DiscussionCommentHolder(private var binding: AdapterArticleCommentBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(articleCommentModel: DiscussionComment.DataModel) {
//        fun bind(articleCommentModel: ArticleCommentModel.ArticleComment) {
            articleCommentModel.userDetails?.apply {
                binding.textViewUserName.text=this.fullName?.let { it } ?: ""
                binding.root.context.loadImageFromServer(this.profilePicture.toString(),binding.imageViewUser)
            }

            binding.textViewUserComment.text=articleCommentModel.comment?.let { it } ?: ""

            binding.textViewDate.text = articleCommentModel.createdOn?.getTimeAgo(
                AppConstants.API_DATE_FORMAT,
                AppConstants.REQUIRED_TIME_FORMAT)

            articleCommentModel.totalLikes?.apply {
                binding.textViewLike.text=this.toString()
            }

            if (articleCommentModel.type == -1 || articleCommentModel.type == 0) {
                binding.root.context.updateTintColor(R.color.internal_app_text_color, binding.imageViewLike)
            } else {
                binding.root.context.updateTintColor(R.color.colorAccent, binding.imageViewLike)
            }

            binding.imageViewLike.click {
                onLikeClick(adapterPosition,articleCommentModel.id.toString(),
                    articleCommentModel.type!!,articleCommentModel.likeId.toString(), false, -1)
            }

            binding.recyclerViewReplay.layoutManager = LinearLayoutManager(binding.root.context)
            commentReplayAdapter = DiscussionCommentReplayAdapter(
                articleCommentModel.replies!!,
                onLikeClick = { position: Int, id: String, type: Int, likeID: String ->
                    onLikeClick(
                        position, id,
                        type, likeID, true, adapterPosition
                    )

                })
            binding.recyclerViewReplay.adapter = commentReplayAdapter

            if (articleCommentModel.replies.isNullOrEmpty()) {
                binding.textViewShowReply.beGone()
            } else {
                binding.textViewShowReply.beVisible()
            }

            if (articleCommentModel.isViewVisible) {
                binding.textViewShowReply.text =
                    binding.root.context.resources.getString(R.string.hide_replies)
                binding.recyclerViewReplay.beVisible()

            }else{
                articleCommentModel.isViewVisible=false
                binding.textViewShowReply.text =
                    binding.root.context.resources.getString(R.string.show_replay)
                binding.recyclerViewReplay.beGone()
            }

            binding.textViewShowReply.click {
                if (binding.recyclerViewReplay.visibility == View.GONE) {
                    articleCommentModel.isViewVisible=true
                    binding.textViewShowReply.text =
                        binding.root.context.resources.getString(R.string.hide_replies)
                    binding.recyclerViewReplay.beVisible()
                } else {
                    articleCommentModel.isViewVisible=false
                    binding.textViewShowReply.text =
                        binding.root.context.resources.getString(R.string.show_replay)
                    binding.recyclerViewReplay.beGone()
                }
            }

            binding.textViewReplay.click {
                if(replyPosition!=-1) {
                    if(replyPosition!=adapterPosition+1){
                        removeReplayView(replyPosition)
                        onReplyClick(adapterPosition + 1)
                    }
                }else {
                    onReplyClick(adapterPosition + 1)
                }
            }
        }

    }

    fun addReplayView(position: Int) {
        replyPosition=position
        val model = DiscussionComment.DataModel()
//        val model = ArticleCommentModel.ArticleComment()
        model.isReply = true
        commentList.add(position, model)
        notifyItemInserted(position)

    }

    fun removeReplayView(position: Int) {
        replyPosition=-1
        commentList.removeAt(position)
        notifyItemRemoved(position)
    }


}