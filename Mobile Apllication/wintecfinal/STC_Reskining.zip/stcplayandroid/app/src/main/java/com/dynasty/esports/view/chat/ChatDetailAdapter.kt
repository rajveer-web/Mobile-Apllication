package com.dynasty.esports.view.chat


import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterChatReceiverBinding
import com.dynasty.esports.databinding.AdapterChatSenderBinding
import com.dynasty.esports.extenstion.getTimeAgo
import com.dynasty.esports.extenstion.id
import com.dynasty.esports.models.ChatMessageListModel
import org.koin.core.KoinComponent
import org.koin.core.inject

/**
 * @desc this is class will be display inbox data
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ChatDetailAdapter(
    private var chatList: MutableList<ChatMessageListModel>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), KoinComponent {
    val sharedPreferences: SharedPreferences by inject()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> {
                val binding: AdapterChatReceiverBinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.context),
                    R.layout.adapter_chat_receiver,
                    parent,
                    false
                )
                ReceiverViewHolder(binding)
            }
            else -> {
                val binding: AdapterChatSenderBinding =
                    DataBindingUtil.inflate(inflater, R.layout.adapter_chat_sender, parent, false)
                SenderViewHolder(binding)
            }
        }

    }

    /**
     * @desc inboxList array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return chatList.size
    }

    override fun getItemViewType(position: Int): Int {
        return when (chatList[position].userid.toString()) {
            sharedPreferences.id -> {
                1
            }
            else -> {
                0
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ReceiverViewHolder).bind(chatList[position])
            }
            else -> {
                (holder as SenderViewHolder).bind(chatList[position])
            }
        }
    }

    inner class ReceiverViewHolder(private var binding: AdapterChatReceiverBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(chatMessageListModel: ChatMessageListModel) {
            binding.textViewReceiverMsg.text = chatMessageListModel.msg?.let { it } ?: ""
            binding.textViewReceiverDate.text = chatMessageListModel.updatedAt?.let {
                it.getTimeAgo(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.REQUIRED_TIME_FORMAT
                )
            } ?: ""
        }

    }

    inner class SenderViewHolder(private var binding: AdapterChatSenderBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(chatMessageListModel: ChatMessageListModel) {
            binding.textViewSenderMsg.text = chatMessageListModel.msg?.let { it } ?: ""
            binding.textViewSenderDate.text = chatMessageListModel.updatedAt?.let {
                it.getTimeAgo(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.REQUIRED_TIME_FORMAT
                )
            } ?: ""
        }
    }


}