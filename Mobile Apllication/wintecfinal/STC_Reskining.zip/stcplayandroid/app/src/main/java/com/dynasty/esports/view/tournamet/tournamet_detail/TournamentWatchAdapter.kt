package com.dynasty.esports.view.tournamet.tournamet_detail

import android.graphics.Rect
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.models.TournamentDetailRes
import kotlinx.android.synthetic.main.fragment_upcoming_watch.view.*

class TournamentWatchAdapter(var listOfStreams: List<TournamentDetailRes.Stream>, var listener: OnItemClickListener) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var listOfStream: MutableList<TournamentDetailRes.Stream>
    var listenerr: OnItemClickListener

    init {
        this.listOfStream = listOfStreams as MutableList<TournamentDetailRes.Stream>
        this.listenerr = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return WatchStreamViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.fragment_upcoming_watch, parent, false)
        )
    }

    override fun getItemCount(): Int = listOfStream.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val gameViewHolder = viewHolder as WatchStreamViewHolder
        gameViewHolder.bindView(listOfStream.get(position), listenerr)
    }

    fun setGameList(listOfMovies: List<TournamentDetailRes.Stream>/*,  listener : View.OnClickListener*/) {
        listOfStream = listOfMovies.toMutableList()
        notifyDataSetChanged()
    }

    fun addMoreData(listOfMovies: List<TournamentDetailRes.Stream>) {
        this.listOfStream.addAll(listOfMovies)
        notifyDataSetChanged()
    }

    class WatchStreamViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(
            streamModel: TournamentDetailRes.Stream,
            listenerr: OnItemClickListener
        ) {
            itemView.watch_title_txt.text = streamModel.title
            itemView.watch_description_txt.text = streamModel.description
            /* val url = "https://img.youtube.com/vi/" + streamModel.youtubeUrl.toString().getVideoIdFromYoutubeUrl() + "/0.jpg"
             itemView.context.loadImageFromServer(url, itemView.imageViewVideoThumbnail)*/
            itemView.cardViewVideoWatch.setOnClickListener {
                listenerr.onItemClick(streamModel)
                /*data.youtubeUrl.toString()*/
            }
        }
    }

    class VerticalSpaceItemDecoration(private val verticalSpaceHeight: Int) :
        RecyclerView.ItemDecoration() {
        override fun getItemOffsets(
            outRect: Rect, view: View, parent: RecyclerView,
            state: RecyclerView.State
        ) {
            outRect.bottom = verticalSpaceHeight
        }
    }

    interface OnItemClickListener {
        fun onItemClick(stream: TournamentDetailRes.Stream)
    }
}