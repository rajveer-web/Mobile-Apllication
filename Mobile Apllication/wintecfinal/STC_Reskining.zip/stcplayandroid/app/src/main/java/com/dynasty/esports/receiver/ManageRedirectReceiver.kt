package com.dynasty.esports.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ManageRedirectReceiver : BroadcastReceiver() {
    var notifyReceiverListener: NotifyActivityListener? = null

    override fun onReceive(context: Context?, intent: Intent?) {
        intent?.extras?.let {
            notifyReceiverListener?.apply {
                this.onNotify(it.getString("type").toString())
            }
        }

    }

    interface NotifyActivityListener {
        fun onNotify(notifyType: String)
    }

    fun setUpRedirectInterface(notifyActivityListener: NotifyActivityListener) {
        notifyReceiverListener = notifyActivityListener
    }

}