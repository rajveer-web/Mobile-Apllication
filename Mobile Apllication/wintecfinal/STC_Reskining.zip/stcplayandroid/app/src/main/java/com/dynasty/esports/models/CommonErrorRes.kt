package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class CommonErrorRes {


    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("err")
    @Expose
    var err: Err? = null

    class Err {
        @SerializedName("message")
        @Expose
        var message: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("stringValue")
        @Expose
        var stringValue: String? = null

        @SerializedName("kind")
        @Expose
        var kind: String? = null

        @SerializedName("value")
        @Expose
        var value: String? = null

        @SerializedName("path")
        @Expose
        var path: String? = null

        @SerializedName("reason")
        @Expose
        var reason: Reason? = null
    }
    class Reason {
        @SerializedName("generatedMessage")
        @Expose
        var generatedMessage = false

        @SerializedName("code")
        @Expose
        var code: String? = null

        @SerializedName("actual")
        @Expose
        var actual = false

        @SerializedName("expected")
        @Expose
        var expected = false

        @SerializedName("operator")
        @Expose
        var operator: String? = null
    }
}