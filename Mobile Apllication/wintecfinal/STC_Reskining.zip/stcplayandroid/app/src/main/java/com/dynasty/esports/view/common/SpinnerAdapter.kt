package com.dynasty.esports.view.common

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.models.CountriesModel
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.models.StateModel
import com.dynasty.esports.models.TournamentGameRes

class SpinnerAdapter(private val mContext: Context,private val type:String="") : BaseAdapter(), Filterable {
    private val infalter: LayoutInflater = mContext
        .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    private val data : MutableList<Any> = mutableListOf()
    private val dataSource : MutableList<Any> = mutableListOf()

    private var isEnable = true

    private var isFilterable = false

    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(position: Int): Any {
        return data[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    fun addAll(files: MutableList<out Any>) {

        try {

            this.data.clear()
            this.data.addAll(files)

            if (isFilterable) {
                this.dataSource.clear()
                this.dataSource.addAll(files)
            }

        } catch (e: Exception) {
//            Utils.sendExceptionReport(e)
        }

        notifyDataSetChanged()
    }

    fun add(files: Any) {

        try {
            this.data.add(files)

            if (isFilterable) {
                this.dataSource.add(files)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var convertView = convertView

        val holder: ViewHolder
        if (convertView == null) {
            holder = ViewHolder()

            convertView = infalter.inflate(R.layout.spinner_item, null)

            holder.tvMenuTitle = convertView!!.findViewById<View>(R.id.tvSpinnerTitle) as TextView

            holder.imgDrawable = convertView.findViewById<View>(R.id.imgDrawable) as ImageView

            convertView.tag = holder

        } else {
            holder = convertView.tag as ViewHolder
        }

        try {
            when(type){
                "country"->{
                    val dataItem=data[position] as CountriesModel.CountryModel
                    holder.tvMenuTitle!!.text = dataItem.name
                    holder.imgDrawable!!.beGone()
                }
                "state"->{
                    val dataItem=data[position] as StateModel.State
                    holder.tvMenuTitle!!.text = dataItem.name
                    holder.imgDrawable!!.beGone()
                }
                "search"->{
                    val dataItem=data[position] as String
                    holder.tvMenuTitle!!.text = dataItem
                    holder.imgDrawable!!.beGone()
                }
                "game"->{
                    val dataItem=data[position] as TournamentGameRes.Datum
                    holder.tvMenuTitle!!.text = dataItem.name
                    holder.imgDrawable!!.beGone()
                }
                else ->{
                    val dataItem=data[position] as Spinner
                    holder.tvMenuTitle!!.text = dataItem.title
                    if (dataItem.drawable != null) {
                        holder.imgDrawable!!.setImageDrawable(dataItem.drawable)
                        holder.imgDrawable!!.visibility = View.VISIBLE
                    } else {
                        holder.imgDrawable!!.beGone()
                    }
                }
            }

        } catch (e: Exception) {
//            Utils.sendExceptionReport(e)
        }

        return convertView
    }

    inner class ViewHolder {
        internal var tvMenuTitle: TextView? = null
        internal var imgDrawable: ImageView? = null
    }

    fun setParentCategEnabled(isEnable: Boolean) {
        this.isEnable = isEnable
    }

    fun setFilterable(isFilterable: Boolean) {
        this.isFilterable = isFilterable
    }

    override fun getFilter(): Filter? {

        return if (isFilterable) {
            PTypeFilter()
        } else null

    }

    private inner class PTypeFilter : Filter() {

        override fun publishResults(prefix: CharSequence, results: FilterResults) {
            // NOTE: this function is *always* called from the UI thread.

            data.clear()
            data.addAll(results.values as MutableList<Any>)
            if (data != null && data.isNotEmpty()) {
                notifyDataSetChanged()
            } else {
                //                data.clear();
                //                data.addAll(dataSource);
                notifyDataSetChanged()
            }
        }

        override fun performFiltering(prefix: CharSequence?): FilterResults {
            // NOTE: this function is *always* called from a background thread,
            // and
            // not the UI thread.

            val results = FilterResults()
            val new_res: MutableList<Any> = mutableListOf()
            if (prefix != null && prefix.toString().isNotEmpty()) {
                for (index in dataSource.indices) {

                    try {
                        when(type){
                            "country"->{
                                val si = dataSource[index] as CountriesModel.CountryModel

                                if (si.name!!.toLowerCase().contains(
                                        prefix.toString().toLowerCase()
                                    )) {
                                    new_res.add(si)
                                }
                            }
                            "state"->{
                                val si = dataSource[index] as StateModel.State

                                if (si.name!!.toLowerCase().contains(
                                        prefix.toString().toLowerCase()
                                    )) {
                                    new_res.add(si)
                                }
                            }
                            else->{
                                val si = dataSource[index] as Spinner

                                if (si.title.toLowerCase().contains(
                                        prefix.toString().toLowerCase()
                                    )) {
                                    new_res.add(si)
                                }
                            }
                        }


                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }

                results.values = new_res
                results.count = new_res.size

            } else {
//                Debug.e("", "Called synchronized view")

                results.values = dataSource
                results.count = dataSource.size

            }

            return results
        }
    }
}