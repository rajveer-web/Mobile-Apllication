package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.BookmarkModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 25-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BookmarkViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {

    val bookmarkSuccessResponse = MutableLiveData<BookmarkModel>()
    val bookmarkErrorResponse = MutableLiveData<ResponseBody>()
    val jsonObjectForBookmark = MutableLiveData<Pair<JsonObject, String>>()
    val deleteBookMarkSuccessResponse = MutableLiveData<ResponseBody>()
    val deleteBookMarkErrorResponse = MutableLiveData<ResponseBody>()
    val makeQueryParameterForBookMark = MutableLiveData<HashMap<String, String>>()
    /**
     * @desc Method will use for fetch bookmark data from server.
     * @param query- pass query string
     * @param option - api option
     */
    fun fetchBookmark(query: String, option: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getMyBookMark(query, option)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    bookmarkSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE->{
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    bookmarkErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     * @desc Method will use for delete bookmark.
     * @param query- bookmark query
     */
    fun deleteBookmark(query: Map<String,String>) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.deleteBookMark(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    deleteBookMarkSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE->{
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    deleteBookMarkErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     * @desc Method will use for create json object for bookmark api.
     * @param userId- Logged in user id.
     */
    fun makeJsonForBookmark(userId: String) {
        val userIdObject = JsonObject()
        userIdObject.addProperty("userId", userId)
        jsonObjectForBookmark.postValue(Pair(userIdObject, "article"))
    }

    /**
     * @desc Method will use for create query parameter for delete bookmar
     * @param key- key (article/video)
     * @param id - article id
     */
    fun makeQueryParameter(key: String, id: String) {
        val hashMap:HashMap<String,String> = hashMapOf()
        hashMap[key] = id
        makeQueryParameterForBookMark.postValue(hashMap)
    }


    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
