package com.dynasty.esports.view.tournamet

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterTournamentOptionBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.TournamentOptionModel
import com.dynasty.esports.utils.BindingHolder
import com.google.android.material.button.MaterialButton

class TournamentOptionAdapter constructor(
    private val tournamentOptionList: MutableList<TournamentOptionModel>,
    private val onItemClick: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterTournamentOptionBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterTournamentOptionBinding> {
        val binding: AdapterTournamentOptionBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.adapter_tournament_option, parent, false)
        return BindingHolder(binding)
    }

    override fun onBindViewHolder(holder: BindingHolder<AdapterTournamentOptionBinding>, position: Int) {
        holder.binding.buttonOption.icon = ContextCompat.getDrawable(holder.itemView.context, tournamentOptionList[position].icon)

        holder.binding.buttonOption.click {
            onItemClick(position)
        }

        if (tournamentOptionList[position].selected == position) {
            selectOption(holder.binding.buttonOption, holder.binding.root.context)
        } else {
            unSelectOption(holder.binding.buttonOption, holder.binding.root.context)
        }
    }

    override fun getItemCount(): Int {
        return tournamentOptionList.size
    }

    private fun selectOption(buttonOption: MaterialButton, context: Context) {
        buttonOption.strokeWidth = 0
        buttonOption.iconTint = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.white))
        buttonOption.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.listview_n_item_bg_color))
    }

    private fun unSelectOption(buttonOption: MaterialButton, context: Context) {
        buttonOption.strokeWidth = 1
        buttonOption.iconTint = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.stroke_boder))
        buttonOption.strokeColor = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.stroke_boder))
        buttonOption.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.internal_app_bg_color))
    }


    fun updateSelection(position: Int) {
        tournamentOptionList.forEachIndexed { index, tournamentOptionModel ->
            if (index == position){
                tournamentOptionModel.selected=position
            }else{
                tournamentOptionModel.selected=-1
            }
        }
        notifyDataSetChanged()
    }


}
