package com.dynasty.esports.view.tournamet.createtournament

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.SpinnerItemBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.nullSafeNA
import com.dynasty.esports.models.SearchUser
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use for search participant
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SearchUserAdapter constructor(
    private val onSearchUserItemClick: (Int, SearchUser.Datum) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<BindingHolder<SpinnerItemBinding>>() {

    private var userList: MutableList<SearchUser.Datum> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindingHolder<SpinnerItemBinding> {
        val binding: SpinnerItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.spinner_item,
            parent,
            false)
        return BindingHolder(binding)
    }

    /**
     * @desc userList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return userList.size
    }

    /**
     * @desc get single item from position
     */
    fun getItem(position: Int): SearchUser.Datum {
        return userList.get(position)
    }

    /**
     * @desc clear userlist, add list in userList and notify adapter
     */
    fun addAll(userList_: List<SearchUser.Datum>) {
        userList.clear()
        userList.addAll(userList_)
        notifyDataSetChanged()
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents and to reflect the item at the given position.
     */
    override fun onBindViewHolder(holder: BindingHolder<SpinnerItemBinding>, position: Int) {
        val data = userList[position]
        holder.binding.tvSpinnerTitle.text = nullSafeNA(data.fullName)
        holder.binding.imgDrawable.beGone()
        holder.binding.container.click {
            onSearchUserItemClick(position, data)
        }
    }

    /**
     * @desc clear or remove all data from userList( main array list)
     */
    fun clear() {
        userList.clear()
        notifyDataSetChanged()
    }
}