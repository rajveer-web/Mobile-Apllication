package com.dynasty.esports.view.leaderboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.SelectGameListItemBinding
import com.dynasty.esports.databinding.SelectLeaderboardGameListItemBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use for select game in CreateTournamentStep1Fragment
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SelectLeaderBoardGameAdapter constructor(
    private val onItemClick: (Int) -> Unit = { _ -> }) :
    RecyclerView.Adapter<BindingHolder<SelectLeaderboardGameListItemBinding>>() {
    private var gameList: MutableList<TournamentGameRes.Datum> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<SelectLeaderboardGameListItemBinding> {
        val binding: SelectLeaderboardGameListItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.select_leaderboard_game_list_item,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    /**
     * @desc gameList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return gameList.size
    }

    /**
     * @desc get gameList( main array list)
     */
    fun getAll(): MutableList<TournamentGameRes.Datum>? {
        return gameList
    }

    /**
     * @desc clear gamelist, add list in gameList and notify adapter
     */
    fun addAll(gameList_: MutableList<TournamentGameRes.Datum>) {
        gameList.clear()
        gameList.addAll(gameList_)
        notifyDataSetChanged()
    }

    /**
     * @desc set selected from id
     */
    fun setSelected(id: String) {
        for (gameItem in gameList) {
            gameItem.isSelected = gameItem.id.equals(id, true)
        }
        notifyDataSetChanged()
    }

    /**
     * @desc check is selected at least one for validation
     */
    fun isSelectedAtleastOne(): Boolean {
        for (i in 0 until gameList.size) {
            if (gameList.get(i).isSelected) {
                return true
            }
        }
        return false
    }

    /**
     * @desc set item selected from id and notify adapter
     */
    fun setSelectedFromId(id: String) {
        for (i in gameList) {
            if (i.id.equals(id, true)) {
                i.isSelected = true
            }
        }
        notifyDataSetChanged()
    }

    /**
     * @desc get selected item id
     */
    fun getSelecedGameId(): String {
        for (i in 0 until gameList.size) {
            if (gameList.get(i).isSelected) {
                return gameList.get(i).id
            }
        }
        return ""
    }

    /**
     * @desc get selected item game name
     */
    fun getSelecedGameName(): String {
        for (i in 0 until gameList.size) {
            if (gameList.get(i).isSelected) {
                return gameList.get(i).name!!
            }
        }
        return ""
    }

    fun getSelecedGameLogo(): String {
        for (i in 0 until gameList.size) {
            if (gameList.get(i).isSelected) {
                return gameList.get(i).logo!!
            }
        }
        return ""
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents and to reflect the item at the given position.
     */
    override fun onBindViewHolder(holder: BindingHolder<SelectLeaderboardGameListItemBinding>, position: Int) {
        val data = gameList[position]
        if (position == 0) {
            holder.binding.flMainLayout.beGone()
            holder.binding.llAllGames.beVisible()
        } else {
            holder.binding.flMainLayout.beVisible()
            holder.binding.llAllGames.beGone()

            holder.binding.gameName.text = nullSafeNA(data.name)

            if (data.image.isNotEmpty()){
                holder.itemView.context.loadImageFromServer(data.image, holder.binding.gameImage)
            }
        }
        holder.binding.container.click {
            onItemClick(position)
        }
        if (data.isSelected) {
            holder.binding.container.strokeWidth = 3
        } else {
            holder.binding.container.strokeWidth = 0
        }
    }

    /**
     * @desc get single item from position
     */
    fun getItem(position: Int): TournamentGameRes.Datum {
        return this.gameList[position]
    }
}