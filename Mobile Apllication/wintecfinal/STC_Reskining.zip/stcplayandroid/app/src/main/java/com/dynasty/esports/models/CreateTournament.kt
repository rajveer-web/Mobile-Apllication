package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class CreateTournament {
    @SerializedName("name")
    @Expose
    var name: String = ""

    @SerializedName("url")
    @Expose
    var url: String = ""

    @SerializedName("participantType")
    @Expose
    var participantType: String = ""

    @SerializedName("startDate")
    @Expose
    var startDate: String = ""

    @SerializedName("startTime")
    @Expose
    var startTime: String = ""

    @SerializedName("isPaid")
    @Expose
    var isPaid: Boolean = false

    @SerializedName("isCheckInRequired")
    @Expose
    var isCheckInRequired: Boolean = false

    @SerializedName("allowSubstituteMember")
    @Expose
    var isallowSubstituteMember: Boolean = false

    @SerializedName("substituteMemberSize")
    @Expose
    var substituteMemberSize: Int = 0

    @SerializedName("description")
    @Expose
    var description: String = ""

    @SerializedName("rules")
    @Expose
    var rules: String = ""

    @SerializedName("criticalRules")
    @Expose
    var criticalRules: String = ""

    @SerializedName("isPrize")
    @Expose
    var isPrize: Boolean = false
    @SerializedName("prizeList")
    @Expose
    var prizeList: ArrayList<PrizeList> = ArrayList()

    class PrizeList{
        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("value")
        @Expose
        var value: Int = 0
    }

    @SerializedName("faqs")
    @Expose
    var faqs: String = ""

    @SerializedName("schedule")
    @Expose
    var schedule: String = ""

    @SerializedName("isIncludeSponsor")
    @Expose
    var isIncludeSponsor: Boolean = false

    @SerializedName("tournamentType")
    @Expose
    var tournamentType: String = ""

    @SerializedName("teamFormat")
    @Expose
    var teamFormat: String = ""

    @SerializedName("isScreenshotRequired")
    @Expose
    var isScreenshotRequired: Boolean = false

    @SerializedName("isShowCountryFlag")
    @Expose
    var isShowCountryFlag: Boolean = false

    @SerializedName("isSpecifyAllowedRegions")
    @Expose
    var isSpecifyAllowedRegions: Boolean = false

    @SerializedName("isParticipantsLimit")
    @Expose
    var isParticipantsLimit: Boolean = false

    @SerializedName("scoreReporting")
    @Expose
    var scoreReporting: Int = 0

    @SerializedName("invitationLink")
    @Expose
    var invitationLink: String = ""

    @SerializedName("youtubeVideoLink")
    @Expose
    var youtubeVideoLink: String = ""

    @SerializedName("participants")
    @Expose
    var participants: List<Participant> = ArrayList<Participant>()

    @SerializedName("facebookVideoLink")
    @Expose
    var facebookVideoLink: String = ""

    @SerializedName("contactDetails")
    @Expose
    var contactDetails: String = ""

    @SerializedName("twitchVideoLink")
    @Expose
    var twitchVideoLink: String = ""

    @SerializedName("visibility")
    @Expose
    var visibility: Int = 1

    @SerializedName("checkInStartDate")
    @Expose
    var checkInStartDate: String? = ""

    @SerializedName("checkInEndDate")
    @Expose
    var checkInEndDate: String = ""

    @SerializedName("regionsAllowed")
    @Expose
    var regionsAllowed: MutableList<String> = mutableListOf()

    @SerializedName("sponsors")
    @Expose
    var sponsors: List<Sponsor> = ArrayList<Sponsor>()

    @SerializedName("banner")
    @Expose
    var banner: String = ""

    @SerializedName("maxParticipants")
    @Expose
    var maxParticipants: Int = 0

    @SerializedName("bracketType")
    @Expose
    var bracketType: String = ""

    @SerializedName("noOfSet")
    @Expose
    var noOfSet: Int = 0

    @SerializedName("tournnamentStage")
    @Expose
    var tournnamentStage: String = ""

    @SerializedName("nextStageMatchFormat")
    @Expose
    var nextStageMatchFormat: Int = 0

    @SerializedName("venueAddress")
    @Expose
    var venueAddress: List<VenueAddress> = ArrayList<VenueAddress>()

    var venueAddressHybrid: VenueAddress = VenueAddress()

    @SerializedName("contactOn")
    @Expose
    var contactOn: String = ""

    @SerializedName("gameDetail")
    @Expose
    var gameDetail: String = ""

    @SerializedName("gameItem")
    @Expose
    var gameItem: TournamentGameRes.Datum? = TournamentGameRes.Datum()

    @SerializedName("platform")
    @Expose
    var platform: String = ""

    @SerializedName("gameName")
    @Expose
    var gameName: String = ""

    @SerializedName("gameLogo")
    @Expose
    var gameLogo: String = ""

    @SerializedName("teamSize")
    @Expose
    var teamSize: Int = 0

    @SerializedName("firstPrize")
    @Expose
    var firstPrize: Int = 0

    @SerializedName("secondPrize")
    @Expose
    var secondPrize: Int = 0

    @SerializedName("thirdPrize")
    @Expose
    var thirdPrize: Int = 0

    @SerializedName("prizeCurrency")
    @Expose
    var prizeCurrency: String = ""

    @SerializedName("slug")
    @Expose
    var slug: String = ""

    @SerializedName("country")
    @Expose
    var country: String = ""

    @SerializedName("endDate")
    @Expose
    var endDate: String = ""

    @SerializedName("createdBy")
    @Expose
    var createdBy: String = ""

    @SerializedName("updatedBy")
    @Expose
    var updatedBy: String = ""

    @SerializedName("tournamentStatus")
    @Expose
    var tournamentStatus: String = ""

    @SerializedName("organizerDetail")
    @Expose
    var organizerDetail: String = ""

    @SerializedName("regFee")
    @Expose
    var regFee: String = ""

    @SerializedName("regFeeCurrency")
    @Expose
    var regFeeCurrency: String = ""

    @SerializedName("noOfPlacement")
    @Expose
    var noOfPlacement: Int = 0

    @SerializedName("noOfTeamInGroup")
    @Expose
    var noOfTeamInGroup: Int = 0

    @SerializedName("noOfWinningTeamInGroup")
    @Expose
    var noOfWinningTeamInGroup: Int = 0

    var noOfRoundPerStage: Int = 0

    var noOfStages: Int = 1

    var noOfRoundRR: Int = 0

    var placementPointList: MutableList<AddPlacementPoint> = ArrayList()

    @SerializedName("isKillPointRequired")
    @Expose
    var isKillPointRequired: Boolean = false

    @SerializedName("allowAdvanceStage")
    @Expose
    var allowAdvanceStage: Boolean = false

    var pointPerKill: Int = 0

    @SerializedName("nextStageBracketType")
    @Expose
    var nextStageBracketType: String = ""

    class Participant {
        @SerializedName("_id")
        @Expose
        var id: String = ""

        @SerializedName("fullName")
        @Expose
        var fullName: String = ""

        @SerializedName("phoneNumber")
        @Expose
        var phoneNumber: String = ""

        @SerializedName("email")
        @Expose
        var email: String = ""

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String = ""
    }

    class Sponsor {
        @SerializedName("sponsorName")
        @Expose
        var sponsorName: String = ""

        @SerializedName("website")
        @Expose
        var website: String = ""

        @SerializedName("playStoreUrl")
        @Expose
        var playStoreUrl: String = ""

        @SerializedName("appStoreUrl")
        @Expose
        var appStoreUrl: String = ""

        @SerializedName("sponsorLogo")
        @Expose
        var sponsorLogo: String = ""

        @SerializedName("sponsorBanner")
        @Expose
        var sponsorBanner: String = ""
    }

    class VenueAddress {
        @SerializedName("country")
        @Expose
        var country: String = ""

        @SerializedName("region")
        @Expose
        var region: String = ""

        @SerializedName("venue")
        @Expose
        var venue: String = ""

        @SerializedName("stage")
        @Expose
        var stage: String = ""
    }
}
