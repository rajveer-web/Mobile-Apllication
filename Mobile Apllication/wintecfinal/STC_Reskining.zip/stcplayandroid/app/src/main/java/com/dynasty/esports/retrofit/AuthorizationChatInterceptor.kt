package com.dynasty.esports.retrofit

import android.content.SharedPreferences
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.extenstion.isLoggedIn
import okhttp3.*
import org.koin.core.KoinComponent
import org.koin.core.inject

class AuthorizationChatInterceptor(private val httpClient: OkHttpClient) : Interceptor, KoinComponent {

    val sharedPreferences: SharedPreferences by inject()
    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        val builder = request.newBuilder()
        builder.header("Accept", "application/json")
        builder.header("Content-Type", "application/json")
        if(sharedPreferences.isLoggedIn) {
            builder.header(
                "Authorization",
                String.format("Bearer %s", sharedPreferences.chatAccessToken)
            )
        }
        request = builder.build() //overwrite old request
        //        if (sharedPreferences.accessToken.isNotEmpty() && sharedPreferences.accessToken != "null") {  // Check token null or empty
//            if (response.code() == AppConstants.API_UNAUTHENTICATED_CODE) { //if unauthorized
//                synchronized(httpClient) {
//                    // Calling refresh token API.
//                    val token = refreshToken()
//                    if (!token) { //compare current token with token that was stored before, if it was not updated - do update
//                        return response
//                    }
//
//                    if (sharedPreferences.accessToken != "null") {
//                        // Add new access token and continue call.
//                        response.close()
//                        builder.header(
//                            "Authorization",
//                            String.format("Bearer %s", sharedPreferences.accessToken)
//                        )//set auth token to updated
//                        request = builder.build() //overwrite old request
//                        return chain.proceed(request)
//                    }
//
//                }
//            }
//        }
        return chain.proceed(request)
    }



}