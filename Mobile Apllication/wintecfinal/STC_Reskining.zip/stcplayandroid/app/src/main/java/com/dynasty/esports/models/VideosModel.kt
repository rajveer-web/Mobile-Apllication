package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class VideosModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null

    class DataModel{
        @SerializedName("docs")
        @Expose
         val docs: MutableList<DocModel>? = null

        @SerializedName("totalDocs")
        @Expose
         val totalDocs: Int? = null

        @SerializedName("limit")
        @Expose
         val limit: Int? = null

        @SerializedName("totalPages")
        @Expose
         val totalPages: Int? = null

        @SerializedName("page")
        @Expose
         val page: Int? = null

        @SerializedName("pagingCounter")
        @Expose
         val pagingCounter: Int? = null

        @SerializedName("hasPrevPage")
        @Expose
         val hasPrevPage: Boolean? = null

        @SerializedName("hasNextPage")
        @Expose
         val hasNextPage: Boolean? = null

        @SerializedName("prevPage")
        @Expose
         val prevPage: Any? = null

        @SerializedName("nextPage")
        @Expose
         val nextPage: Any? = null
    }

    class DocModel{
        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
         val updatedBy: String? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("youtubeUrl")
        @Expose
         val youtubeUrl: String? = null

        @SerializedName("description")
        @Expose
         val description: TitleModel? = null


        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        var isLoadMore=false
    }
}