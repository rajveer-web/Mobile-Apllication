package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName



class CreatedTournamentModel {
    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null

    @SerializedName("message")
    @Expose
     val message: String? = null


    class DataModel {
        @SerializedName("docs")
        @Expose
         val docs: MutableList<DocModel>? = null

        @SerializedName("totalDocs")
        @Expose
         val totalDocs: Int? = null

        @SerializedName("limit")
        @Expose
         val limit: Int? = null

        @SerializedName("totalPages")
        @Expose
         val totalPages: Int? = null

        @SerializedName("page")
        @Expose
         val page: Int? = null

        @SerializedName("pagingCounter")
        @Expose
         val pagingCounter: Int? = null

        @SerializedName("hasPrevPage")
        @Expose
         val hasPrevPage: Boolean? = null

        @SerializedName("hasNextPage")
        @Expose
         val hasNextPage: Boolean? = null

        @SerializedName("prevPage")
        @Expose
         val prevPage: Any? = null

        @SerializedName("nextPage")
        @Expose
         val nextPage: Int? = null
    }
    class DocModel{

        @SerializedName("_id")
        @Expose
         val id: String = ""

        @SerializedName("name")
        @Expose
         val name: String? = null

        @SerializedName("startDate")
        @Expose
         val startDate: String? = null

        @SerializedName("startTime")
        @Expose
        val startTime: String? = null



        @SerializedName("description")
        @Expose
         val description: String? = null

        @SerializedName("isPaid")
        @Expose
        val isPaid: Boolean? = null


        @SerializedName("banner")
        @Expose
        val banner: String? = null

        var isLoadMore:Boolean=false

    }
}