package com.dynasty.esports.view.leaderboard

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.bignerdranch.expandablerecyclerview.ChildViewHolder
import com.bignerdranch.expandablerecyclerview.ExpandableRecyclerAdapter
import com.bignerdranch.expandablerecyclerview.ParentViewHolder
import com.bignerdranch.expandablerecyclerview.model.Parent
import com.dynasty.esports.R
import com.dynasty.esports.databinding.LeaderboardChildItemBinding
import com.dynasty.esports.databinding.LeaderboardParentItemBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.LeaderboardModel
import com.facebook.FacebookSdk.getApplicationContext


class LeaderboardExpandableAdapter constructor(
    private var context: Context?,
    groups: List<LeaderboardModel.LeaderboardDatum>,
    private val onItemClick: (String) -> Unit = { _ -> }
) :
    ExpandableRecyclerAdapter<LeaderboardModel.LeaderboardDatum, LeaderboardModel.LeaderboardDatumChild, LeaderboardExpandableAdapter.GrpViewHolder, LeaderboardExpandableAdapter.ItemViewHolder>(
        groups as MutableList<LeaderboardModel.LeaderboardDatum>
    ) {

    private var mInflater: LayoutInflater? = null
    private var mEventListener: EventListener? = null
    private var animationUp: Animation? = null
    private var animationDown: Animation? = null

    init {
        parentList.clear()
        parentList.addAll(groups!!)
        mInflater = LayoutInflater.from(context)
        animationUp = AnimationUtils.loadAnimation(context, R.anim.slide_up)
        animationDown = AnimationUtils.loadAnimation(context, R.anim.slide_down)
    }

    fun getAll(): List<LeaderboardModel.LeaderboardDatum?>? {
        return parentList

    }

    fun getMenuItem(position: Int): LeaderboardModel.LeaderboardDatum? {
        return parentList[position]
    }

    fun getMenuSubItem(position: Int, child: Int): LeaderboardModel.LeaderboardDatumChild? {
        return parentList[position].childList[child]
    }

    fun addAll(groups: List<LeaderboardModel.LeaderboardDatum?>?) {
        parentList.clear()
        parentList.addAll(groups!!)
        notifyParentDataSetChanged(false)
    }

    override fun onCreateParentViewHolder(
        parentViewGroup: ViewGroup,
        viewType: Int
    ): GrpViewHolder {
        val categoryView: View =
            mInflater!!.inflate(R.layout.leaderboard_parent_item, parentViewGroup, false)
        return GrpViewHolder(categoryView)
    }

    override fun onCreateChildViewHolder(childViewGroup: ViewGroup, viewType: Int): ItemViewHolder {
        val subCategoryView: View =
            mInflater!!.inflate(R.layout.leaderboard_child_item, childViewGroup, false)
        return ItemViewHolder(subCategoryView)
    }

    override fun onBindParentViewHolder(
        recipeViewHolder: GrpViewHolder, parentPosition: Int,
        recipe: LeaderboardModel.LeaderboardDatum
    ) {
        /*if (parentPosition == 0) {
            recipeViewHolder.parentBinding.viewBorder.setVisibility(View.GONE)
        }
        recipeViewHolder.parentBinding.tvCategoryName.setTextColor(context!!.resources.getColor(R.color.black))*/

        recipeViewHolder.bind(recipe)
    }

    override fun onBindChildViewHolder(
        ingredientViewHolder: ItemViewHolder,
        parentPosition: Int, childPosition: Int,
        ingredient: LeaderboardModel.LeaderboardDatumChild
    ) {


        ingredientViewHolder.bind(ingredient)


    }

    fun getItem(position: Int): LeaderboardModel.LeaderboardDatum? {
        return parentList[position]
    }


    class GrpViewHolder(itemView: View?) : ParentViewHolder<Parent<Any?>, Any?>(itemView!!) {
        var parentBinding: LeaderboardParentItemBinding?
        fun bind(datum: LeaderboardModel.LeaderboardDatum) {
            parentBinding!!.tvPlayerName.text = datum.name
            parentBinding!!.tvLeaderboardRank.text = (parentAdapterPosition + 1).toString()
            if (!datum.profilePicture!!.isFieldEmpty()) {
                parentBinding!!.root.context.loadImageFromServer(
                    datum.profilePicture!!,
                    parentBinding!!.imgLeaderBoard
                )
            } else {
                parentBinding!!.imgLeaderBoard.setImageResource(R.mipmap.leaderboard_asset_1)
            }
            itemView.click {
                if (isExpanded){
                    parentBinding!!.viewSelectedLine.beGone()
                    parentBinding!!.imgLeaderBoardExpand.setImageDrawable(
                        ContextCompat.getDrawable(
                            itemView.context,
                            R.drawable.ic_baseline_arrow_right_24
                        )
                    )
                    parentBinding!!.container.setBackgroundColor(itemView.context.resources.getColor(R.color.article_detail_bg_color))
                    parentBinding!!.imgLeaderBoardExpand.animate().rotationBy(-90F).setDuration(500).start()
                    collapseView()
                }else{
                    parentBinding!!.viewSelectedLine.beVisible()
                    parentBinding!!.imgLeaderBoardExpand.setImageDrawable(
                        ContextCompat.getDrawable(
                            itemView.context,
                            R.drawable.ic_baseline_arrow_right_24
                        )
                    )
                    parentBinding!!.container.setBackgroundColor(itemView.context.resources.getColor(R.color.colorGray_628))
                    parentBinding!!.imgLeaderBoardExpand.animate().rotationBy(90F).setDuration(500).start()
                    expandView()
                }

            }
        }

        init {
            parentBinding = DataBindingUtil.bind(itemView!!)
        }
    }


    inner class ItemViewHolder(itemView: View?) : ChildViewHolder<Any?>(itemView!!) {
        private var childBinding: LeaderboardChildItemBinding? = DataBindingUtil.bind(itemView!!)
        fun bind(item: LeaderboardModel.LeaderboardDatumChild) {
            if (item.country != null) {
                childBinding!!.tvLeaderboardRegion.text = nullSafeNA("" + item.country)
            } else {
                childBinding!!.tvLeaderboardRegion.text =
                    itemView.resources.getString(R.string.empty_desc)
            }
            childBinding!!.tvLeaderboardPoints.text = nullSafeNA(item.points)
            childBinding!!.tvLeaderboardPointOne.text = nullSafeNA(item.firstPosition)
            childBinding!!.tvLeaderboardPointTwo.text = nullSafeNA(item.secondPosition)
            childBinding!!.tvLeaderboardPointThree.text = nullSafeNA(item.thirdPosition)
            childBinding!!.linearLayoutLeaderBoard.click {
                onItemClick(item.userId.toString())
            }
        }

    }

    interface EventListener {
        fun OnMenuClick(parentPosition: Int, childPosition: Int)
    }

    fun setEventListener(eventlistener: EventListener?) {
        mEventListener = eventlistener
    }
}