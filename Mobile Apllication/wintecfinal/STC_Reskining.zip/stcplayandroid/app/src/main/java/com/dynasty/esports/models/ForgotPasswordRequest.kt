package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class ForgotPasswordRequest (

    @field:SerializedName("type")
    var type: String? = null,
    @field:SerializedName("phoneNumber")
    var phoneNumber: String? = null,
    @field:SerializedName("phoneOTP")
    var phoneOTP: Int? = null,
    @field:SerializedName("password")
    var password: String? = null,
    @field:SerializedName("email")
    var email: String? = null,
    @field:SerializedName("emailOTP")
    var emailOTP: Int? = null

)