package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class GameRoundModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<Int>? = null
}