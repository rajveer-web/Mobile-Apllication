package com.dynasty.esports.view.transaction

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dynasty.esports.R
import com.dynasty.esports.view.common.CommonPagerAdapter
import kotlinx.android.synthetic.main.fragment_transaction_history.*

/**
 * @desc this class will display transaction history
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class TransactionHistoryFragment : Fragment() {

    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_transaction_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        /**
         * assign fragments in fragment list
         * Fragment list assign to viewpager adapter
         */
//        fragmentList.add(
//            Pair(
//                PurchaseHistoryFragment.newInstance("purchase"),
//                resources.getString(R.string.str_purchase_history)
//            )
//        )
        fragmentList.add(
            Pair(
                PurchaseHistoryFragment.newInstance("reward"),
                resources.getString(R.string.str_rewards_history)
            )
        )
        commonPagerAdapter =
            CommonPagerAdapter(
                fragmentList,
                childFragmentManager
            )
        viewPagerTransaction.adapter = commonPagerAdapter
        tabLayoutTransaction.setupWithViewPager(viewPagerTransaction)
    }


}