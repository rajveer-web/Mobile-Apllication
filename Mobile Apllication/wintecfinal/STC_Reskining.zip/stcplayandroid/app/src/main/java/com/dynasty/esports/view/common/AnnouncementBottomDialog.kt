package com.dynasty.esports.view.common


import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beInVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.android.synthetic.main.custom_announcement_dialog.*


class AnnouncementBottomDialog : BottomSheetDialogFragment() {
    private var header:String=""
    private var description:String=""
    private var fileUrl:String=""
    private var destination:String=""

    override fun setupDialog(dialog: Dialog, style: Int) {
        val contentView: View = View.inflate(context, R.layout.custom_announcement_dialog, null)
        dialog.setContentView(contentView)
        isCancelable=false
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.custom_announcement_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textViewTitle.text=header
        textViewDescription.text=description
        imgIcon?.let { requireActivity().loadImageFromServer(fileUrl, it) }
        imageViewClose.click {
            dialog?.apply {
                dismiss()
            }
        }
        buttonPositive.text=resources.getString(R.string.btn_ok)
        imageViewBackground.beInVisible()
//        imageViewBackground?.let { requireActivity().loadImageFromServer(isBckImg, it) }
        buttonPositive.click {
            redirectToWebsite(destination)
            dialog?.apply {
                dismiss()
            }
        }
        buttonNegative.click {
            dialog?.apply {
                dismiss()
            }
        }
    }

    private fun redirectToWebsite(redirectionUrl: String){
//        Log.d("redirectionUrl ","redirectionUrl; " +redirectionUrl)
        if(redirectionUrl.contains("tournament")){
            DashboardActivity.navController.navigate(R.id.esportsFragment)
        }else if(redirectionUrl.contains("article")){
            DashboardActivity.navController.navigate(R.id.articlesFragment)
        }else{
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(redirectionUrl)
            startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(DialogFragment.STYLE_NO_FRAME,R.style.AppBottomSheetDialogTheme);
        arguments?.apply {
            header=this.getString("header").toString()
            description=this.getString("description").toString()
            fileUrl=this.getString("fileUrl").toString()
            destination=this.getString("destination").toString()
        }
    }

    companion object {
        fun newInstance(
            header: String,
            description: String,
            fileUrl: String,
            destination: String
        ): AnnouncementBottomDialog {
            val args = Bundle()
            args.putString("header", header)
            args.putString("description", description)
            args.putString("fileUrl", fileUrl)
            args.putString("destination", destination)
            val fragment = AnnouncementBottomDialog()
            fragment.arguments = args
            return fragment
        }
    }
}