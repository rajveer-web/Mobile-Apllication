package com.dynasty.esports.view.tournamet.tournamet_detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.nullSafeNA
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.view.common.BaseFragment
import kotlinx.android.synthetic.main.fragment_upcoming_highlight.*
import java.text.SimpleDateFormat
import java.util.*


class TournamentHighlightFragment : BaseFragment() {

    private lateinit var tournamentItem: TournamentDetailRes

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_upcoming_highlight, container, false)
    }

    companion object {
        fun newInstance(gameItem: TournamentDetailRes): Fragment {
            val args = Bundle()
            args.putParcelable("data", gameItem)
            val fragment = TournamentHighlightFragment()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
    }

    fun initialise() {
//      get data from arguments and set tournamentItem
        arguments?.apply {
            tournamentItem = this.getParcelable<TournamentDetailRes>("data")!!
        }
        desc_txt.text = nullSafeNA(tournamentItem.data!!.description)
        rules_txt.text = nullSafeNA(tournamentItem.data!!.rules)
        critical_rules_txt.text = nullSafeNA(tournamentItem.data!!.criticalRules)
        faq_txt.text = nullSafeNA(tournamentItem.data!!.faqs)
        hightlight_date_txt.text =
            resources.getString(R.string.date_highlight).plus(
                tournamentItem.data!!.startDate!!.convertDateToRequireDateFormat(
                    AppConstants.API_DATE_FORMAT,
                    AppConstants.REQUIRED_TIME_FORMAT
                )
            )
        highlight_time_txt.text = resources.getString(R.string.time_highlight).plus(nullSafeNA(tournamentItem.data!!.startTime))
        highlight_start_time_txt.text =
            resources.getString(R.string.starts_time_highlight).plus(nullSafeNA(tournamentItem.data!!.startTime))
    }
}