package com.dynasty.esports.models

import android.graphics.drawable.Drawable


class Spinner {
    lateinit var ID: String
    var title: String
    var drawable: Drawable? = null
    var isSelected: Boolean = false

    constructor(ID: String, title: String) {
        this.ID = ID
        this.title = title
    }

    constructor(ID: String, title: String, drawable: Drawable) {
        this.ID = ID
        this.title = title
        this.drawable = drawable
    }

    constructor(title: String) {
        this.title = title
    }

    fun setSelected(isSelected: Boolean): Spinner {
        this.isSelected = isSelected
        return this
    }
}