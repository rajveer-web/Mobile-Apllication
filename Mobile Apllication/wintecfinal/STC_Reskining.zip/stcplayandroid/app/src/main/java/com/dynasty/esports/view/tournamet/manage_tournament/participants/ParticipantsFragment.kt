package com.dynasty.esports.view.tournamet.manage_tournament.participants

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.models.ParticipantsModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.viewmodel.UpcomingParticipantsViewModel
import kotlinx.android.synthetic.main.fragment_participants.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ParticipantsFragment : BaseFragment(),
    ConnectivityReceiver.ConnectivityReceiverListener ,
    ParticipantsListFragment.OnParticipantsFragmentInteractionListener {
    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private val mViewModel: UpcomingParticipantsViewModel by viewModel()
    private var participantsList: MutableList<ParticipantsModel.DataModel> = arrayListOf()
    private var approvedParticipantsList: MutableList<ParticipantsModel.DataModel> = arrayListOf()
    private var rejectedParticipantsList: MutableList<ParticipantsModel.DataModel> = arrayListOf()
    private var pendingParticipantsList: MutableList<ParticipantsModel.DataModel> = arrayListOf()
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
    private var connectivityReceiver = ConnectivityReceiver()
    private var id: String = ""
    private var tournamentType:String=""
    private var bracketType:String=""
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_participants, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            id = this.getString("id").toString()
            bracketType=this.getString("bracketType").toString()
            tournamentType=this.getString("tournamentType").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenToViewModel()
    }

    private fun listenToViewModel() {
        mViewModel.makeJsonObjectForParticipantsQuery.observe(viewLifecycleOwner, {
            mViewModel.getParticipantsList(it.toString())
        })

        mViewModel.participantsListSuccessResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
            dismissProgressDialog()
            mViewModel.updateUI(it.data)
        })

        mViewModel.participantsListErrorResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
            dismissProgressDialog()
        })

        mViewModel.passDataAndUpdateUI.observe(viewLifecycleOwner, {

            it?.apply {
                participantsList.clear()
                fragmentList.clear()
                participantsList.addAll(this)

                approvedParticipantsList.clear()
                rejectedParticipantsList.clear()
                pendingParticipantsList.clear()

                participantsList.forEach {

                    when (it.participantStatus.toString().toLowerCase()) {
                        "approved" -> {
                            approvedParticipantsList.add(it)
                        }
                        "rejected" -> {
                            rejectedParticipantsList.add(it)
                        }
                        "null" -> {
                            pendingParticipantsList.add(it)
                        }
                    }
                }

                fragmentList.add(
                    Pair(
                        ParticipantsListFragment.newInstance(
                            0,
                            approvedParticipantsList,
                            bracketType,
                            tournamentType
                        ), resources.getString(R.string.approve))
                )
                fragmentList.add(
                    Pair(
                        ParticipantsListFragment.newInstance(
                            1,
                            rejectedParticipantsList,
                            bracketType,
                            tournamentType
                        ),
                        resources.getString(R.string.rejected)
                    )
                )
                fragmentList.add(
                    Pair(
                        ParticipantsListFragment.newInstance(
                            2,
                            pendingParticipantsList,
                            bracketType,
                            tournamentType
                        ), resources.getString(R.string.pending_approval))
                )

                commonPagerAdapter = CommonPagerAdapter(fragmentList, childFragmentManager)
                viewPagerParticipants.isSaveEnabled = false
                viewPagerParticipants.adapter = commonPagerAdapter
                tabLayoutParticipants.setupWithViewPager(viewPagerParticipants)
                viewPagerParticipants.offscreenPageLimit = 3

            }
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })

        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            if (it) {
                mViewModel.onDetach()
                logOut()
            }
        })


    }


    companion object {
        fun newInstance(id: String,bracketType:String,tournamentType:String): Fragment {
            val args = Bundle()
            args.putString("bracketType",bracketType)
            args.putString("tournamentType",tournamentType)
            args.putString("id", id)
            val fragment = ParticipantsFragment()
            fragment.arguments = args
            return fragment
        }
    }

    // Register receiver for check internet connection
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    // Unregister receiver for internet connection
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    // Prevent to API call from view model
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    // Manage internet connection using receiver
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && participantsList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            mViewModel.makeQueryForParticipantsList(id)
        } else if (!isConnected && participantsList.isNullOrEmpty()) {

        }
    }

    override fun notifyParticipant(isUpdate: Boolean) {
        if(isUpdate){
            launchProgressDialog()
            mViewModel.makeQueryForParticipantsList(id)
        }
    }
}