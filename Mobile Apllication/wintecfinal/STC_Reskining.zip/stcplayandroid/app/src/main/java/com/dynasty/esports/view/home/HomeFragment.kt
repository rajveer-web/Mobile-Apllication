package com.dynasty.esports.view.home

/*//import com.dynasty.esports.view.leaderboard.LeaderboardActivity*/
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.constants.ArticleConstant
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.BannerModel
import com.dynasty.esports.models.CustomArticleModel
import com.dynasty.esports.models.LeaderboardModel
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.article.article_detail.ArticlesDetailActivity
import com.dynasty.esports.view.article.article_section.ArticlesAdapter
import com.dynasty.esports.view.article.view_all_article.ViewAllArticlesActivity
import com.dynasty.esports.view.common.AnnouncementBottomDialog
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.view.esport.OngoingTournamentFragment
import com.dynasty.esports.view.esport.UpcomingTournamentFragment
import com.dynasty.esports.view.leaderboard.LeaderBoardProfileActivity
import com.dynasty.esports.view.leaderboard.LeaderboardExpandableAdapter
import com.dynasty.esports.view.search.SearchActivity
import com.dynasty.esports.viewmodel.HomeViewModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.home_app_bbar_layout.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 *
 * @desc this is class will use for Home page
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class HomeFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {

    private var artistList: MutableList<CustomArticleModel> = mutableListOf()
    private lateinit var articlesAdapter: ArticlesAdapter
    private val mViewModel: HomeViewModel by viewModel()
    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private lateinit var homeViewPagerAdapter: HomePagerAdapter
    private lateinit var leaderboardExpandableAdapter: LeaderboardExpandableAdapter
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    private var connectivityReceiver = ConnectivityReceiver()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
     //   listenToPref()
    }

    private fun listenToPref() {
        val data = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData

        if (!sharedPreferences.checkUserLoggedInOrNot()) {
            welcome_username_txt.text = resources.getString(R.string.welcome)

        }else{
            welcome_username_txt.text = resources.getString(R.string.welcome).plus(", " + data.fullName)
        }

    }

            /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this

        //setHomePageBannerSlideAdpater()

    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
        handler.removeCallbacks(timeCounter)
    }

    /**
     * @desc this method is used for initialize adapter and recyclerview
     */
    fun initialise() {
        homeRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        artistList.clear()
        articlesAdapter =
            ArticlesAdapter(
                artistList,
                onItemClick = ::onItemClick,
                onViewAllItemClick = ::onViewAllItemClick
            )
        homeRecyclerView.adapter = articlesAdapter
//        setWebViewBanner()
        setStatePageAdapter()

        searchImageView.click {
            startActivityFromFragment<SearchActivity>()
        }
        btnViewAllLeaderBoard.click {
        //    startActivityFromFragment<LeaderboardActivity>()
        }

//        tvLeaderboard.click {
//            startActivityFromFragment<LeaderboardActivity>()
//        }
    }

//    private fun setWebViewBanner() {
//        webView.webChromeClient = WebChromeClient()
//        webView.settings.javaScriptEnabled = true
//        webView.setBackgroundColor(Color.TRANSPARENT)
//        webView.loadData(
//            "<html><body  style='margin: 0; padding: 0'><iframe src='https://chat.exaltaretech.com/static/getInitials' width='100%' height='100%' style='border: none;'></iframe></body></html>",
//            "text/html",
//            "UTF-8"
//        )
//
//        llWebViewProgressDialog.beVisible()
//        webView.beGone()

//        webView.webChromeClient = object : WebChromeClient() {
//            override fun onProgressChanged(view: WebView, progress: Int) {
//                if (progress == 100) {
//                    llWebViewProgressDialog.beGone()
//                    webView.beVisible()
//                }
//            }
//        }

//        webView.setWebViewClient(object : WebViewClient() {
//            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap) {
//                super.onPageStarted(view, url, favicon)
//                println("your current url when webpage loading..$url")
//            }
//
//            override fun onPageFinished(view: WebView, url: String) {
//                llWebViewProgressDialog.beGone()
//                webView.beVisible()
//                super.onPageFinished(view, url)
//            }
//
//            override fun onLoadResource(view: WebView, url: String) {
//                // TODO Auto-generated method stub
//                super.onLoadResource(view, url)
//            }
//
//            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
//                "when you click on any interlink on webview that time you got url :-$url".showToast(requireContext())
//                return super.shouldOverrideUrlLoading(view, url)
//            }
//        })

//        webView.webViewClient = object : WebViewClient() {
//            override fun shouldOverrideUrlLoading(
//                view: WebView?,
//                request: WebResourceRequest?
//            ): Boolean {
////                val url = request?.url.toString()
////                view?.loadUrl(url)
//                request?.url.toString().showToast(requireContext())
//
////                debugE("url", request?.url.toString())
//
////                if (request?.url.toString().contains("tournament")) {
////                    val tournamentId = request!!.url.toString().replace("https://www.mesf.gg/tournament/"," ")
////                    val bundle = Bundle()
////                    bundle.putString("tournamentId", tournamentId.trim())
////                    bundle.putBoolean("isUpcoming", false)
////                    requireActivity().startActivityInline<TournamentDetailActivity>(
////                        bundle
////                    )
////                }
////                return super.shouldOverrideUrlLoading(view, request)
//                return true
//            }
//
//            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
//                super.onPageStarted(view, url, favicon)
//            }
//
//            override fun onPageFinished(view: WebView?, url: String?) {
//                try {
//                    Handler().postDelayed({
//                        if (llWebViewProgressDialog != null) {
//                            llWebViewProgressDialog.beGone()
//                            webView.beVisible()
//                        }
//                    }, 1000)
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                }
//                super.onPageFinished(view, url)
//            }
//
//            override fun onReceivedError(
//                view: WebView,
//                request: WebResourceRequest,
//                error: WebResourceError
//            ) {
//                super.onReceivedError(view, request, error)
//            }
//        }
//    }

    /**
     * @desc listen observer and observer that will receive the events
     * Also, Manage API success and failure,Internet and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.makeJsonForArticleData.observe(viewLifecycleOwner,{
            Handler().postDelayed({
                mViewModel.getAllArticles(it.first.toString(),it.second.first.toString(),it.second.second.toString())
                mViewModel.fetchLeaderBoardDetail()
            }, 500)
        })
        mViewModel.announcemntSuccessResponse.observe(viewLifecycleOwner, Observer {
            val dataSize: Int = it.data!!.size - 1
            for (i in 0..dataSize) {
                if ("announcementId" in sharedPreferences) {
                    if (it.data[i].id != sharedPreferences.announcementId) {
                        val bottomSheetDialog: AnnouncementBottomDialog = AnnouncementBottomDialog.newInstance(it.data[i].header.toString(),it.data[i].description.toString(),it.data[i].announcementFileUrl.toString(),it.data[i].destination.toString())
                        bottomSheetDialog.show(
                            childFragmentManager,
                            "Bottom Sheet Dialog Fragment"
                        )
//                        displayAnnouncemnetDialog(
//                            it.data[i].header.toString(),
//                            it.data[i].description.toString(),
//                            isCancelable = false,
//                            isCloseShow = true,
//                            isIconImg = it.data[i].announcementFileUrl.toString(),
//                            isBckImg = "",
//                            positiveText = resources.getString(R.string.btn_ok),
//                            positiveClick = {
//                                //it.dismiss()
//                                redirectToWebsite(it.data[i].destination.toString())
//                            })
                    }
                } else {
                    sharedPreferences.announcementId = it.data[i].id.toString()
                    val bottomSheetDialog: AnnouncementBottomDialog = AnnouncementBottomDialog.newInstance(it.data[i].header.toString(),it.data[i].description.toString(),it.data[i].announcementFileUrl.toString(),it.data[i].destination.toString())
                    bottomSheetDialog.show(
                        childFragmentManager,
                        "Bottom Sheet Dialog Fragment"
                    )
//                    displayAnnouncemnetDialog(
//                        it.data[i].header.toString(),
//                        it.data[i].description.toString(),
//                        isCancelable = false,
//                        isCloseShow = true,
//                        isIconImg = it.data[i].announcementFileUrl.toString(),
//                        isBckImg = "",
//                        positiveText = resources.getString(R.string.btn_ok),
//                        positiveClick = {
//                            //it.dismiss()
//                            redirectToWebsite(it.data[i].destination.toString())
//                        })
                }
            }
        })

        mViewModel.bannerSuccessResponse.observe(viewLifecycleOwner, Observer {
            it.data?.apply {
                progressBarBanner.beGone()
                setHomePageBannerSlideAdapter(this)
            }

        })

        mViewModel.bannerErrorResponse.observe(viewLifecycleOwner, Observer {
            progressBarBanner.beGone()
            textViewBannerNoData.beVisible()
            textViewBannerNoData.text = resources.getString(R.string.some_thing_went_wrong)
        })

        // Get all trending article response
        mViewModel.articleTrendingResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBarDialog.beGone()
            it?.data?.docs?.apply {
                if (this.isNotEmpty()) {
                    artistList.add(
                        CustomArticleModel(
                            ArticleConstant.CONST_LATEST_ARTICLE,
                            title = resources.getString(R.string.treanding_post_title),
                            latestArticleList = this
                        )
                    )
                    articlesAdapter.notifyDataSetChanged()
                }
            }
        })

        // Get all Post by games response
        mViewModel.articlePostByGamesResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBarDialog.beGone()
            it?.data?.apply {
                if (this.isNotEmpty()) {
                    artistList.add(
                        CustomArticleModel(
                            ArticleConstant.CONST_HOME_POST_BY_GAMES,
                            title = resources.getString(R.string.post_by_games),
                            gamesList = this
                        )
                    )
                    articlesAdapter.notifyDataSetChanged()
                }
            }
        })

        // Get all trending article response
        mViewModel.latestVideoResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBarDialog.beGone()
        })

        mViewModel.fetchLeaderboardSuccessResponse.observe(requireActivity(), Observer {
            debugE("fetchLeaderboardSuccessResponse", Gson().toJson(it))

            for (i in it.data!!.leaderboardData) {
                val item = LeaderboardModel.LeaderboardDatumChild()
                if (item.country != null) {
                    item.country = i.country
                }
                item.firstPosition = i.firstPosition
                item.createdOn = i.createdOn
                item.id = i.id
                item.name = i.name
                item.points = i.points
                item.profilePicture = i.profilePicture
                item.secondPosition = i.secondPosition
                item.thirdPosition = i.thirdPosition
                item.updatedOn = i.updatedOn
                item.userId = i.userId
                item.v = i.v
                i.leaderboardDataChild.add(item)
            }

            leaderboardExpandableAdapter = LeaderboardExpandableAdapter(
                requireContext(),
                it.data!!.leaderboardData,onItemClick = ::onLeaderBoardItemClick
            )

            rvHomeLeaderBoard.layoutManager =
                LinearLayoutManager(requireContext())
            rvHomeLeaderBoard.adapter = leaderboardExpandableAdapter
            leaderboardExpandableAdapter.expandAllParents()


//            it.data!!.leaderboardData[0].name!!.showToast(this)
            try {
                llLeadeboardHomeProgress.beGone()
                rvHomeLeaderBoard.beVisible()
            } catch (e: Exception) {
            }
        })

        mViewModel.fetchLeaderboardErrorResponse.observe(requireActivity(), Observer {
            debugE("fetchLeaderboardErrorResponse", it.string())
            try {
                llLeadeboardHomeProgress.beGone()
                rvHomeLeaderBoard.beGone()
                constraintLayoutErrorView.beVisible()
                dismissProgressDialog()
            } catch (e: Exception) {
            }
        })


        // Managed no internet and 500 error
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            refreshPlaceHolder(false)
            dismissProgressDialog()
//            refreshPlaceHolder(false)
        })
    }

    val handler = Handler()

    var currentIndex = 0

    /**
     * @desc set Runnable for timeCounter for auto change images in banner
     */
    private val timeCounter: Runnable = object : Runnable {
        override fun run() {
            if (currentIndex + 1 > homeViewPagerAdapter.count) {
                currentIndex = 0
            } else {
                currentIndex++
            }
            home_view_pager?.apply {
                this.setCurrentItem(currentIndex, true)
            }
            handler.postDelayed(this, 3 * 1000)
        }
    }


    private fun onLeaderBoardItemClick(id:String){
        val bundle=Bundle()
        bundle.putString("id",id)
        startActivityFromFragment<LeaderBoardProfileActivity>(bundle)
    }

    /**
     * @desc method will set homeViewPagerAdapter and run timer for next image in banner (auto change images every 3 sec)
     */
    private fun setHomePageBannerSlideAdapter(data: MutableList<BannerModel.DataModel>) {
        homeViewPagerAdapter = HomePagerAdapter(requireContext(), data)
        home_view_pager.adapter = homeViewPagerAdapter
        homepageIndicatorView.setViewPager(home_view_pager)
        homepageIndicatorView.beVisible()
        handler.postDelayed(timeCounter, 3 * 1000)
    }


    /**
     * @desc method will add fragments in fragmentList and set to commonPagerAdapter
     */
    private fun setStatePageAdapter() {
        fragmentList.clear()
        fragmentList.add(
            Pair(
                UpcomingTournamentFragment.newInstance(),
                resources.getString(R.string.upcoming)
            )
        )
        fragmentList.add(
            Pair(
                OngoingTournamentFragment.newInstance(),
                resources.getString(R.string.ongoing)
            )
        )

        commonPagerAdapter =
            CommonPagerAdapter(
                fragmentList,
                childFragmentManager
            )

        homePager.adapter = commonPagerAdapter
        homePager.offscreenPageLimit = 2
        homeTabLayout.setupWithViewPager(homePager, true)

        homePager?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {}

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {}

        })
    }

    /**
     * @desc method will call when tap on view all from article adapter and redirect to view all article screen
     * @param type article type
     * @param title article title
     */
    private fun onViewAllItemClick(type: Int, title: String) {
        val bundle = Bundle()
        if (type == 5) {
            bundle.putInt("type", ArticleConstant.CONST_POST_BY_GAMES)
        } else {
            bundle.putInt("type", type)
        }
        bundle.putString("title", title)
        startActivityFromFragment<ViewAllArticlesActivity>(bundle)
    }

    /**
     * @desc method will call when tap on article from article adapter and redirect to different screen
     * @param type article type
     * @param id article id
     * @param title article title
     */
    fun onItemClick(type: Int, id: Any, title: String) {
        when (type) {
            ArticleConstant.CONST_LATEST_ARTICLE -> {
                val bundle = Bundle()
                bundle.putString("id", id.toString())
                startActivityFromFragment<ArticlesDetailActivity>(bundle)
            }

            ArticleConstant.CONST_HOME_POST_BY_GAMES -> {
                val bundle = Bundle()
                bundle.putString("id", id.toString())
                bundle.putBoolean("isGame", true)
                bundle.putString("title", title)
                bundle.putInt("type", ArticleConstant.CONST_LATEST_ARTICLE)
                startActivityFromFragment<ViewAllArticlesActivity>(bundle)
            }
        }

    }

    /**
     * @desc stop apis call and clear view model
     *       and remove timeCounter from handler
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()


        handler.removeCallbacks(timeCounter)
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if(isConnected){
            mViewModel.getLatestAnnouncement()
        }
        if (isConnected && artistList.isEmpty()) {
            artistList.clear()
            mViewModel.getAllBanner()
            refreshPlaceHolder(true)
            mViewModel.makeJsonForArticleParameter()
//            val jsonObject = JSONObject()
//            jsonObject.put("pagination", false)
//            jsonObject.put("page", 1)
//            jsonObject.put("limit", 3)


        } else if (artistList.isEmpty()) {
            refreshPlaceHolder(false)
        }
    }

    private fun refreshPlaceHolder(isInternetAvailable: Boolean) {
        if (isInternetAvailable) {
            clHome.beVisible()
            llNoInternet.beGone()
        } else {
            clHome.beGone()
            llNoInternet.beVisible()
        }
    }
}