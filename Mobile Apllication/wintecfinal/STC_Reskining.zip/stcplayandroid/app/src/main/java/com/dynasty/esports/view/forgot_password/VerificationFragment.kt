package com.dynasty.esports.view.forgot_password

import `in`.aabhasjindal.otptextview.OTPListener
import android.os.Bundle
import android.os.CountDownTimer
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.getMessageFromObject
import com.dynasty.esports.extenstion.makeSpannableString
import com.dynasty.esports.extenstion.showToast
import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.viewmodel.ForgotPasswordMobileFragmentViewModel
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.fragment_forgot_password_verification.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class VerificationFragment : ForgotPasswordPageFragment() {

    lateinit var mREquest: ForgotPasswordRequest
    var otpValue: String? = null
    val mViewModel: ForgotPasswordMobileFragmentViewModel by viewModel()


    fun displayReceivedData(message: ForgotPasswordRequest) {
//        txtData.setText("Data received: $message")

        mREquest.phoneNumber = message.phoneNumber
        mREquest.type = message.type
        mREquest.email = message.email

        if (mREquest.type == "phone") {
            successful_reset_password_subtxt.text =
                resources.getString(R.string.forgot_password_subtitle)
                    .plus(" " + mREquest.phoneNumber)
        } else {
            successful_reset_password_subtxt.text =
                resources.getString(R.string.forgot_password_subtitle_mail)
                    .plus(" " + mREquest.email)
        }

    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
    }

    fun listenToViewModel() {
        mViewModel.forgotPasswordResendOTPSuccessResponse.observe(
            requireActivity(), {
                it.string().getMessageFromObject("message").showToast(requireActivity())
            })

        mViewModel.forgotPasswordResendOTPErrorResponse.observe(
            requireActivity(),
            androidx.lifecycle.Observer {
                it.string().getMessageFromObject("message").showToast(requireActivity())
            })


        mViewModel.phoneOrEmailVerificationSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            mForgotPasswordWizard!!.nextPage()
            Toast.makeText(
                context,
                it.string().getMessageFromObject("message"),
                Toast.LENGTH_SHORT
            ).show()
        })

        mViewModel.phoneOrEmailVerificationErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            rest_otp_text.setOTP("")
            Toast.makeText(
                context,
                it.string().getMessageFromObject("message"),
                Toast.LENGTH_SHORT
            ).show()
        })

    }

    fun initialise() {
        dismissProgressDialog()
        mREquest = ForgotPasswordRequest()
        getCountDownTimer()
        rest_otp_text?.requestFocusOTP()
        rest_otp_text?.otpListener = object : OTPListener {
            override fun onInteractionListener() {}
            override fun onOTPComplete(otp: String) {
                otpValue = otp
            }
        }
        reset_password_resend.makeSpannableString(
            requireActivity(),
            resources.getString(R.string.resend_title),
            20,
            resources.getString(R.string.resend_title).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    reset_password_resend.visibility = View.GONE
                    getCountDownTimer()

                    val jsonObject = JsonObject()

                    if(mREquest.type == "phone" || mREquest.type == "phone_otp"){
                        jsonObject.addProperty("type", "forgot_phone")
                        jsonObject.addProperty("phoneNumber", mREquest.phoneNumber)
                    }else{
                        jsonObject.addProperty("type", "forgot_email")
                        jsonObject.addProperty("email", mREquest.email)
                    }
                    mViewModel.resetPasswordREsendOtp(jsonObject)
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }


            })


    }

    private fun getCountDownTimer() {
        val timer = object : CountDownTimer(240000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                var diff = millisUntilFinished
                val secondsInMilli: Long = 1000
                val minutesInMilli = secondsInMilli * 60
                val hoursInMilli = minutesInMilli * 60
                val daysInMilli = hoursInMilli * 24

                val elapsedMinutes = diff / minutesInMilli
                diff %= minutesInMilli

                val elapsedSeconds = diff / secondsInMilli

                restet_expries_in_text?.text =
                    resources.getString(R.string.expires) + " " + "$elapsedMinutes : $elapsedSeconds "
//                expiresTxt.text = resources.getString(R.string.expires) +" "+ "$elapsedDays days $elapsedHours hs $elapsedMinutes min $elapsedSeconds sec"
            }

            override fun onFinish() {
                restet_expries_in_text?.text =  resources.getString(R.string.expires) + " " + "00 : 00 "
                reset_password_resend?.visibility = View.VISIBLE
            }
        }
        timer.start()
    }

    override fun getPageType(): ForgotPasswordMobileActivity.ForgotPasswordWizardPageType {
        return ForgotPasswordMobileActivity.ForgotPasswordWizardPageType.VERIFICATION
    }

    override fun onNextButtonClick() {
        launchProgressDialog()
        if (otpValue?.length == 4) {
            mREquest.apply {
                this.phoneNumber = mREquest.phoneNumber
                this.email = mREquest.email
                if (mREquest.type == "phone" || mREquest.type == "phone_otp") {
                    this.type = "phone_otp"
                    this.phoneOTP = otpValue?.toInt()
                } else {
                    this.type = "email_otp"
                    this.emailOTP = otpValue?.toInt()
                }
            }
            mViewModel.emailOrMobileNosVerification(mREquest)
            mForgotPasswordWizard!!.sendDataToChangePasswordFragment(mREquest)
        } else {
            dismissProgressDialog()
            Toast.makeText(
                context,
                resources.getString(R.string.enter_otp_msg),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun shouldEnableButton(): Boolean {
        TODO("Not yet implemented")
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_forgot_password_verification, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = VerificationFragment()
    }

}