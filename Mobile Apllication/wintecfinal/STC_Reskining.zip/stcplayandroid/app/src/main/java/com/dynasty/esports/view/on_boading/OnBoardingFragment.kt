package com.dynasty.esports.view.on_boading

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dynasty.esports.R
import kotlinx.android.synthetic.main.fragment_onboarding.*

/**
 * @desc this class will hold functions for user interaction
 * examples include view initialisation
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class OnBoardingFragment : Fragment() {
    private lateinit var title: String
    private lateinit var description: String
    private var imageResource = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            title = this.getString(ARG_PARAM1).toString()
            description = this.getString(ARG_PARAM2).toString()
            imageResource = this.getInt(ARG_PARAM3)

        }

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_onboarding, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        text_onboarding_title.text = title
        text_onboarding_description.text = description
        image_onboarding.setImageResource(imageResource)
    }

    companion object {
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private const val ARG_PARAM1 = "param1"
        private const val ARG_PARAM2 = "param2"
        private const val ARG_PARAM3 = "param3"
        fun newInstance(
            title: String?,
            description: String?,
            imageResource: Int
        ): OnBoardingFragment {
            val fragment =
                OnBoardingFragment()
            val args = Bundle()
            args.putString(ARG_PARAM1, title)
            args.putString(ARG_PARAM2, description)
            args.putInt(ARG_PARAM3, imageResource)
            fragment.arguments = args
            return fragment
        }
    }
}
