package com.dynasty.esports.view.article.article_section


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterLatestArticleHeaderBinding
import com.dynasty.esports.databinding.AdapterLatestTrendingPostBinding
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.RowArticlePostBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.models.LatestTrendingModel
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.LoadingViewHolder

/**
 * @desc this is class will handle Trending Post article
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class LatestTrendingPostAdapter constructor(
    private var articleList: MutableList<LatestTrendingModel.DatumModel>,
    private val onItemClick: (String) -> Unit = { _ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindingHolder<RowArticlePostBinding> {
//        val binding: RowArticlePostBinding = DataBindingUtil.inflate(
//            LayoutInflater.from(parent.context),
//            R.layout.row_article_post,
//            parent,
//            false
//        )
//        return BindingHolder(binding)
//
//    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: AdapterLatestTrendingPostBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_latest_trending_post,
                        parent,
                        false
                    )
                return ViewHolderTrendingArticle(binding)
            }
            else -> {
                val binding: AdapterLatestArticleHeaderBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_latest_article_header,
                        parent,
                        false
                    )
                return ViewHolderTrendingArticleHeader(binding)
            }

        }
    }

    /**
     * @desc trending post array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return articleList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (position==0) {
            1
        } else {
            0
        }
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderTrendingArticle).bind(articleList[position])
            }
            else -> {
                (holder as ViewHolderTrendingArticleHeader).bind(articleList[position])
            }
        }
    }

    /**
     *@desc This call use for display Video data
     */
    inner class ViewHolderTrendingArticle(private var binding: AdapterLatestTrendingPostBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: LatestTrendingModel.DatumModel) {
            if(adapterPosition==1){
                binding.linearLayoutTitle.beVisible()
            }else{
                binding.linearLayoutTitle.beGone()
            }

            when(data.trend){
                1->{
                    binding.imageViewIcon.setImageResource(R.drawable.ic_hottest)
                    binding.textViewTitle.text=binding.root.context.resources.getString(R.string.hottest_posts)
                }
                2->{
                    binding.imageViewIcon.setImageResource(R.drawable.ic_trending)
                    binding.textViewTitle.text=binding.root.context.resources.getString(R.string.trending_now)

                }
                else->{
                    binding.imageViewIcon.setImageResource(R.drawable.ic_star)
                    binding.textViewTitle.text=binding.root.context.resources.getString(R.string.editor_pick)

                }
            }

            binding.linearLayoutData.click {
                onItemClick(data.id.toString())
            }
            if (LocaleHelper.getLanguage(binding.root.context) == "en") {
                binding.textViewDescription.text = data.title?.english?.let { it } ?: ""
//                binding.textViewDescription.text = data.shortDescription?.english?.let { it } ?: ""
            }else{
                binding.textViewDescription.text =
                    if (data.title?.malay.isNullOrEmpty()) data.title?.english?.let { it }
                        ?: "" else data.title?.malay?.let { it } ?: ""
//                binding.textViewDescription.text =
//                    if (data.shortDescription?.malay.isNullOrEmpty()) data.shortDescription?.english?.let { it }
//                        ?: "" else data.shortDescription?.malay?.let { it } ?: ""
            }
        }

    }


    /**
     *@desc This call use for display Video data
     */
    inner class ViewHolderTrendingArticleHeader(private var binding: AdapterLatestArticleHeaderBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: LatestTrendingModel.DatumModel) {
            data.apply {

                binding.linearLayoutData.click {
                    onItemClick(data.id.toString())
                }

                when(data.trend){
                    1->{
                        binding.imageViewIcon.setImageResource(R.drawable.ic_hottest)
                        binding.textViewTitle.text=binding.root.context.resources.getString(R.string.hottest_posts)
                    }
                    2->{
                        binding.imageViewIcon.setImageResource(R.drawable.ic_trending)
                        binding.textViewTitle.text=binding.root.context.resources.getString(R.string.trending_now)

                    }
                    else->{
                        binding.imageViewIcon.setImageResource(R.drawable.ic_star)
                        binding.textViewTitle.text=binding.root.context.resources.getString(R.string.editor_pick)

                    }
                }

                binding.root.context.loadImageFromServer(this.image.toString(),binding.imageViewBanner)

                    if (LocaleHelper.getLanguage(binding.root.context) == "en") {
                        binding.textViewDescription.text = data.title?.english?.let { it } ?: ""
                       // binding.textViewDescription.text = data.shortDescription?.english?.let { it } ?: ""
                    }else{
                        binding.textViewDescription.text =
                            if (data.title?.malay.isNullOrEmpty()) data.title?.english?.let { it }
                                ?: "" else data.title?.malay?.let { it } ?: ""
//                        binding.textViewDescription.text =
//                            if (data.shortDescription?.malay.isNullOrEmpty()) data.shortDescription?.english?.let { it }
//                                ?: "" else data.shortDescription?.malay?.let { it } ?: ""
                    }

            }
        }

    }


}