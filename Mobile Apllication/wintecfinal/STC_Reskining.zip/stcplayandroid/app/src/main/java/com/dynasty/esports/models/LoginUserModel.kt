package com.dynasty.esports.models

data class LoginUserModel(var id:String,var name:String,var profile:String)