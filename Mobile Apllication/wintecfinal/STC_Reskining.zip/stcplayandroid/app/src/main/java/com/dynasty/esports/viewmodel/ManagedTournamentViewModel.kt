package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.CheckedInTournamentModel
import com.dynasty.esports.models.GameRoundDetailModel
import com.dynasty.esports.models.GameRoundModel
import com.dynasty.esports.models.ManageTournamentModel
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class ManagedTournamentViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val jsonObjectForGetTournament =
        MutableLiveData<Pair<Pair<JsonObject, JsonObject>, Pair<JsonObject, JsonObject>>>()

    val tournamentDetailSuccessResponse = MutableLiveData<ManageTournamentModel>()
    val tournamentDetailErrorResponse = MutableLiveData<ResponseBody>()

    val tournamentUpdateSuccessResponse = MutableLiveData<ResponseBody>()
    val tournamentUpdateErrorResponse = MutableLiveData<ResponseBody>()


    val tournamentRegisterTeamSuccessResponse = MutableLiveData<CheckedInTournamentModel>()
    val tournamentCheckInSuccessResponse = MutableLiveData<CheckedInTournamentModel>()

    val gameRoundSuccessResponse = MutableLiveData<GameRoundModel>()
    val gameRoundErrorResponse = MutableLiveData<ResponseBody>()
    val gameRoundDetailSuccessResponse = MutableLiveData<GameRoundDetailModel>()
    val gameRoundDetailErrorResponse = MutableLiveData<ResponseBody>()

    val jsonObjectForGetMatchRound = MutableLiveData<JsonObject>()
    val jsonObjectForUpdateTournament = MutableLiveData<JsonObject>()

    val jsonObjectForGetMatchRoundDetail = MutableLiveData<JsonObject>()

    //val tournamentCheckInErrorResponse = MutableLiveData<ResponseBody>()


    fun checkFormValidation(
        name: String,
        date: String,
        time: String,
        partNumber: Int,
        isValidDateTime: Boolean
    ) {
        when {
            name.isFieldEmpty() -> validationLiveData.postValue(0)
            date.isFieldEmpty() -> validationLiveData.postValue(1)
            time.isFieldEmpty() -> validationLiveData.postValue(2)
            partNumber < 2 || partNumber > 1024 -> validationLiveData.postValue(3)
            !isValidDateTime -> validationLiveData.postValue(4)
            else -> isFormValid.postValue(true)

        }
    }

    fun getTournamentDetails(
        jsonObject: String,
        jsonObjectCheckIn: String,
        jsonObjectRegister: String,
        select: String,
        selectCheckIn: String,
        option: String
    ) {
        viewModelScope.launch(apiException("detail") + Dispatchers.Main) {

            val registerTermsResponse = async {
                restInterface.getCheckInParticipant(
                    jsonObjectRegister,
                    selectCheckIn,
                    option
                )
            }

            val checkInTermsResponse = async {
                restInterface.getCheckInParticipant(
                    jsonObjectCheckIn,
                    selectCheckIn,
                    option
                )
            }
            val tournamentDetailResponse =
                async { restInterface.getTournamentDetail(jsonObject, select) }

            if (registerTermsResponse.await().code() == AppConstants.API_SUCCESS_CODE) {
                tournamentRegisterTeamSuccessResponse.postValue(
                    registerTermsResponse.await().body()
                )
            }
            if (checkInTermsResponse.await().code() == AppConstants.API_SUCCESS_CODE) {
                tournamentCheckInSuccessResponse.postValue(checkInTermsResponse.await().body())
            }
//            else { %7B%22_id%22%3A%225f69c0ca0f18e600086be33e%22%7D
//                tournamentCheckInErrorResponse.postValue(checkInResponse.await().errorBody())
//            }

            if (tournamentDetailResponse.await().code() == AppConstants.API_SUCCESS_CODE) {
                tournamentDetailSuccessResponse.postValue(tournamentDetailResponse.await().body())
            } else {
                tournamentDetailErrorResponse.postValue(
                    tournamentDetailResponse.await().errorBody()
                )
            }


        }

    }


    fun getMatchRound(jsonObjectString: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {

            val response = restInterface.getMatchRound(jsonObjectString)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gameRoundSuccessResponse.postValue(response.body())
                }
                else -> {
                    gameRoundErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun getMatchRoundDetail(jsonObjectString: String, select: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getMatchRoundDetail(jsonObjectString, select)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gameRoundDetailSuccessResponse.postValue(response.body())
                }
                else -> {
                    gameRoundDetailErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    fun updateTournamentDetail(id: String, jsonObjectString: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.updateTournamentDetails(id, jsonObjectString)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    tournamentUpdateSuccessResponse.postValue(response.body())
                }
                else -> {
                    tournamentUpdateErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun makeJsonForUpdateTournament(
        name: String,
        participants: String,
        startDate: String,
        startTime: String
    ) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("name", name)
        jsonObject.addProperty("maxParticipants", participants)
        jsonObject.addProperty("startDate", startDate)
        jsonObject.addProperty("startTime", startTime)
        jsonObjectForUpdateTournament.postValue(jsonObject)
    }

    fun makeJsonForMatchRound(id: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("tournamentId", id)
        jsonObjectForGetMatchRound.postValue(jsonObject)
    }

    fun makeJsonForMatchRoundDetail(id: String, round: Int) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("tournamentId", id)
        jsonObject.addProperty("currentMatch.round", round)
        jsonObject.addProperty("bye", false)
        val jsonObjectMatchStatus = JsonObject()
        jsonObjectMatchStatus.addProperty("\$ne", "inactive")
        jsonObject.add("matchStatus", jsonObjectMatchStatus)
        jsonObjectForGetMatchRoundDetail.postValue(jsonObject)

    }

    fun makeJsonForGetTournament(id: String, count: Boolean) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("_id", id)
        val jsonObjectRegisterTeam = JsonObject()
        jsonObjectRegisterTeam.addProperty("tournamentId", id)
        val jsonObjectCheckIn = JsonObject()
        jsonObjectCheckIn.addProperty("tournamentId", id)
        jsonObjectCheckIn.addProperty("checkedIn", true)
        val jsonObjectCount = JsonObject()
        jsonObjectCount.addProperty("count", count)
        jsonObjectForGetTournament.postValue(
            Pair(
                Pair(jsonObject, jsonObjectCheckIn),
                Pair(jsonObjectRegisterTeam, jsonObjectCount)
            )
        )
    }

    fun onDetach() {
        viewModelScope.cancel()
    }

}
