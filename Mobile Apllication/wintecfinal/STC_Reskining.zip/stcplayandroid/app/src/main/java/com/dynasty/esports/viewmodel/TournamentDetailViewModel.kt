package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.ParticipantRes
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody


class TournamentDetailViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val fetchTournamentDetailSuccessResponse = MutableLiveData<TournamentDetailRes>()
    val fetchTournamentDetailErrorResponse = MutableLiveData<ResponseBody>()

    val isAlreadyJoinSuccessResponse = MutableLiveData<ParticipantRes>()
    val isAlreadyJoinErrorResponse = MutableLiveData<ResponseBody>()

    val joinTournamentObservable = MutableLiveData<Boolean>()

    fun joinTournamentClick() {
        joinTournamentObservable.postValue(true)
    }

    fun fetchTournamentDetail(tournamentId: String, sort: String, type: String) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getTournamentDetails(tournamentId)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchTournamentDetailSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchTournamentDetailErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun checkIsAlreadyJoindOrNot(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.checkParticipant(jsonObject.toString())

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    isAlreadyJoinSuccessResponse.postValue(response.body())
                }
                else -> {
                    isAlreadyJoinErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * Clears the [ViewModel] when the [ArticlesFragment] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}