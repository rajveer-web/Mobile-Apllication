package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.BracketData
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 22-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BracketViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    // define MutableLiveData for emit observer
    val bracketSuccessResponse = MutableLiveData<BracketData>()
    val bracketErrorResponse = MutableLiveData<ResponseBody>()
    val updateBracketUI = MutableLiveData<BracketData>()
    val jsonObjectForBracket = MutableLiveData<JsonObject>()

    /**
     * @desc Method will handle fetch bracket API success, failure
     * @param jsonObject- pass json object with parameter
     */
    fun fetchBracketData(jsonObject: JsonObject) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.fetchAllBracket(jsonObject.toString())
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    bracketSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE->{
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    bracketErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     * @desc Method will use for create json object for bracket data
     * @param page - page number
     * @param limit -data limit
     */
    fun makeJsonForBracket(page: Int, limit: Int) {
        val arrayProjection = JsonArray()
        arrayProjection.add("_id")
        arrayProjection.add("name")
        arrayProjection.add("bracketType")
        arrayProjection.add("updatedOn")
        arrayProjection.add("maximumParticipants")
        val rootObject = JsonObject()
        rootObject.addProperty("page", page)
        rootObject.addProperty("limit", limit)
        rootObject.addProperty("sort", "-updatedOn")
        rootObject.add("projection", arrayProjection)
        jsonObjectForBracket.postValue(rootObject)
    }

    /**
     *@desc method will call when get success from API and pass data to UI
     */
    fun updateBracketUI(bracketData: BracketData) {
        updateBracketUI.postValue(bracketData)
    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
