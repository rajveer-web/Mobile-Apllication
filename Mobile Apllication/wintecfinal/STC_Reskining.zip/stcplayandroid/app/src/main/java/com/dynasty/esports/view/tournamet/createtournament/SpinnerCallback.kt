package com.dynasty.esports.view.tournamet.createtournament

import com.dynasty.esports.models.Spinner
import java.util.*

/**
 * @desc this is class will use for get Callback from Spinner
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
interface SpinnerCallback {
    abstract fun onDone(list: ArrayList<Spinner>)
}