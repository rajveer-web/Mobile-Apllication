package com.dynasty.esports.view.tournamet.tournamet_detail

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.models.TournamentDetailRes
import kotlinx.android.synthetic.main.row_overview_sponsor.view.*

class OverViewSponsorAdapter(var listOfSponsor: List<TournamentDetailRes.Sponsor>,
                             var listener: OnItemClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    var listOfSponsors : List<TournamentDetailRes.Sponsor>
    var listenerr : OnItemClickListener

    init {
        this.listOfSponsors = listOfSponsor
        this.listenerr = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SponsorDetailViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.row_overview_sponsor, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return listOfSponsors.size
    }

    class SponsorDetailViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(
            sponsorDetail: TournamentDetailRes.Sponsor,
            listenerr: OnItemClickListener
        ) {
            itemView.overview_sponsor_game_txt.text = sponsorDetail.sponsorName
            if(!sponsorDetail.website.isNullOrEmpty()) {
                itemView.overview_sponsor_visit_txt.beVisible()
                itemView.overview_sponsor_visit_txt.text = "Visit Us : " + sponsorDetail.website
            }


            Glide.with(itemView.context).load(sponsorDetail.sponsorLogo).into(itemView.participant_image)
            Glide.with(itemView.context).load(sponsorDetail.sponsorBanner).into(itemView.participant_gaming_image)
            if(!sponsorDetail.appStoreUrl.isNullOrEmpty()){
                itemView.participant_app_store_img.beVisible()
//                Glide.with(itemView.context).load(sponsorDetail.appStoreUrl).into(itemView.participant_app_store_img)
            }

            if(!sponsorDetail.playStoreUrl.isNullOrEmpty()){
                itemView.participant_play_store_img.beVisible()
//                Glide.with(itemView.context).load(sponsorDetail.playStoreUrl).into(itemView.participant_play_store_img)
            }

            itemView.participant_play_store_img.setOnClickListener {
                listenerr.onItemClick(sponsorDetail,"PlayStore")
            }

            itemView.participant_app_store_img.setOnClickListener {
                listenerr.onItemClick(sponsorDetail, "Appstore")
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(sponsor: TournamentDetailRes.Sponsor, clickEventName : String)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val gameViewHolder = viewHolder as SponsorDetailViewHolder
        gameViewHolder.bindView(listOfSponsors[position],listenerr)
    }


}