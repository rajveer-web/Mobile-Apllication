package com.dynasty.esports.view.inbox


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterReveiverMessageViewBinding
import com.dynasty.esports.databinding.AdapterSenderMessageViewBinding
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.InboxMessagesListModel

/**
 * @desc this is class will be use for display
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class InboxMessagesAdapter(
    private var inboxMessagesList: MutableList<InboxMessagesListModel.DataModel>,
    private var id: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    /**
     *@desc This ViewHolder should be constructed with a new View that can represent the items
     * of the given type.
     */
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            1 -> {
                val binding: AdapterSenderMessageViewBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_sender_message_view,
                        parent,
                        false
                    )
                return ViewHolderSender(binding)
            }
            else -> {
                val binding: AdapterReveiverMessageViewBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_reveiver_message_view,
                        parent,
                        false
                    )
                return ViewHolderReceiver(binding)
            }

        }

    }

    /**
     * @desc inbox messages array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return inboxMessagesList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * identify the type using sent by id and represent the item at position
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (inboxMessagesList[position].sentBy.toString() == id) {
            0
        } else {
            1
        }
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderReceiver).bind(inboxMessagesList[position])
            }
            else -> {
                (holder as ViewHolderSender).bind(inboxMessagesList[position])
            }
        }
    }

    /**
     *@desc This class will display sender message
     */
    inner class ViewHolderSender(private var binding: AdapterSenderMessageViewBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: InboxMessagesListModel.DataModel) {
            dataModel.senderDetails?.apply {
                binding.textViewSenderName.text =this.fullName?.let { it } ?: "-"
                this.profilePicture?.apply {
                    binding.root.context.loadImageFromServer(this,binding.imageViewSenderAvatar)
                }
            }
            binding.textViewMessage.text =dataModel.message?.let { it } ?: "-"
            binding.textViewSenderDate.text =dataModel.createdAt?.let { it.convertDateToRequireDateFormat(AppConstants.API_DATE_FORMAT,AppConstants.MM_DD_YYYY_HH_MM_FORMAT) } ?: "-"
        }

    }

    /**
     *@desc This class will display sender receiver
     */
    inner class ViewHolderReceiver(private var binding: AdapterReveiverMessageViewBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: InboxMessagesListModel.DataModel) {
            dataModel.senderDetails?.apply {
                binding.textViewReceiverName.text =this.fullName?.let { it } ?: "-"
                this.profilePicture?.apply {
                    binding.root.context.loadImageFromServer(this,binding.imageViewReceiverAvatar)
                }

            }

            binding.textViewMessage.text =dataModel.message?.let { it } ?: "-"
            binding.textViewReceiverDate.text =dataModel.createdAt?.let { it.convertDateToRequireDateFormat(AppConstants.API_DATE_FORMAT,AppConstants.MM_DD_YYYY_HH_MM_FORMAT) } ?: "-"
        }
    }

}