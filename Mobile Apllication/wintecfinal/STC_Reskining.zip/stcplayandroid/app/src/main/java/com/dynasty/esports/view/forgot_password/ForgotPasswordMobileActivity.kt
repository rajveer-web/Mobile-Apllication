package com.dynasty.esports.view.forgot_password

import android.os.Bundle
import androidx.lifecycle.Observer
import com.badoualy.stepperindicator.StepperIndicator
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.getFontTypeFace
import com.dynasty.esports.extenstion.runningActivities
import com.dynasty.esports.models.Country
import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.viewmodel.ForgotPasswordViewModel
import com.google.android.material.appbar.AppBarLayout
import kotlinx.android.synthetic.main.activity_create_tournament.*
import kotlinx.android.synthetic.main.activity_forgot_password_mobile.*
import kotlinx.android.synthetic.main.forgot_password_stepper.*
import kotlinx.android.synthetic.main.fragment_forgot_password_mobile.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will hold functions for user interaction
 * examples include initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class ForgotPasswordMobileActivity : BaseActivity(), CountryCodePicker.Listener,
    ForgotPasswordWizard {

    private val mViewModel: ForgotPasswordViewModel by viewModel()
    private var forgotPasswordReq: ForgotPasswordRequest? = null
    lateinit var pageAdapterForgotPassword: ForgotPasswordPagerAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password_mobile)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        setUpToolBar()
        initialise()
    }

    private fun setUpToolBar() {
        toolbarCrateTournament.title = ""
        setSupportActionBar(toolbarCrateTournament)
    }

    fun initialise() {
        collapsingToolbarCreateTournamen.setCollapsedTitleTypeface(this.getFontTypeFace(R.font.stc_forward_medium))
        appBarLayoutCreateTournament.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                Math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbarCreateTournamen.title = ""
                }
                else -> {
                    collapsingToolbarCreateTournamen.title = ""
                    // Expanded
                }
            }
        })

        forgotPasswordReq = ForgotPasswordRequest()

        pageAdapterForgotPassword =
            ForgotPasswordPagerAdapter(
                supportFragmentManager
            )

        forgotPasswordPager.adapter = pageAdapterForgotPassword
        forgotPasswordPager.beginFakeDrag()
        stepper_indicator.setViewPager(forgotPasswordPager, forgotPasswordPager.adapter!!.count)
        stepper_indicator.addOnStepClickListener(StepperIndicator.OnStepClickListener { step ->
            forgotPasswordPager.setCurrentItem(
                step,
                true
            )
        })


        mViewModel.btnNextClickObserver.observe(this, {
            //pager.setCurrentItem(pager.currentItem + 1, true)
            val currentPage: ForgotPasswordPageFragment =
                pageAdapterForgotPassword.getCurrentPage()!!
            currentPage.onNextButtonClick()
        })

        forgot_password_btn_next.click {
            mViewModel.btnNextClick()
        }


        /*   forgotPasswordPager?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
               override fun onPageScrollStateChanged(state: Int) {}

               override fun onPageScrolled(
                   position: Int,
                   positionOffset: Float,
                   positionOffsetPixels: Int
               ) {}

               override fun onPageSelected(position: Int) {}


               fun onInterceptTouchEvent(event: MotionEvent?): Boolean {
                   // Never allow swiping to switch between pages
                   return false
               }

               fun onTouchEvent(event: MotionEvent?): Boolean {
                   // Never allow swiping to switch between pages
                   return false
               }
           })*/
    }

    enum class ForgotPasswordWizardPageType(
        val index: Int, private val mTitleResId: Int
    ) {
        FORGOT_PASSWORD(0, R.string.forgot_passwrd_screen1),
        VERIFICATION(1, R.string.forgot_passwrd_screen2),
        CHANGE_PASSWORD(1, R.string.forgot_passwrd_screen3),
        SUCCEFUL_RESET(2, R.string.forgot_passwrd_screen4);

        companion object {
            fun enumForIndex(index: Int): ForgotPasswordWizardPageType? {
                for (page in ForgotPasswordWizardPageType.values()) {
                    if (page.index == index) {
                        return page
                    }
                }
                return null
            }
        }
    }

    override fun getCurrentPageType(): ForgotPasswordWizardPageType {
        val currentPageIndex: Int = forgotPasswordPager!!.currentItem
        return ForgotPasswordWizardPageType.enumForIndex(
            currentPageIndex
        )!!
    }

    override fun setNextButtonEnabled(enable: Boolean) {
    }

    override fun nextPage() {
        val currentPageIndex: Int = forgotPasswordPager!!.currentItem
        val currentPageType =
            ForgotPasswordWizardPageType.enumForIndex(
                currentPageIndex
            )
        val nextPageIndex = currentPageIndex + 1
        forgotPasswordPager!!.currentItem = nextPageIndex
        /*Toast.makeText(
            this,
            "Base Fragmet next button",
            Toast.LENGTH_SHORT
        ).show()*/
    }

    override fun createAPIRequest(stepperReq: ForgotPasswordRequest?) {

    }

    override fun senDataToVerificationFragment(mReq: ForgotPasswordRequest?) {
        val tag = "android:switcher:" + R.id.forgotPasswordPager.toString() + ":" + 1
        val f: VerificationFragment? =
            supportFragmentManager.findFragmentByTag(tag) as VerificationFragment?
        if (mReq != null) {
            forgotPasswordReq = mReq
            f?.displayReceivedData(mReq)
        }
    }

    override fun sendDataToChangePasswordFragment(mReq: ForgotPasswordRequest?) {
        val tag = "android:switcher:" + R.id.forgotPasswordPager.toString() + ":" + 2
        val f: ChangePasswordFragment? =
            supportFragmentManager.findFragmentByTag(tag) as ChangePasswordFragment?
        if (mReq != null) {
            forgotPasswordReq = mReq
            f?.displayReceivedData(mReq)
        }
    }

    override fun sendDataToSuccessfulFragment(mReq: ForgotPasswordRequest?) {
        val tag = "android:switcher:" + R.id.forgotPasswordPager.toString() + ":" + 3
        val f: SuccessfullyResetPasswordFragment? =
            supportFragmentManager.findFragmentByTag(tag) as SuccessfullyResetPasswordFragment?
        if (mReq != null) {
            forgotPasswordReq = mReq
            f?.displayReceivedData(mReq)
        }
    }

    override fun onCountryChosen(country: Country) {
        reset_country_code.setText("+".plus(country.phoneCode))
    }

    override fun onBackPressed() {
        if(forgotPasswordPager.currentItem == 3){
            forgotPasswordPager.setCurrentItem(2, true)
        }
        else if (forgotPasswordPager.currentItem == 2) {
            forgotPasswordPager.setCurrentItem(1, true)
        } else if (forgotPasswordPager.currentItem == 1) {
            forgotPasswordPager.setCurrentItem(0, true)
        } else if (forgotPasswordPager.currentItem == 0) {
            super.onBackPressed()
        }
    }
}