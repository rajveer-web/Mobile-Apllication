package com.dynasty.esports.constants

object AppConstants {
    val IMAGE_CODE = 196
    val TAKE_PHOTO = 197
    val PERMISSION_CODE = 198
    var API_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:SS.SSS'Z'"
    var APP_DATE_FORMAT = "dd MMM"
    var API_SUCCESS_CODE = 200
    var API_UNAUTHENTICATED_CODE = 401
    var API_CREATED_SUCCESS_CODE = 201
    var REFRESH_CODE = 199
    var REQUIRED_TIME_FORMAT = "dd MMM yyyy"
    var DD_MM_YYYY_FORMAT = "dd/MM/yyyy"
    var DD_MM_YYYY_HH_MM_FORMAT = "dd/MM/yyyy hh:mma"
    var MM_DD_YYYY_HH_MM_FORMAT = "MM/dd/yyyy hh:mma"
    var YYYY_MM_DD_T_HH_MM_FORMAT = "yyyy-MM-dd'T'hh:mma"
    var YYYY_MM_DD_FORMAT_API = "yyyy-MM-dd"
    var TIME_FORMAT_API = "hh:mma"
    var DATE_AND_TIME = "yyyy-MM-dd hh:mma"
    var DATE_AND_TIME_24 = "yyyy-MM-dd HH:mm"
    var DATE_AND_TIME_FORMATE = "dd MMM yyyy , hh:mm"
    var CONNECTION_ACTION="android.net.conn.CONNECTIVITY_CHANGE"
    var NOTIFY_ACTION="com.mesf.NOTIFY_ACTION"
    var NOTIFY_START_TYPING="com.notify.start.typing"
    var NOTIFY_STOP_TYPING="com.notify.stop.typing"
    var NOTIFY_RECEIVE_MESSAGE="com.notify.message"
}