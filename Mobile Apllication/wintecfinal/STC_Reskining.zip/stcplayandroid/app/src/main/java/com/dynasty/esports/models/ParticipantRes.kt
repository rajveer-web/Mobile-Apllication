package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class ParticipantRes {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: List<Any> = ArrayList()

    @SerializedName("totals")
    @Expose
    var totals: Totals? = null

    class Totals {
        @SerializedName("count")
        @Expose
        var count = 0
    }
}