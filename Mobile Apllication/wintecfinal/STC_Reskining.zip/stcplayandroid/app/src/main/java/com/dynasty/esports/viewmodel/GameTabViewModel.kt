package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class GameTabViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    val allGameSucessReponse = MutableLiveData<GamesModel>()

    fun getAllGamesTab() {
        viewModelScope.launch(apiException("all")) {
            val getPostGames = async { restInterface.getAllGamesTab() }
            allGameSucessReponse.postValue(getPostGames.await().body())
        }

    }

    /**
     * Clears the [ViewModel] when the [ArticlesFragment] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
