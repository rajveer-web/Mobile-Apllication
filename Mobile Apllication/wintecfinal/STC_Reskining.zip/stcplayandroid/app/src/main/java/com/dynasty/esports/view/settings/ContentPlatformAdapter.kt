package com.dynasty.esports.view.settings


import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterContentPlatformsBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.PlatformModel
import com.dynasty.esports.utils.BindingHolder
import com.google.android.material.button.MaterialButton

/**
 * @desc this is class handle platform view
 * @author : Mahesh Vayak
 * @created : 24-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ContentPlatformAdapter(
    private var platformList: MutableList<PlatformModel>,
    private var choosePlatform: MutableList<String>,
    private val onItemClick: (Int, String) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterContentPlatformsBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterContentPlatformsBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_content_platforms,
                parent,
                false
            )
        )

    }


    /**
     * @desc platform array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return platformList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterContentPlatformsBinding>,
        position: Int
    ) {

        if (choosePlatform.contains(platformList[position].key)) {
            selectPlatform(holder.binding.buttonPlatform, holder.itemView.context)
        } else {
            unSelectPlatform(holder.binding.buttonPlatform, holder.itemView.context)
        }


        holder.binding.buttonPlatform.setIconResource(platformList[position].icon)
        holder.binding.buttonPlatform.text = platformList[position].title
        holder.binding.buttonPlatform.click {
            onItemClick(holder.adapterPosition, platformList[holder.adapterPosition].key)
        }
    }

    /**
     *@desc method will call when platform select
     */
    private fun selectPlatform(
        buttonPlatform: MaterialButton,
        context: Context
    ) {
        buttonPlatform.strokeWidth = 0
        buttonPlatform.iconTint =
            ColorStateList.valueOf(ContextCompat.getColor(context, R.color.white))
        buttonPlatform.setTextColor(ContextCompat.getColor(context, R.color.white))
        buttonPlatform.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(
                context,
                R.color.background_color
            )
        )
    }

    /**
     *@desc method will call when platform un select
     */
    private fun unSelectPlatform(
        buttonPlatform: MaterialButton,
        context: Context
    ) {
        buttonPlatform.strokeWidth = 1
        buttonPlatform.iconTint =
            ColorStateList.valueOf(ContextCompat.getColor(context, R.color.color_gray_999))
        buttonPlatform.setTextColor(ContextCompat.getColor(context, R.color.color_gray_999))
        buttonPlatform.strokeColor =
            ColorStateList.valueOf(ContextCompat.getColor(context, R.color.color_gray_999))
        buttonPlatform.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(context, android.R.color.transparent))
    }

    /**
     *@desc method will use for update platform UI.
     */
    fun updateSelection(position: Int, key: String) {
        if (choosePlatform.contains(key)) {
            choosePlatform.remove(key)
        } else {
            choosePlatform.add(key)
        }
        notifyItemChanged(position)
    }


}