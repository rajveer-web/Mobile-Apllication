package com.dynasty.esports.models

data class TournamentOptionModel(
    val icon:Int,
    var selected:Int =0
)