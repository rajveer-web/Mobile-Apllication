package com.dynasty.esports.view.forgot_password

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.Country
import com.dynasty.esports.models.ForgotPasswordRequest
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.viewmodel.ForgotPasswordMobileFragmentViewModel
import kotlinx.android.synthetic.main.fragment_forgot_password_mobile.*
import org.koin.androidx.viewmodel.ext.android.viewModel


class ForgotPasswordFragment : ForgotPasswordPageFragment(), CountryCodePicker.Listener {

    private val mViewModel: ForgotPasswordMobileFragmentViewModel by viewModel()
    lateinit var mRequest: ForgotPasswordRequest
    var isPhoneNumField: Boolean = true

    override fun getPageType(): ForgotPasswordMobileActivity.ForgotPasswordWizardPageType {
        return ForgotPasswordMobileActivity.ForgotPasswordWizardPageType.FORGOT_PASSWORD
    }

    override fun onNextButtonClick() {
        launchProgressDialog()
        mViewModel.emailNPhonNotEmpty()
    }

    private fun cmmonFeatire() {
        mRequest.apply {
            if(!reset_phone_nos.text.toString().isNullOrEmpty()){
                this.phoneNumber = reset_country_code.text.toString().plus(reset_phone_nos.text.toString().removeZeroFormNumber())
            }else{
                this.email = reset_email.text.toString()
            }


            if (email.isNullOrEmpty()) {
                this.type = "phone"
            } else {
                this.type = "email"
            }
        }
        mViewModel.emailOrMobileNosVerification(mRequest)

    }

    override fun shouldEnableButton(): Boolean {
        TODO("Not yet implemented")
    }

    override fun onCreateView(
         inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_forgot_password_mobile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenToViewModel()
        initialise()
    }

    private fun listenToViewModel() {
        mViewModel.countryCodeObserver.observe(viewLifecycleOwner, {
            displayCountryCodeDialog()
        })

        mViewModel.redirectEmailForgotPasswordObserver.observe(viewLifecycleOwner, {
            if (forgot_email_btn.text == resources.getString(R.string.forgot_by_email)) {
                verfiy_phone_txt.setText(R.string.verify_email)
                outlinedEmailR.beVisible()
                forgot_email_btn.setText(R.string.forgot_by_phone)
                reset_phone_nos.text = null
                isPhoneNumField = false
                reset_country_code.text = null
                outlinedCodeR.beGone()
                outlinedPhoneNosR.beGone()
            } else {
                verfiy_phone_txt.setText(R.string.verify_phone_title)
                isPhoneNumField = true
                outlinedCodeR.beVisible()
                outlinedPhoneNosR.beVisible()
                forgot_email_btn.setText(R.string.forgot_by_email)
                reset_email.text = null
                outlinedEmailR.beGone()
            }
        })

        mViewModel.phoneOrEmailVerificationSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            it.string().getMessageFromObject("message").showToast(requireContext())
            mForgotPasswordWizard?.apply {
                this.senDataToVerificationFragment(mRequest)
                this.nextPage()
            }
        })

        mViewModel.phoneOrEmailVerificationErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            it.string().getMessageFromObject("message").showToast(requireContext())
        })

        mViewModel.emailPhoneNotEmptyObserver.observe(viewLifecycleOwner, {
            if (isPhoneNumField) {
                if (reset_country_code.text.isNullOrEmpty()) {
                    dismissProgressDialog()
                    Toast.makeText(
                        context,
                        resources.getString(R.string.mobile_code_error),
                        Toast.LENGTH_SHORT
                    ).show()
                } else if (reset_phone_nos.text.isNullOrEmpty()) {
                    dismissProgressDialog()
                    Toast.makeText(
                        context,
                        resources.getString(R.string.mobile_number_error),
                        Toast.LENGTH_SHORT
                    ).show()
                }else if (reset_country_code.text.toString() =="+966" && reset_phone_nos.text.toString().checkPhoneValid()) {
                    dismissProgressDialog()
                    Toast.makeText(
                        context,
                        resources.getString(R.string.mobile_number_not_valid_error),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    cmmonFeatire()
                }
            } else {
                if (reset_email.text.isNullOrEmpty()) {
                    dismissProgressDialog()
                    Toast.makeText(
                        context,
                        resources.getString(R.string.email_error),
                        Toast.LENGTH_SHORT
                    ).show()
                } else if (!reset_email.text.toString().isEmailValid()) {
                    dismissProgressDialog()
                    Toast.makeText(
                        context,
                        resources.getString(R.string.email_valid_error),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    cmmonFeatire()
                }
            }
        })
    }

    private fun initialise() {
        mRequest = ForgotPasswordRequest()
        reset_country_code.click {
            mViewModel.countryCodeClick()
        }
        forgot_email_btn.click {
            mViewModel.redirectEmailForgotPassword()
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            ForgotPasswordFragment()
    }

    override fun onCountryChosen(country: Country) {
        reset_country_code.setText("+".plus(country.phoneCode))
    }
}