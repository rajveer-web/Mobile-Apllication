package com.dynasty.esports.view.article.article_section

import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.constants.ArticleConstant.CONST_LATEST_NEWS
import com.dynasty.esports.constants.ArticleConstant.CONST_LATEST_VIDEO
import com.dynasty.esports.constants.ArticleConstant.CONST_POST_BY_AUTHOR
import com.dynasty.esports.constants.ArticleConstant.CONST_POST_BY_GAMES
import com.dynasty.esports.constants.ArticleConstant.CONST_LATEST_ARTICLE
import com.dynasty.esports.constants.ArticleConstant.CONST_TRENDING_POST
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CustomArticleModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.article.article_detail.ArticlesDetailActivity
import com.dynasty.esports.view.article.view_all_article.ViewAllArticlesActivity
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.ArticleViewModel
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*

import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will use for show different types of article categories
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ArticlesFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    private var articleList: MutableList<CustomArticleModel> = mutableListOf()  // define article list
    private lateinit var articlesAdapter: ArticlesAdapter // define article adapter
    private val mViewModel: ArticleViewModel by viewModel() // inject article view model class
    private var connectivityReceiver = ConnectivityReceiver() // initialize connection receiver

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_articles, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
        Set up Article data adapter
         */
        articleList.clear()
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        commonRecyclerView.isNestedScrollingEnabled=false
        commonRecyclerView.setHasFixedSize(true)
//        recyclerViewVideo.layoutManager = LinearLayoutManager(requireContext())
//        recyclerViewVideo.isNestedScrollingEnabled=false
//        recyclerViewVideo.setHasFixedSize(true)
        articlesAdapter = ArticlesAdapter(
            articleList,
            onItemClick = ::onItemClick,
            onViewAllItemClick = ::onViewAllItemClick,
            onVideoClick = ::onVideoClick
        )
        commonRecyclerView.adapter = articlesAdapter


//        articleVideoAdapter = ArticleVideoAdapter(
//            articleVideoList,onItemClick = ::onVideoClick
//        )
//        recyclerViewVideo.adapter=articleVideoAdapter
        listenToViewModel()


    }

    /**
     * @desc listen observer and observer that will receive the events
     * Also, Manage API success and failure,Internet and un authorization.
     */
    private fun listenToViewModel() {
        // make json for Article data api.
        mViewModel.makeJsonForArticleData.observe(viewLifecycleOwner, {
            mViewModel.getAllArticles(it.first.first.toString(),it.first.second.toString(),
                it.second.first.first.toString(),it.second.first.second.first.toString(),it.second.first.second.second.toString(),it.second.second.first.toString())
        })

        mViewModel.articleDataResponse.observe(viewLifecycleOwner, {
            it?.second?.second?.second?.second?.data?.apply {
                if (this.isNotEmpty()) {
                    //    articleVideoList.addAll(this)
                    articleList.add(
                        CustomArticleModel(
                            CONST_TRENDING_POST,
                            title = resources.getString(R.string.latest),
                            trendingPostList = this
                        )
                    )
//
//                    Handler().postDelayed({
//                        articleVideoAdapter.notifyDataSetChanged()
//                    },300)
                }
            }

            it?.first?.data?.docs?.apply {
                if (this.isNotEmpty()) {
                    articleList.add(
                        CustomArticleModel(
                            CONST_LATEST_ARTICLE,
                            title = resources.getString(R.string.latest_article),
                            latestArticleList = this
                        )
                    )
                }
            }

            it?.second?.second?.first?.data?.apply {
                if (this.isNotEmpty()) {
                    articleList.add(
                        CustomArticleModel(
                            CONST_POST_BY_GAMES,
                            title = resources.getString(R.string.post_by_games),
                            gamesList = this
                        )
                    )
                }
            }

            it?.second?.second?.second?.first?.data?.docs?.apply {
                if (this.isNotEmpty()) {
                //    articleVideoList.addAll(this)
                    articleList.add(
                        CustomArticleModel(
                            CONST_LATEST_VIDEO,
                            title = resources.getString(R.string.latest_videos_title),
                            latestViewPostList = this
                        )
                    )
//
//                    Handler().postDelayed({
//                        articleVideoAdapter.notifyDataSetChanged()
//                    },300)
                }
            }
            it?.second?.first?.data?.docs?.apply {
                if (this.isNotEmpty()) {
                    articleList.add(
                        CustomArticleModel(
                            CONST_LATEST_NEWS,
                            title = resources.getString(R.string.latest_news),
                            newsList = this
                        )
                    )

                }
            }
            articlesAdapter.notifyDataSetChanged()
            linearLayoutProgressBar.beGone()

        })
//        // Get all trending article response
//        mViewModel.articleTrendingResponse.observe(viewLifecycleOwner, Observer {
//
//        })

        // Get all article author response
//        mViewModel.articleAuthorResponse.observe(viewLifecycleOwner, Observer {
//            it?.data?.apply {
//                if (this.isNotEmpty()) {
//                    articleList.add(
//                        CustomArticleModel(
//                            CONST_POST_BY_AUTHOR,
//                            title = resources.getString(R.string.posts_by_authors_title),
//                            postByAuthorList = this
//                        )
//                    )
//                    articlesAdapter.notifyDataSetChanged()
//                }
//            }
//            linearLayoutProgressBar.beGone()
//        })

        // Get all Post by games response
//        mViewModel.articlePostByGamesResponse.observe(viewLifecycleOwner, Observer {
//            it?.data?.apply {
//                if (this.isNotEmpty()) {
//                    articleList.add(
//                        CustomArticleModel(
//                            CONST_POST_BY_GAMES,
//                            title = resources.getString(R.string.post_by_games),
//                            gamesList = this
//                        )
//                    )
//                    articlesAdapter.notifyDataSetChanged()
//                }
//            }
//            linearLayoutProgressBar.beGone()
//
//        })

        // Get all trending article response
//        mViewModel.latestVideoResponse.observe(viewLifecycleOwner, Observer {
//            it?.data?.docs?.apply {
//                if (this.isNotEmpty()) {
//                    articleList.add(
//                        CustomArticleModel(
//                            CONST_LATEST_VIDEO,
//                            title = resources.getString(R.string.latest_videos_title),
//                            latestViewPostList = this
//                        )
//                    )
//                    articlesAdapter.notifyDataSetChanged()
//                }
//            }
//
//            linearLayoutProgressBar.beGone()
//        })

        // Managed no internet and 500 error
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            if(!requireActivity().isOnline()){
                constraintLayoutErrorView.beGone()
                constraintLayoutNoInternet.beVisible()
                linearLayoutProgressBar.beGone()
                commonRecyclerView.beGone()
            }else{
                constraintLayoutErrorView.beVisible()
                constraintLayoutNoInternet.beGone()
                linearLayoutProgressBar.beGone()
                commonRecyclerView.beGone()
            }
          //  resources.getString(R.string.no_internet_message).showToast(requireContext())
        })
    }


    /**
     * @desc method will call when tap on view all from article adapter and redirect to view all article screen
     * @param type article type
     * @param title article title
     */
    private fun onViewAllItemClick(type: Int, title: String) {
        if(type==CONST_LATEST_VIDEO){
            startActivityFromFragment<ViewAllVideoActivity>()
        }else {
            val bundle = Bundle()
            bundle.putInt("type", type)
            bundle.putString("title", title)
            startActivityFromFragment<ViewAllArticlesActivity>(bundle)
        }
    }

    /**
     * @desc method will call when tap on article from article adapter and redirect to different screen
     * @param type article type
     * @param id article id
     * @param title article title
     */
    fun onItemClick(type: Int, id: Any, title: String) {
        when (type) {
            CONST_TRENDING_POST, CONST_LATEST_ARTICLE, CONST_LATEST_NEWS->{
                val bundle = Bundle()
                bundle.putString("id", id.toString())
                startActivityFromFragment<ArticlesDetailActivity>(bundle)
            }

            CONST_POST_BY_AUTHOR -> {
                val bundle = Bundle()
                bundle.putString("id", id.toString())
                bundle.putBoolean("isGame", false)
                bundle.putString("title", title)
                bundle.putInt("type", CONST_LATEST_ARTICLE)
                startActivityFromFragment<ViewAllArticlesActivity>(bundle)
            }
            CONST_POST_BY_GAMES -> {
                val bundle = Bundle()
                bundle.putString("id", id.toString())
                bundle.putBoolean("isGame", true)
                bundle.putString("title", title)
                bundle.putInt("type", CONST_LATEST_ARTICLE)
                startActivityFromFragment<ViewAllArticlesActivity>(bundle)
            }
        }

    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }


    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc method will call when tap on video article from article adapter and redirect to youtube
     * @param url article video url
     */
    private fun onVideoClick(url: String) {
        val videoClient = Intent(Intent.ACTION_VIEW)
        videoClient.data = Uri.parse(url)
        requireActivity().startActivity(videoClient)
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && articleList.isNullOrEmpty()) {
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            linearLayoutProgressBar.beVisible()
            commonRecyclerView.beVisible()
            mViewModel.makeJsonForVideoParameter()
        } else if (articleList.isNullOrEmpty()) {
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beVisible()
            linearLayoutProgressBar.beGone()
            commonRecyclerView.beGone()
        }
    }
}

