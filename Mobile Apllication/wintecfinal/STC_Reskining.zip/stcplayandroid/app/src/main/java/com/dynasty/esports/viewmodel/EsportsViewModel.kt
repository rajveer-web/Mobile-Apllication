package com.dynasty.esports.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.debugE
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.extenstion.parseTime
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.*
import okhttp3.ResponseBody
import retrofit2.HttpException
import java.net.ConnectException
import java.net.UnknownHostException
import java.util.*

class EsportsViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {

    val createTournamentObservable = MutableLiveData<Boolean>()

    val fetchUpcomingTournamentSuccessResponse = MutableLiveData<TournamentListRes>()
    val fetchUpcomingTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val fetchOngoingTournamentSuccessResponse = MutableLiveData<TournamentListRes>()
    val fetchOngoingTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val fetchGameFilterTournamentSuccessResponse = MutableLiveData<TournamentListRes>()
    val fetchGameFilterTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val jsonObjectForUpcomingTournament = MutableLiveData<Pair<JsonObject, JsonObject>>()
    val jsonObjectForOngoingTournament = MutableLiveData<Pair<JsonObject, JsonObject>>()
    val jsonObjectForGameFilterTournament = MutableLiveData<Pair<JsonObject, JsonObject>>()

    val jsonObjectallTournament = MutableLiveData<AllTournamentJson>()


    val gameListSuccessResponse = MutableLiveData<TournamentGameRes>()
    val gameListErrorResponse = MutableLiveData<ResponseBody>()
    val esportsbannerErrorResponse = MutableLiveData<ResponseBody>()
    val esportsbannerSuccessResponse= MutableLiveData<TournamentListRes>()

//    fun getAllTournamentList(
//        upComingQuery: String,
//        onGoingQuery: String,
//        pagignation: String,
//        type: String
//    ) {
//        viewModelScope.launch(apiException("all")) {
//            val fetchUpcomingResponce = async {
//                restInterface.fetchAllCreatedTournamentPastAndOngoing(
//                    upComingQuery,
//                    pagignation
//                )
//            }
//            val fetchOngoingResponce = async {
//                restInterface.fetchAllCreatedTournamentPastAndOngoing(
//                    onGoingQuery,
//                    pagignation
//                )
//            }
//            val gameListResponce = async { restInterface.getTournamentGameList() }
//
//            if (fetchUpcomingResponce.await().code() == AppConstants.API_SUCCESS_CODE) {
//                fetchUpcomingTournamentSuccessResponse.postValue(
//                    fetchUpcomingResponce.await().body()
//                )
//            } else {
//                fetchUpcomingTournamentErrorResponse.postValue(
//                    fetchUpcomingResponce.await().errorBody()
//                )
//            }
//
//            if (fetchOngoingResponce.await().code() == AppConstants.API_SUCCESS_CODE) {
//                fetchOngoingTournamentSuccessResponse.postValue(
//                    fetchOngoingResponce.await().body()
//                )
//            } else {
//                fetchOngoingTournamentErrorResponse.postValue(
//                    fetchOngoingResponce.await().errorBody()
//                )
//            }
//
//            if (gameListResponce.await().code() == AppConstants.API_SUCCESS_CODE) {
//                gameListSuccessResponse.postValue(
//                    gameListResponce.await().body()
//                )
//            } else {
//                gameListErrorResponse.postValue(gameListResponce.await().errorBody())
//            }
//        }
//    }

//    fun fetchUpcomingTournament(query: String, pagignation: String, type: String) {
//        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
//            when (response.code()) {
//                AppConstants.API_SUCCESS_CODE -> {
//                    fetchUpcomingTournamentSuccessResponse.postValue(response.body())
//                }
//                AppConstants.API_UNAUTHENTICATED_CODE -> {
//                    unAuthorizationException.postValue(true)
//                }
//                else -> {
//                    fetchUpcomingTournamentErrorResponse.postValue(response.errorBody())
//                }
//            }
//        }
//    }

//    fun fetchOngoingTournament(query: String, pagignation: String, type: String) {
//        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
//            when (response.code()) {
//                AppConstants.API_SUCCESS_CODE -> {
//                    fetchOngoingTournamentSuccessResponse.postValue(response.body())
//                }
//                AppConstants.API_UNAUTHENTICATED_CODE -> {
//                    unAuthorizationException.postValue(true)
//                }
//                else -> {
//                    fetchOngoingTournamentErrorResponse.postValue(response.errorBody())
//                }
//            }
//        }
//    }

    fun fetchGameList(type: String) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
            val response = restInterface.getTournamentGameList()
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gameListSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    gameListErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun fetchOngoingTournament(status: String, sort: String, type: String,
                               page: Int,
                               limit: Int) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
            val response = restInterface.getAllTournament(status, sort,page,limit)
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchOngoingTournamentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchOngoingTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun fetchUpcomingTournament(
        status: String, sort: String, type: String,
        page: Int,
        limit: Int
    ) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getAllTournament(status, sort, page, limit)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchUpcomingTournamentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchUpcomingTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun fetchOngoingGameFilter(status: String, sort: String, gameId: String, type: String,page: Int,limit: Int) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getFilterByGameTournament(status, sort, gameId,page,limit)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchGameFilterTournamentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchGameFilterTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun makeJsonForFetchAllTournamentAndGameList(
        page: Int,
        limit: Int
    ) {

        val pagignation = JsonObject()
        pagignation.addProperty("page", page)
        pagignation.addProperty("limit", limit)
        pagignation.addProperty("sort", "startDate")
//        pagignation.add("projection", arrayProjection)

        val upComing = JsonObject()
        val jarray: JsonArray = JsonArray()

        val isSeededObj: JsonObject = JsonObject()
        isSeededObj.addProperty("isSeeded", false)

        val isFinishedObj: JsonObject = JsonObject()
        isFinishedObj.addProperty("isFinished", false)

        val tournamentStatusObj: JsonObject = JsonObject()
        tournamentStatusObj.addProperty("tournamentStatus", "publish")

        val startDateObj = JsonObject()
        val startDateObj_ = JsonObject()
        startDateObj_.addProperty("\$gt", parseTime(Date().time, AppConstants.API_DATE_FORMAT))
        startDateObj.add("startDate", startDateObj_)

        jarray.add(startDateObj)
        jarray.add(isSeededObj)
        jarray.add(isFinishedObj)
        jarray.add(tournamentStatusObj)


        upComing.add("\$and", jarray)

        val rootOngoingObject = JsonObject()
        val jarrayOngoing: JsonArray = JsonArray()

        val isSeededObjOngoing: JsonObject = JsonObject()
        isSeededObjOngoing.addProperty("isSeeded", true)

        val tournamentStatusObjOngoing: JsonObject = JsonObject()
        tournamentStatusObjOngoing.addProperty("tournamentStatus", "publish")

        val startDateObjOngoing = JsonObject()
        val startDateObjOngoing_ = JsonObject()
        startDateObjOngoing_.addProperty(
            "\$lt",
            parseTime(Date().time, AppConstants.API_DATE_FORMAT)
        )
        startDateObjOngoing.add("startDate", startDateObjOngoing_)

        jarrayOngoing.add(startDateObjOngoing)
        jarrayOngoing.add(isSeededObjOngoing)
        jarrayOngoing.add(tournamentStatusObjOngoing)


        rootOngoingObject.add("\$or", jarrayOngoing)

        debugE("upComing £", Gson().toJson(upComing))

        jsonObjectallTournament.postValue(
            AllTournamentJson(
                upComing,
                rootOngoingObject,
                pagignation
            )
        )
    }

    fun makeJsonForUpcomingTournament(
        page: Int,
        limit: Int,
        isFinished: Boolean,
        isSeeded: Boolean
    ) {
        val pagignation = JsonObject()
        pagignation.addProperty("page", page)
        pagignation.addProperty("limit", limit)
        pagignation.addProperty("sort", "startDate")
//        pagignation.add("projection", arrayProjection)

        val rootObject = JsonObject()
        val jarray: JsonArray = JsonArray()

        val isSeededObj: JsonObject = JsonObject()
        isSeededObj.addProperty("isSeeded", isSeeded)

        val isFinishedObj: JsonObject = JsonObject()
        isFinishedObj.addProperty("isFinished", isFinished)

        val tournamentStatusObj: JsonObject = JsonObject()
        tournamentStatusObj.addProperty("tournamentStatus", "publish")

        val startDateObj = JsonObject()
        val startDateObj_ = JsonObject()
        startDateObj_.addProperty("\$gt", parseTime(Date().time, AppConstants.API_DATE_FORMAT))
        startDateObj.add("startDate", startDateObj_)

        jarray.add(startDateObj)
        jarray.add(isSeededObj)
        jarray.add(isFinishedObj)
        jarray.add(tournamentStatusObj)


        rootObject.add("\$and", jarray)

        debugE("rootObject £", Gson().toJson(rootObject))

        jsonObjectForUpcomingTournament.postValue(Pair(rootObject, pagignation))


    }

    fun makeJsonForGameFilterTournament(
        page: Int,
        limit: Int,
        isFinished: Boolean,
        isSeeded: Boolean,
        gameId: String
    ) {
        val pagignation = JsonObject()
        pagignation.addProperty("page", page)
        pagignation.addProperty("limit", limit)
        pagignation.addProperty("sort", "startDate")
//        pagignation.add("projection", arrayProjection)

        val rootObject = JsonObject()

        val jarray: JsonArray = JsonArray()

        val isSeededObj: JsonObject = JsonObject()
        isSeededObj.addProperty("isSeeded", isSeeded)

        val isFinishedObj: JsonObject = JsonObject()
        isFinishedObj.addProperty("isFinished", isFinished)

        val tournamentStatusObj: JsonObject = JsonObject()
        tournamentStatusObj.addProperty("tournamentStatus", "publish")

        val startDateObj = JsonObject()
        val startDateObj_ = JsonObject()
        startDateObj_.addProperty("\$gt", parseTime(Date().time, AppConstants.API_DATE_FORMAT))
        startDateObj.add("startDate", startDateObj_)

        jarray.add(startDateObj)
        jarray.add(isSeededObj)
        jarray.add(isFinishedObj)
        jarray.add(tournamentStatusObj)


//        rootObject.add("\$and", jarray)
        if (!gameId.isFieldEmpty()) {
            rootObject.addProperty("gameDetail", gameId)
        }

        debugE("rootObject £", Gson().toJson(rootObject))

        jsonObjectForGameFilterTournament.postValue(Pair(rootObject, pagignation))
    }

    fun makeJsonForOngoingTournament(
        page: Int,
        limit: Int,
        isSeeded: Boolean
    ) {


        val pagignation = JsonObject()
        pagignation.addProperty("page", page)
        pagignation.addProperty("limit", limit)
        pagignation.addProperty("sort", "startDate")
//        pagignation.add("projection", arrayProjection)

        val rootOngoingObject = JsonObject()
        val jarrayOngoing: JsonArray = JsonArray()

        val isSeededObjOngoing: JsonObject = JsonObject()
        isSeededObjOngoing.addProperty("isSeeded", isSeeded)

        val tournamentStatusObjOngoing: JsonObject = JsonObject()
        tournamentStatusObjOngoing.addProperty("tournamentStatus", "publish")

        val startDateObjOngoing = JsonObject()
        val startDateObjOngoing_ = JsonObject()
        startDateObjOngoing_.addProperty(
            "\$lt",
            parseTime(Date().time, AppConstants.API_DATE_FORMAT)
        )
        startDateObjOngoing.add("startDate", startDateObjOngoing_)

        jarrayOngoing.add(startDateObjOngoing)
        jarrayOngoing.add(isSeededObjOngoing)
        jarrayOngoing.add(tournamentStatusObjOngoing)


        rootOngoingObject.add("\$or", jarrayOngoing)
//        rootObject.addProperty("isSeeded", isSeeded)
//        if(!isUpcoming){
//        rootObject.addProperty("isFinished", isFinished)
//        rootObject.addProperty("tournamentStatus", "publish")
//        }

        debugE("rootObject £", Gson().toJson(rootOngoingObject))
        debugE("pagignation £", Gson().toJson(pagignation))

        jsonObjectForOngoingTournament.postValue(Pair(rootOngoingObject, pagignation))


    }

    fun createTournmentClick() {
        createTournamentObservable.postValue(true)
    }

    fun esportsGetBanner(status: String, limit: String, sort: String,){
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getEsportsBanner(status,limit, sort)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    esportsbannerSuccessResponse.postValue(response.body())
                }
                else -> {
                    esportsbannerErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * Clears the [ViewModel] when the [SignInActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }
}
