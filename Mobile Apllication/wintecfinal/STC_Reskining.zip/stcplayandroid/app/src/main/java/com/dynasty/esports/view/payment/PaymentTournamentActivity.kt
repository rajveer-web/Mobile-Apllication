package com.dynasty.esports.view.payment

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.TextView
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CreateTournament
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.tournamet.createtournament.SponsorListAdapter
import com.dynasty.esports.viewmodel.PublishTournamentViewModel
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_payment_tournament.*
import kotlinx.android.synthetic.main.activity_publish_tournament.*
import org.koin.androidx.viewmodel.ext.android.viewModel

open class PaymentTournamentActivity : BaseActivity() {

    private val mViewModel: PublishTournamentViewModel by viewModel()

    private lateinit var sponsorListAdapter: SponsorListAdapter

    private var loginUserModel: UserModel.UserData? = null

    private lateinit var createTournamentSaved: CreateTournament

    private var totalPrize = 0
    private var totalAmt = 0
    private var platformFee = 0
    private var tournamentId: String = ""
    private var createdName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_tournament)
        initIntentParams()
        initialize()
        listenToViewModel()
        fillData()
    }

    private fun initIntentParams() {
        try {
            if (intent.extras != null) {
                if (intent.extras!!.containsKey("tournamentId")) {
                    tournamentId = intent.getStringExtra("tournamentId")
                }
                if (intent.extras!!.containsKey("name")) {
                    createdName = intent.getStringExtra("name")!!
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initialize() {

//        get logindata from sharedPreferences
        loginUserModel =
            sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData


//      get createTournamentSaved data from sharedPreferences
        createTournamentSaved = sharedPreferences.get<CreateTournament>("createTournamentSave")!!

        btnPayWithPaypal.click {
            val bundle = Bundle()
            bundle.putString(
                "paymentLink",
                "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=EC-3J615036U31704534"
            )
            startActivityInline<PaypalActivity>(bundle)
        }

        btnSaveAsDraft.click {
            launchProgressDialog()
            debugE("jsonObject £", Gson().toJson(getJsonForApi()))
            mViewModel.createTournament(getJsonForApi(), tournamentId)
        }
    }

    private fun listenToViewModel() {
//      createTournamentSuccessResponse 
        mViewModel.createTournamentSuccessResponse.observe(this, Observer {
            debugE("createTournamentPublishResponse", Gson().toJson(it))
            showPublishSuccessDialog(it.message!!, false)
        })

//      createTournamentErrorResponse
        mViewModel.createTournamentErrorResponse.observe(this, Observer {
            debugE("createTournamentPublishErrorResponse", it.string())
            try {
                showPublishSuccessDialog("", true)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            dismissProgressDialog()
        })
    }

    //  Set data to each field from saved data
    private fun fillData() {




//        tvPaymentFirstPrice.text =
//            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.firstPrize.toString()
//        tvPaymentSecondPrice.text =
//            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.secondPrize.toString()
//        tvPaymentThirdPrice.text =
//            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.thirdPrize.toString()

        if (createTournamentSaved.prizeList.isNotEmpty()) {
            for (i in 0 until createTournamentSaved.prizeList.size) {
                when (i) {
                    0 -> {
                        tvPaymentFirstPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    1 -> {
                        tvPaymentSecondPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    2 -> {
                        tvPaymentThirdPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    3 -> {
                        llFourthprize.visibility = View.VISIBLE
                        tvPaymentFourthPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    4 -> {
                        llFifthprize.visibility = View.VISIBLE
                        tvPaymentFifthPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                    5 -> {
                        llSixthprize.visibility = View.VISIBLE
                        tvPaymentSixthPrice.text =
                            createTournamentSaved.prizeCurrency + " " + createTournamentSaved.prizeList[i].value.toString()
                    }
                }
            }
        }
//        totalPrize =
//            createTournamentSaved.firstPrize + createTournamentSaved.secondPrize + createTournamentSaved.thirdPrize

        for (i in 0 until createTournamentSaved.prizeList.size) {
            totalPrize += createTournamentSaved.prizeList[i].value
        }
//        tvConsolationPrice.text = ""

        platformFee = totalPrize * 20 / 100
        totalAmt = totalPrize + platformFee

        tvPaymentPriceAmount.text = nullSafeNA(createTournamentSaved.prizeCurrency).plus(" ")
            .plus(nullSafeNA(totalPrize.toString())).plus("/-")
        tvPlatformFees.text = nullSafeNA(createTournamentSaved.prizeCurrency).plus(" ")
            .plus(nullSafeNA(platformFee.toString())).plus("/-")
        tvPaymentTotalAmt.text =
            nullSafeNA(createTournamentSaved.prizeCurrency).plus(" ")
                .plus(nullSafeNA(totalAmt.toString())).plus("/-")
    }

    //   Create Json for send in api
    private fun getJsonForApi(): JsonObject {
        val dateTime = mergeDateAndTime(
            createTournamentSaved.startDate.plus('T')
                .plus(createTournamentSaved.startTime), "yyyy-MM-dd'T'hh:mma"
        )
        val jsonObject = JsonObject()
        jsonObject.addProperty("name", createTournamentSaved.name)
        jsonObject.addProperty("url", createTournamentSaved.url)
        jsonObject.addProperty("participantType", createTournamentSaved.participantType)
        jsonObject.addProperty("startDate", dateTime)
        jsonObject.addProperty("startTime", createTournamentSaved.startTime)
        jsonObject.addProperty("isPaid", createTournamentSaved.isPaid)
        jsonObject.addProperty("description", createTournamentSaved.description)
        jsonObject.addProperty("rules", createTournamentSaved.rules)
        jsonObject.addProperty("criticalRules", createTournamentSaved.criticalRules)
        jsonObject.addProperty("isPrize", createTournamentSaved.isPrize)
        jsonObject.addProperty("faqs", createTournamentSaved.faqs)
        jsonObject.addProperty("schedule", createTournamentSaved.schedule)
        jsonObject.addProperty("isIncludeSponsor", createTournamentSaved.isIncludeSponsor)
        jsonObject.addProperty("tournamentType", createTournamentSaved.tournamentType)
        jsonObject.addProperty("isScreenshotRequired", createTournamentSaved.isScreenshotRequired)
        jsonObject.addProperty("isShowCountryFlag", createTournamentSaved.isShowCountryFlag)
        jsonObject.addProperty("allowSubstituteMember", createTournamentSaved.isallowSubstituteMember)
        jsonObject.addProperty("substituteMemberSize", createTournamentSaved.substituteMemberSize)


        jsonObject.addProperty(
            "isSpecifyAllowedRegions",
            createTournamentSaved.isSpecifyAllowedRegions
        )
        jsonObject.addProperty("isParticipantsLimit", createTournamentSaved.isParticipantsLimit)
        jsonObject.addProperty("scoreReporting", createTournamentSaved.scoreReporting)
        jsonObject.addProperty("invitationLink", createTournamentSaved.invitationLink)
        jsonObject.addProperty("youtubeVideoLink", createTournamentSaved.youtubeVideoLink)
        jsonObject.addProperty("facebookVideoLink", createTournamentSaved.facebookVideoLink)
        jsonObject.addProperty("contactDetails", createTournamentSaved.contactDetails)
        jsonObject.addProperty("twitchVideoLink", createTournamentSaved.twitchVideoLink)
        jsonObject.addProperty("visibility", createTournamentSaved.visibility)
        jsonObject.addProperty("checkInEndDate", createTournamentSaved.checkInEndDate)
        jsonObject.addProperty("banner", createTournamentSaved.banner)
        jsonObject.addProperty("maxParticipants", createTournamentSaved.maxParticipants)
        jsonObject.addProperty("bracketType", createTournamentSaved.bracketType)
        jsonObject.addProperty("noOfSet", createTournamentSaved.noOfSet)
        jsonObject.addProperty("contactOn", createTournamentSaved.contactOn)
        jsonObject.addProperty("gameDetail", createTournamentSaved.gameDetail)
        if (createTournamentSaved.participantType.equals("team", true)) {
            jsonObject.addProperty("teamSize", createTournamentSaved.teamSize)
        } else {
//            jsonObject.addProperty("teamSize", "0")
        }
        jsonObject.addProperty("firstPrize", createTournamentSaved.firstPrize)
        jsonObject.addProperty("secondPrize", createTournamentSaved.secondPrize)
        jsonObject.addProperty("thirdPrize", createTournamentSaved.thirdPrize)
        jsonObject.addProperty("prizeCurrency", createTournamentSaved.prizeCurrency)
        jsonObject.addProperty("slug", createTournamentSaved.name)
//        draft & submitted_for_approval
        jsonObject.addProperty("tournamentStatus", "draft")
        jsonObject.addProperty("organizerDetail", loginUserModel!!.id)
        jsonObject.addProperty("updatedBy", loginUserModel!!.id)
        jsonObject.addProperty("createdBy", loginUserModel!!.id)
        jsonObject.addProperty("checkInStartDate", createTournamentSaved.checkInStartDate)

        val prizeList = JsonArray()

        for (i in createTournamentSaved.prizeList) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("name", i.name)
            jsonObject.addProperty("value", i.value)
            prizeList.add(jsonObject)
        }
        jsonObject.add("prizeList", prizeList)
//      Get the data from createTournamentSaved and prepare json for send api
        val venueAddressList = JsonArray()

        if (createTournamentSaved.tournamentType.equals("offline", false)) {
            if (createTournamentSaved.venueAddress.isNotEmpty()) {
                for (i in createTournamentSaved.venueAddress) {
                    val jsonObject = JsonObject()
                    jsonObject.addProperty("country", i.country)
                    jsonObject.addProperty("region", i.region)
                    jsonObject.addProperty("venue", i.venue)
                    jsonObject.addProperty("stage", i.stage)
                    venueAddressList.add(jsonObject)
                }
            }
        } else if (createTournamentSaved.tournamentType.equals("hybrid", false)) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("country", createTournamentSaved.venueAddressHybrid.country)
            jsonObject.addProperty("region", createTournamentSaved.venueAddressHybrid.region)
            jsonObject.addProperty("venue", createTournamentSaved.venueAddressHybrid.venue)
            jsonObject.addProperty("stage", createTournamentSaved.venueAddressHybrid.stage)
            venueAddressList.add(jsonObject)
        }

        val sponsorsList = JsonArray()

        for (i in createTournamentSaved.sponsors) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("sponsorName", i.sponsorName)
            jsonObject.addProperty("website", i.website)
            jsonObject.addProperty("playStoreUrl", i.playStoreUrl)
            jsonObject.addProperty("appStoreUrl", i.appStoreUrl)
            jsonObject.addProperty("sponsorLogo", i.sponsorLogo)
            jsonObject.addProperty("sponsorBanner", i.sponsorBanner)
            sponsorsList.add(jsonObject)
        }

        val participantsList = JsonArray()

        for (i in createTournamentSaved.participants) {
            val jsonObjectpart = JsonObject()
            jsonObjectpart.addProperty("_id", i.id)
            jsonObjectpart.addProperty("fullName", i.fullName)
            jsonObjectpart.addProperty("phoneNumber", i.phoneNumber)
            jsonObjectpart.addProperty("email", i.email)
            jsonObjectpart.addProperty("profilePicture", i.profilePicture)
            participantsList.add(jsonObjectpart)
        }

        val regList = JsonArray()

        for (i in createTournamentSaved.regionsAllowed) {
            regList.add(i)
        }

        if (venueAddressList.size() != 0) {
            jsonObject.add("venueAddress", venueAddressList)
        }
        if (sponsorsList.size() != 0) {
            jsonObject.add("sponsors", sponsorsList)
        }
//        if (participantsList.size() != 0) {
        jsonObject.add("participants", participantsList)
//        }
        if (regList.size() != 0) {
            jsonObject.add("regionsAllowed", regList)
        }

        return jsonObject
    }

    //  Clears the [ViewModel] when the [PublishTournamentViewModel] is not visible to user.
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc method will use for show success and failure dialog for join tournament
     */
    private fun showPublishSuccessDialog(messageFromObject: String, isFail: Boolean) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.dialog_join_success_view)
        val tvJoinSuccess = dialog.findViewById(R.id.tvJoinSuccess) as TextView
        val tvJoinSuccessTitle = dialog.findViewById(R.id.tvJoinSuccessTitle) as TextView
        val tvJoinSuccessFail = dialog.findViewById(R.id.tvJoinSuccessFail) as TextView

        if (isFail) {
            if (!messageFromObject.isFieldEmpty()) {
                tvJoinSuccessTitle.text = messageFromObject
            } else {
                tvJoinSuccessTitle.text = resources.getString(R.string.some_thing_went_wrong)
            }
            tvJoinSuccessFail.beGone()
        } else {
            tvJoinSuccessTitle.text = resources.getString(R.string.published_successfully)
            tvJoinSuccessFail.text =
                resources.getString(R.string.tournament_publish_success)
        }

        tvJoinSuccess.click {
            dialog.dismiss()
            if (!isFail) {
                sharedPreferences.clearPreference("createTournamentSave")
                dismissProgressDialog()
                startActivityInlineWithFinishAll<DashboardActivity>()
            }
        }
        dialog.show()
    }
}