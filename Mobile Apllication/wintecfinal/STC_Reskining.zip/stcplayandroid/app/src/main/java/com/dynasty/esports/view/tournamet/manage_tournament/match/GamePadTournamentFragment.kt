package com.dynasty.esports.view.tournamet.manage_tournament.match

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.SimpleItemAnimator
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.models.CustomGameRoundModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.ManagedTournamentViewModel
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel


class GamePadTournamentFragment : BaseFragment(),
    ConnectivityReceiver.ConnectivityReceiverListener {
    private lateinit var gamePadTournamentAdapter: GamePadTournamentAdapter
    private var roundList: MutableList<CustomGameRoundModel> = mutableListOf()
    private var connectivityReceiver = ConnectivityReceiver()
    val mViewModel: ManagedTournamentViewModel by viewModel()
    var position: Int = 0

    private var id: String = ""
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_match, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            id = this.getString("id").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        linearLayoutProgressBar.beGone()
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        (commonRecyclerView.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
        gamePadTournamentAdapter =
            GamePadTournamentAdapter(roundList, onItemClick = ::onItemClick)
        commonRecyclerView.adapter = gamePadTournamentAdapter



        listenToViewModel()
    }

    private fun onItemClick(round: Int, pos: Int) {
        position = pos
        mViewModel.makeJsonForMatchRoundDetail(id, round)
    }

    private fun listenToViewModel() {
        mViewModel.jsonObjectForGetMatchRoundDetail.observe(viewLifecycleOwner, {
            if (roundList[position].detailList.isNullOrEmpty()) {
                launchProgressDialog()
                mViewModel.getMatchRoundDetail(
                    it.toString(),
                    "sets,totalSet,matchNo,winnerTeam,loserTeam,teamBWinSet,teamAWinSet"
                )
            }
        })

        mViewModel.jsonObjectForGetMatchRound.observe(viewLifecycleOwner, {
            mViewModel.getMatchRound(it.toString())
        })

        mViewModel.gameRoundSuccessResponse.observe(viewLifecycleOwner, {
            roundList.clear()
            linearLayoutProgressBar.beGone()
            it.data?.apply {
                this.forEach {
                    roundList.add(CustomGameRoundModel(it))
                }
                gamePadTournamentAdapter.notifyDataSetChanged()
            }

            if (roundList.isNullOrEmpty()) {
                constraintLayoutNoData.beVisible()
                commonRecyclerView.beGone()
                textViewNoData.text = resources.getString(R.string.match_not_available)
            }
        })

        mViewModel.gameRoundErrorResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
        })

        mViewModel.gameRoundDetailSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            it.data?.apply {
                roundList[position].detailList.addAll(this)
            }
            gamePadTournamentAdapter.notifyItemChanged(position)
        })

        mViewModel.gameRoundDetailErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner,{
            dismissProgressDialog()
            linearLayoutProgressBar.beGone()
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    companion object {
        fun newInstance(id: String, tournamentType: String): Fragment {
            val args = Bundle()
            args.putString("tournamentType", tournamentType)
            args.putString("id", id)
            val fragment = GamePadTournamentFragment()
            fragment.arguments = args
            return fragment
        }
    }


    // Register receiver for check internet connection
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    // Unregister receiver for internet connection
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }


    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && roundList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoData.beGone()
            constraintLayoutNoInternet.beGone()
            mViewModel.makeJsonForMatchRound(id)
        }
    }
}