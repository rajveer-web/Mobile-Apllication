package com.dynasty.esports.view.tournamet.createtournament

import android.content.IntentFilter
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.CommonPagerAdapter
import kotlinx.android.synthetic.main.fragment_transaction_history.*

class CreatedTournamentProfileFragment : BaseFragment() ,  ManageRedirectReceiver.NotifyActivityListener {

    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
    private var type: String = ""
    private var manageRedirectReceiver = ManageRedirectReceiver()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_transaction_history, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            type = this.getString("type").toString()
        }
        LocalBroadcastManager.getInstance(requireContext())
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (type == "joined") {
            textViewTitle.text = resources.getString(R.string.joined_tournaments)
        } else {
            textViewTitle.text = resources.getString(R.string.created_tournaments)
        }
        initView()
    }

    private fun initView() {
        fragmentList.clear()
        fragmentList.add(
            Pair(OnGoingAndPastFragment.newInstance("upcoming", type), resources.getString(R.string.upcoming))
        )
        fragmentList.add(
            Pair(OnGoingAndPastFragment.newInstance("ongoing", type), resources.getString(R.string.str_ongoing))
        )
        fragmentList.add(
            Pair(
                OnGoingAndPastFragment.newInstance("past", type),
                resources.getString(R.string.str_past)
            )
        )

        viewPagerTransaction?.apply {
            commonPagerAdapter = CommonPagerAdapter(fragmentList, childFragmentManager)
            this.adapter = commonPagerAdapter
            tabLayoutTransaction?.setupWithViewPager(this)
            this.offscreenPageLimit = 3
        }
    }

    override fun onNotify(notifyType: String) {
        if(notifyType=="past"){
            initView()
        }
    }


    // Prevent to API call from view model
    override fun onDestroy() {
        super.onDestroy()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(requireContext()).unregisterReceiver(this)
        }
    }


}