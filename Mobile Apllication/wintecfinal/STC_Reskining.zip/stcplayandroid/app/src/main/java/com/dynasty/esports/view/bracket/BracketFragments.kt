package com.dynasty.esports.view.bracket

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.isOnline
import com.dynasty.esports.models.Docs
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.utils.RecyclerViewLoadMoreScroll
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.BracketViewModel
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this is class will show bracket list
 * @author : Mahesh Vayak
 * @created : 27-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BracketFragments : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    private val mViewModel: BracketViewModel by viewModel() // inject bracket viewmodel
    lateinit var bracketAdapter: BracketAdapter
    private lateinit var layoutManager: LinearLayoutManager
    var page = 1
    var limit = 8
    private var isLoadedAllItems: Boolean = false
    private var bracketList: MutableList<Docs> = mutableListOf() // define bracket list
    private lateinit var scrollListener: RecyclerViewLoadMoreScroll
    private var connectivityReceiver = ConnectivityReceiver() // define connectivity receiver
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_bracket, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        listenToViewModel()
    }

    /**
     * @desc Initialize view and assign bracket adapter to recyclerview
     */
    private fun initView() {
        layoutManager = LinearLayoutManager(requireActivity())
        commonRecyclerView.layoutManager = layoutManager
        bracketAdapter = BracketAdapter(bracketList)
        commonRecyclerView.adapter = bracketAdapter
        scrollListener = RecyclerViewLoadMoreScroll(layoutManager)
        setLoadMoreListener()
    }

    /**
     * @desc Identify need to load more data or not.
     */
    private fun setLoadMoreListener() {
        scrollListener.setOnLoadMoreListener(object :
            RecyclerViewLoadMoreScroll.OnLoadMoreListener {
            override fun onLoadMore() {
                if (!isLoadedAllItems) {
                    onLoadMoreBracket()
                }
            }
        })
        commonRecyclerView.addOnScrollListener(scrollListener)
    }

    /**
     * @desc remove dummy view in array list and show progress bar
     */
    private fun onLoadMoreBracket() {
        val model = Docs()
        model.isLoadMore = true
        bracketList.add(model)
        commonRecyclerView.post {
            bracketAdapter.apply {
                notifyItemInserted(bracketList.size - 1)
            }
            mViewModel.makeJsonForBracket(page, limit)
        }
    }

    /**
     * @desc remove dummy view from array list and hide progress bar
     */
    private fun stopLoadMore() {
        scrollListener.setLoaded()
        bracketList.removeAt(bracketList.size-1)
        commonRecyclerView.post {
            bracketAdapter.apply {
                notifyDataSetChanged()
            }
        }

    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make jsonobject for API and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.jsonObjectForBracket.observe(viewLifecycleOwner, Observer {
            mViewModel.fetchBracketData(it)
        })
        mViewModel.bracketSuccessResponse.observe(viewLifecycleOwner, Observer {
            mViewModel.updateBracketUI(it)
        })
        mViewModel.bracketErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
        })
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            if (requireActivity().isOnline()) {
                if (!bracketList.isNullOrEmpty()) {
                    displayCustomAlertDialog(
                        resources.getString(R.string.something_wrong_try_again),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.retry),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForBracket(page, limit)
                        })
                }
            } else {
                if (!bracketList.isNullOrEmpty()) {
                    displayCustomAlertDialog(
                        resources.getString(R.string.no_internet_message),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.retry),
                        positiveClick = {
                            it.dismiss()
                            mViewModel.makeJsonForBracket(page, limit)
                        })
                }
            }
        })
        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it) {
                mViewModel.onDetach()
                logOut()
            }
        })
        mViewModel.updateBracketUI.observe(viewLifecycleOwner, Observer {
            // bracketData = it
            linearLayoutProgressBar.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()

            it?.data?.apply {

                if (!bracketList.isNullOrEmpty()) {
                    stopLoadMore()
                }
                if (!this.hasNextPage!!) {
                    isLoadedAllItems = true
                }

                this.docsList.apply {
                    bracketList.addAll(this)
                }
                if (page == 1 && bracketList.isEmpty()) {
                    constraintLayoutNoData.beVisible()
                    commonRecyclerView.beGone()
                } else {
                    bracketAdapter.notifyDataSetChanged()
                    this@BracketFragments.page += 1
                }
            }

        })
    }


    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc UnRegister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && bracketList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beGone()
            constraintLayoutErrorView.beGone()
            mViewModel.makeJsonForBracket(page, limit)
        } else if (bracketList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutErrorView.beGone()
        }
    }

}