package com.dynasty.esports.view.profile

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.SimpleItemAnimator
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ProfileModel
import com.dynasty.esports.models.SubProfileOptionModel
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.signin.email.EmailSignInActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.ChatViewModel
import com.dynasty.esports.viewmodel.CommonViewModel
import kotlinx.android.synthetic.main.nav_header.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import zendesk.core.AnonymousIdentity
import zendesk.core.Identity
import zendesk.core.Zendesk
import zendesk.messaging.MessagingActivity
import zendesk.support.Support
import zendesk.support.SupportEngine


class PrrofileActivity : BaseActivity(), ManageRedirectReceiver.NotifyActivityListener  {

    private lateinit var profileOptionAdapter: ProfileOptionAdapter
    private var profileOptionList: MutableList<ProfileModel> = mutableListOf()
    private var manageRedirectReceiver = ManageRedirectReceiver()
    val commonViewModel: CommonViewModel by viewModel()
    val chatViewModel: ChatViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_profile)

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)

        commonRecyclerView.layoutManager = LinearLayoutManager(this)
        initView()

        Zendesk.INSTANCE.init(
            this,
            "https://intigral.zendesk.com",
            "eb281f4c84f89fc2eaa0ecafeab0c64fface11c130e30309",
            "mobile_sdk_client_7a55e85b98f52e125135"
        )

        val identity: Identity = AnonymousIdentity()
        Zendesk.INSTANCE.setIdentity(identity)

        Support.INSTANCE.init(Zendesk.INSTANCE)
    }


    private fun initView() {

        /*val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.main_nav_host) as NavHostFragment
        navController = navHostFragment.navController*/
        commonViewModel.fetchUser()

        drawer_close.click {
            finish()
        }

        drawer_signup.click {
            finish()
            startActivityInline<EmailSignInActivity>()
        }

        drawer_create_acct.click {
            finish()
            startActivityInline<PhoneNumRegistrationActivity>()
        }


//        val subProfileLanguage: MutableList<SubProfileOptionModel> = mutableListOf()
//
//        subProfileLanguage.add(
//            SubProfileOptionModel(
//                "language",
//                resources.getString(R.string.english)
//            )
//        )
//        subProfileLanguage.add(
//            SubProfileOptionModel(
//                "language",
//                resources.getString(R.string.arabic)
//            )
//        )



        if (!sharedPreferences.checkUserLoggedInOrNot()) {
            leftlayout.beGone()
          //  relativeLayoutRight.beGone()
            centerLayout.beVisible()
            profileOptionList.clear()

            if(LocaleHelper.getLanguage(this)!="en"){
                profileOptionList.add(
                    ProfileModel(
                        resources.getString(R.string.english)
                    )
                )
            }else{
                profileOptionList.add(
                    ProfileModel(
                        resources.getString(R.string.arabic)
                    )
                )
            }

//            profileOptionList.add(
//                ProfileModel(
//                    resources.getString(R.string.language),
//                    isExpandable = true,
//                    expandListData = subProfileLanguage
//                )
//            )
            profileOptionList.add(ProfileModel(resources.getString(R.string.lbl_support)))
        }
        else {
            centerLayout?.apply {
                centerLayout.beGone()
            }
            leftlayout?.apply {
                leftlayout.beVisible()
            }
            relativeLayoutRight?.apply {
              //  relativeLayoutRight.beGone()
            }


            val subProfileTournament: MutableList<SubProfileOptionModel> = mutableListOf()
            subProfileTournament.add(
                SubProfileOptionModel(
                    "tournament",
                    resources.getString(R.string.joined_tournaments)
                )
            )
            subProfileTournament.add(
                SubProfileOptionModel(
                    "tournament",
                    resources.getString(R.string.created_tournaments)
                )
            )
            profileOptionList.clear()
            profileOptionList.add(ProfileModel(resources.getString(R.string.basic_info)))
            if(LocaleHelper.getLanguage(this)!="en"){
                profileOptionList.add(
                    ProfileModel(
                        resources.getString(R.string.english)
                    )
                )
            }else{
                profileOptionList.add(
                    ProfileModel(
                        resources.getString(R.string.arabic)
                    )
                )
            }
            profileOptionList.add(ProfileModel(resources.getString(R.string.settings)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_bracket)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.my_tournament),
                    isExpandable = true,
                    expandListData = subProfileTournament,
                    drawable = ResourcesCompat.getDrawable(
                        this.resources,
                        R.drawable.ic_baseline_arrow_right_24,
                        null
                    )
                )
            )
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_transactions)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_bookmark)))

            profileOptionList.add(ProfileModel(resources.getString(R.string.inbox)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.lbl_support)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.logout)))

            listenToPref()


        }

        commonRecyclerView?.apply {
            (commonRecyclerView.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
            profileOptionAdapter = ProfileOptionAdapter(
                profileOptionList,
                onItemClick = ::onProfileItemClick,
                onSubItemClick = ::onSubItemClick
            )
            commonRecyclerView.adapter = profileOptionAdapter
            listenToViewModel()
        }

    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make json object for API and un authorization.
     */
    private fun listenToViewModel() {

        commonViewModel.userSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            it?.apply {
                sharedPreferences.id = this.data?.id.toString()
                sharedPreferences.put("user", this.data)
                listenToPref()
            }
        })

        commonViewModel.logOutSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            sharedPreferences.clear()
            sharedPreferences.isAppOpenFirstTime = true
            sendFlag(1)
//            DashboardActivity.navController.navigate(R.id.homeFragment)
        })
        commonViewModel.logOutErrorResponse.observe(this, Observer {

            dismissProgressDialog()
            displayCustomAlertDialog(title = resources.getString(R.string.some_thing_went_wrong),
                isCancelable = true,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })

        chatViewModel.makeJsonObjectForChatLogOut.observe(this, {
            chatViewModel.chatLogout(it)
        })
    }

    /**
     * @desc This method for listen shared preference data and display data
     */
    private fun listenToPref() {
        val data = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        data.apply {
            tvusersmall?.let {
                it.text = this.fullName?.let { it } ?: ""
            }

          /*  tvuseremail?.let {
                if (this.emailisVerified) {
                    it.beVisible()
                    it.text = this.email?.let { it } ?: ""
                } else {
                    it.beGone()
                }
            }
*/
           /* imageViewInfluencer?.let {
                this.isInfluencer?.apply {
                    if (this == 0) {
                        it.beVisible()
                        textViewInfluencer.beVisible()
                    } else {
                        it.beGone()
                        textViewInfluencer.beGone()
                    }
                }
            }*/


            imageViewVerify?.let {
                this.isVerified?.apply {
                    if (this == 0) {
//                        it.borderWidth = 6
                        imageViewVerify.beVisible()
                    } else {
//                        it.borderWidth = 0
                        imageViewVerify.beGone()
                    }
                }
            }

           /* tvorganizerrate?.let {
                this.organizerRating?.apply {
                    if (this.toInt() == 0) {
                        it.beGone()
                        rating.beGone()
                    } else {
                        rating.rating = this.toFloat()
                    }
                }
            }*/

            textViewPoint?.let {

                this.accountDetail?.apply {
                    textViewPoint.text = this.reward?.let { it.toString() } ?: "0"
                }
            }

            textViewfollower?.let {
                if(this.preference!=null){
                    textViewfollower.text = this.preference.followersCount?.let { it.toString() } ?: "0"
                    textViewFollowing.text = this.preference.followingCount?.let { it.toString() } ?: "0"
                }else{
                    textViewfollower.text="0"
                    textViewFollowing.text="0"
                }

            }

//            textViewFollowing?.let {
//                this.preference?.apply {
//                    textViewFollowing.text = this.followingCount?.let { it.toString() } ?: "0"
//                }
//            }


            imageViewUser?.let {
                this.profilePicture?.apply {
                    loadImageFromServer(this, it)
                }
            }

           /* textViewUserName?.let {
                it.text = this.fullName?.let { it } ?: ""
            }*/

        }

    }

    /**
     * @desc This method will call when tap sub items of sub items
     * @param position - sub item position
     * @param type - sub item type
     */
    private fun onSubItemClick(position: Int, type: String) {
        when (position) {
            0 -> {
                if (type == "tournament") {
                    sendFlag(8)
                }
//                else if (type == "language") {
//                    sendFlag(9)
//                }
            }
            1 -> {
                if (type == "tournament") {
                    sendFlag(10)
                }
//                else if (type == "language") {
//                    sendFlag(11)
//                }
            }
        }
    }

    private fun launchChangeLanguageDialog(language: String) {
        displayCustomAlertDialog(
            resources.getString(R.string.language),
            resources.getString(R.string.language_change_msg),
            true,
            positiveText = resources.getString(R.string.yes),
            negativeText = resources.getString(R.string.no),
            positiveClick = {
                it.dismiss()
                LocaleHelper.setLocale(this, language)
                startActivityInlineWithFinishAll<DashboardActivity>()
            },
            negativeClick = {
                it.dismiss()
            })
    }

    /**
     * @desc This method will call when tap on profile item
     * @param position - profile option position
     */
    private fun onProfileItemClick(position: Int) {
        when (position) {
            0 -> {
                if (!sharedPreferences.checkUserLoggedInOrNot()) {
                    if (LocaleHelper.getLanguage(this) == "en") {
                        launchChangeLanguageDialog("ar")
                    } else {
                        launchChangeLanguageDialog("en")
                    }
                } else {
                    sendFlag(0)
                }
            }
            1 -> {
                if (sharedPreferences.checkUserLoggedInOrNot()) {
                    if (LocaleHelper.getLanguage(this) == "en") {
                        launchChangeLanguageDialog("ar")
                    } else {
                        launchChangeLanguageDialog("en")
                    }
                } else {
                    MessagingActivity.builder()
                        .withEngines(SupportEngine.engine())
                        .show(this)
                }
            }
            3 -> {
                profileOptionAdapter.expandView(position)
            }
            2 -> {
                sendFlag(2)
            }
            4 -> {
                sendFlag(4)
            }
            5 -> {
                sendFlag(5)
            }
            6 -> {
                sendFlag(6)
            }
            7 -> {
                sendFlag(7)
            }
            8 -> {
                MessagingActivity.builder()
                    .withEngines(SupportEngine.engine())
                    .show(this)

//                val requestActivityIntent = RequestActivity.builder()
//                    .withRequestSubject("")
//                    .withTags("sdk", "android")
//                    .intent(this)
//                startActivity(requestActivityIntent)
//                .builder().show(this)
            }
            9 -> {
                displayCustomAlertDialog(title = resources.getString(R.string.logout),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.yes),
                    negativeText = resources.getString(R.string.str_cancel),
                    negativeClick = {
                        it.dismiss()
                    },
                    positiveClick = {
                        it.dismiss()
                        launchProgressDialog()
                        chatViewModel.makeJsonForChatLogOut(sharedPreferences.chatRefreshToken)
                        commonViewModel.logoutUser("true", sharedPreferences.refreshToken)

                    })
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(baseContext).unregisterReceiver(this)
        }
    }

    override fun onNotify(notifyType: String) {
        if (notifyType == "profile") {
            initView()
        }
    }

    fun sendFlag(flag: Int){
        val intent= Intent()
        intent.putExtra("flag", flag)
        setResult(1010, intent)
        finish()
    }
/*
    companion object {
        lateinit var navController: NavController
    }*/
}