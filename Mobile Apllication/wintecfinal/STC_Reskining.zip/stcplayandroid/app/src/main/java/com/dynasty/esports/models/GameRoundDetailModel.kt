package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class GameRoundDetailModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    class DataModel{
        @SerializedName("teamA")
        @Expose
         val teamA: TeamModel? = null

        @SerializedName("teamB")
        @Expose
         val teamB: TeamModel? = null

        @SerializedName("matchNo")
        @Expose
         val matchNo: Int? = null

        @SerializedName("loserTeam")
        @Expose
         val loserTeam: TeamModel? = null

        @SerializedName("winnerTeam")
        @Expose
         val winnerTeam: TeamModel? = null

        @SerializedName("sets")
        @Expose
         val sets: MutableList<SetModel>? = null

        @SerializedName("totalSet")
        @Expose
         val totalSet: Int? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("teamBWinSet")
        @Expose
        val teamBWinSet: Int? = null

        @SerializedName("teamAWinSet")
        @Expose
        val teamAWinSet: Int? = null

    }

    class TeamModel{
        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("logo")
        @Expose
         val logo: String? = null

        @SerializedName("teamName")
        @Expose
         val name: String? = null
    }
    
    class SetModel{
        @SerializedName("id")
        @Expose
         val id: Int? = null

        @SerializedName("teamAScore")
        @Expose
         val teamAScore: Int? = null

        @SerializedName("teamBScore")
        @Expose
         val teamBScore: Int? = null

        @SerializedName("winner")
        @Expose
         val winner: String? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("teamAScreenShot")
        @Expose
         val teamAScreenShot: Any? = null

        @SerializedName("teamBScreenShot")
        @Expose
         val teamBScreenShot: Any? = null

        @SerializedName("teamBWinSet")
        @Expose
        val teamBWinSet: Int? = null

        @SerializedName("teamAWinSet")
        @Expose
        val teamAWinSet: Int? = null

    }
}