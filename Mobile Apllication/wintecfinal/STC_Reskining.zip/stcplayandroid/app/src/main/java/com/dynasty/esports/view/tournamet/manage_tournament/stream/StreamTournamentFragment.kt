package com.dynasty.esports.view.tournamet.manage_tournament.stream

import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.observe
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ManageTournamentModel
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.StreamViewModel
import kotlinx.android.synthetic.main.fragment_tournament_stream.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class StreamTournamentFragment : BaseFragment() {
    private lateinit var streamTournamentAdapter: StreamTournamentAdapter
    private val mViewModel: StreamViewModel by viewModel()
    private var streamList: ArrayList<ManageTournamentModel.StreamModel> = arrayListOf()
    private var type: String = ""

    private var id: String = ""
    private var currentPosition: Int =0
    private var isEdit: Boolean = false
    private var tournamentType: String = ""
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_tournament_stream, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.apply {
            streamList.clear()
            streamList.addAll(this.getParcelableArrayList("stream")!!)
            id = this.getString("id").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerViewStream.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewStream.isNestedScrollingEnabled = false
        streamTournamentAdapter = StreamTournamentAdapter(
            streamList,
            onItemClick = ::onItemClick,
            onDeleteItemClick = ::onDeleteClick,
            onEditItemClick = ::onEditClick
        )
        recyclerViewStream.adapter = streamTournamentAdapter
        viewClickListener()
        listenToViewModel()
    }

    private fun onEditClick(position: Int) {
        currentPosition=position
        isEdit = true
        textViewAddNewStream.text = ""
        constraintLayoutAddStream.beVisible()
        buttonAddStream.beGone()
        nestedScrollViewStream.post {
            nestedScrollViewStream.smoothScrollTo(0, constraintLayoutAddStream.bottom)
        }
        editTextProvider.setText(streamList[position].videoUrl?.providerName)
        editTextChannel.setText(streamList[position].videoUrl?.channelName)
        editTextTitle.setText(streamList[position].title)
        editTextDescription.setText(streamList[position].description)
    }

    private fun onDeleteClick(position: Int) {
        displayCustomAlertDialog(resources.getString(R.string.delete_stream),
            desc = resources.getString(R.string.delete_stream_msg),
            isCancelable = true,
            positiveText = resources.getString(R.string.confirm), positiveClick = {
                it.dismiss()
                streamList.removeAt(position)
                mViewModel.makeJsonObjectForPostStream(streamList)
            }, negativeText = resources.getString(R.string.str_cancel), negativeClick = {
                it.dismiss()
            })
    }

    private fun onItemClick(url: String) {
        val bundle = Bundle()
        bundle.putString("url", url)
        startActivityFromFragment<ViewTournamentVideoActivity>(bundle)
    }

    private fun listenToViewModel() {

        mViewModel.arrayListForProvider.observe(viewLifecycleOwner, {
            mViewModel.updateSpinnerValueAndUI(it)
        })

        mViewModel.updateSpinnerItem.observe(viewLifecycleOwner, {
            requireActivity().showSpinner(
                resources.getString(R.string.choose_provider),
                editTextProvider,
                it, false, onItemClick = {
                    val data = it as Spinner
                    type = data.ID
                }
            )
        })

        mViewModel.validationLiveData.observe(viewLifecycleOwner, {
            when (it) {
                0 -> {
                    requireActivity().makeSnackBar(
                        constraintLayoutStream,
                        resources.getString(R.string.please_choose_provider)
                    )
                }
                1 -> {
                    requireActivity().makeSnackBar(
                        constraintLayoutStream,
                        resources.getString(R.string.enter_channel_name)
                    )
                }
                2 -> {
                    requireActivity().makeSnackBar(
                        constraintLayoutStream,
                        resources.getString(R.string.enter_title_msg)
                    )
                }
                else -> {
                    requireActivity().makeSnackBar(
                        constraintLayoutStream,
                        resources.getString(R.string.enter_description_msg)
                    )
                }
            }
        })

        mViewModel.isFormValid.observe(viewLifecycleOwner, {
            if (!isEdit) {
                val tempStream = ManageTournamentModel.StreamModel()

                val videoUrlModel= ManageTournamentModel.VideoUrlModel()
                videoUrlModel.channelName=editTextChannel.text.toString()
                videoUrlModel.providerName=editTextProvider.text.toString()
                tempStream.videoUrl=videoUrlModel
                tempStream.title = editTextTitle.text.toString()
                tempStream.description = editTextDescription.text.toString()
                tempStream.type = type
                streamList.add(0,tempStream)
            } else {
                val tempStream = ManageTournamentModel.StreamModel()
                val videoUrlModel= ManageTournamentModel.VideoUrlModel()
                videoUrlModel.channelName=editTextChannel.text.toString()
                videoUrlModel.providerName=editTextProvider.text.toString()
                tempStream.videoUrl=videoUrlModel
                tempStream.title = editTextTitle.text.toString()
                tempStream.description = editTextDescription.text.toString()
                tempStream.type = type
                streamList[currentPosition] = tempStream
            }

            mViewModel.makeJsonObjectForPostStream(streamList)
        })

        mViewModel.jsonObjectForPublishStream.observe(viewLifecycleOwner, {
            it?.apply {
                if (!this.isJsonNull) {
                    launchProgressDialog()
                    mViewModel.publishStream(id, it)
                }
            }
        })

        mViewModel.publishStreamSuccessResponse.observe(viewLifecycleOwner, {
            mViewModel.makeJsonForGetTournament(id)
        })

        mViewModel.jsonObjectForGetTournament.observe(viewLifecycleOwner, {
            mViewModel.getTournamentDetail(it)
        })

        mViewModel.tournamentDetailSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            constraintLayoutAddStream.beGone()
            buttonAddStream.beVisible()
            editTextProvider.setText("")
            editTextTitle.setText("")
            editTextChannel.setText("")
            editTextDescription.setText("")
            it?.data?.get(0)?.apply {
                streamList.clear()
                streamList.addAll(this.stream!!)
                streamTournamentAdapter.notifyDataSetChanged()
            }
        })

        mViewModel.tournamentDetailErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })

        mViewModel.publishStreamErrorResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, {
            dismissProgressDialog()
        })
    }

    private fun viewClickListener() {
        buttonAddStream.click {
            isEdit = false
            editTextProvider.setText("")
            editTextChannel.setText("")
            editTextTitle.setText("")
            editTextDescription.setText("")

            constraintLayoutAddStream.beVisible()
            buttonAddStream.beGone()
        }

        buttonCancel.click {
            constraintLayoutAddStream.beGone()
            buttonAddStream.beVisible()
        }

        buttonPublish.click {
            mViewModel.onValidationForForm(
                editTextProvider.text.toString().trim(),
                editTextChannel.text.toString().trim(),
                editTextTitle.text.toString().trim(),
                editTextDescription.text.toString().trim()
            )
        }
        editTextProvider.click {
            mViewModel.makeArrayListForProvider(streamList)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    companion object {
        fun newInstance(
            id: String,
            streamList: MutableList<ManageTournamentModel.StreamModel>,
            tournamentType: String
        ): Fragment {
            val args = Bundle()
            args.putString("tournamentType", tournamentType)
            args.putString("id", id)
            args.putParcelableArrayList("stream", ArrayList<Parcelable>(streamList))
            val fragment = StreamTournamentFragment()
            fragment.arguments = args
            return fragment
        }
    }
}