package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class CheckTeamNameModel {
    @SerializedName("message")
    @Expose
    var message: String = ""

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: List<Any> = ArrayList()

    @SerializedName("totals")
    @Expose
    var totals: Totals = Totals()

    class Totals {
        @SerializedName("count")
        @Expose
        var count = 0
    }
}