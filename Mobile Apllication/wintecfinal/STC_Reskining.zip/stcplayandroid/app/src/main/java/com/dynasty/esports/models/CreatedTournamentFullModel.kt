package com.dynasty.esports.models

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


class CreatedTournamentFullModel {

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: Data? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    class Data {
        @SerializedName("docs")
        @Expose
        var docs: List<Doc> = ArrayList<Doc>()

        @SerializedName("totalDocs")
        @Expose
        var totalDocs = 0

        @SerializedName("limit")
        @Expose
        var limit = 0

        @SerializedName("totalPages")
        @Expose
        var totalPages = 0

        @SerializedName("page")
        @Expose
        var page = 0

        @SerializedName("pagingCounter")
        @Expose
        var pagingCounter = 0

        @SerializedName("hasPrevPage")
        @Expose
        var hasPrevPage = false

        @SerializedName("hasNextPage")
        @Expose
        var hasNextPage = false

        @SerializedName("prevPage")
        @Expose
        var prevPage: Any? = null

        @SerializedName("nextPage")
        @Expose
        var nextPage = 0
    }

    @Parcelize
    class Doc : Parcelable {
        @SerializedName("participants")
        @Expose
        var participants: List<String> = ArrayList()

        @SerializedName("isSeeded")
        @Expose
        var isSeeded = false

        @SerializedName("regionsAllowed")
        @Expose
        var regionsAllowed: List<String> = ArrayList()

        @SerializedName("sponsors")
        @Expose
        var sponsors: List<Sponsor> = ArrayList()

        @SerializedName("status")
        @Expose
        var status: String? = null

        @SerializedName("venueAddress")
        @Expose
        var venueAddress: List<VenueAddress> = ArrayList<VenueAddress>()

        @SerializedName("stream")
        @Expose
        var stream: List<Stream> = ArrayList<Stream>()

        @SerializedName("isFinished")
        @Expose
        var isFinished = false

        @SerializedName("rating")
        @Expose
        var rating = 0

        @SerializedName("changeRequest")
        @Expose
        var changeRequest: Any? = null

        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("url")
        @Expose
        var url: String? = null

        @SerializedName("participantType")
        @Expose
        var participantType: String? = null

        @SerializedName("startDate")
        @Expose
        var startDate: String? = null

        @SerializedName("startTime")
        @Expose
        var startTime: String? = null

        @SerializedName("isPaid")
        @Expose
        var isPaid = false

        @SerializedName("description")
        @Expose
        var description: String? = null

        @SerializedName("rules")
        @Expose
        var rules: String? = null

        @SerializedName("criticalRules")
        @Expose
        var criticalRules: String? = null

        @SerializedName("faqs")
        @Expose
        var faqs: String? = null

        @SerializedName("schedule")
        @Expose
        var schedule: String? = null

        @SerializedName("isIncludeSponsor")
        @Expose
        var isIncludeSponsor = false

        @SerializedName("tournamentType")
        @Expose
        var tournamentType: String? = null

        @SerializedName("isScreenshotRequired")
        @Expose
        var isScreenshotRequired = false

        @SerializedName("isShowCountryFlag")
        @Expose
        var isShowCountryFlag = false

        @SerializedName("isSpecifyAllowedRegions")
        @Expose
        var isSpecifyAllowedRegions = false

        @SerializedName("isParticipantsLimit")
        @Expose
        var isParticipantsLimit = false

        @SerializedName("scoreReporting")
        @Expose
        var scoreReporting = 0

        @SerializedName("invitationLink")
        @Expose
        var invitationLink: String? = null

        @SerializedName("youtubeVideoLink")
        @Expose
        var youtubeVideoLink: String? = null

        @SerializedName("facebookVideoLink")
        @Expose
        var facebookVideoLink: String? = null

        @SerializedName("contactDetails")
        @Expose
        var contactDetails: String? = null

        @SerializedName("twitchVideoLink")
        @Expose
        var twitchVideoLink: String? = null

        @SerializedName("visibility")
        @Expose
        var visibility = 0

        @SerializedName("checkInStartDate")
        @Expose
        var checkInStartDate: String? = null

        @SerializedName("checkInEndDate")
        @Expose
        var checkInEndDate: String? = null

        @SerializedName("banner")
        @Expose
        var banner: String? = null

        @SerializedName("maxParticipants")
        @Expose
        var maxParticipants = 0

        @SerializedName("bracketType")
        @Expose
        var bracketType: String? = null

        @SerializedName("noOfSet")
        @Expose
        var noOfSet = 0

        @SerializedName("contactOn")
        @Expose
        var contactOn: String? = null

        @SerializedName("gameDetail")
        @Expose
        var gameDetail: String? = null

        @SerializedName("teamSize")
        @Expose
        var teamSize: Int = 0

        @SerializedName("firstPrize")
        @Expose
        var firstPrize = 0

        @SerializedName("secondPrize")
        @Expose
        var secondPrize = 0

        @SerializedName("thirdPrize")
        @Expose
        var thirdPrize = 0

        @SerializedName("prizeCurrency")
        @Expose
        var prizeCurrency: String? = null

        @SerializedName("slug")
        @Expose
        var slug: String? = null

        @SerializedName("country")
        @Expose
        var country: String? = null

        @SerializedName("endDate")
        @Expose
        var endDate: String? = null

        @SerializedName("createdBy")
        @Expose
        var createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
        var updatedBy: String? = null

        @SerializedName("tournamentStatus")
        @Expose
        var tournamentStatus: String? = null

        @SerializedName("organizerDetail")
        @Expose
        var organizerDetail: String? = null

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("fullText")
        @Expose
        var fullText: String? = null

        @SerializedName("__v")
        @Expose
        var v = 0

        @SerializedName("participantJoined")
        @Expose
        var participantJoined = 0

        @SerializedName("isCheckInRequired")
        @Expose
        var isCheckInRequired = false

        @SerializedName("isPrize")
        @Expose
        var isPrize = false

        @SerializedName("regFeeCurrency")
        @Expose
        var regFeeCurrency: String? = null

        @SerializedName("regFee")
        @Expose
        var regFee = 0

        var isUpcomming: Boolean = false

        var isLoadMore: Boolean = false
    }


    class Sponsor {
        @SerializedName("sponsorName")
        @Expose
        var sponsorName: String? = null

        @SerializedName("website")
        @Expose
        var website: String? = null

        @SerializedName("playStoreUrl")
        @Expose
        var playStoreUrl: String? = null

        @SerializedName("appStoreUrl")
        @Expose
        var appStoreUrl: String? = null

        @SerializedName("sponsorLogo")
        @Expose
        var sponsorLogo: String? = null

        @SerializedName("sponsorBanner")
        @Expose
        var sponsorBanner: String? = null
    }


    class Stream {
        @SerializedName("type")
        @Expose
        var type: String? = null

        @SerializedName("videoUrl")
        @Expose
        var videoUrl: VideoUrl? = null

        @SerializedName("title")
        @Expose
        var title: String? = null

        @SerializedName("description")
        @Expose
        var description: String? = null

        @SerializedName("url")
        @Expose
        var url: String? = null
    }

    class VenueAddress {
        @SerializedName("country")
        @Expose
        var country: String? = null

        @SerializedName("region")
        @Expose
        var region: String? = null

        @SerializedName("venue")
        @Expose
        var venue: String? = null

        @SerializedName("stage")
        @Expose
        var stage: String? = null
    }


    class VideoUrl {
        @SerializedName("providerName")
        @Expose
        var providerName: String? = null

        @SerializedName("channelName")
        @Expose
        var channelName: String? = null
    }
}