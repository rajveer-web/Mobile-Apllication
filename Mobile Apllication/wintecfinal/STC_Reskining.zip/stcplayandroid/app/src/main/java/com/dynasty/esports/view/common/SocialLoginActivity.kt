package com.dynasty.esports.view.common

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.extenstion.refreshToken
import com.dynasty.esports.models.SocialLoginRequest
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.phone_verification.PhoneNumVerificationActivity
import com.dynasty.esports.viewmodel.ChatViewModel
import com.dynasty.esports.viewmodel.CommonViewModel
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.FacebookSdk
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.gson.JsonObject
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class use manage social login response for sign in and sign up screen.
 * @author : Mahesh Vayak
 * @created : 23-07-2020
 * @modified : 14-08-2020
 * ©Dynasty eSports Pte ltd
 **/

open class SocialLoginActivity : BaseActivity() {
    lateinit var gso: GoogleSignInOptions
    val commonViewModel: CommonViewModel by viewModel()
    val chatViewModel: ChatViewModel by viewModel()
    lateinit var mGoogleSignInClient: GoogleSignInClient
    val RC_SIGN_IN: Int = 1
    var loginType = ""

    private var mCallbackManager: CallbackManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // generateKeyHash()
        FacebookSdk.sdkInitialize(this.applicationContext)
        mCallbackManager = CallbackManager.Factory.create()
        LoginManager.getInstance().registerCallback(mCallbackManager,
            object : FacebookCallback<LoginResult?> {
                override fun onSuccess(loginResult: LoginResult?) {
                    loginResult?.apply {
                        runOnUiThread {
                            loginType = "FACEBOOK"
                            launchProgressDialog()
                            val socialLoginReq = SocialLoginRequest()
                            socialLoginReq.provider = loginType
                            socialLoginReq.type="login"
                            socialLoginReq.token = loginResult.accessToken.token.toString()
                            commonViewModel.socialLogin(socialLoginReq)
                        }
                    }

                }

                override fun onCancel() {
                    "Login Cancel".showToast(this@SocialLoginActivity)
                }

                override fun onError(exception: FacebookException) {
                    resources.getString(R.string.no_internet_message)
                        .showToast(this@SocialLoginActivity)
                }
            })
        gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)

        listenToViewModel()
    }

    override fun attachBaseContext(newBase: Context?) {
        newBase?.apply {
            super.attachBaseContext(LocaleHelper.onAttach(this))
        } ?: super.attachBaseContext(LocaleHelper.onAttach(this))
    }

    private fun listenToViewModel() {
        commonViewModel.socialLoginSuccessResponse.observe(this, {
            if (loginType == "GOOGLE") {
                mGoogleSignInClient.signOut()
            }else{
                LoginManager.getInstance().logOut()
            }
            sharedPreferences.refreshToken = it.first


            if(it.second.code.toString()=="ER1001"){
                dismissProgressDialog()
                it.second.message.toString().showToast(this@SocialLoginActivity)
                val bundle = Bundle()
                bundle.putString("type","login")
                bundle.putBoolean("isEmail", true)
                bundle.putBoolean("isSocial", true)
                bundle.putString("id", it.second.data?.id.toString())
                startActivityInline<PhoneNumVerificationActivity>(bundle)
            }else {
                it.second.data?.apply {
                    sharedPreferences.accessToken =this.token.toString()
                    registerFCMToken()
                    commonViewModel.fetchUser()
                }
            }
        })
        commonViewModel.socialLoginErrorResponse.observe(this, {
            dismissProgressDialog()
            it.string().getMessageFromObject("message").showToast(this@SocialLoginActivity)
            if (loginType == "GOOGLE") {
                mGoogleSignInClient.signOut()
            }else{
                LoginManager.getInstance().logOut()
            }
        })
        commonViewModel.noInternetException.observe(this, {
            dismissProgressDialog()
            resources.getString(R.string.no_internet_message).showToast(this@SocialLoginActivity)
        })

        commonViewModel.registerFCMTokenSuccessResponse.observe(this, {
              //   it.string().getMessageFromObject("message").showToast(this)
        })

        commonViewModel.registerFCMTokenErrorResponse.observe(this, {
              //  it.string().getMessageFromObject("message").showToast(this)
        })

        commonViewModel.userSuccessResponse.observe(this, {
            dismissProgressDialog()
            if (loginType == "GOOGLE"||loginType=="FACEBOOK")
                sharedPreferences.isLogin=true
            it.data?.apply {
                chatViewModel.makeJsonForChatLogin(this.phoneNumber.toString())
                sharedPreferences.id = this.id.toString()
                sharedPreferences.put("user", this)
            }
        })

        commonViewModel.userErrorResponse.observe(this, {
            dismissProgressDialog()
            resources.getString(R.string.something_wrong_try_again).showToast(this)
        })

        chatViewModel.makeJsonObjectForChatLogin.observe(this, Observer {
            chatViewModel.chatLogin(it)
        })

        chatViewModel.chatLoginErrorResponse.observe(this, Observer {
            dismissProgressDialog()
            resources.getString(R.string.something_wrong_try_again).showToast(this)

        })

        chatViewModel.chatLoginSuccessResponse.observe(this, {
            dismissProgressDialog()
            val result = it.string()
            sharedPreferences.chatAccessToken = result.getMessageFromObject("accessToken")
            sharedPreferences.chatRefreshToken = result.getMessageFromObject("refreshToken")
            redirectToDashBoard(true)
        })
    }


    fun registerFCMToken(){
        // code here will register FCMToken
        if(sharedPreferences.FCMToken.isNotEmpty()) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("requestType", "register-push-notification")
            jsonObject.addProperty("platform", "android")
            jsonObject.addProperty("token", sharedPreferences.FCMToken)
            commonViewModel.registrationPushNotification(jsonObject)
        }
    }

    /*
     * Hide progress bar when doing api call or heavy task on main thread
     */
//
//    override fun onDestroy() {
//        dismissProgressDialog()
//        super.onDestroy()
//    }

    fun googleLogin() {
        val signInIntent: Intent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
        launchProgressDialog()
    }




    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        dismissProgressDialog()
        mCallbackManager?.onActivityResult(requestCode, resultCode, data)
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }

    private fun handleSignInResult(task: Task<GoogleSignInAccount>) {
        try {
            val account: GoogleSignInAccount = task.getResult(ApiException::class.java)!!
            val scope = "oauth2:" + Scopes.EMAIL + " " + Scopes.PROFILE
            AsyncTask.execute {
                account.account?.apply {
                    val token = GoogleAuthUtil.getToken(this@SocialLoginActivity, this, scope)
                    runOnUiThread {
                        loginType = "GOOGLE"
                        launchProgressDialog()
                        val socialLoginReq = SocialLoginRequest()
                        socialLoginReq.provider = loginType
                        socialLoginReq.token = token
                        socialLoginReq.type="login"
                        commonViewModel.socialLogin(socialLoginReq)
                    }
                }
            }
        } catch (e: ApiException) {
            e.printStackTrace()
        }
    }

    fun fbLogin() {
        launchProgressDialog()
        LoginManager.getInstance().logInWithReadPermissions(this, listOf("email", "public_profile"))
    }

     open fun redirectToDashBoard(isRedirect:Boolean){

     }


//    override fun onStop() {
//        super.onStop()
//        commonViewModel.onDetach()
//    }
//
//     private fun generateKeyHash() {
//         try {
//             val info = packageManager.getPackageInfo(
//                 packageName,
//                 PackageManager.GET_SIGNATURES)
//             for (signature in info.signatures) {
//                 val md = MessageDigest.getInstance("SHA")
//                 md.update(signature.toByteArray())
//
//             }
//         } catch (e: PackageManager.NameNotFoundException) {
//
//         } catch (e: NoSuchAlgorithmException) {
//
//         }
//    }

}


