package com.dynasty.esports.view.tournamet.tournamet_detail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.nullSafeNA
import com.dynasty.esports.extenstion.showToast
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.view.common.BaseFragment
import kotlinx.android.synthetic.main.fragment_upcoming_overview.*
import java.util.*


class TournamentOverviewFragment : BaseFragment() {

    private lateinit var gameItem: TournamentDetailRes

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_upcoming_overview, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
    }

    companion object {
        fun newInstance(gameItem: TournamentDetailRes): Fragment {
            val args = Bundle()
            args.putParcelable("data", gameItem)
            val fragment = TournamentOverviewFragment()
            fragment.arguments = args
            return fragment
        }
    }

    fun initialise() {
        arguments?.apply {
            gameItem = this.getParcelable<TournamentDetailRes>("data")!!
        }

        tournament_type_txt.text = nullSafeNA(gameItem.data!!.tournamentType!!.capitalize())

        bracket_format_txt.text = nullSafeNA(gameItem.data!!.bracketType!!.capitalize())

        if (!gameItem.data!!.regionsAllowed.isNullOrEmpty()) {
            region_txt.text = nullSafeNA(gameItem.data!!.regionsAllowed.joinToString())
        } else {
            region_txt.text = resources.getString(R.string.empty_desc)
        }

        if (gameItem.data!!.venueAddress.isNullOrEmpty()) {
            venue_txt.text = resources.getString(R.string.empty_desc)
        } else {
            val tempVenueArr = ArrayList<String>()
            for (i in 0 until gameItem.data!!.venueAddress.size) {
                tempVenueArr.add(gameItem.data!!.venueAddress.get(i).venue!!.capitalize())
            }
            venue_txt.text = tempVenueArr.joinToString()
        }

        rvPrizeList.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        if (gameItem.data!!.prizeList.isNullOrEmpty()) {
            rvPrizeList.beGone()
        } else {
            rvPrizeList.beVisible()
            rvPrizeList.adapter = OverViewPrizeAdapter(
                gameItem.data!!.prizeList,
                gameItem.data!!.prizeCurrency
            )
        }

        sponsors_recycler_view.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        if (!gameItem.data!!.sponsors.isNullOrEmpty()) {
            sponsors_recycler_view.adapter =
                OverViewSponsorAdapter(gameItem.data!!.sponsors,
                    object :
                        OverViewSponsorAdapter.OnItemClickListener {
                        override fun onItemClick(
                            sponsor: TournamentDetailRes.Sponsor,
                            clickEventName: String
                        ) {
                            if (clickEventName.equals("PlayStore", true)) {
                                try {
                                    val browserIntent =
                                        Intent(Intent.ACTION_VIEW, Uri.parse(sponsor.playStoreUrl))
                                    startActivity(browserIntent)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
//                                sponsor.playStoreUrl!!.showToast(requireActivity())
                            } else {
                                try {

                                    val browserIntent =
                                        Intent(Intent.ACTION_VIEW, Uri.parse(sponsor.appStoreUrl))
                                    startActivity(browserIntent)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
//                                sponsor.appStoreUrl!!.showToast(requireActivity())
                            }
                        }
                    })
        }
    }
}