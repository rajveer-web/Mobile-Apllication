package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import org.json.JSONObject

class HomeViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    val articleTrendingResponse = MutableLiveData<LatestArticleModel>()
    val articlePostByGamesResponse = MutableLiveData<GamesModel>()
    val latestVideoResponse = MutableLiveData<VideosModel>()

    val fetchLeaderboardSuccessResponse = MutableLiveData<LeaderboardModel>()
    val fetchLeaderboardErrorResponse = MutableLiveData<ResponseBody>()

    val bannerSuccessResponse = MutableLiveData<BannerModel>()
    val bannerErrorResponse = MutableLiveData<ResponseBody>()

    val announcemntSuccessResponse = MutableLiveData<AnnouncementResponse>()
    val announcemntErrorResponse = MutableLiveData<ResponseBody>()
    val makeJsonForArticleData = MutableLiveData<Pair<JsonObject,Pair<JsonObject,JsonObject>>>()
    fun getAllArticles(articleQuery: String,pagination:String,prefrence:String) {
        viewModelScope.launch(apiException("all")) {

            val getTrendingPost = async { restInterface.articleTrendingPost(articleQuery,pagination,prefrence) }
            val getPostGames = async { restInterface.getGames() }
//            val fetchLeaderboardList = async { restInterface.getLeaderboardDetails() }

            articleTrendingResponse.postValue(getTrendingPost.await().body())
            articlePostByGamesResponse.postValue(getPostGames.await().body())
//            fetchLeaderboardSuccessResponse.postValue(fetchLeaderboardList.await().body())
        }

    }

    fun getAllBanner() {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.getBanner()
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    bannerSuccessResponse.postValue(response.body())
                }
                else -> {
                    bannerErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun fetchLeaderBoardDetail() {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getLeaderboardDetails()
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchLeaderboardSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchLeaderboardErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun getLatestAnnouncement() {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            val response = restInterface.getLatestAnnouncement()
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    announcemntSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    announcemntErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun makeJsonForArticleParameter(){
        //  pagination={"page":2,"limit":20,"sort":"-updatedOn","projection":["_id","title","description","youtubeUrl","thumbnailUrl","updatedOn"]}
        val jsonObjectLatestArticle = JsonObject()
        jsonObjectLatestArticle.addProperty("articleStatus", "publish")
        jsonObjectLatestArticle.addProperty("category", "News")


        val jsonObjectPagination = JsonObject()
        val jsonObjectSort = JsonObject()
        jsonObjectSort.addProperty("createdDate",-1)
        jsonObjectPagination.addProperty("limit",7)
        jsonObjectPagination.add("sort",jsonObjectSort)

        val jsonObjectPrefernce = JsonObject()
        jsonObjectPrefernce.addProperty("prefernce", "")



        makeJsonForArticleData.postValue(Pair(jsonObjectLatestArticle,
            Pair(jsonObjectPagination,jsonObjectPrefernce)
        ))
    }



    /**
     * Clears the [ViewModel] when the [ArticlesFragment] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
