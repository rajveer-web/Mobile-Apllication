package com.dynasty.esports.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class SearchViewModel constructor(private val restInterface: RestInterface) : BaseViewModel() {
    //    val tournamentUpComingSuccessResponse = MutableLiveData<SearchTournamentModel>()
//    val tournamentOnGoingSuccessResponse = MutableLiveData<SearchTournamentModel>()
//    val tournamentCompleteSuccessResponse = MutableLiveData<SearchTournamentModel>()
    val articleSuccessResponse = MutableLiveData<SearchArticleModel>()
    val videoSuccessResponse = MutableLiveData<SearchVideoModel>()

    val updateTournamentList = MutableLiveData<MutableList<TournamentSearchResultModel>>()
    val updateTournamentView =
        MutableLiveData<Pair<SearchTournamentModel, Pair<SearchTournamentModel, SearchTournamentModel>>>()
    val makeQueryParameterGlobal =
        MutableLiveData<Pair<HashMap<String, String>, Pair<HashMap<String, String>, Pair<HashMap<String, String>, Pair<HashMap<String, String>, HashMap<String, String>>>>>>()
//    val latestVideoResponse = MutableLiveData<VideosModel>()

    val gameListSuccessResponse = MutableLiveData<TournamentGameRes>()
    val gameListErrorResponse = MutableLiveData<ResponseBody>()

    fun getAllSearchResult(
        tournamentUpComingQuery: Map<String, String>,
        tournamentOnGoing: Map<String, String>,
        tournamentComplete: Map<String, String>,
        articleQuery: Map<String, String>,
        videoQuery: Map<String, String>,
        type: String = ""
    ) {
        viewModelScope.launch(apiException("all")) {
            when (type) {
                "Article" -> {
                    val getArticleResponse = async { restInterface.getSearchArticle(articleQuery) }
                    articleSuccessResponse.postValue(getArticleResponse.await().body())
                }
                "Video" -> {
                    val getVideosResponse = async { restInterface.getVideos(videoQuery) }
                    videoSuccessResponse.postValue(getVideosResponse.await().body())
                }
                "Tournament" -> {
                    val tournamentUpComingResponse =
                        async { restInterface.getSearchTournament(tournamentUpComingQuery) }
                    val tournamentOnGoingResponse =
                        async { restInterface.getSearchTournament(tournamentOnGoing) }
                    val tournamentCompleteResponse =
                        async { restInterface.getSearchTournament(tournamentComplete) }

                    updateTournamentView.postValue(
                        Pair(
                            tournamentUpComingResponse.await().body()!!,
                            Pair(
                                tournamentOnGoingResponse.await().body()!!,
                                tournamentCompleteResponse.await().body()!!
                            )
                        )
                    )


                }
                else -> {
                    val tournamentUpComingResponse =
                        async { restInterface.getSearchTournament(tournamentUpComingQuery) }
                    val tournamentOnGoingResponse =
                        async { restInterface.getSearchTournament(tournamentOnGoing) }
                    val tournamentCompleteResponse =
                        async { restInterface.getSearchTournament(tournamentComplete) }
                    val articleResponse = async { restInterface.getSearchArticle(articleQuery) }
                    val videosResponse = async { restInterface.getVideos(videoQuery) }


//                    tournamentUpComingSuccessResponse.postValue(tournamentUpComingResponse.await().body())
//                    tournamentOnGoingSuccessResponse.postValue(tournamentOnGoingResponse.await().body())
//                    tournamentCompleteSuccessResponse.postValue(tournamentCompleteResponse.await().body())

                    updateTournamentView.postValue(
                        Pair(
                            tournamentUpComingResponse.await().body()!!,
                            Pair(
                                tournamentOnGoingResponse.await().body()!!,
                                tournamentCompleteResponse.await().body()!!
                            )
                        )
                    )

                    articleSuccessResponse.postValue(articleResponse.await().body())
                    videoSuccessResponse.postValue(videosResponse.await().body())
                }
            }


        }

    }

    fun getGameList() {
        viewModelScope.launch(apiException("gameList") + Dispatchers.Main) {
            val response = restInterface.getTournamentGameList()

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gameListSuccessResponse.postValue(response.body())
                }
                else -> {
                    gameListErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }


    fun makeQueryParameter(
        search: String = "",
        filterOptionList: MutableList<CustomSearchFilterModel>? = null,
        isAllSelect: Boolean = false
    ) {
        val hashMapUpComingTournament: HashMap<String, String> = hashMapOf()
        val hashMapOnGoingTournament: HashMap<String, String> = hashMapOf()
        val hashMapCompleteTournament: HashMap<String, String> = hashMapOf()

        val hashMapArticle: HashMap<String, String> = hashMapOf()
        val hashMapVideo: HashMap<String, String> = hashMapOf()

        hashMapUpComingTournament["status"] = 0.toString()
        hashMapOnGoingTournament["status"] = 1.toString()
        hashMapCompleteTournament["status"] = 2.toString()



        hashMapArticle["text"] = search
        hashMapVideo["text"] = search
        hashMapUpComingTournament["text"] = search
        hashMapOnGoingTournament["text"] = search
        hashMapCompleteTournament["text"] = search
        if (!isAllSelect) {
            filterOptionList?.forEachIndexed { index, customSearchFilterModel ->
                when (index) {
                    0 -> {
                        hashMapUpComingTournament["sort"] = customSearchFilterModel.selectedKey
                        hashMapOnGoingTournament["sort"] = customSearchFilterModel.selectedKey
                        hashMapCompleteTournament["sort"] = customSearchFilterModel.selectedKey

                        hashMapArticle["sort"] = customSearchFilterModel.selectedKey
                        hashMapVideo["sort"] = customSearchFilterModel.selectedKey
                    }
                    1 -> {
                        hashMapUpComingTournament["category"] = customSearchFilterModel.selectedKey
                        hashMapOnGoingTournament["category"] = customSearchFilterModel.selectedKey
                        hashMapCompleteTournament["category"] = customSearchFilterModel.selectedKey

                        hashMapArticle["category"] = customSearchFilterModel.selectedKey
                        hashMapVideo["category"] = customSearchFilterModel.selectedKey
                    }
                    2 -> {
                        hashMapUpComingTournament["game"] = customSearchFilterModel.selectedKey
                        hashMapOnGoingTournament["game"] = customSearchFilterModel.selectedKey
                        hashMapCompleteTournament["game"] = customSearchFilterModel.selectedKey

                        hashMapArticle["game"] = customSearchFilterModel.selectedKey
                        hashMapVideo["game"] = customSearchFilterModel.selectedKey
                    }
                    3 -> {
                        hashMapUpComingTournament["platform"] = customSearchFilterModel.selectedKey
                        hashMapOnGoingTournament["platform"] = customSearchFilterModel.selectedKey
                        hashMapCompleteTournament["platform"] = customSearchFilterModel.selectedKey

                        hashMapArticle["platform"] = customSearchFilterModel.selectedKey
                        hashMapVideo["platform"] = customSearchFilterModel.selectedKey
                    }
                    4 -> {
                        hashMapUpComingTournament["region"] = customSearchFilterModel.selectedKey
                        hashMapOnGoingTournament["region"] = customSearchFilterModel.selectedKey
                        hashMapCompleteTournament["region"] = customSearchFilterModel.selectedKey

                        hashMapArticle["region"] = customSearchFilterModel.selectedKey
                        hashMapVideo["region"] = customSearchFilterModel.selectedKey
                    }
                }
            }
        }

        makeQueryParameterGlobal.postValue(
            Pair(
                hashMapUpComingTournament,
                Pair(
                    hashMapOnGoingTournament,
                    Pair(hashMapCompleteTournament, Pair(hashMapArticle, hashMapVideo))
                )
            )
        )
    }

    fun updateTournamentView(tournamentList: MutableList<TournamentSearchResultModel>) {
        updateTournamentList.postValue(tournamentList)
    }

    /**
     * Clears the [ViewModel] when the is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
