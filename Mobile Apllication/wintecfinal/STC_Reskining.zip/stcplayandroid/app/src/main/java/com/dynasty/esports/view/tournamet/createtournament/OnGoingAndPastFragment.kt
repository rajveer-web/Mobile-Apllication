package com.dynasty.esports.view.tournamet.createtournament

import android.content.IntentFilter
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CreatedTournamentModel
import com.dynasty.esports.models.JoinedTournamentModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.RecyclerViewLoadMoreScroll
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.tournamet.joined_tournamet.JoinTournamentActivity
import com.dynasty.esports.view.tournamet.joined_tournamet.JoinedTournamentProfileAdapter
import com.dynasty.esports.view.tournamet.manage_tournament.ManagedTournamentActivity
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamentDetailActivity
import com.dynasty.esports.viewmodel.CreatedAndJoinedTournamentViewModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class OnGoingAndPastFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    private lateinit var createdTournamentsAdapter: CreatedTournamentsAdapter
    private lateinit var joinedTournamentsAdapter: JoinedTournamentProfileAdapter
    private val mViewModel: CreatedAndJoinedTournamentViewModel by viewModel()
    private var createdTournamentList: MutableList<CreatedTournamentModel.DocModel> =
        mutableListOf()
    private var joinedTournamentList: MutableList<JoinedTournamentModel.DocModel> = mutableListOf()
    private var type = ""
    private var parentType = ""
    private var pageNo = 1
    private var limit = 10
    private var connectivityReceiver = ConnectivityReceiver()
    private var isLoadedAllItems: Boolean = false
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var scrollListener: RecyclerViewLoadMoreScroll

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.recycler_progress_bar_view, container, false)
    }

    // get arguments
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.apply {
            type = this.getString("type").toString()
            parentType = this.getString("parentType").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        layoutManager = LinearLayoutManager(requireActivity())
        commonRecyclerView.layoutManager = layoutManager

        if (parentType == "joined") {
            joinedTournamentsAdapter =
                JoinedTournamentProfileAdapter(
                    joinedTournamentList,
                    onItemClick = ::onItemClick,
                    onItemEditClick = ::onItemEditClick

                )
            commonRecyclerView.adapter = joinedTournamentsAdapter
        } else {
            createdTournamentsAdapter =
                CreatedTournamentsAdapter(type,
                    createdTournamentList, onItemClick = ::onItemClick,
                    onItemEditClick = ::onTournamentItemEditClick
                )
            commonRecyclerView.adapter = createdTournamentsAdapter
        }


        scrollListener = RecyclerViewLoadMoreScroll(layoutManager)
        setLoadMoreListener()
        listenToViewModel()

    }

    // For identify need to load more data or not
    private fun setLoadMoreListener() {
        scrollListener.setOnLoadMoreListener(object :
            RecyclerViewLoadMoreScroll.OnLoadMoreListener {
            override fun onLoadMore() {
                if (!isLoadedAllItems) {
                    onLoadMoreBracket()
                }
            }
        })
        commonRecyclerView.addOnScrollListener(scrollListener)
    }

    // add dummy data in list and show progress bar
    private fun onLoadMoreBracket() {
        if (parentType == "joined") {
            val model = JoinedTournamentModel.DocModel()
            model.isLoadMore = true
            joinedTournamentList.add(model)
            commonRecyclerView.post {
                joinedTournamentsAdapter.apply {
                    notifyItemInserted(joinedTournamentList.size - 1)
                }
                callJoinTournamentAPI()
            }

        } else {
            val model = CreatedTournamentModel.DocModel()
            model.isLoadMore = true
            createdTournamentList.add(model)
            commonRecyclerView.post {
                createdTournamentsAdapter.apply {
                    notifyItemInserted(createdTournamentList.size - 1)
                }
                callCreateTournamentAPI()
            }
//            createdTournamentsAdapter.apply {
//                addLoadingView()
//            }
//            callCreateTournamentAPI()
        }


    }

    // remove progress bar from list
    private fun stopLoadMore() {
        scrollListener.setLoaded()
        if (parentType == "joined") {
            joinedTournamentList.removeAt(joinedTournamentList.size - 1)
            commonRecyclerView.post {
                joinedTournamentsAdapter.apply {
                    notifyDataSetChanged()
                }
            }
        } else {
            createdTournamentList.removeAt(createdTournamentList.size - 1)
            commonRecyclerView.post {
                createdTournamentsAdapter.apply {
                    notifyDataSetChanged()
                }
            }
        }
    }

    // make item click for redirect manage tournament
    private fun onItemClick(id: String) {
        if (parentType == "joined") {
            val bundle = Bundle()
            bundle.putString("tournamentId", id)
            if (type == "upcoming") {
                bundle.putBoolean("isUpcoming", true)
            } else {
                bundle.putBoolean("isUpcoming", false)
            }
            startActivityFromFragment<TournamentDetailActivity>(bundle)
        } else {
            val bundle = Bundle()
            bundle.putString("id", id)
            bundle.putString("type", type)
            startActivityFromFragment<ManagedTournamentActivity>(bundle)
        }
    }

    // make join edit item click for redirect manage tournament
    private fun onItemEditClick(data: JoinedTournamentModel.DocModel) {

        val bundle = Bundle()
        bundle.putString("tournamentId", data.tournament!!.id)
        bundle.putBoolean("isForEditJoin", true)
        bundle.putString("tournamentName", data.tournament.name)
        startActivityFromFragment<JoinTournamentActivity>(bundle)

//        if (parentType == "joined") {
//            val bundle = Bundle()
//            bundle.putString("tournamentId", id)
//            if (type == "upcoming") {
//                bundle.putBoolean("isUpcoming", true)
//            } else {
//                bundle.putBoolean("isUpcoming", false)
//            }
//            startActivityFromFragment<TournamentDetailActivity>(bundle)
//        } else {
//            val bundle = Bundle()
//            bundle.putString("id", id)
//            bundle.putString("type", type)
//            startActivityFromFragment<ManagedTournamentActivity>(bundle)
//        }
    }

    // make tournament edit item click for redirect manage tournament
    private fun onTournamentItemEditClick(data: CreatedTournamentModel.DocModel) {

        val bundle = Bundle()
        bundle.putString("tournamentId", data.id)
        bundle.putBoolean("isForEdit", true)
        startActivityFromFragment<CreateTourmamentActivity>(bundle)

//        if (parentType == "joined") {
//            val bundle = Bundle()
//            bundle.putString("tournamentId", id)
//            if (type == "upcoming") {
//                bundle.putBoolean("isUpcoming", true)
//            } else {
//                bundle.putBoolean("isUpcoming", false)
//            }
//            startActivityFromFragment<TournamentDetailActivity>(bundle)
//        } else {
//            val bundle = Bundle()
//            bundle.putString("id", id)
//            bundle.putString("type", type)
//            startActivityFromFragment<ManagedTournamentActivity>(bundle)
//        }
    }

    // listen view model and managed API success and error
    private fun listenToViewModel() {
        mViewModel.jsonObjectForTournament.observe(viewLifecycleOwner, {
            Log.d("Hello", sharedPreferences.accessToken)
            if (parentType == "joined") {
                Log.d("Hello", it.second.toString() + " " + it.first.toString())
                mViewModel.fetchJoinedTournamentOngoingAndPast(
                    it.first.toString(),
                    it.second.toString(),
                    type
                )
            }
//            else {
//                mViewModel.fetchCreatedTournamentOngoingAndPast(
//                    it.first.toString(),
//                    it.second.toString(),
//                    type
//                )
//            }
        })

        mViewModel.fetchCreatedTournamentSuccessResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beVisible()
            if (pageNo == 1) {
                createdTournamentList.clear()
            }
            it?.data?.apply {
                if (!createdTournamentList.isNullOrEmpty()) {
                    if (createdTournamentList[createdTournamentList.size - 1].isLoadMore) {
                        stopLoadMore()
                    }
                }

                if (!this.hasNextPage!!) {
                    isLoadedAllItems = true
                }

                this.docs?.apply {
                    createdTournamentList.addAll(this)
                }
                if (page == 1 && createdTournamentList.isEmpty()) {
                    constraintLayoutNoData.beVisible()
                    commonRecyclerView.beGone()
                } else {
                    createdTournamentsAdapter.notifyDataSetChanged()
                    pageNo += 1
                }
            }
        })
        mViewModel.fetchCreatedTournamentErrorResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beVisible()
            constraintLayoutNoInternet.beGone()
        })

        mViewModel.fetchJoinedTournamentSuccessResponse.observe(viewLifecycleOwner, {

            debugE("fetchJoinedTournamentSuccessResponse", Gson().toJson(it.toString()))

            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beVisible()
            if (pageNo == 1) {
                joinedTournamentList.clear()
            }
            it?.data?.apply {
                if (!joinedTournamentList.isNullOrEmpty()) {
                    if (joinedTournamentList[joinedTournamentList.size - 1].isLoadMore) {
                        stopLoadMore()
                    }
                }

                if (!this.hasNextPage!!) {
                    isLoadedAllItems = true
                }

                this.docs?.apply {
                    joinedTournamentList.addAll(this)
                }

                if (page == 1 && joinedTournamentList.isEmpty()) {
                    constraintLayoutNoData.beVisible()
                    commonRecyclerView.beGone()
                } else {
                    joinedTournamentsAdapter.notifyDataSetChanged()
                    pageNo += 1
                }
            }
        })

        mViewModel.fetchJoinedTournamentErrorResponse.observe(viewLifecycleOwner, {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beVisible()
            constraintLayoutNoInternet.beGone()
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, {
            if (requireActivity().isOnline()) {
                linearLayoutProgressBar.beGone()
                constraintLayoutNoData.beGone()
                constraintLayoutErrorView.beVisible()
                constraintLayoutNoInternet.beGone()
            }
        })

        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, {
            if (it) {
                logOut()
            }
        })
    }

    // make fragment instance and put arguments
    companion object {
        fun newInstance(type: String, parentType: String): Fragment {
            val args = Bundle()
            args.putString("type", type)
            args.putString("parentType", parentType)
            val fragment = OnGoingAndPastFragment()
            fragment.arguments = args
            return fragment
        }
    }

    // Register receiver for check internet connection
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    // Unregister receiver for internet connection
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    // Prevent to API call from view model
    override fun onDestroy() {
        super.onDestroy()

        mViewModel.onDetach()
    }


    // Manage internet connection using receiver
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected) {
            if (parentType == "joined") {
                if (joinedTournamentList.isNullOrEmpty()) {
                    linearLayoutProgressBar.beVisible()
                    constraintLayoutNoData.beGone()
                    constraintLayoutErrorView.beGone()
                    constraintLayoutNoInternet.beGone()
                    callJoinTournamentAPI()
                }
            } else {
                if (createdTournamentList.isNullOrEmpty()) {
                    linearLayoutProgressBar.beVisible()
                    constraintLayoutNoData.beGone()
                    constraintLayoutErrorView.beGone()
                    constraintLayoutNoInternet.beGone()
                    callCreateTournamentAPI()

                }
            }
        } else {
            if (parentType == "joined") {
                if (joinedTournamentList.isNullOrEmpty()) {
                    linearLayoutProgressBar.beGone()
                    constraintLayoutNoData.beGone()
                    constraintLayoutErrorView.beGone()
                    constraintLayoutNoInternet.beVisible()
                }
            } else {
                if (createdTournamentList.isNullOrEmpty()) {
                    linearLayoutProgressBar.beGone()
                    constraintLayoutNoData.beGone()
                    constraintLayoutErrorView.beGone()
                    constraintLayoutNoInternet.beVisible()
                }
            }
        }
    }

    private fun callCreateTournamentAPI() {
        when (type) {
            "ongoing" -> {
                mViewModel.fetchCreatedTournamentOngoingAndPast(
                    1,
                    pageNo,
                    "Latest",
                    sharedPreferences.id,
                    type
                )
//                mViewModel.makeJsonForCreatedTournament(
//                    pageNo,
//                    limit,
//                    false,
//                    true,
//                    sharedPreferences.id
//                )
            }
            "past" -> {
                mViewModel.fetchCreatedTournamentOngoingAndPast(
                    2,
                    pageNo,
                    "Latest",
                    sharedPreferences.id,
                    type
                )
//                mViewModel.makeJsonForCreatedTournament(
//                    pageNo,
//                    limit,
//                    false,
//                    true,
//                    sharedPreferences.id
//                )
            }
            else -> {
                mViewModel.fetchCreatedTournamentOngoingAndPast(
                    0,
                    pageNo,
                    "Latest",
                    sharedPreferences.id,
                    type
                )
//                mViewModel.makeJsonForCreatedTournament(
//                    pageNo,
//                    limit,
//                    false,
//                    false,
//                    sharedPreferences.id,
//                    true
//                )
            }
        }
    }

    private fun callJoinTournamentAPI() {
        when (type) {
            "ongoing" -> {
                mViewModel.makeJsonForJoinedTournament(false, pageNo, limit, false, true)
            }
            "past" -> {
                mViewModel.makeJsonForPstJoinedTournament(pageNo, limit)
            }
            else -> {
                mViewModel.makeJsonForJoinedTournament(true, pageNo, limit, false, false)
            }
        }
    }


}