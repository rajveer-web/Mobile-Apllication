package com.dynasty.esports.view.transaction


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.RowRewardHistoryBinding
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.models.RewardsHistoryModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will show rewarded history data.
 * @author : Mahesh Vayak
 * @created : 25-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class RewardHistoryAdapter constructor(private val rewardsTransactionList: MutableList<RewardsHistoryModel.DataModel>) :
    RecyclerView.Adapter<BindingHolder<RowRewardHistoryBinding>>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<RowRewardHistoryBinding> {
        val binding: RowRewardHistoryBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.row_reward_history,
            parent,
            false
        )
        return BindingHolder(binding)

    }


    /**
     * @desc rewards Transaction array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return rewardsTransactionList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: BindingHolder<RowRewardHistoryBinding>, position: Int) {
        val data = rewardsTransactionList[position]
        holder.binding.textViewRewardType.text = data.type?.let { it } ?: ""
        holder.binding.textViewRewardBalance.text = data.rewardBalance?.let { it.toString() } ?: "0"
        holder.binding.textViewStatus.text = data.status?.let { it } ?: ""
        holder.binding.textViewDescription.text = data.description?.let { it } ?: ""
        holder.binding.textViewDate.text = data.createdOn?.let {
            it.convertDateToRequireDateFormat(
                AppConstants.API_DATE_FORMAT,
                AppConstants.REQUIRED_TIME_FORMAT
            )
        } ?: ""
        holder.binding.textViewExpiryDate.text = data.expiredOn?.let {
            it.convertDateToRequireDateFormat(
                AppConstants.API_DATE_FORMAT,
                AppConstants.REQUIRED_TIME_FORMAT
            )
        } ?: ""
    }
}