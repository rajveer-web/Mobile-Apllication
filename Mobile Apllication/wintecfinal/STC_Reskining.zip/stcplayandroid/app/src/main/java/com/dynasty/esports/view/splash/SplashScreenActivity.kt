package com.dynasty.esports.view.splash

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.util.Base64.DEFAULT
import android.util.Base64.encodeToString
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.isAppOpenFirstTime
import com.dynasty.esports.extenstion.startActivityInline
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.on_boading.OnBoardingActivity
import org.koin.android.ext.android.inject
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

/**
 * @desc this class will hold functions for user interaction
 * examples include adMob()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class SplashScreenActivity : AppCompatActivity() {
    val sharedPreferences: SharedPreferences by inject()

    override fun attachBaseContext(newBase: Context?) {
        newBase?.apply {
            super.attachBaseContext(LocaleHelper.onAttach(this))
        } ?: super.attachBaseContext(LocaleHelper.onAttach(this))
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )


        setContentView(R.layout.activity_splash_screen)
        //adMob()
        key()
        Handler().postDelayed({
            if (!sharedPreferences.isAppOpenFirstTime) {
                sharedPreferences.isAppOpenFirstTime = true
                startActivityInline<OnBoardingActivity>(finish = true)
            } else {
                startActivityInline<DashboardActivity>(finish = true)
//                if (sharedPreferences.isLogin) {
//                    startActivityInline<DashboardActivity>(finish = true)
//                } else {
//                    startActivityInline<PhoneSignInActivity>(finish = true)
//                }
            }
        }, 6000)

    }

    fun key() {
        try {
            val info = packageManager.getPackageInfo(
                packageName,
                PackageManager.GET_SIGNATURES
            )
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())

                Log.e("KeyHash:", encodeToString(md.digest(), DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {

        } catch (e: NoSuchAlgorithmException) {

        }
    }


}