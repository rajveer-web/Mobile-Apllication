package com.dynasty.esports.view.article.article_detail


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterRepliesCommentBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.getTimeAgo
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.extenstion.updateTintColor
import com.dynasty.esports.models.ArticleCommentModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will handle list of reply comments
 * @author : Mahesh Vayak
 * @created : 11-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CommentReplayAdapter constructor(
    private var repliesList: MutableList<ArticleCommentModel.ArticleComment>,
    private val onLikeClick:(Int, String, Int, String) -> Unit = { _, _, _, _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterRepliesCommentBinding>>() {


    /**
     *@desc This ViewHolder should be constructed with a new View that can represent the items
     * of the given type.
     */
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterRepliesCommentBinding> {
        val binding: AdapterRepliesCommentBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_replies_comment,
            parent,
            false
        )
        return BindingHolder(binding)

    }

    /**
     * @desc comment array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return repliesList.size
    }


    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterRepliesCommentBinding>,
        position: Int
    ) {
        val articleCommentModel = repliesList[holder.adapterPosition]
        articleCommentModel.userDetails?.apply {
            holder.binding.textViewUserName.text = this.fullName?.let { it } ?: ""
            holder.binding.root.context.loadImageFromServer(
                this.profilePicture.toString(),
                holder.binding.imageViewUser
            )
        }

        holder.binding.textViewUserComment.text = articleCommentModel.comment?.let { it } ?: ""

        holder.binding.textViewDate.text = articleCommentModel.createdOn?.getTimeAgo(
            AppConstants.API_DATE_FORMAT,
            AppConstants.REQUIRED_TIME_FORMAT
        )

        articleCommentModel.totalLikes?.apply {
            holder.binding.textViewLike.text = this.toString()
        }

        if(articleCommentModel.type==1){
            holder. binding.root.context.updateTintColor(R.color.colorAccent, holder.binding.imageViewLike)
        }else{
            holder. binding.root.context.updateTintColor(
                R.color.black,
                holder.binding.imageViewLike
            )
        }

        holder.binding.imageViewLike.click {
            onLikeClick(
                holder.adapterPosition, articleCommentModel.id.toString(),
                articleCommentModel.type!!, articleCommentModel.likeId.toString()
            )
        }
    }

}