package com.dynasty.esports.view.tournamet.manage_tournament.participants


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterParticipantsMemberBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.ParticipantsModel
import com.dynasty.esports.utils.BindingHolder

//row_article_post

class ParticipantsListAdapter constructor(private var tournamentType:String,private var type:Int,private val onItemClick: (Int) -> Unit = { _ -> }) :
    RecyclerView.Adapter<BindingHolder<AdapterParticipantsMemberBinding>>() {

    private var listOfParticipants: MutableList<ParticipantsModel.DataModel> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterParticipantsMemberBinding> {
        val binding: AdapterParticipantsMemberBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_participants_member,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    override fun getItemCount(): Int {
        return listOfParticipants.size
    }

    fun getAll(): MutableList<ParticipantsModel.DataModel>? {
        return listOfParticipants
    }

    fun addAll(listOfParticipants_: MutableList<ParticipantsModel.DataModel>) {
        listOfParticipants.clear()
        listOfParticipants.addAll(listOfParticipants_)
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(
        holder: BindingHolder<AdapterParticipantsMemberBinding>,
        position: Int
    ) {
        val data = listOfParticipants[position]

        when(type){
            0->{
                holder.binding.viewStrip.setBackgroundColor(ContextCompat.getColor(holder.binding.root.context, R.color.colorAccent))
                holder.binding.imageViewStrip.setColorFilter(ContextCompat.getColor(holder.binding.root.context, R.color.colorAccent), android.graphics.PorterDuff.Mode.SRC_IN)
            }
            1->{
                holder.binding.viewStrip.setBackgroundColor(ContextCompat.getColor(holder.binding.root.context,  android.R.color.black))
                holder.binding.imageViewStrip.setColorFilter(ContextCompat.getColor(holder.binding.root.context, android.R.color.black), android.graphics.PorterDuff.Mode.SRC_IN)
            }
            2->{
                holder.binding.viewStrip.setBackgroundColor(ContextCompat.getColor(holder.binding.root.context, android.R.color.black))
                holder.binding.imageViewStrip.setColorFilter(ContextCompat.getColor(holder.binding.root.context, android.R.color.black), android.graphics.PorterDuff.Mode.SRC_IN)
            }
        }



        data.tournamentUsername?.let { holder.binding.textViewTeamName.text =it }
        data.name?.let { holder.binding.textViewName.text =it }

        if(tournamentType=="team"){
            holder.binding.textViewPost.text=holder.binding.root.context.resources.getString(R.string.caption)
            data.inGamerUserId?.let { holder.binding.textViewGameID.text =it }
        }else{
            data.inGamerUserId?.let { holder.binding.textViewPost.text =it }
        }

        if (data.logo.isNotEmpty()) {
            holder.itemView.context.loadImageFromServer(data.logo, holder.binding.circleImageViewAvatar)
        }

        holder.binding.materialCardView.click {
            onItemClick(position)
        }
    }

    fun getItem(position: Int): ParticipantsModel.DataModel {
        return this.listOfParticipants[position]
    }
}