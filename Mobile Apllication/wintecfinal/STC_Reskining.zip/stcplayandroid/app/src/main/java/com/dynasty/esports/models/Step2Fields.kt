package com.dynasty.esports.models

data class Step2Fields(
    var step2Id: String = "",
    var step2ParantTitle: String = "",
    var step2Child: String = "",
    var isExpanded: Boolean = false
)