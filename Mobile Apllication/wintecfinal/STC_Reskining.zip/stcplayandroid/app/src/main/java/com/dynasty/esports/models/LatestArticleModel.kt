package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class LatestArticleModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null

    @SerializedName("messageCode")
    @Expose
     val messageCode: String? = null

    
    class DataModel{
        @SerializedName("docs")
        @Expose
         val docs: MutableList<DocModel>? = null

        @SerializedName("totalDocs")
        @Expose
         val totalDocs: Int? = null

        @SerializedName("offset")
        @Expose
         val offset: Int? = null

        @SerializedName("limit")
        @Expose
         val limit: Int? = null

        @SerializedName("totalPages")
        @Expose
         val totalPages: Int? = null

        @SerializedName("page")
        @Expose
         val page: Int? = null

        @SerializedName("pagingCounter")
        @Expose
         val pagingCounter: Int? = null

        @SerializedName("hasPrevPage")
        @Expose
         val hasPrevPage: Boolean? = null

        @SerializedName("hasNextPage")
        @Expose
         val hasNextPage: Boolean? = null

        @SerializedName("prevPage")
        @Expose
         val prevPage: Any? = null

        @SerializedName("nextPage")
        @Expose
         val nextPage: Any? = null
    }
    class DocModel{
        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("content")
        @Expose
         val content: TitleModel? = null

        @SerializedName("shortDescription")
        @Expose
         val shortDescription: TitleModel? = null

        @SerializedName("genre")
        @Expose
         val genre: List<String>? = null

        @SerializedName("platform")
        @Expose
         val platform: List<String>? = null

        @SerializedName("tags")
        @Expose
         val tags: List<String>? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("views")
        @Expose
         val views: Int? = null

        @SerializedName("game")
        @Expose
         val game: String? = null

        @SerializedName("minRead")
        @Expose
         val minRead: Int? = null

        @SerializedName("location")
        @Expose
         val location: String? = null

        @SerializedName("isSponsor")
        @Expose
         val isSponsor: Boolean? = null

        @SerializedName("isInfluencer")
        @Expose
         val isInfluencer: Boolean? = null

        @SerializedName("isInfluencerHighlight")
        @Expose
         val isInfluencerHighlight: Boolean? = null

        @SerializedName("slug")
        @Expose
         val slug: String? = null

        @SerializedName("category")
        @Expose
         val category: String? = null

        @SerializedName("image")
        @Expose
         val image: String? = null

        @SerializedName("gameDetails")
        @Expose
         val gameDetails: String? = null

        @SerializedName("author")
        @Expose
         val author: String? = null

        @SerializedName("articleStatus")
        @Expose
         val articleStatus: String? = null

        @SerializedName("s3RefKey")
        @Expose
         val s3RefKey: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("createdDate")
        @Expose
         val createdDate: String? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("fullText")
        @Expose
         val fullText: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("id")
        @Expose
         val id: String? = null

        var isLoadMore:Boolean=false

    }

}