package com.dynasty.esports.view.home

import android.content.Context
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.LeaderboardByGameModel
import com.dynasty.esports.models.TournamentGameRes
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.utils.EndlessList
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.leaderboard.LeaderBoardProfileActivity
import com.dynasty.esports.view.leaderboard.LeaderBoardWinnerAdapter
import com.dynasty.esports.view.leaderboard.LeaderboardByGameExpandableAdapter
import com.dynasty.esports.view.leaderboard.SelectLeaderBoardGameAdapter
import com.dynasty.esports.viewmodel.LeaderBoardViewModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_leaderboard.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [LeaderboardTabFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class LeaderboardTabFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {

    private val mViewModel: LeaderBoardViewModel by viewModel()
    private lateinit var selectLeaderBoardGameAdapter: SelectLeaderBoardGameAdapter
    private lateinit var leaderboardExpandableAdapter: LeaderboardByGameExpandableAdapter
    private lateinit var leaderBoardWinnerAdapter: LeaderBoardWinnerAdapter
    private var connectivityReceiver = ConnectivityReceiver() // initialize connection receiver
    private var isDataLoaded = false
    private var selectedGameId: String = "all"
    private var leaderBoardPageNo = 0
    private var limit = 10
    internal lateinit var endlessList: EndlessList
    private var mLayoutManager: RecyclerView.LayoutManager? = null
/*
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)
        initialise()
        listenToViewModel()
    }*/

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.activity_leaderboard, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
        //   listenToPref()
    }

    fun initialise() {
        selectLeaderBoardGameAdapter = SelectLeaderBoardGameAdapter(onItemClick = ::onItemClick)
        leaderBoardWinnerAdapter = LeaderBoardWinnerAdapter(onItemClick= ::onLeaderBoardItemClick)

        rvLeaderboardByGame.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false)
        rvLeaderboardByGame.adapter = selectLeaderBoardGameAdapter

        rvWinnerList.layoutManager =
            LinearLayoutManager(requireActivity())
        rvWinnerList.adapter = leaderBoardWinnerAdapter

        leaderboardExpandableAdapter = LeaderboardByGameExpandableAdapter(
            requireActivity(),
            ArrayList(),onItemClick = ::onLeaderBoardItemClick
        )

        mLayoutManager = LinearLayoutManager(requireActivity())

        rvLeaderboard.layoutManager = mLayoutManager
        rvLeaderboard.adapter = leaderboardExpandableAdapter
        initEndlessList()
    }

    private fun onLeaderBoardItemClick(id:String){
        val bundle=Bundle()
        bundle.putString("id",id)
        startActivityFromFragment<LeaderBoardProfileActivity>(bundle)
    }

    private fun initEndlessList() {
        endlessList = EndlessList(rvLeaderboard, mLayoutManager as LinearLayoutManager)
        endlessList.setStackFromEnd(true)
        endlessList.setOnLoadMoreListener(object : EndlessList.OnLoadMoreListener {

            override fun onLoadMore() {
                debugE("onLoadMore", "onLoadMore")
                fetchLeaderBoardByGame(false, selectedGameId)
            }
        })
    }

    /**
     * @desc Register receiver for check internet connection
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(connectivityReceiver, IntentFilter(AppConstants.CONNECTION_ACTION))
        ConnectivityReceiver.connectivityReceiverListener = this
    }


    /**
     * @desc Unregister receiver for check internet connection
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc method will call when tap on gamelist recyclerview from selectGameAdapter and set selected true and selected false
     */
    private fun onItemClick(position: Int) {
        leaderBoardPageNo = 0
        leaderboardExpandableAdapter.clear()

        val item = selectLeaderBoardGameAdapter.getItem(position)
        selectLeaderBoardGameAdapter.setSelected(item.id)
        selectedGameId = item.id
        tvLeaderboardByGame.text = item.name!!.plus(" " + resources.getString(R.string.leaderboard))

        llPlaceHolderNoLeaderboardData.beGone()
        llPlaceHolderNoDataWinnerList.beGone()
        rvLeaderboard.beGone()
        rvWinnerList.beGone()
        constraintLayoutNoInternet.beGone()
        constraintLayoutErrorView.beGone()
        fetchLeaderBoardByGame(true, item.id)
        initEndlessList()
    }

    private fun fetchLeaderBoardByGame(showPrimaryLoader: Boolean, gameId: String) {
        if (showPrimaryLoader) {
            pbLeaederboardWinnerList.beVisible()
        }
        llLeadeboardProgressBarDialog.beVisible()
        leaderBoardPageNo++
        mViewModel.fetchLeaderBoardByGame(gameId, leaderBoardPageNo, limit)
    }

    /**
     * @desc listen observer and observer that will receive the events
     *       Next and previous button observer for fragment page change.
     */
    private fun listenToViewModel() {

        mViewModel.gameListSuccessResponse.observe(
            requireActivity(),
            androidx.lifecycle.Observer {

                debugE("gameListSuccessResponse", Gson().toJson(it))
                pbLeaederboardGameList?.apply {
                    beGone()
                }

                val gameList: MutableList<TournamentGameRes.Datum> = ArrayList()

                val firstItem = TournamentGameRes.Datum()
                firstItem.isSelected = true
                firstItem.id = "all"
                firstItem.name = resources.getString(R.string.all_leaderboard_)
                firstItem.image = ""
                firstItem.logo = ""
                gameList.add(firstItem)

                it.data?.forEach {
                    gameList.add(it)
                }

                selectLeaderBoardGameAdapter.addAll(gameList)

                if (it.data!!.isNotEmpty()) {
                    rvLeaderboardByGame.beVisible()
                    llPlaceHolderNoDataGameList.beGone()
                    constraintLayoutNoInternet.beGone()
                } else {
                    llPlaceHolderNoDataGameList.beVisible()
                    constraintLayoutNoInternet.beGone()
                    rvLeaderboardByGame.beGone()
                }
                dismissProgressDialog()

            })

//      get game list data from api error responce
        mViewModel.gameListErrorResponse.observe(
            requireActivity(),
            androidx.lifecycle.Observer {
                pbLeaederboardGameList.beGone()
                dismissProgressDialog()
            })


        mViewModel.fetchLeaderBoardByGameSuccessResponse.observe(requireActivity(), Observer {
            debugE("fetchLeaderboardByGameSuccessResponse", Gson().toJson(it))

            endlessList.releaseLock()

            if (!it.data!!.hasNextPage) {
                endlessList.disableLoadMore()
            }

            if (it.data!!.docs.isNotEmpty()) {
                if (leaderBoardPageNo == 1) {
                    val leaderboardData: ArrayList<LeaderboardByGameModel.Doc> =
                        ArrayList()

                    if (it.data!!.docs.size > 2) {
                        leaderboardData.add(it.data!!.docs[0])
                        leaderboardData.add(it.data!!.docs[1])
                        leaderboardData.add(it.data!!.docs[2])
                    } else {
                        leaderboardData.addAll(it.data!!.docs)
                    }

                    leaderBoardWinnerAdapter.addAll(leaderboardData)
                }


                for (i in it.data!!.docs) {
                    val item = LeaderboardByGameModel.DocChild()
                    item.firstPosition = i.firstPosition
                    item.id = i.id
                    item.points = i.points
                    item.user = i.user
                    item.secondPosition = i.secondPosition
                    item.thirdPosition = i.thirdPosition
                    i.leaderboardDataChild.add(item)
                }

                leaderboardExpandableAdapter.addAll(it.data!!.docs)

                rvLeaderboard.beVisible()
                rvWinnerList.beVisible()
                llPlaceHolderNoLeaderboardData.beGone()
                llPlaceHolderNoDataWinnerList.beGone()
            } else {
                rvLeaderboard.beGone()
                rvWinnerList.beGone()
                llPlaceHolderNoLeaderboardData.beVisible()
                llPlaceHolderNoDataWinnerList.beVisible()
            }
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beGone()
            pbLeaederboardWinnerList.beGone()
            llLeadeboardProgressBarDialog.beGone()
        })

        mViewModel.fetchLeaderBoardByGameErrorResponse.observe(requireActivity(), Observer {
            debugE("fetchLeaderboardByGameErrorResponse", it.string())
//            endlessLeaderBoardList.isLoadMoreEnabled = false
            endlessList.disableLoadMore()
            pbLeaederboardWinnerList.beGone()
            llLeadeboardProgressBarDialog.beGone()
            rvLeaderboard.beGone()
            rvWinnerList.beGone()
            constraintLayoutErrorView.beVisible()
            dismissProgressDialog()
        })

    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && !isDataLoaded) {
            pbLeaederboardGameList.beVisible()
            rvLeaderboard.beGone()
            rvWinnerList.beGone()
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beGone()
            mViewModel.getGameList()
            leaderBoardPageNo = 0
            leaderboardExpandableAdapter.clear()
            selectedGameId = "all"
            fetchLeaderBoardByGame(true, "all")
        } else if (!isDataLoaded) {
            constraintLayoutNoInternet.beVisible()
            constraintLayoutErrorView.beGone()
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }
}