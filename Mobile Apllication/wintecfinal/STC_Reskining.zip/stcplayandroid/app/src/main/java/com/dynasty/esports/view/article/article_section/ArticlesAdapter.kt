package com.dynasty.esports.view.article.article_section

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.ArticleConstant
import com.dynasty.esports.databinding.AdapterArticlesDataBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beInVisible
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.CustomArticleModel
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.view.esport.HottestGameAdapter
import com.dynasty.esports.view.home.HomeArticlePostGamesAdapter

/**
 * @desc this is class will handle Articles
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ArticlesAdapter constructor(
    private var articleList: MutableList<CustomArticleModel>,
    private val onItemClick: (Int, Any,String) -> Unit = { _, _,_ -> },
    private val onVideoClick: (String) -> Unit = {  _ -> },
    private val onViewAllItemClick: (Int, String) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterArticlesDataBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterArticlesDataBinding> {
        val binding: AdapterArticlesDataBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_articles_data,
            parent,
            false
        )
        return BindingHolder(binding)

    }

    /**
     * @desc articles array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return articleList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterArticlesDataBinding>,
        position: Int
    ) {
        val data = articleList[holder.adapterPosition]

        holder.binding.textViewTitle.text = data.title?.let {
            it
        } ?: ""

        if(data.title == holder.itemView.context.getString(R.string.all_games_title)){
            holder.binding.btnViewAll.beGone()
        }else{
            holder.binding.btnViewAll.beVisible()

            holder.binding.btnViewAll.click {
                onViewAllItemClick(data.type!!,data.title.toString())
            }
        }
        /*holder.binding.btnViewAll.click {
            onViewAllItemClick(data.type!!,data.title.toString())
        }
         holder.binding.btnViewAll.beVisible()
         */
        holder.binding.constraintLayoutArticles.background = null

        when (data.type) {
            ArticleConstant.CONST_TRENDING_POST->{
                holder.binding.textViewTitle.beGone()
                holder.binding.btnViewAll.beGone()
                holder.binding.recyclerViewArticleTypes.setPadding(0,0,0,0)
                holder.binding.recyclerViewArticleTypes.layoutManager = LinearLayoutManager(
                    holder.itemView.context)
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.post {
                    val articlePostAdapter =
                        LatestTrendingPostAdapter(
                            data.trendingPostList!!,
                            onItemClick = { id: String ->
                                onItemClick(data.type, id, "")
                            })
                    holder.binding.recyclerViewArticleTypes.adapter = articlePostAdapter
                }
            }
            ArticleConstant.CONST_LATEST_ARTICLE -> {
                holder.binding.recyclerViewArticleTypes.layoutManager = LinearLayoutManager(
                    holder.itemView.context,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
                data.latestArticleList!!.sortByDescending { it.createdDate }
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.post {
                    val articlePostAdapter =
                        LatestArticleAndNewsAdapter(
                            data.latestArticleList,
                            onItemClick = { id: String ->
                                onItemClick(data.type, id, "")
                            })
                    holder.binding.recyclerViewArticleTypes.adapter = articlePostAdapter
                }
            }
            ArticleConstant.CONST_LATEST_NEWS -> {
                holder.binding.btnViewAll.beInVisible()
                holder.binding.recyclerViewArticleTypes.layoutManager = LinearLayoutManager(
                    holder.itemView.context,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
                data.newsList!!.sortByDescending { it.createdDate }
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.post {
                    val articlePostAdapter =
                        LatestArticleAndNewsAdapter(
                            data.newsList,
                            onItemClick = { id: String ->
                                onItemClick(data.type, id, "")
                            })
                    holder.binding.recyclerViewArticleTypes.adapter = articlePostAdapter
                }
            }
            ArticleConstant.CONST_POST_BY_AUTHOR -> {
                holder.binding.recyclerViewArticleTypes.layoutManager = LinearLayoutManager(
                    holder.itemView.context,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.post {
                    val articleAuthorAdapter =
                        ArticleAuthorAdapter(
                            data.postByAuthorList!!,
                            onItemClick = { id: String, title: String ->
                                onItemClick(data.type, id, title)
                            })
                    holder.binding.recyclerViewArticleTypes.adapter = articleAuthorAdapter
                }

            }
            ArticleConstant.CONST_POST_BY_GAMES -> {
                holder.binding.recyclerViewArticleTypes.layoutManager =
                    GridLayoutManager(holder.itemView.context, 2)
                holder.binding.recyclerViewArticleTypes.isNestedScrollingEnabled = false
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.post {
                    val articleTrendingPostAdapter =
                        ArticlePostGamesAdapter(
                            data.gamesList!!,
                            onItemClick = { id: String, title: String ->
                                onItemClick(data.type, id, title)
                            })

                    holder.binding.recyclerViewArticleTypes.adapter = articleTrendingPostAdapter
                }
        //        holder.binding.constraintLayoutArticles.background = holder.itemView.context.getGradientColor()
            }
            ArticleConstant.CONST_LATEST_VIDEO -> {

                holder.binding.recyclerViewArticleTypes.layoutManager =
                    LinearLayoutManager(holder.itemView.context)
                holder.binding.recyclerViewArticleTypes.setPadding(0,8,0,0)
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.isNestedScrollingEnabled = false
                holder.binding.recyclerViewArticleTypes.post {
                    val articleVideoAdapter =
                        ArticleVideoAdapter(
                            data.latestViewPostList!!,
                            onItemClick = {
                                onVideoClick(it)
                            })
                    holder.binding.recyclerViewArticleTypes.adapter = articleVideoAdapter
                }

            }
            ArticleConstant.CONST_HOME_POST_BY_GAMES -> {
                holder.binding.recyclerViewArticleTypes.layoutManager =
                    LinearLayoutManager(holder.itemView.context,
                        LinearLayoutManager.HORIZONTAL,
                        false)
                holder.binding.recyclerViewArticleTypes.isNestedScrollingEnabled = false
                holder.binding.recyclerViewArticleTypes.post {
                    val postGamesAdapter =
                        HomeArticlePostGamesAdapter(
                            data.gamesList!!,
                            onItemClick = { id: String, title: String ->
                                onItemClick(data.type, id, title)
                            })

                    holder.binding.recyclerViewArticleTypes.adapter = postGamesAdapter
                }
           //     holder.binding.constraintLayoutArticles.background = holder.itemView.context.getGradientColor()
            }
//            ArticleConstant.CONST_LATEST_ARTICLES -> {
//                holder.binding.recyclerViewArticleTypes.layoutManager =
//                    LinearLayoutManager(holder.itemView.context,
//                        LinearLayoutManager.HORIZONTAL,
//                        false)
//                val lattestArticleAdater =
//                    LattestArticleAdapter(
//                        generateGameDummyData() as MutableList<SelectGameModel>,
//                        object :
//                            LattestArticleAdapter.OnItemClickListener {
//                            override fun onItemClick(gameName: String?) {
//                                val gameSelected = gameName
//                                /*Toast.makeText(
//                                    holder.itemView.context,
//                                    gameName.toString() + " " + " article is Clicked",
//                                    Toast.LENGTH_LONG
//                                ).show()*/
//                            }
//                        })
//
//                holder.binding.recyclerViewArticleTypes.adapter = lattestArticleAdater
//            }
            ArticleConstant.CONST_HOTTEST_GAMES -> {
                holder.binding.recyclerViewArticleTypes.layoutManager =
                    LinearLayoutManager(holder.itemView.context,
                        LinearLayoutManager.HORIZONTAL,
                        false)
                holder.binding.recyclerViewArticleTypes.isNestedScrollingEnabled = false

                val hottestGameAdapter =
                    HottestGameAdapter(
                        data.hottestPostList as MutableList<HottestPostArticleModel.DataModel>,
                        object :
                            HottestGameAdapter.OnItemClickListener {
                            override fun onItemClick(gameName: String?) {
                                val gameSelected = gameName
                                /*Toast.makeText(
                                    holder.itemView.context,
                                    gameName.toString() + " " + "hottest post is Clicked",
                                    Toast.LENGTH_LONG
                                ).show()*/
                            }
                        })

                holder.binding.recyclerViewArticleTypes.adapter = hottestGameAdapter
            }

            ArticleConstant.CONST_ALL_GAMES -> {
                holder.binding.recyclerViewArticleTypes.layoutManager =
                    GridLayoutManager(holder.itemView.context, 3)
                holder.binding.recyclerViewArticleTypes.isNestedScrollingEnabled = false
                holder.binding.recyclerViewArticleTypes.setHasFixedSize(true)
                holder.binding.recyclerViewArticleTypes.post {
                    val articleTrendingPostAdapter =
                        ArticlePostGamesAdapter(
                            data.gamesList!!,
                            onItemClick = { id: String, title: String ->
                                onItemClick(data.type, id, title)
                            })

                    holder.binding.recyclerViewArticleTypes.adapter = articleTrendingPostAdapter
                }
                //        holder.binding.constraintLayoutArticles.background = holder.itemView.context.getGradientColor()
            }
        }
    }




}