package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName





 class UserModel{
     @SerializedName("message")
     @Expose
     val message: String? = null

     @SerializedName("data")
     @Expose
     val data: UserData? = null

     class UserData{
         @SerializedName("phoneisVerified")
         @Expose
          val phoneisVerified: Boolean? = null

         @SerializedName("emailisVerified")
         @Expose
          val emailisVerified: Boolean = false

         @SerializedName("Status")
         @Expose
          val status: Int? = null

         @SerializedName("identifiers")
         @Expose
          val identifiers: MutableList<IdentifierModel>? = null

         @SerializedName("firstLogin")
         @Expose
          val firstLogin: Int? = null

         @SerializedName("isAuthor")
         @Expose
          val isAuthor: Int? = null

         @SerializedName("isInfluencer")
         @Expose
          val isInfluencer: Int? = null

         @SerializedName("isVerified")
         @Expose
          val isVerified: Int? = null

         @SerializedName("organizerRating")
         @Expose
          val organizerRating: Double? = null

         @SerializedName("_id")
         @Expose
          val id: String? = null

         @SerializedName("accountType")
         @Expose
          val accountType: String? = null

         @SerializedName("fullName")
         @Expose
          val fullName: String? = null

         @SerializedName("phoneNumber")
         @Expose
          val phoneNumber: String? = null

         @SerializedName("email")
         @Expose
          val email: String? = null

         @SerializedName("profilePicture")
         @Expose
          val profilePicture: String? = null

         @SerializedName("createdBy")
         @Expose
          val createdBy: String? = null

         @SerializedName("updatedBy")
         @Expose
          val updatedBy: String? = null

         @SerializedName("createdOn")
         @Expose
          val createdOn: String? = null

         @SerializedName("updatedOn")
         @Expose
          val updatedOn: String? = null

         @SerializedName("text")
         @Expose
          val text: String? = null

         @SerializedName("__v")
         @Expose
          val v: Int? = null

         @SerializedName("accountDetail")
         @Expose
          val accountDetail: AccountDetailModel? = null

         @SerializedName("accountId")
         @Expose
          val accountId: String? = null

         @SerializedName("state")
         @Expose
          val state: String? = null

         @SerializedName("country")
         @Expose
          val country: String? = null

         @SerializedName("gender")
         @Expose
          val gender: String? = null

         @SerializedName("martialStatus")
         @Expose
          val martialStatus: String? = null

         @SerializedName("postalCode")
         @Expose
          val postalCode: String? = null

         @SerializedName("profession")
         @Expose
          val profession: String? = null

         @SerializedName("shortBio")
         @Expose
          val shortBio: String? = null

         @SerializedName("progress")
         @Expose
          val progress: Int? = null

         @SerializedName("parentalStatus")
         @Expose
         val parentalStatus: String? = null

         @SerializedName("dob")
         @Expose
         val dob: String? = null

         @SerializedName("preference")
         @Expose
         val preference: PreferenceModel? = null
     }

     class PreferenceModel{

         @SerializedName("followingCount")
         @Expose
         val followingCount: Int? = null

         @SerializedName("followersCount")
         @Expose
         val followersCount: Int? = null
     }

     class IdentifierModel{
         @SerializedName("_id")
         @Expose
         val _id: String? = null

         @SerializedName("idenType")
         @Expose
         val idenType: String? = null

         @SerializedName("uuid")
         @Expose
         val uuid: String? = null
     }

     class AccountDetailModel{

         @SerializedName("reward")
         @Expose
          val reward: Int? = null

         @SerializedName("totalSpent")
         @Expose
          val totalSpent: Int? = null

         @SerializedName("status")
         @Expose
          val status: String? = null

         @SerializedName("_id")
         @Expose
          val id: String? = null

         @SerializedName("user")
         @Expose
          val user: String? = null

         @SerializedName("userDetail")
         @Expose
          val userDetail: String? = null

         @SerializedName("createdBy")
         @Expose
          val createdBy: String? = null

         @SerializedName("updatedBy")
         @Expose
          val updatedBy: String? = null

         @SerializedName("createdOn")
         @Expose
          val createdOn: String? = null

         @SerializedName("updatedOn")
         @Expose
          val updatedOn: String? = null

         @SerializedName("__v")
         @Expose
          val v: Int? = null
     }
 }