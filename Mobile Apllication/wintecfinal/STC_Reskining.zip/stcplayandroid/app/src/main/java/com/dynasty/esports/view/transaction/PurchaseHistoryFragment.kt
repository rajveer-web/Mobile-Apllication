package com.dynasty.esports.view.transaction

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.isOnline
import com.dynasty.esports.models.RewardsHistoryModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.TransactionHistoryViewModel
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class handle purchase history view
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class PurchaseHistoryFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    private var type: String = ""
    private lateinit var rewardHistoryAdapter: RewardHistoryAdapter
    private val mViewModel: TransactionHistoryViewModel by viewModel()
    private var rewardsHistoryList: MutableList<RewardsHistoryModel.DataModel> = mutableListOf()
    private var connectivityReceiver = ConnectivityReceiver()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.recycler_progress_bar_view, container, false)
    }

    // get parameter from arguments
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /**
         * Get data from arguments
         */
        arguments?.apply {
            type = this.getString("type").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        listenToViewModel()
    }

    /**
     * @desc Initialize view
     */
    private fun initView() {
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        rewardHistoryAdapter = RewardHistoryAdapter(rewardsHistoryList)
        commonRecyclerView.adapter = rewardHistoryAdapter
    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make json object for API and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.rewardHistorySuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beVisible()
            it?.data?.apply {
                rewardsHistoryList.addAll(this)
                rewardHistoryAdapter.notifyDataSetChanged()
            }
            if (rewardsHistoryList.isNullOrEmpty()) {
                constraintLayoutNoData.beVisible()
            } else {
                constraintLayoutNoData.beGone()
            }

        })
        mViewModel.rewardHistoryErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beVisible()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beGone()
        })
        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            if (requireActivity().isOnline()) {
                linearLayoutProgressBar.beGone()
                constraintLayoutNoData.beGone()
                constraintLayoutErrorView.beVisible()
                constraintLayoutNoInternet.beGone()
                commonRecyclerView.beGone()
            }
        })

        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it) {
                logOut()
            }
        })
    }

    /**
     * @desc make fragment instance and pass parameter
     */
    companion object {
        fun newInstance(type: String): Fragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = PurchaseHistoryFragment()
            fragment.arguments = args
            return fragment
        }
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }


    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && rewardsHistoryList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            if (type == "reward") {
                mViewModel.fetchRewardsHistory()
            } else {
                linearLayoutProgressBar.beGone()
                constraintLayoutNoData.beVisible()
            }
        } else if (rewardsHistoryList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beVisible()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
        }
    }
}