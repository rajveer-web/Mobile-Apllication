package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class SocialLoginRequest (
    @field:SerializedName("provider")
    var provider: String? = null,

    @field:SerializedName("token")
    var token:String? = null,

    @field:SerializedName("type")
var type:String? = null
)