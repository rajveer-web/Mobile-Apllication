package com.dynasty.esports.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class ProfileContentModel {
    @SerializedName("message")
    @Expose
    val message: String? = null

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: DataModel? = null

    class DataModel {
        @SerializedName("game")
        @Expose
        val game: MutableList<ContentModel>? = null

        @SerializedName("genre")
        @Expose
        val genre: MutableList<ContentModel>? = null

        @SerializedName("prefer")
        @Expose
        val prefer: MutableList<ContentModel>? = null
    }

    class ContentModel {
        @SerializedName("_id")
        @Expose
        val id: String? = null

        @SerializedName("name")
        @Expose
        val name: String? = null

        @SerializedName("logo")
        @Expose
        val logo: String? = null

        @SerializedName("image")
        @Expose
        val image: String? = null
    }

}