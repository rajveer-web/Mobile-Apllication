package com.dynasty.esports.view.tournamet.tournamet_detail

import android.content.IntentFilter
import android.os.Bundle
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.DiscussionComment
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.ArticleDetailViewModel
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_article_detail.*

import kotlinx.android.synthetic.main.fragment_upcoming_discussion.*
import kotlinx.android.synthetic.main.fragment_upcoming_discussion.relativeLayoutLogin
import kotlinx.android.synthetic.main.fragment_upcoming_discussion.textViewLoginFirst
import org.json.JSONObject
import org.koin.androidx.viewmodel.ext.android.viewModel

class TournamentDiscussionFragment : BaseFragment(),  ManageRedirectReceiver.NotifyActivityListener {

    lateinit var discussionCommentAdapter: DiscussionCommentAdapter
    private var commentList: MutableList<DiscussionComment.DataModel> = mutableListOf()
    private val mViewModel: ArticleDetailViewModel by viewModel()
    private var positionComment: Int = 0
    private var replayCommentPosition: Int = 0
    private var isReplyLikeComment: Boolean = false
    private var commentsLikeID: String = ""
    private var manageRedirectReceiver = ManageRedirectReceiver()

    private lateinit var gameItem: TournamentDetailRes

    lateinit var loginUserModel: UserModel.UserData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalBroadcastManager.getInstance(requireContext())
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_upcoming_discussion, container, false)
    }

    companion object {
        fun newInstance(gameItem: TournamentDetailRes): Fragment {
            val args = Bundle()
            args.putParcelable("data", gameItem)
            val fragment = TournamentDiscussionFragment()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
    }

    fun initialise() {
        arguments?.apply {
            gameItem = this.getParcelable<TournamentDetailRes>("data")!!
        }

        discussionCommentAdapter = DiscussionCommentAdapter(
            commentList,
            onReplyClick = ::onReplayClick,
            onLikeClick = ::onLikeComment,
            postReplyComment = ::onPostReplayComment
        )
        rvDiscussion.adapter = discussionCommentAdapter

        manageUIAfterBeforeLogin()


        rvDiscussion.layoutManager =
            LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)

        mViewModel.getDiscussionComment(sharedPreferences.id, gameItem.data!!.id!!)


//        Glide.with(context).load().into(imageViewUser)

        discussion_reply_txt.click {
            mViewModel.checkValidation(discussion_comment_edit_text.text.toString())
        }

        if(sharedPreferences.checkUserLoggedInOrNot()) {
            if ((activity as TournamentDetailActivity).isAlreadyJoined) {
                llJoined.beVisible()
                llNotJoin.beGone()
            } else {
                llJoined.beGone()
                llNotJoin.beVisible()
            }
        }else{
            llNotJoin.beGone()
            llJoined.beVisible()
            relativeLayoutLogin.beVisible()
        }

        textViewLoginFirst.makeSpannableMultipleString(requireContext(),
            resources.getString(R.string.please_login_or_register_to_add_comment),
            if (LocaleHelper.getLanguage(requireContext()) == "en") {
                7
            } else {
                5
            },
            if (LocaleHelper.getLanguage(requireContext()) == "en") {
                12
            } else {
                14
            },
            if (LocaleHelper.getLanguage(requireContext()) == "en") {
                16
            } else {
                20
            },
            if (LocaleHelper.getLanguage(requireContext()) == "en") {
                24
            } else {
                29
            },
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    redirectType = "tournament_discussion"
                    startActivityFromFragment<PhoneSignInActivity>()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            },
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    redirectType = "tournament_discussion"
                    startActivityFromFragment<PhoneNumRegistrationActivity>()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })
    }

    fun listenToViewModel() {

        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {

            when (it) {
                "all" -> {

                }
                "comment" -> {
                    resources.getString(R.string.no_internet_message)
                        .showToast(requireContext())
                }
            }
            dismissProgressDialog()
        })

        mViewModel.discussionPostCommentSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            discussion_comment_edit_text.setText("")
            commentList.add(it.data!!)
            discussionCommentAdapter.notifyItemInserted(commentList.size - 1)
        })

        mViewModel.discussionPostCommentErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            it.string().getMessageFromObject("message").showToast(requireContext())
        })

        mViewModel.isFormValid.observe(viewLifecycleOwner, Observer {
            launchProgressDialog()
            val jsonObject = JsonObject()
            jsonObject.addProperty("comment", discussion_comment_edit_text.text.toString())
            jsonObject.addProperty("userId", loginUserModel.id)
            jsonObject.addProperty("objectId", gameItem.data!!.id)
            jsonObject.addProperty("objectType", "tournament")
            mViewModel.discussionPostComment(jsonObject)
        })
        mViewModel.validationLiveData.observe(viewLifecycleOwner, Observer {
            if (it == 0) {
                resources.getString(R.string.enter_comment_error)
                    .showToast(requireContext())
            }
        })

        mViewModel.getDiscussionCommentListPostSuccessResponse.observe(
            viewLifecycleOwner,
            Observer {
                dismissProgressDialog()
                commentList.clear()
                it.data?.apply {
                    commentList.addAll(this)
                }


            })

        mViewModel.getDiscussionCommentListPostErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
        })

        mViewModel.makeJsonObjectForArticle.observe(requireActivity(), Observer {
            launchProgressDialog()
            when (it.first) {
                "post", "replies_comment" -> {
                    mViewModel.postCommentDiscussion(it.first, it.second)
                }

                "article", "comment" -> {
                    mViewModel.likeCommentAndArticle(it.second, it.first)
                }
                "updateLikeComment" -> {
                    mViewModel.updateLikeComment(commentsLikeID, it.second, "comment")
                }
            }
        })


        mViewModel.postCommentDiscussionSuccessResponse.observe(requireActivity(), Observer {
            dismissProgressDialog()
            when (it.first) {
                "post" -> {
                    discussion_comment_edit_text.setText("")
                    commentList.add(it.second.data!!)
                    discussionCommentAdapter.notifyItemInserted(commentList.size - 1)
                }
                else -> {
                    commentList[replayCommentPosition].replies?.add(it.second.data!!)
                    discussionCommentAdapter.notifyItemChanged(replayCommentPosition)
                    discussionCommentAdapter.removeReplayView(replayCommentPosition + 1)
                }
            }
        })

        mViewModel.postCommentErrorResponse.observe(requireActivity(), Observer {
            dismissProgressDialog()
            it.second.string().getMessageFromObject("message")
                .showToast(requireActivity())

        })

        mViewModel.likeCommentSuccessResponse.observe(requireActivity(), Observer {
            dismissProgressDialog()
            if (it.second == "comment") {
                if (isReplyLikeComment) {
                    val comment = commentList[positionComment].replies?.get(replayCommentPosition)!!
                    if (comment.type != -1) {
                        if (comment.type == 0) {
                            comment.type = 1
                            comment.totalLikes?.apply {
                                comment.totalLikes = this + 1
                            }
                        } else {
                            comment.type = 0
                            comment.totalLikes?.apply {
                                comment.totalLikes = this - 1
                            }
                        }
                    } else {
                        val linkedId =
                            JSONObject(it.first.string()).getJSONObject("data").getString("likeId")
                        comment.type = 1
                        comment.totalLikes = 1
                        comment.likeId = linkedId
                    }
                    commentList[positionComment].replies?.set(replayCommentPosition, comment)

                    discussionCommentAdapter.notifyItemChanged(positionComment)

                } else {
                    val comment = commentList[positionComment]
                    if (comment.type != -1) {
                        if (comment.type == 0) {
                            comment.type = 1
                            comment.totalLikes?.apply {
                                comment.totalLikes = this + 1
                            }
                        } else {
                            comment.type = 0
                            comment.totalLikes?.apply {
                                comment.totalLikes = this - 1
                            }
                        }
                    } else {
                        val linkedId =
                            JSONObject(it.first.string()).getJSONObject("data").getString("likeId")

                        comment.type = 1
                        comment.totalLikes = 1
                        comment.likeId = linkedId

                    }
                    commentList[positionComment] = comment
                    discussionCommentAdapter.notifyItemChanged(positionComment)
                }

            }
        })

        mViewModel.likeCommentErrorResponse.observe(requireActivity(), Observer {
            dismissProgressDialog()
        })

    }

    private fun onReplayClick(position: Int) {

//        if(articleCommentAdapter.getReplyPosition()!=-1){
//            if(position!=articleCommentAdapter.getReplyPosition()) {
//                articleCommentAdapter.addReplayView(position)
//            }
//        }else {
        if (sharedPreferences.checkUserLoggedInOrNot()) {
            discussionCommentAdapter.addReplayView(position)
        }else{
            launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
        }

//        }
    }

    private fun onLikeComment(
        position: Int, id: String, type: Int, likeId: String,
        isReplyComment: Boolean,
        replyPosition: Int
    ) {

        if (sharedPreferences.checkUserLoggedInOrNot()) {
            positionComment = if (replyPosition != -1) {
                replayCommentPosition = position
                replyPosition
            } else {
                position
            }

            isReplyLikeComment = isReplyComment
            if (type == -1) {
                mViewModel.makeJsonObjectForLikeComment(id, sharedPreferences.id, "comment")
            } else {
                commentsLikeID = likeId
                mViewModel.makeJsonObjectForUpdateLike("updateLikeComment", if (type == 1) 0 else 1)
            }
        }else{
            launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
        }

    }

    /**
     * @desc method will call when tap on post comment button from comment adapter
     * @param comment comment message
     * @param position adapter click item position
     */
    private fun onPostReplayComment(comment: String, position: Int) {
        if (sharedPreferences.checkUserLoggedInOrNot()) {
            replayCommentPosition = position - 1
            mViewModel.makeJsonObjectForRepliesComment(
                "replies_comment",
                comment,
                commentList[replayCommentPosition].id.toString(),
                sharedPreferences.id
            )
        }else{
            launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
        }

    }

    private fun manageUIAfterBeforeLogin(){
        if (sharedPreferences.checkUserLoggedInOrNot()) {
            linearLayoutAddNewComment.beVisible()
            relativeLayoutLogin.beGone()
            loginUserModel = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
            textViewUserName.text = loginUserModel.fullName
            requireActivity().loadImageFromServer(
                loginUserModel.profilePicture.toString(),
                imageViewUser
            )
        }else{
            linearLayoutAddNewComment.beGone()
            relativeLayoutLogin.beVisible()
        }
        discussionCommentAdapter.updateUserData()
    }

    private fun launchLoginPopUp(msg: String) {
        displayCustomAlertDialog(msg,
            isCancelable = true,
            isCloseShow = true,
            positiveText = resources.getString(R.string.login),
            positiveClick = {
                it.dismiss()
                redirectType = "tournament_discussion"
                startActivityFromFragment<PhoneSignInActivity>()
            },
            negativeText = resources.getString(R.string.str_cancel),
            negativeClick = {
                it.dismiss()
            }, onCloseClick = {
                it.dismiss()
            })
    }

    override fun onNotify(notifyType: String) {
        if(notifyType=="tournament_discussion"){
            manageUIAfterBeforeLogin()
            (activity as TournamentDetailActivity).onNotify("tournament_detail_discussion")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(requireContext()).unregisterReceiver(this)
        }
    }

}