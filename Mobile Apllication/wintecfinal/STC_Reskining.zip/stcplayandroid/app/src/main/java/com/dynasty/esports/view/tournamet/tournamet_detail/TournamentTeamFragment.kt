package com.dynasty.esports.view.tournamet.tournamet_detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R/*
import com.dynasty.esports.activities.DashboardActivity
import com.dynasty.esports.adapters.TournamntTeamAdapter*/
import com.dynasty.esports.models.TeamListDetail
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamntTeamAdapter


class TournamentTeamFragment : Fragment() {

    lateinit var tournmentTeamList : RecyclerView
    lateinit var tournamenentTeamAdapter: TournamntTeamAdapter
    var dataList: ArrayList<TeamListDetail> = ArrayList<TeamListDetail>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tournament_team, container, false)
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
    }

    fun initialise(){
        tournmentTeamList = requireActivity().findViewById(R.id.tournament_team_list)
        tournmentTeamList.layoutManager = GridLayoutManager(context, 3)
        tournmentTeamList.adapter =
            TournamntTeamAdapter(
                teamListDummyData() as MutableList<TeamListDetail>,
                object :
                    TournamntTeamAdapter.OnItemClickListener {
                    override fun onItemClick(playerList: ArrayList<String>?) {
                        ////
                        /*Toast.makeText(
                            context,
                            " team selected",
                            Toast.LENGTH_LONG
                        ).show()*/
                        //NewUpcomingDetailFrragment().replaceFragment(TeamPlayerListFragment(),null,"",false,false)
                        // DashboardActivity.navController.navigate(R.id.teamPlayerList)
                        ////
                        /* val gameSelected = gameName
                            Toast.makeText(
                                context,
                                gameName.toString()+ " " + " team selected",
                                Toast.LENGTH_LONG
                            ).show()*/
                    }
                })
    }

    private fun teamListDummyData(): List<TeamListDetail> {
        val listOfMovie = mutableListOf<TeamListDetail>()
        val arrayList1 = ArrayList<String>(5)
        arrayList1.add("Ajay")
        arrayList1.add("Vijay")
        arrayList1.add("Prakash")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        var movieModel = TeamListDetail("Avengers", R.drawable.ic_launcher_background, "8",arrayList1)
        listOfMovie.add(movieModel)

        val arrayList2 = ArrayList<String>(5)
        arrayList1.add("Sonali")
        arrayList1.add("Monali")
        arrayList1.add("Amrpali")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        movieModel = TeamListDetail("Ultron" ,R.drawable.ic_launcher_background, "5",arrayList2)
        listOfMovie.add(movieModel)

        val arrayList3 = ArrayList<String>(5)
        arrayList1.add("James")
        arrayList1.add("Bonnd")
        arrayList1.add("Prakash")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        movieModel = TeamListDetail("Iron Man 3", R.drawable.ic_launcher_background, "9",arrayList3)
        listOfMovie.add(movieModel)

        val arrayList4 = ArrayList<String>(5)
        arrayList1.add("James")
        arrayList1.add("Bonnd")
        arrayList1.add("Prakash")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        movieModel = TeamListDetail("Iron Man 3", R.drawable.ic_launcher_background, "9",arrayList4)
        listOfMovie.add(movieModel)

        val arrayList5 = ArrayList<String>(5)
        arrayList1.add("James")
        arrayList1.add("Bonnd")
        arrayList1.add("Prakash")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        movieModel = TeamListDetail("Iron Man 3", R.drawable.ic_launcher_background, "9",arrayList5)
        listOfMovie.add(movieModel)

        val arrayList6 = ArrayList<String>(5)
        arrayList1.add("James")
        arrayList1.add("Bonnd")
        arrayList1.add("Prakash")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        movieModel = TeamListDetail("Iron Man 3", R.drawable.ic_launcher_background, "9",arrayList6)
        listOfMovie.add(movieModel)

        val arrayList7 = ArrayList<String>(5)
        arrayList1.add("James")
        arrayList1.add("Bonnd")
        arrayList1.add("Prakash")
        arrayList1.add("Rohan")
        arrayList1.add("Vijay")

        movieModel = TeamListDetail("Iron Man 3", R.drawable.ic_launcher_background, "9",arrayList7)
        listOfMovie.add(movieModel)

        return listOfMovie
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            TournamentTeamFragment()
    }
}