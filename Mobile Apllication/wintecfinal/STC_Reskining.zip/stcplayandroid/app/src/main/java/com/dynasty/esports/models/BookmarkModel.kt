package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class BookmarkModel {

    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: MutableList<DataModel>? = null

    class DataModel{
        @SerializedName("articleBookmarks")
        @Expose
         val articleBookmarks: MutableList<ArticleBookmark>? = null

        @SerializedName("videoLibrary")
        @Expose
         val videoLibrary: MutableList<VideoBookMark>? = null

        @SerializedName("_id")
        @Expose
         val id: String? = null
    }

    class ArticleBookmark{
        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("content")
        @Expose
         val content: TitleModel? = null

        @SerializedName("shortDescription")
        @Expose
         val shortDescription: TitleModel? = null

        @SerializedName("genre")
        @Expose
         val genre: MutableList<String>? = null

        @SerializedName("platform")
        @Expose
         val platform: MutableList<String>? = null

        @SerializedName("tags")
        @Expose
         val tags: MutableList<String>? = null

        @SerializedName("status")
        @Expose
         val status: String? = null

        @SerializedName("views")
        @Expose
         val views: Int? = null

        @SerializedName("game")
        @Expose
         val game: String? = null

        @SerializedName("minRead")
        @Expose
         val minRead: Int? = null

        @SerializedName("location")
        @Expose
         val location: String? = null

        @SerializedName("isSponsor")
        @Expose
         val isSponsor: Boolean? = null

        @SerializedName("isInfluencer")
        @Expose
         val isInfluencer: Boolean? = null

        @SerializedName("isInfluencerHighlight")
        @Expose
         val isInfluencerHighlight: Boolean? = null

        @SerializedName("slug")
        @Expose
         val slug: String? = null

        @SerializedName("category")
        @Expose
         val category: String? = null

        @SerializedName("image")
        @Expose
         val image: String? = null

        @SerializedName("gameDetails")
        @Expose
         val gameDetails: String? = null

        @SerializedName("author")
        @Expose
         val author: String? = null

        @SerializedName("articleStatus")
        @Expose
         val articleStatus: String? = null

        @SerializedName("s3RefKey")
        @Expose
         val s3RefKey: String? = null

        @SerializedName("createdBy")
        @Expose
         val createdBy: String? = null

        @SerializedName("createdDate")
        @Expose
         val createdDate: String? = null

        @SerializedName("createdOn")
        @Expose
         val createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
         val updatedOn: String? = null

        @SerializedName("fullText")
        @Expose
         val fullText: String? = null

        @SerializedName("__v")
        @Expose
         val v: Int? = null

        @SerializedName("id")
        @Expose
         val id: String? = null
    }

    class VideoBookMark{

        @SerializedName("_id")
        @Expose
         val id: String? = null

        @SerializedName("title")
        @Expose
         val title: TitleModel? = null

        @SerializedName("description")
        @Expose
         val description: TitleModel? = null

        @SerializedName("thumbnailUrl")
        @Expose
         val thumbnailUrl: String? = null

        @SerializedName("youtubeUrl")
        @Expose
        val youtubeUrl: String? = null
    }
}