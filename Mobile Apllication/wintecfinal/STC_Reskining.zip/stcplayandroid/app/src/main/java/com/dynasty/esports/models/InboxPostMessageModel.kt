package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class InboxPostMessageModel {
    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("message")
    @Expose
    val message: String? = null

    @SerializedName("data")
    @Expose
    val data: InboxMessagesListModel.DataModel? = null
}