package com.dynasty.esports.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineExceptionHandler
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * @desc this class will handle Error Exception
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

open class BaseViewModel : ViewModel() {
    // define MutableLiveData for emit observer
    val noInternetException = MutableLiveData<String>()
    val timeOutException = MutableLiveData<Boolean>()
    val unAuthorizationException = MutableLiveData<Boolean>()

    /**
     * @desc Method will use for handle timeout and connection exception from API.
     * @param type- type for identify API call and  handle error using type
     */
    fun apiException(type: String = ""): CoroutineExceptionHandler {
        return CoroutineExceptionHandler { _, throwable ->
            Log.d("Hello",throwable.message.toString())
            when (throwable) {
                is SocketTimeoutException -> timeOutException.postValue(true)
                is ConnectException, is HttpException, is UnknownHostException -> noInternetException.postValue(
                    type
                )
            }
        }
    }


}