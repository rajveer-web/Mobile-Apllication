package com.dynasty.esports.models

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class GetTournmentModel : Parcelable {

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: MutableList<DataModel>? = null

    @SerializedName("message")
    @Expose
    val message: String = ""

    @SerializedName("totals")
    @Expose
    val totals: TotalsModel? = null

    @Parcelize
    class DataModel : Parcelable {

        @SerializedName("sponsors")
        @Expose
        var sponsors: MutableList<Sponsors>? = null

        @SerializedName("isSeeded")
        @Expose
        var isSeeded: Boolean? = null

        @SerializedName("stream")
        @Expose
        var stream: MutableList<StreamModel>? = null


        @SerializedName("venueAddress")
        @Expose
        var venueAddress: List<VenueAddress> = ArrayList<VenueAddress>()

        @SerializedName("regionsAllowed")
        @Expose
        var regionsAllowed: List<String> = ArrayList()


        @SerializedName("status")
        @Expose
        val status: String = ""

        @SerializedName("isFinished")
        @Expose
        val isFinished: Boolean? = null

        @SerializedName("_id")
        @Expose
        var id: String = ""

        @SerializedName("name")
        @Expose
        var name: String = ""

        @SerializedName("url")
        @Expose
        val url: String = ""

        @SerializedName("participantType")
        @Expose
        val participantType: String = ""

        @SerializedName("startDate")
        @Expose
        var startDate: String = ""

        @SerializedName("startTime")
        @Expose
        var startTime: String = ""

        @SerializedName("isPaid")
        @Expose
        var isPaid: Boolean = false

        @SerializedName("isCheckInRequired")
        @Expose
        val isCheckInRequired: String = ""

        @SerializedName("description")
        @Expose
        var description: String = ""

        @SerializedName("rules")
        @Expose
        var rules: String = ""

        @SerializedName("criticalRules")
        @Expose
        var criticalRules: String = ""

        @SerializedName("isPrize")
        @Expose
        val isPrize: Boolean? = null

        @SerializedName("faqs")
        @Expose
        var faqs: String = ""

        @SerializedName("schedule")
        @Expose
        val schedule: String = ""

        @SerializedName("isIncludeSponsor")
        @Expose
        val isIncludeSponsor: Boolean? = null

        @SerializedName("tournamentType")
        @Expose
        var tournamentType: String = ""

        @SerializedName("isScreenshotRequired")
        @Expose
        val isScreenshotRequired: Boolean? = null

        @SerializedName("isShowCountryFlag")
        @Expose
        val isShowCountryFlag: Boolean? = null

        @SerializedName("isSpecifyAllowedRegions")
        @Expose
        val isSpecifyAllowedRegions: String = ""

        @SerializedName("isParticipantsLimit")
        @Expose
        val isParticipantsLimit: Boolean? = null

        @SerializedName("scoreReporting")
        @Expose
        val scoreReporting: Int? = null

        @SerializedName("invitationLink")
        @Expose
        val invitationLink: String = ""

        @SerializedName("youtubeVideoLink")
        @Expose
        val youtubeVideoLink: String = ""

        @SerializedName("facebookVideoLink")
        @Expose
        val facebookVideoLink: String = ""

        @SerializedName("contactDetails")
        @Expose
        val contactDetails: String = ""

        @SerializedName("twitchVideoLink")
        @Expose
        val twitchVideoLink: String = ""

        @SerializedName("visibility")
        @Expose
        val visibility: Int? = null

        @SerializedName("checkInStartDate")
        @Expose
        val checkInStartDate: String = ""

        @SerializedName("checkInEndDate")
        @Expose
        val checkInEndDate: String = ""

        @SerializedName("banner")
        @Expose
        val banner: String = ""

        @SerializedName("maxParticipants")
        @Expose
        val maxParticipants: Int? = null

        @SerializedName("bracketType")
        @Expose
        var bracketType: String = ""

        @SerializedName("noOfSet")
        @Expose
        val noOfSet: Int? = null

        @SerializedName("contactOn")
        @Expose
        val contactOn: String = ""

        @SerializedName("firstPrize")
        @Expose
        var firstPrize: Int = 0

        @SerializedName("secondPrize")
        @Expose
        var secondPrize: Int = 0

        @SerializedName("thirdPrize")
        @Expose
        var thirdPrize: Int = 0

        @SerializedName("prizeCurrency")
        @Expose
        var prizeCurrency: String = ""

        @SerializedName("teamSize")
        @Expose
        val teamSize: Int = 0

        @SerializedName("slug")
        @Expose
        val slug: String = ""

        @SerializedName("country")
        @Expose
        val country: String = ""

        @SerializedName("endDate")
        @Expose
        val endDate: String = ""

        @SerializedName("createdBy")
        @Expose
        val createdBy: String = ""

        @SerializedName("updatedBy")
        @Expose
        val updatedBy: String = ""

        @SerializedName("tournamentStatus")
        @Expose
        val tournamentStatus: String = ""

        @SerializedName("createdOn")
        @Expose
        val createdOn: String = ""

        @SerializedName("updatedOn")
        @Expose
        val updatedOn: String = ""

        @SerializedName("fullText")
        @Expose
        val fullText: String = ""

        @SerializedName("__v")
        @Expose
        val __v: String = ""

        @SerializedName("organizerDetail")
        @Expose
        val organizerDetail: OrganizerDetail? = null

        @SerializedName("gameDetail")
        @Expose
        var gameDetail: GameDetail? = null

        var isUpcomming: Boolean = false

        var isLoadMore:Boolean=false
    }

    class GameDetail {
        @SerializedName("_id")
        @Expose
        val _id: String = ""

        @SerializedName("name")
        @Expose
        var name: String = ""

        @SerializedName("logo")
        @Expose
        var logo: String = ""

        @SerializedName("image")
        @Expose
        var image: String = ""

        @SerializedName("activeTournament")
        @Expose
        val activeTournament: String = ""

        @SerializedName("bracketTypes")
        @Expose
        val bracketTypes: BracketTypes? = null

        @SerializedName("platforms")
        @Expose
        val platforms: Platforms? = null

        @SerializedName("__v")
        @Expose
        val __v: String = ""

        var isSelected: Boolean = false
    }

    class Platforms {
        @SerializedName("data")
        @Expose
        val platformData: MutableList<PlatformData>? = null
    }

    class PlatformData {
        @SerializedName("id")
        @Expose
        val id: Int? = null

        @SerializedName("name")
        @Expose
        val name: String = ""
    }

    class BracketTypes {
        @SerializedName("simple")
        @Expose
        val simple: Boolean? = null

        @SerializedName("double")
        @Expose
        val double: Boolean? = null

        @SerializedName("single")
        @Expose
        val single: Boolean? = null

        @SerializedName("round-robin")
        @Expose
        val round_robin: Boolean? = null
    }

    class OrganizerDetail {

        @SerializedName("phoneisVerified")
        @Expose
        val phoneisVerified: Boolean? = null

        @SerializedName("emailisVerified")
        @Expose
        val emailisVerified: Boolean? = null

        @SerializedName("Status")
        @Expose
        val Status: Int? = null

        @SerializedName("firstLogin")
        @Expose
        val firstLogin: Int? = null

        @SerializedName("isAuthor")
        @Expose
        val isAuthor: Int? = null

        @SerializedName("isInfluencer")
        @Expose
        val isInfluencer: Int? = null

        @SerializedName("isVerified")
        @Expose
        val isVerified: Int? = null

        @SerializedName("organizerRating")
        @Expose
        val organizerRating: Double? = null

        @SerializedName("_id")
        @Expose
        val _id: String = ""

        @SerializedName("accountType")
        @Expose
        val accountType: String = ""

        @SerializedName("fullName")
        @Expose
        val fullName: String = ""

        @SerializedName("phoneNumber")
        @Expose
        val phoneNumber: String = ""

        @SerializedName("email")
        @Expose
        val email: String = ""

        @SerializedName("profilePicture")
        @Expose
        val profilePicture: String = ""

        @SerializedName("createdBy")
        @Expose
        val createdBy: String = ""

        @SerializedName("updatedBy")
        @Expose
        val updatedBy: String = ""

        @SerializedName("createdOn")
        @Expose
        val createdOn: String = ""

        @SerializedName("updatedOn")
        @Expose
        val updatedOn: String = ""

        @SerializedName("text")
        @Expose
        val text: String = ""

        @SerializedName("__v")
        @Expose
        val __v: Int? = null

        @SerializedName("accountDetail")
        @Expose
        val accountDetail: String = ""

        @SerializedName("accountId")
        @Expose
        val accountId: String = ""

        @SerializedName("phoneOTP")
        @Expose
        val phoneOTP: Int? = null

        @SerializedName("phoneOTPexp")
        @Expose
        val phoneOTPexp: String = ""

        @SerializedName("state")
        @Expose
        val state: String = ""

        @SerializedName("country")
        @Expose
        val country: String = ""

        @SerializedName("gender")
        @Expose
        val gender: String = ""

        @SerializedName("martialStatus")
        @Expose
        val martialStatus: String = ""

        @SerializedName("postalCode")
        @Expose
        val postalCode: String = ""

        @SerializedName("profession")
        @Expose
        val profession: String = ""

        @SerializedName("shortBio")
        @Expose
        val shortBio: String = ""

        @SerializedName("emailOTP")
        @Expose
        val emailOTP: Int? = null

        @SerializedName("emailOTPexp")
        @Expose
        val emailOTPexp: String = ""

    }

    class VenueAddress {
        @SerializedName("country")
        @Expose
        var country: String = ""

        @SerializedName("region")
        @Expose
        var region: String = ""

        @SerializedName("venue")
        @Expose
        var venue: String = ""

        @SerializedName("stage")
        @Expose
        var stage: String = ""
    }

    class StreamModel {
        @SerializedName("type")
        @Expose
        var type: String = ""

        @SerializedName("title")
        @Expose
        var title: String = ""

        @SerializedName("description")
        @Expose
        var description: String = ""

        @SerializedName("videoUrl")
        @Expose
        var videoUrl: VideoUrlModel? = null
    }

    class VideoUrlModel {
        @SerializedName("providerName")
        @Expose
        var providerName: String = ""

        @SerializedName("channelName")
        @Expose
        var channelName: String = ""

    }

    class Sponsors {
        @SerializedName("sponsorName")
        @Expose
        var sponsorName: String = ""

        @SerializedName("website")
        @Expose
        var website: String = ""

        @SerializedName("playStoreUrl")
        @Expose
        var playStoreUrl: String = ""

        @SerializedName("appStoreUrl")
        @Expose
        var appStoreUrl: String = ""

        @SerializedName("sponsorLogo")
        @Expose
        var sponsorLogo: String = ""

        @SerializedName("sponsorBanner")
        @Expose
        var sponsorBanner: String = ""
    }

}