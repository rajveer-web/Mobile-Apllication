package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.ManageTournamentModel
import com.dynasty.esports.models.Spinner
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class StreamViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val updateSpinnerItem = MutableLiveData<MutableList<Spinner>>()
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val jsonObjectForGetTournament =
        MutableLiveData<JsonObject>()

    val publishStreamSuccessResponse = MutableLiveData<ResponseBody>()
    val publishStreamErrorResponse = MutableLiveData<ResponseBody>()
    val jsonObjectForPublishStream = MutableLiveData<JsonObject>()
    val arrayListForProvider = MutableLiveData<MutableList<Spinner>>()

    val tournamentDetailSuccessResponse = MutableLiveData<ManageTournamentModel>()
    val tournamentDetailErrorResponse = MutableLiveData<ResponseBody>()

    /**
    0 * @desc Method will use to create json object for replies comment.
     * @param type- video url type
     * @param title - stream title
     * @param description - stream description
     * @param provider - stream provider
     * @param channel - stream channel
     */
    fun makeJsonObjectForPostStream(
        title: String,
        description: String,
        provider: String,
        channel: String,
        type: String
    ) {

        val jsonObjectVideo = JsonObject()
        jsonObjectVideo.addProperty("providerName", provider)
        jsonObjectVideo.addProperty("channelName", channel)

        val jsonObjectVideoURL = JsonObject()
        jsonObjectVideoURL.addProperty("type", type)
        jsonObjectVideoURL.addProperty("title", title)
        jsonObjectVideoURL.addProperty("description", description)
        jsonObjectVideoURL.add("videoUrl", jsonObjectVideo)

        val jsonArray = JsonArray()
        jsonArray.add(jsonObjectVideoURL)

        val jsonObjectRoot = JsonObject()
        jsonObjectRoot.add("stream", jsonArray)


        jsonObjectForPublishStream.postValue(jsonObjectRoot)
    }

    /**
    0 * @desc Method will use to create json object for replies comment.
     * @param type- video url type
     * @param title - stream title
     * @param description - stream description
     * @param provider - stream provider
     * @param channel - stream channel
     */
    fun makeJsonObjectForPostStream(arrayListStream: ArrayList<ManageTournamentModel.StreamModel>) {
        val jsonObjectRoot = JsonObject()
        val jsonArray = JsonArray()
        arrayListStream.forEach {
            val jsonObjectVideo = JsonObject()
            jsonObjectVideo.addProperty("providerName", it.videoUrl?.providerName)
            jsonObjectVideo.addProperty("channelName", it.videoUrl?.channelName)

            val jsonObjectVideoURL = JsonObject()
            jsonObjectVideoURL.addProperty("type", it.type)
            jsonObjectVideoURL.addProperty("title", it.title)
            jsonObjectVideoURL.addProperty("description", it.description)
            jsonObjectVideoURL.add("videoUrl", jsonObjectVideo)

            jsonArray.add(jsonObjectVideoURL)
        }



        jsonObjectRoot.add("stream", jsonArray)


        jsonObjectForPublishStream.postValue(jsonObjectRoot)
    }

    /**
     * @desc Method will handle social media API success, failure
     * @param jsonObject-
     */
    fun getTournamentDetail(jsonObject: JsonObject) {
        viewModelScope.launch(apiException("social") + Dispatchers.Main) {
            val response = restInterface.getTournamentDetail(jsonObject.toString(), "stream")
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    tournamentDetailSuccessResponse.postValue(response.body())
                }
                else -> {
                    tournamentDetailErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    /**
     * @desc Method will handle social media API success, failure
     * @param id- pass
     */
    fun publishStream(id: String, jsonObject: JsonObject) {
        viewModelScope.launch(apiException("social") + Dispatchers.Main) {
            val response = restInterface.postStream(id, jsonObject)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    publishStreamSuccessResponse.postValue(response.body())
                }
                else -> {
                    publishStreamErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }


    /**
     * @desc Method will use for update spinner adapter and update spinner UI.
     * @param type- spinner type
     * @param array- spinner array
     */
    fun updateSpinnerValueAndUI(array: MutableList<Spinner>) {
        updateSpinnerItem.postValue(array)
    }


    fun makeArrayListForProvider(streamList: MutableList<ManageTournamentModel.StreamModel>) {
        val providerList: MutableList<Spinner> = mutableListOf()
        //if(!checkProviderExistsOrNot(streamList,"YOUTUBE")){
        providerList.add(Spinner("YOUTUBE", "https://www.youtube.com/watch?v="))
        //  }

        // if(!checkProviderExistsOrNot(streamList,"TWITCH")){
        providerList.add(Spinner("TWITCH", "https://www.twitch.tv/"))
        //  }

        //  if(!checkProviderExistsOrNot(streamList,"SMASHCAST")){
        providerList.add(Spinner("SMASHCAST", "https://www.smashcast.tv/"))
        //   }

        //  if(!checkProviderExistsOrNot(streamList,"MOBCRUSH")){
        providerList.add(Spinner("MOBCRUSH", "https://www.mobcrush.com/"))
        //   }

        //  if(!checkProviderExistsOrNot(streamList,"LIVESTREAM")){
        providerList.add(Spinner("LIVESTREAM", "rtmp://streaming.exaltaretech.com/live/"))
        //  }

        //  if(!checkProviderExistsOrNot(streamList,"FACEBOOK")){
        providerList.add(Spinner("FACEBOOK", "https://www.facebook.com/"))
        //  }

        arrayListForProvider.postValue(providerList)
    }

    private fun checkProviderExistsOrNot(
        streamList: MutableList<ManageTournamentModel.StreamModel>,
        type: String
    ): Boolean {
        streamList.forEach {
            if (type.toLowerCase() == it.type.toString().toLowerCase()) {
                return true
            }
        }
        return false
    }


    fun onValidationForForm(provider: String, channelName: String, title: String, des: String) {
        when {
            provider.isFieldEmpty() -> validationLiveData.postValue(0)
            channelName.isFieldEmpty() -> validationLiveData.postValue(1)
            title.isFieldEmpty() -> validationLiveData.postValue(2)
            des.isFieldEmpty() -> validationLiveData.postValue(3)
            else -> isFormValid.postValue(true)
        }
    }

    fun makeJsonForGetTournament(id: String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("_id", id)
        jsonObjectForGetTournament.postValue(jsonObject)
    }


    /**
     * Clears the [ViewModel] when the [Fragment or Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
