package com.dynasty.esports.view.search


import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterSearchOptionBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use to show search option
 * @author : Mahesh Vayak
 * @created : 06-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class SearchOptionAdapter(
    private var searchOptionList: Array<String>,
    private val onItemClick: (Int, String) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterSearchOptionBinding>>() {
    private var selectedItem: Int = -1
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterSearchOptionBinding> {
        return BindingHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.adapter_search_option,
                parent,
                false
            )
        )

    }

    /**
     * @desc search option array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return searchOptionList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterSearchOptionBinding>,
        position: Int
    ) {
        holder.binding.buttonSearchOption.text = searchOptionList[position]

        if (selectedItem == position) {
            if (selectedItem != 0) {
                holder.binding.buttonSearchOption.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(
                        holder.itemView.context,
                        R.color.colorAccent
                    )
                )
                holder.binding.buttonSearchOption.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
            } else {
                holder.binding.buttonSearchOption.backgroundTintList =
                    ColorStateList.valueOf(
                        ContextCompat.getColor(
                            holder.itemView.context,
                            android.R.color.transparent
                        )
                    )
                holder.binding.buttonSearchOption.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
            }
        } else {
            if (position == 0) {
                holder.binding.buttonSearchOption.backgroundTintList =
                    ColorStateList.valueOf(
                        ContextCompat.getColor(
                            holder.itemView.context,
                            android.R.color.transparent
                        )
                    )
                holder.binding.buttonSearchOption.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
            } else {
                holder.binding.buttonSearchOption.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(
                        holder.itemView.context,
                        R.color.white
                    )
                )
                holder.binding.buttonSearchOption.strokeColor = ColorStateList.valueOf(
                    ContextCompat.getColor(
                        holder.itemView.context,
                        R.color.background_color
                    )
                )
                holder.binding.buttonSearchOption.strokeWidth = 1
                holder.binding.buttonSearchOption.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.background_color))
            }
        }
        holder.binding.buttonSearchOption.click {
            onItemClick(position, searchOptionList[position])
        }
    }

    /**
     *@desc method will call when update selected position from activity
     * @param position - adapter position
     */
    fun updateSelectedPosition(position: Int) {
        selectedItem = position
        notifyDataSetChanged()
    }


}