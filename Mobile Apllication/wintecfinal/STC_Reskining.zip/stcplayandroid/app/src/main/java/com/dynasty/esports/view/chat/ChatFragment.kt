package com.dynasty.esports.view.chat

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.application.DynastyApplication
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.id
import com.dynasty.esports.extenstion.startActivityFromFragment
import com.dynasty.esports.models.MatchsListModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.ChatViewModel
import com.dynasty.esports.viewmodel.CommonViewModel
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ChatFragment : BaseFragment() , ConnectivityReceiver.ConnectivityReceiverListener {
    var chatListAdapter: ChatListAdapter? = null
    private var connectivityReceiver = ConnectivityReceiver()// define connection receiver
    private val mViewModel: ChatViewModel by viewModel()
    private val matchesList:MutableList<MatchsListModel> = mutableListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_chat, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        chatListAdapter = ChatListAdapter(matchesList, onItemClick = ::onItemClick)
        commonRecyclerView.adapter = chatListAdapter
        (requireActivity().application as DynastyApplication).connectSocket()

        listenToViewModel()
    }

    private fun listenToViewModel() {
        mViewModel.matchListSuccessResponse.observe(viewLifecycleOwner,{
            it?.apply {
                matchesList.addAll(this)
                chatListAdapter?.apply {
                    this.notifyDataSetChanged()
                }
                linearLayoutProgressBar.beGone()
            }
        })
        mViewModel.matchListErrorResponse.observe(viewLifecycleOwner,{
            linearLayoutProgressBar.beGone()
        })
    }

    private fun onItemClick(matchID:String,tournamentId:String) {
        val bundle=Bundle()
        bundle.putString("matchId",matchID)
        bundle.putString("tournamentId",tournamentId)
        startActivityFromFragment<ChatDetailActivity>(bundle)
    }

    // Register receiver for check internet connection
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    // Unregister receiver for internet connection
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }


    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && matchesList.isEmpty()) {
            mViewModel.getAllMatches(sharedPreferences.id)
        }
    }

}