package com.dynasty.esports.view.signin.mobile

import android.content.Intent
import android.os.Bundle
import android.text.TextPaint
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.text.style.ClickableSpan
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.Country
import com.dynasty.esports.models.SignInRequest
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.SocialLoginActivity
import com.dynasty.esports.view.country_picker.dialogg.CountryCodePicker
import com.dynasty.esports.view.forgot_password.ForgotPasswordMobileActivity
import com.dynasty.esports.view.signin.email.EmailSignInActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.SignInViewModel
import kotlinx.android.synthetic.main.activity_phone_nos_sign_in.*
import kotlinx.android.synthetic.main.content_phone_num_signin_screen.*
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class PhoneSignInActivity : SocialLoginActivity(), CountryCodePicker.Listener {

    private val mViewModel: SignInViewModel by viewModel()
//    private var phoneNumberUtil: PhoneNumberUtil? = null
//    private var phoneNumberFormattingTextWatcher: PhoneNumberFormattingTextWatcher? = null
//    private var code:String="966"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_nos_sign_in)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
//        phoneNumberUtil = PhoneNumberUtil.createInstance(this)
        initialise()
        listenToViewModel()

    }

//    private var mTextWatcher: TextWatcher = object : TextWatcher {
//        override fun beforeTextChanged(
//            charSequence: CharSequence,
//            i: Int,
//            i2: Int,
//            i3: Int
//        ) {
//        }
//
//        override fun onTextChanged(
//            charSequence: CharSequence,
//            i: Int,
//            i2: Int,
//            i3: Int
//        ) {
//        }
//
//        override fun afterTextChanged(editable: Editable) {
//            // check Fields For Empty Values
//            checkSignInFieldsForEmptyValues(
//                signin_country_code,
//                phone_nos,
//                password,
//                phoneSignin_continue,
//                true
//            )
//        }
//    }


    // to initialise the view
    fun initialise() {
        login_privacy.makeSpannableString(
            this, resources.getString(R.string.login_privacy),
            0,
            resources.getString(R.string.login_privacy).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    widget.cancelPendingInputEvents()
                    openUrlFromIntent()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = true
                }

            }, true
        )


        // set listeners
        /*signin_country_code.addTextChangedListener(mTextWatcher)
        phone_nos.addTextChangedListener(mTextWatcher)
        password.addTextChangedListener(mTextWatcher)*/

        // run once to disable if empty
        /*checkSignInFieldsForEmptyValues(
            signin_country_code,
            phone_nos,
            password,
            phoneSignin_continue,
            true
        )*/


     //   signin_country_code.setText(getBaseCountryDialCode())

        password.onRightDrawableClicked {
            if (showPassword) {
                showPassword = false
                password.setCompoundDrawablesWithIntrinsicBounds(
                    null,
                    null,
                    ContextCompat.getDrawable(
                        baseContext,
                        R.drawable.ic_baseline_visibility_off_24
                    ),
                    null
                )
                password.transformationMethod = PasswordTransformationMethod.getInstance()
            } else {
                showPassword = true
                password.setCompoundDrawablesWithIntrinsicBounds(
                    null,
                    null,
                    ContextCompat.getDrawable(baseContext, R.drawable.ic_password_show),
                    null
                )
                password.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
        }

        phSigninbottom_vieww.makeSpannableString(
            this,
            resources.getString(R.string.no_account_txt),
            if (LocaleHelper.getLanguage(this@PhoneSignInActivity) == "en") {
                22
            } else {
                23
            },
            resources.getString(R.string.no_account_txt).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    mViewModel.phoneRegisterClick()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })

        signin_country_code.click {
            mViewModel.countryCodeClick()
        }

        social_login_fb.click {
            mViewModel.fbLoginClick()
        }

       /* social_login_twitter.click {

        }*/

        social_login_gPlus.click {
            mViewModel.googleLoginClick()
        }

        phoneSignin_continue.click {
            mViewModel.onValidationForPhoneLogin(
                signin_country_code.text.toString().trim(),
                phone_nos.text.toString().trim(),
                password.text.toString().trim()
            )
        }

        phSigninbottom_vieww.click {
            mViewModel.phoneRegisterClick()
        }

        phoneSignInEmail.click {
            mViewModel.emailRegisterClick()
        }

        forgot_pssword_btn.click {
            startActivityInline<ForgotPasswordMobileActivity>(finish = false)
            // Redirect to Forgot screen
            /* val i = Intent(this@EmailSignInActivity, EmailSignInActivity::class.java)
             startActivity(i)      */
        }

//        if (phoneNumberFormattingTextWatcher == null) {
//            phoneNumberFormattingTextWatcher = PhoneNumberFormattingTextWatcher(
//                this.code!!.toUpperCase(),
//                this@PhoneSignInActivity
//            )
//            updatePlaceHolder()
//        }

    }


//    // to register the device token
//    private fun registerFCMToken(){
//        if(sharedPreferences.FCMToken.isNotEmpty()) {
//            val jsonObject = JsonObject()
//            jsonObject.addProperty("requestType", "register-push-notification")
//            jsonObject.addProperty("platform", "android")
//            jsonObject.addProperty("token", sharedPreferences.FCMToken)
//            mViewModel.registrationPushNotification(jsonObject)
//        }
//    }

    // to listen view model and manage the api
    private fun listenToViewModel() {

        //startActivityInline<DashboardActivity>(finish = true)

//        mViewModel.registerFCMTokenSuccessResponse.observe(this, androidx.lifecycle.Observer {
//            Log.d("Login","Nos" + it.string().getMessageFromObject("message"))
//     //       it.string().getMessageFromObject("message").showToast(this)
//        })
//
//        mViewModel.registerFCMTokenErrorResponse.observe(this, androidx.lifecycle.Observer {
//            Log.d("Login","Nos" + it.string().getMessageFromObject("message"))
//        //    it.string().getMessageFromObject("message").showToast(this)
//        })

        mViewModel.countryCodeObserver.observe(this, Observer {
            displayCountryCodeDialog()
        })

        mViewModel.validationLiveData.observe(this, Observer {
            when (it) {
                0 -> {
                    makeSnackBar(
                        constraintLayoutSignIn,
                        resources.getString(R.string.mobile_code_error)
                    )
                }
                1 -> {
                    makeSnackBar(
                        constraintLayoutSignIn,
                        resources.getString(R.string.mobile_number_error)
                    )
                }
                2 -> {
                    makeSnackBar(
                        constraintLayoutSignIn,
                        resources.getString(R.string.mobile_number_not_valid_error)
                    )
                }
                3 -> {
                    makeSnackBar(
                        constraintLayoutSignIn,
                        resources.getString(R.string.password_error)
                    )
                }
            }
        })

        mViewModel.isLoginFormValid.observe(this, Observer {
            launchProgressDialog()
            val signInRequest = SignInRequest()
            signInRequest.phoneNumber = signin_country_code.text.toString().trim().plus(phone_nos.text.toString().trim().removeZeroFormNumber())
            signInRequest.password = password.text.toString().trim()
            signInRequest.type = "phone"
            mViewModel.callPhoneOrEmailLoginAPI(signInRequest)
        })

        mViewModel.fbLoginObserver.observe(this, Observer {
            if (it) {
                fbLogin()
            }
        })

        mViewModel.googleLoginObserver.observe(this, Observer {
            if (it) {
                googleLogin()
            }
        })

        mViewModel.redirectPhoneRegistrationObserver.observe(this, Observer {
            if (it) {
                startActivityInline<PhoneNumRegistrationActivity>()
            }
        })

        mViewModel.redirectEmailRegistrationObserver.observe(this, Observer {
            if (it) {
                startActivityInline<EmailSignInActivity>()
            }
        })

        commonViewModel.userSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            if (sharedPreferences.id == "null" || sharedPreferences.id == "") {
                it.data?.apply {
                    sharedPreferences.id = this.id.toString()
                    sharedPreferences.put("user", this)
                    redirectToDashBoard(true)
                }
            }
        })
        commonViewModel.userErrorResponse.observe(this, {
            dismissProgressDialog()
        })
        mViewModel.loginSuccessResponse.observe(this, {

            if (rememberMe.isChecked) {
                sharedPreferences.isLogin = rememberMe.isChecked
            }

            sharedPreferences.refreshToken = it.first
            sharedPreferences.accessToken = it.second.data.token
            registerFCMToken()
            commonViewModel.fetchUser()
        })

        commonViewModel.unAuthorizationException.observe(this, {
            dismissProgressDialog()
        })

        mViewModel.loginErrorResponse.observe(this, {
            /*here */
            makeSnackBar(constraintLayoutSignIn, it)
            dismissProgressDialog()
     })

        mViewModel.noInternetException.observe(this, {
            dismissProgressDialog()
            if (isOnline()) {
                makeSnackBar(
                    constraintLayoutSignIn,
                    resources.getString(R.string.something_wrong_try_again)
                )
            } else {
                makeSnackBar(
                    constraintLayoutSignIn,
                    resources.getString(R.string.no_internet_message)
                )
            }
        })

    }

    override fun onCountryChosen(country: Country) {
//        code=country.phoneCode
//        updatePlaceHolder()
        signin_country_code.setText("+".plus(country.phoneCode))
    }

    override fun redirectToDashBoard(isRedirect: Boolean) {
        if (isRedirect) {
            sharedPreferences.isLoggedIn = true
            val bundle=Bundle()
            bundle.putString("type",redirectType)
            val intent=Intent(AppConstants.NOTIFY_ACTION)
            intent.putExtras(bundle)
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
            killAllActivities()
        }
    }


    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }


//    private fun updatePlaceHolder(){
//        phoneNumberUtil?.let {
//            val phoneNumber =
//                it.getExampleNumberForType(code, PhoneNumberUtil.PhoneNumberType.MOBILE)
//            phoneNumberFormattingTextWatcher?.let {
//                it.updateCountry(
//                    this.code.toUpperCase()
//                )
//            }
//            phoneNumber?.apply {
//                val finalHint =
//                    PhoneNumberUtils.formatNumber(
//                        phoneNumber.nationalNumber.toString(),
//                        code
//                    )
//                outlinedPhoneNos.hint = finalHint.toString()
//            }
//        }
//    }


}