package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

 class Docs{
     @SerializedName("createdBy")
     val createdBy: String?=null

     @SerializedName("updatedBy")
     val updatedBy: String?=null
     @SerializedName("status")
     val status: String?=null
     @SerializedName("_id")
     val _id: String?=null
     @SerializedName("name")
     val name: String?=null
     @SerializedName("bracketType")
     val bracketType: String?=null
     @SerializedName("maximumParticipants")
     val maximumParticipants: Int?=null
     @SerializedName("isKnowParticipantName")
     val isKnowParticipantName: Boolean?=null
     @SerializedName("nfMatchBetweenTwoTeam")
     val nfMatchBetweenTwoTeam: Int?=null
     @SerializedName("isRoundRobin")
     val isRoundRobin: Boolean?=null
     @SerializedName("noOfSet")
     val noOfSet: Int?=null
     @SerializedName("createdOn")
     val createdOn: String?=null
     @SerializedName("updatedOn")
     val updatedOn: String?=null
     @SerializedName("__v")
     val __v: Int?=null

     var isLoadMore: Boolean = false
 }