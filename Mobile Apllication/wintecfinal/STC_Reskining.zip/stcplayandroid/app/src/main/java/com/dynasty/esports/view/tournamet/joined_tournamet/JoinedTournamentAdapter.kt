package com.dynasty.esports.view.tournamet.joined_tournamet


import android.content.Context
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.dynasty.esports.R
import com.dynasty.esports.models.ArticlePostList


class JoinedTournamentAdapter// data is passed into the constructor
internal constructor(
    private val context: Context,
    private val nData: ArrayList<ArticlePostList>
) :
    RecyclerView.Adapter<JoinedTournamentAdapter.ViewHolder>() {
    private val mInflater: LayoutInflater
    private var mClickListener: ItemClickListener? = null
    private val mData: ArrayList<ArticlePostList>
    init {
        this.mInflater = LayoutInflater.from(context)
        this.mData=nData
    }

    // inflates the cell layout from xml when needed
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = mInflater.inflate(R.layout.row_tournament_join, parent, false)
        return ViewHolder(view)
    }

    // binds the data to the TextView in each cell
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        /* try {
             if (mData.get(position).title != null) {
                 if (mData.get(position).quarter != null) {
                     holder.myTextView1.text =
                         mData.get(position).title + " | " + mData.get(position).quarter
                 } else {
                     holder.myTextView1.text = mData.get(position).title
                 }
             } else {
                 if (mData.get(position).quarter != null) {
                     holder.myTextView1.text = mData.get(position).quarter
                 } else {

                 }
             }
         }catch(e:Exception)
         {

         }
         try {
             if (mData.get(position).year != null) {
                 holder.myTextView2.text = mData.get(position).year
             }
         }catch(e:java.lang.Exception)
         {

         }
         try {
             if (mData.get(position).company != null) {
                 holder.myTextView3.text = mData.get(position).company
             }
         }catch(e:java.lang.Exception)
         {

         }*/

    }

    // total number of cells
    override fun getItemCount(): Int {
        return mData.size
    }


    // stores and recycles views as they are scrolled off screen
    inner class ViewHolder internal constructor(itemView: View) : RecyclerView.ViewHolder(itemView),
        View.OnClickListener {
        lateinit var myTextView1: TextView
        lateinit var myTextView2: TextView
        lateinit var myTextView3: TextView



        init {
            /*
             myTextView1 = itemView.findViewById(R.id.tv1) as TextView

             myTextView2 = itemView.findViewById(R.id.tv2) as TextView

             myTextView3 = itemView.findViewById(R.id.tv3) as TextView*/


        }

        override fun onClick(view: View) {
            if (mClickListener != null) mClickListener!!.onItemClick(view, adapterPosition)
        }
    }

    // convenience method for getting data at click position
    internal fun getItem(id: Int): String {
        return mData.get(id).postID!!
    }

    // allows clicks events to be caught
    internal fun setClickListener(itemClickListener: ItemClickListener) {
        this.mClickListener = itemClickListener
    }

    // parent activity will implement this method to respond to click events
    interface ItemClickListener {
        fun onItemClick(view: View, position: Int)
    }
}