package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class SignInRequest(
    @field:SerializedName("password")
    var password: String? = null,

    @field:SerializedName("email")
    var email: String? = null,

    @field:SerializedName("phoneNumber")
    var phoneNumber: String? = null,

    @field:SerializedName("type")
    var type: String? = null

    )