package com.dynasty.esports.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.debugE
import com.dynasty.esports.extenstion.parseTime
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import org.json.JSONObject
import java.util.*

class OngoingTournamentViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val fetchOngoingTournamentSuccessResponse = MutableLiveData<TournamentListRes>()
    val fetchOngoingTournamentErrorResponse = MutableLiveData<ResponseBody>()

    val jsonObjectForOngoingTournament = MutableLiveData<Pair<JsonObject, JsonObject>>()

    fun fetchOngoingTournament(
        status: String, sort: String, type: String,
        page: Int,
        limit: Int
    ) {
        viewModelScope.launch(apiException(type) + Dispatchers.Main) {
            val response = restInterface.getAllTournament(status, sort, page, limit)
//            val response = restInterface.fetchAllCreatedTournamentPastAndOngoing(query, pagignation)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    fetchOngoingTournamentSuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    fetchOngoingTournamentErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    fun makeJsonForOngoingTournament(
        page: Int,
        limit: Int,
        isSeeded: Boolean
    ) {
//        val arrayProjection = JsonArray()
//        arrayProjection.add("_id")
//        arrayProjection.add("name")
//        arrayProjection.add("description")
//        arrayProjection.add("startDate")
//        arrayProjection.add("checkInStartDate")
//        arrayProjection.add("isPaid")


        val pagignation = JsonObject()
        pagignation.addProperty("page", page)
        pagignation.addProperty("limit", limit)
        pagignation.addProperty("sort", "startDate")
//        pagignation.add("projection", arrayProjection)

        val rootObject = JsonObject()
        val jarray: JsonArray = JsonArray()

        val isSeededObj: JsonObject = JsonObject()
        isSeededObj.addProperty("isSeeded", isSeeded)

        val tournamentStatusObj: JsonObject = JsonObject()
        tournamentStatusObj.addProperty("tournamentStatus", "publish")

        val startDateObj = JsonObject()
        val startDateObj_ = JsonObject()
        startDateObj_.addProperty("\$lt", parseTime(Date().time, AppConstants.API_DATE_FORMAT))
        startDateObj.add("startDate", startDateObj_)

        jarray.add(startDateObj)
        jarray.add(isSeededObj)
        jarray.add(tournamentStatusObj)


        rootObject.add("\$or", jarray)
//        rootObject.addProperty("isSeeded", isSeeded)
//        if(!isUpcoming){
//        rootObject.addProperty("isFinished", isFinished)
//        rootObject.addProperty("tournamentStatus", "publish")
//        }

        debugE("rootObject £", Gson().toJson(rootObject))
        debugE("pagignation £", Gson().toJson(pagignation))

        jsonObjectForOngoingTournament.postValue(Pair(rootObject, pagignation))


    }

    /**
     * Clears the [ViewModel] when the [ArticlesFragment] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
