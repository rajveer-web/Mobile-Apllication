package com.dynasty.esports.view.bracket


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.RowMybracketsBinding
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.models.Docs
import com.dynasty.esports.models.VideosModel
import com.dynasty.esports.view.common.LoadingViewHolder

/**
 * @desc this is class will be use for show bracket list
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class BracketAdapter internal constructor(private val bracketList: MutableList<Docs>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    /**
     *@desc This ViewHolder should be constructed with a new View that can represent the items
     * of the given type.
     */
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: RowMybracketsBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.row_mybrackets,
                        parent,
                        false
                    )
                return ViewHolderBracket(binding)
            }
            else -> {
                val binding: ItemLoadMoreBinding =
                    DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
                return LoadingViewHolder(binding)
            }

        }
    }


    /**
     * @desc bracket array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {

        return bracketList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (bracketList[position].isLoadMore) {
            1
        } else {
            0
        }
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderBracket).bind(bracketList[position])
            }
            else -> {
                (holder as LoadingViewHolder).progressBar.isIndeterminate = true
            }
        }
    }

    /**
     *@desc This call use for display bracket data
     */
    inner class ViewHolderBracket(private var binding: RowMybracketsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: Docs) {
            binding.textViewBracketName.text = data.name?.let { it } ?: ""
            binding.textViewSize.text = data.maximumParticipants?.let { it.toString() } ?: "0"
            binding.textViewType.text = data.bracketType?.let { it } ?: ""

            binding.textViewDate.text = data.updatedOn?.let {
                it.convertDateToRequireDateFormat(AppConstants.API_DATE_FORMAT, AppConstants.REQUIRED_TIME_FORMAT)
            } ?: ""
        }

    }



}