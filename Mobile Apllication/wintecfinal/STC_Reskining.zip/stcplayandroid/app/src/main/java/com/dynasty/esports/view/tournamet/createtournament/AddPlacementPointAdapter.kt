package com.dynasty.esports.view.tournamet.createtournament


import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AddPlacementPointItemBinding
import com.dynasty.esports.models.AddPlacementPoint
import com.dynasty.esports.models.AddVenue

/**
 * @desc this is class will use for add venue item
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class AddPlacementPointAdapter : RecyclerView.Adapter<AddPlacementPointAdapter.MyViewHolder>() {
    class MyViewHolder(val binding: AddPlacementPointItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    private var placementPointList: MutableList<AddPlacementPoint> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val binding: AddPlacementPointItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.add_placement_point_item,
            parent,
            false
        )
        return MyViewHolder(binding)
    }

    /**
     * @desc vanueList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return placementPointList.size
    }

    /**
     * @desc add item in venueList and notify adapter
     */
    fun add(item: AddPlacementPoint) {
        placementPointList.add(item)
        notifyDataSetChanged()
    }

    /**
     * @desc add list in venueList and notify adapter
     */
    fun addAll(venueList: MutableList<AddPlacementPoint>) {
        placementPointList.clear()
        placementPointList.addAll(venueList)
        notifyDataSetChanged()
    }

    /**
     * @desc remove item from venueList and notify adapter
     */
    fun remove(item: AddPlacementPoint) {
        placementPointList.remove(item)
        notifyDataSetChanged()
    }

    /**
     * @desc get single item from position
     */
    fun getItem(position: Int): AddPlacementPoint {
        return placementPointList[position]
    }

    /**
     * @desc get venueList( main array list)
     */
    fun getAll(): MutableList<AddPlacementPoint> {
        return placementPointList
    }

    /**
     * @desc clear or remove all data from venueList( main array list)
     */
    fun clear() {
        placementPointList.clear()
        notifyDataSetChanged()
    }

    /**
     * @desc check validation in venue form
     */
    fun isValidated(): Boolean {
        for (i in placementPointList) {
            if (i.point.isEmpty()) {
                return false
            }
        }
        return true
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = placementPointList[position]

        holder.binding.addPlacementPoint = data
        holder.binding.tvPointNumber.text = data.id
//        holder.binding.editPlacementPoint.text = dat

//        holder.binding.tvOfflineSelectRegion.click {
//            onVenueSelectRegionClick(
//                position,
//                holder.binding.tvOfflineSelectRegion
//            )
//        }
    }
}