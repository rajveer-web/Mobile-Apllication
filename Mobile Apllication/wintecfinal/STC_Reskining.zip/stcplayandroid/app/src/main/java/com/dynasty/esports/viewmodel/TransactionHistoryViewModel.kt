package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.models.RewardsHistoryModel
import com.dynasty.esports.retrofit.RestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

/**
 * @desc this class will handle API functions and create json object for API request
 * @author : Mahesh Vayak
 * @created : 25-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class TransactionHistoryViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    // define MutableLiveData for emit observer
    val rewardHistorySuccessResponse = MutableLiveData<RewardsHistoryModel>()
    val rewardHistoryErrorResponse = MutableLiveData<ResponseBody>()

    /**
     * @desc Method will handle reward history success and failure
     */

    fun fetchRewardsHistory() {
        viewModelScope.launch(apiException("rewards") + Dispatchers.Main) {
            val response = restInterface.rewardTransaction()
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    rewardHistorySuccessResponse.postValue(response.body())
                }
                AppConstants.API_UNAUTHENTICATED_CODE -> {
                    unAuthorizationException.postValue(true)
                }
                else -> {
                    rewardHistoryErrorResponse.postValue(response.errorBody())
                }
            }
        }

    }

    /**
     * Clears the [ViewModel] when the [Fragment] or [Activity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

}
