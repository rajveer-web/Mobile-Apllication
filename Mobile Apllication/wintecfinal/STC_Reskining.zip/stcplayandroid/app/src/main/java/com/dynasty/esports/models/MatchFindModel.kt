package com.dynasty.esports.models

import android.os.Parcelable
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


class MatchFindModel {
    @SerializedName("message")
    @Expose
     val message: String? = null

    @SerializedName("messageCode")
    @Expose
     val messageCode: String? = null

    @SerializedName("success")
    @Expose
     val success: Boolean? = null

    @SerializedName("data")
    @Expose
     val data: DataModel? = null

    @Parcelize
    class DataModel : Parcelable {
        @SerializedName("_id")
        @Expose
         var id: String? = null

        @SerializedName("fullName")
        @Expose
        var fullName: String? = null

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String? = null

        @SerializedName("country")
        @Expose
        var country: String? = null

        @SerializedName("state")
        @Expose
        var state: String? = null

    }
}