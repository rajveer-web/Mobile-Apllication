package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DiscussionPostCommentModel {
    @SerializedName("data")
    @Expose
//    val data:ArticleCommentModel.ArticleComment? = null
    val data: DiscussionComment.DataModel? = null

    @SerializedName("message")
    @Expose
    val message: String? = null
}