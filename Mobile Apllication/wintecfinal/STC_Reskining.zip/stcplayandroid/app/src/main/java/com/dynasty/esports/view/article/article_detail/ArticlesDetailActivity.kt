package com.dynasty.esports.view.article.article_detail

import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ArticleCommentModel
import com.dynasty.esports.models.HottestPostArticleModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.article.article_section.TrendingPostAdapter
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.ArticleDetailViewModel
import com.google.android.material.appbar.AppBarLayout
import kotlinx.android.synthetic.main.activity_article_detail.*
import kotlinx.android.synthetic.main.article_app_bar_layout.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.json.JSONObject
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will show article details
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class ArticlesDetailActivity : BaseActivity(),
    ConnectivityReceiver.ConnectivityReceiverListener,
    ManageRedirectReceiver.NotifyActivityListener {
    private lateinit var articleCommentAdapter: ArticleCommentAdapter  // define article comment adapter
    private lateinit var relatedArticleAdapter: TrendingPostAdapter // define related games adapter
    private var commentList: MutableList<ArticleCommentModel.ArticleComment> =
        mutableListOf() // define comment empty list
    private var relatedArticleList: MutableList<HottestPostArticleModel.DataModel> = mutableListOf()
    private val mViewModel: ArticleDetailViewModel by viewModel() // inject article view model class
    private var manageRedirectReceiver = ManageRedirectReceiver()
    private var id: String = ""
    private var title: String = ""
    private var isDataLoaded = false
    private var isBookMark = false
    private var likeType: Int = -1
    private var articleLikeID: String = ""
    private var commentsLikeID: String = ""
    private var positionComment: Int = 0
    private var isReplyLikeComment: Boolean = false
    private var replayCommentPosition: Int = 0
    private var likeCounter: Int = 0
    private var isBookMarkDeleted = false
    private var connectivityReceiver = ConnectivityReceiver() // initialize connection receiver
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_article_detail)
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
        getIntentData()
        setUpToolBar()
        initView()
        viewClickListener()
        listenToViewModel()
    }

    /**
     * @desc get data from intent
     */
    private fun getIntentData() {
//        intent.extras?.apply {
//            id = this.getString("id").toString()
//            isBookMarkDeleted = this.getBoolean("isBookMarkDeleted")
//        }
        intent.data?.apply {
            id = this.lastPathSegment.toString()
        }
        intent.data?.apply {
            id = this.lastPathSegment.toString()
        }
        intent.extras?.apply {

            if (this.containsKey("id")) {
                id = this.getString("id").toString()
            }
            if (this.containsKey("isBookMarkDeleted")) {
                isBookMarkDeleted = this.getBoolean("isBookMarkDeleted")
            }


        }
    }

    /**
     * @desc set up toolbar with empty title
     */
    private fun setUpToolBar() {
        toolbar.title = ""
        setSupportActionBar(toolbar)
    }

    /**
     * @desc this method will use for initialize view and assign adapter to recyclerview and other some operations.
     */
    private fun initView() {
    //    linearLayoutRelatedArticles.background = getGradientColor()
        recyclerViewComment.layoutManager = LinearLayoutManager(this)
        recyclerViewComment.isNestedScrollingEnabled = false
        recyclerViewComment.isFocusable = false

        recyclerViewRelatedVideo.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerViewRelatedVideo.isNestedScrollingEnabled = false
        recyclerViewRelatedVideo.isFocusable = false

        articleCommentAdapter = ArticleCommentAdapter(
            commentList,
            onReplyClick = ::onReplayClick,
            onLikeClick = ::onLikeComment,
            postReplyComment = ::onPostReplayComment
        )
        recyclerViewComment.adapter = articleCommentAdapter

        relatedArticleAdapter =
            TrendingPostAdapter(relatedArticleList, onItemClick = ::onRelatedArticleClick)
        recyclerViewRelatedVideo.adapter = relatedArticleAdapter

        collapsingToolbar.setCollapsedTitleTypeface(this.getFontTypeFace(R.font.stc_forward_medium))
        manageUIAfterBeforeLogin()

    }

    private fun onRelatedArticleClick(id: String) {
        val bundle = Bundle()
        bundle.putString("id", id)
        startActivityInline<ArticlesDetailActivity>(bundle)
    }

    /**
     * @desc method will call when tap on post comment button from comment adapter
     * @param comment comment message
     * @param position adapter click item position
     */
    private fun onPostReplayComment(comment: String, position: Int) {
        replayCommentPosition = position - 1
        mViewModel.makeJsonObjectForRepliesComment(
            "replies_comment",
            comment,
            commentList[replayCommentPosition].id.toString(),
            sharedPreferences.id
        )
    }

    /**
     * @desc this method use for assign listener and view click
     */
    private fun viewClickListener() {
        appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                kotlin.math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbar.title = title
                }
                else -> {
                    collapsingToolbar.title = ""
                    // Expanded
                }
            }
        })

//        btnViewAll.click {
//            val bundle = Bundle()
//            bundle.putInt("type", ArticleConstant.CONST_TRENDING_POST)
//            bundle.putString("title", resources.getString(R.string.str_related_article))
//            startActivityInline<ViewAllArticlesActivity>(bundle)
//        }

        linearLayoutHideComment.click {
            if (cardViewComment.isVisible) {
                textViewHideShowComment.text = resources.getString(R.string.show_comments)
                cardViewComment.beInVisible()
                imageViewArrow.rotation = 0f
                val animSlideDown: Animation =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_up)
                cardViewComment.startAnimation(animSlideDown)
                Handler().postDelayed({ cardViewComment.beGone() }, 500)


            } else {
                cardViewComment.beVisible()
                imageViewArrow.rotation = 180f
                textViewHideShowComment.text = resources.getString(R.string.str_hide_comments)
                val animSlideDown: Animation =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_down)
                cardViewComment.startAnimation(animSlideDown)
            }
        }

        ivback.click {
            onBackPressed()
        }

        buttonSubmitComment.click {
            mViewModel.checkValidation(editTextComment.text.toString())

        }

        imageViewLike.click {
            if (sharedPreferences.checkUserLoggedInOrNot()) {
                if (likeType != -1) {
                    likeType = if (likeType == 1) {
                        0
                    } else {
                        1
                    }

                    mViewModel.makeJsonObjectForUpdateLike("updateLikeArticle", likeType)
                } else {
                    likeType = -1
                    mViewModel.makeJsonObjectForLikeComment(id, sharedPreferences.id, "article")
                }
            } else {
                launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
            }

        }

        imageViewBookMark.click {
            if (sharedPreferences.checkUserLoggedInOrNot()) {
                if (isBookMark) {
                    mViewModel.makeQueryParameter("articleId", id)
                } else {
                    mViewModel.makeJsonObjectForAddBookMark("addBookMark", id)
                }
            } else {
                launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
            }

        }

        article_share.click {
            val intent = Intent(Intent.ACTION_SEND)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            val urlLink = BuildConfig.ARTICLE_PATH.plus("article/$id")
            intent.putExtra(Intent.EXTRA_TEXT, urlLink)
            intent.type = "text/plain"
            startActivity(Intent.createChooser(intent, "Share Article via"))
        }

        textViewLoginFirst.makeSpannableMultipleString(this,
            resources.getString(R.string.please_login_or_register_to_add_comment),
            if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {
                7
            } else {
                5
            },
            if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {
                12
            } else {
                14
            },
            if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {
                16
            } else {
                20
            },
            if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {
                24
            } else {
                29
            },
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    redirectType = "article"
                    startActivityInline<PhoneSignInActivity>()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            },
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    redirectType = "article"
                    startActivityInline<PhoneNumRegistrationActivity>()
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })
    }

    /**
     * @desc listen observer and observer that will receive the events
     * Also, Manage API success and failure,Internet and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.makeQueryParameterForBookMark.observe(this, Observer {
            launchProgressDialog()
            mViewModel.deleteBookMark(it)
        })
        mViewModel.makeJsonObjectForArticle.observe(this, Observer {
            launchProgressDialog()
            when (it.first) {
                "post", "replies_comment" -> {
                    mViewModel.postComment(it.first, it.second)
                }

                "article", "comment" -> {
                    mViewModel.likeCommentAndArticle(it.second, it.first)
                }
                "updateLikeArticle" -> {
                    mViewModel.updateLikeComment(articleLikeID, it.second, "article")
                }
                "updateLikeComment" -> {
                    mViewModel.updateLikeComment(commentsLikeID, it.second, "comment")
                }
                "addBookMark" -> {
                    mViewModel.addBookMark(it.second)
                }
            }
        })

        mViewModel.makeJsonObjectForArticleDetail.observe(this, Observer {
            mViewModel.getAllArticles(
                id, it.first, sharedPreferences.id,
                it.second.toString()
            )
        })

        mViewModel.unAuthorizationException.observe(this, Observer {
            if (it)
                logOut()
        })
        mViewModel.noInternetException.observe(this, Observer {
            dismissProgressDialog()
            if (isOnline()) {
                if (it != "all") {
                    displayCustomAlertDialog(
                        resources.getString(R.string.something_wrong_try_again),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.btn_ok),
                        positiveClick = {
                            it.dismiss()
                        })
                }
            } else {
                if (it != "all") {
                    displayCustomAlertDialog(
                        resources.getString(R.string.no_internet_message),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.btn_ok),
                        positiveClick = {
                            it.dismiss()
                        })
                }
            }


        })
        mViewModel.deleteBookMarkSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            isBookMark = false
            isBookMarkDeleted = true
            this@ArticlesDetailActivity.updateTintColor(
                R.color.black,
                imageViewBookMark
            )
            imageViewBookMark.background =
                ContextCompat.getDrawable(this, R.drawable.article_detail_round_border)
            // it.string().getMessageFromObject("message").showToast(this@ArticlesDetailActivity)
        })
        mViewModel.deleteBookMarkErrorResponse.observe(this, Observer {
            dismissProgressDialog()
        })
        mViewModel.addBookMarkSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            isBookMarkDeleted = false
            isBookMark = true
            this@ArticlesDetailActivity.updateTintColor(R.color.white, imageViewBookMark)
            imageViewBookMark.background =
                ContextCompat.getDrawable(this, R.drawable.article_option_selected_bg)
            // it.string().getMessageFromObject("message").showToast(this@ArticlesDetailActivity)
        })
        mViewModel.addBookMarkErrorResponse.observe(this, {
            dismissProgressDialog()
        })

        mViewModel.isFormValid.observe(this, {

            mViewModel.makeJsonObjectForPostComment(
                "post",
                editTextComment.text.toString().trim(),
                id,
                sharedPreferences.id
            )
        })
        mViewModel.validationLiveData.observe(this, {
            if (it == 0) {
                resources.getString(R.string.enter_comment_error)
                    .showToast(this@ArticlesDetailActivity)
            }
        })

        mViewModel.articleDetailSuccessResponse.observe(this, {
            isDataLoaded = true
            it.data?.apply {
                mViewModel.updateArticleUI(this[0])
            }
        })

        mViewModel.articleDetailErrorResponse.observe(this, {
            isDataLoaded = true
            dismissProgressDialog()
            coordinatorLayoutArticleDetail.beGone()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beVisible()
        })

        mViewModel.articleViewUpdateSuccessResponse.observe(this, {
            val result=it.string()
            if(!result.isNullOrEmpty()){
                val data = JSONObject(result).getJSONObject("data")
                if (data.has("views")) {
                    textViewView.text = data.getString("views").toString().plus(" ")
                        .plus(resources.getString(R.string.view))
                } else {
                    textViewView.text = "0".plus(" ").plus(resources.getString(R.string.view))
                }
            }

        })

        mViewModel.checkBookMarkSuccessResponse.observe(this, {
            val result=it.string()
            if(!result.isNullOrEmpty()){
                val jsonArrayData = JSONObject(result).getJSONArray("data")
                if (jsonArrayData.length() == 0) {
                    isBookMark = false
                    this@ArticlesDetailActivity.updateTintColor(
                        R.color.black,
                        imageViewBookMark
                    )
                    imageViewBookMark.background =
                        ContextCompat.getDrawable(this, R.drawable.article_detail_round_border)
                } else {
                    isBookMark = true
                    this@ArticlesDetailActivity.updateTintColor(R.color.white, imageViewBookMark)
                    imageViewBookMark.background =
                        ContextCompat.getDrawable(this, R.drawable.article_option_selected_bg)
                }
                dismissProgressDialog()
            }

        })

        mViewModel.checkBookMarkErrorResponse.observe(this, {
            isBookMark = false
            dismissProgressDialog()
        })

        mViewModel.articleCommentSuccessResponse.observe(this, {
            it.data?.apply {
                commentList.addAll(this.comments!!)
                this.article?.apply {
                    likeType = this.type!!
                    this.likeId?.apply {
                        articleLikeID = this
                    }
                    likeCounter = this.totalLikes!!
                    txtlikes.text =
                        likeCounter.toString().plus(" ").plus(resources.getString(R.string.like))
                    if (likeType == -1 || likeType == 0) {
                        this@ArticlesDetailActivity.updateTintColor(
                            R.color.black,
                            imageViewLike
                        )
                        imageViewLike.background = ContextCompat.getDrawable(
                            this@ArticlesDetailActivity,
                            R.drawable.article_detail_round_border
                        )
                    } else {
                        this@ArticlesDetailActivity.updateTintColor(R.color.white, imageViewLike)
                        imageViewLike.background = ContextCompat.getDrawable(
                            this@ArticlesDetailActivity,
                            R.drawable.article_option_selected_bg
                        )
                    }
                }
                if (commentList.isNullOrEmpty()) {
                    textViewNoComment.beVisible()
                } else {
                    textViewNoComment.beGone()
                }
                articleCommentAdapter.notifyDataSetChanged()


            }
        })

        mViewModel.articleDetailUIResponse.observe(this, {
            coordinatorLayoutArticleDetail.beVisible()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beGone()
            it.title?.apply {
                if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {
                    title = this.english.toString()
                    textViewTitle.text = title
                } else {
                    title =
                        if (this.malay.isNullOrEmpty()) this.english.toString() else this.malay.toString()
                    textViewTitle.text = title
                }

            }
            it.shortDescription?.apply {
                if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {

                    textViewSubTitle.text = this.english.toString()
                } else {

                    textViewSubTitle.text =
                        if (this.malay.isNullOrEmpty()) this.english.toString() else this.malay
                }

            }
            this.loadImageFromServer(it.image.toString(), imageViewBanner)

            it.content?.apply {
                webViewDescription.settings.useWideViewPort = true

                webViewDescription.settings.javaScriptEnabled = true
                webViewDescription.settings.loadWithOverviewMode = true
                webViewDescription.isVerticalScrollBarEnabled = false
                webViewDescription.isHorizontalScrollBarEnabled = false
                webViewDescription.setBackgroundColor(Color.TRANSPARENT)

              //  val stringDesHtml: String

                if (LocaleHelper.getLanguage(this@ArticlesDetailActivity) == "en") {
//                    stringDesHtml =
//                        ("<htm><head><style>body{color:white;}  h1 { font-size: 56px; font-weight: bold; text-align: center; }\n" +
//                                "            h2 { font-size: 48px; font-weight: bold; text-align: center; }\n" +
//                                "            h3 { font-size: 44px; text-align: center; }p{align:justify;font-size:40px;}a{color:white;text-decoration: none;font-weight: bold;}img{ max-width: 100%; }</style></head><body>" ).plus(this.english?.let { it } ?: "").plus("</body></html>")
                    webViewDescription.loadData(bindHTMLText(this.english?.let { it } ?: ""), "text/html; charset=utf-8", "UTF-8")
                } else {
//                    stringDesHtml =
//                        "<html><head><style>body{color:white;}p{align:justify;font-size:40px;}a{color:white;text-decoration: none;font-weight: bold;}img{ max-width: 100%; }</style></head><body>".plus(
//                            if (this.malay.isNullOrEmpty()) this.english?.let { it }
//                                ?: "" else this.malay.toString()).plus("</font></body></html>")
                    webViewDescription.loadData(bindHTMLText(if (this.malay.isNullOrEmpty()) this.english?.let { it } ?: "" else this.malay.toString()), "text/html; charset=utf-8", "UTF-8")
                }

            }
            it.authorDetails?.apply {
                tvusernamearticle.text = this.fullName?.let { it } ?: ""
                this@ArticlesDetailActivity.loadImageFromServer(
                    this.profilePicture.toString(),
                    imageViewAuthor
                )
            }
            mViewModel.makeJsonObjectForRelatedArticles(
                "related",
                it.tags!!,
                it.gameDetails?.id.toString()
            )
        })

        mViewModel.makeJsonObjectForRelatedArticle.observe(this, Observer {
            mViewModel.fetchRelatedArticles(it.first.toString(), it.second.toString())
        })

        mViewModel.relatedArticleSuccessResponse.observe(this, Observer {
            it?.data?.apply {
                if (!this.isNullOrEmpty()) {
                    relatedArticleList.addAll(this)
                    relatedArticleAdapter.notifyDataSetChanged()
                    linearLayoutRelatedArticles.beVisible()
                    //   btnViewAll.beVisible()
                } else {
                    //   btnViewAll.beGone()
                    linearLayoutRelatedArticles.beGone()
                }
            }
        })

        mViewModel.postCommentSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            when (it.first) {
                "post" -> {
                    textViewNoComment.beGone()
                    editTextComment.setText("")
                    commentList.add(it.second.data!!)
                    articleCommentAdapter.notifyItemInserted(commentList.size - 1)
                }
                else -> {
                    commentList[replayCommentPosition].replies?.add(it.second.data!!)
                    articleCommentAdapter.notifyItemChanged(replayCommentPosition)
                    articleCommentAdapter.removeReplyView(replayCommentPosition + 1)
                }
            }
        })

        mViewModel.postCommentErrorResponse.observe(this, Observer {
            dismissProgressDialog()
            it.second.string().getMessageFromObject("message")
                .showToast(this@ArticlesDetailActivity)

        })

        mViewModel.likeCommentSuccessResponse.observe(this, Observer {
            dismissProgressDialog()
            if (it.second == "comment") {
                if (isReplyLikeComment) {
                    val comment = commentList[positionComment].replies?.get(replayCommentPosition)!!
                    if (comment.type != -1) {
                        if (comment.type == 0) {
                            comment.type = 1
                            comment.totalLikes?.apply {
                                comment.totalLikes = this + 1
                            }
                        } else {
                            comment.type = 0
                            comment.totalLikes?.apply {
                                comment.totalLikes = this - 1
                            }
                        }
                    } else {
                        val linkedId =
                            JSONObject(it.first.string()).getJSONObject("data").getString("likeId")
                        comment.type = 1
                        comment.totalLikes = 1
                        comment.likeId = linkedId
                    }
                    commentList[positionComment].replies?.set(replayCommentPosition, comment)

                    articleCommentAdapter.notifyItemChanged(positionComment)

                } else {
                    val comment = commentList[positionComment]
                    if (comment.type != -1) {
                        if (comment.type == 0) {
                            comment.type = 1
                            comment.totalLikes?.apply {
                                comment.totalLikes = this + 1
                            }
                        } else {
                            comment.type = 0
                            comment.totalLikes?.apply {
                                comment.totalLikes = this - 1
                            }
                        }
                    } else {
                        val linkedId =
                            JSONObject(it.first.string()).getJSONObject("data").getString("likeId")

                        comment.type = 1
                        comment.totalLikes = 1
                        comment.likeId = linkedId

                    }
                    commentList[positionComment] = comment
                    articleCommentAdapter.notifyItemChanged(positionComment)
                }

            } else {
                if (likeType != -1) {
                    if (likeType == 0) {
                        likeCounter -= 1
                        this@ArticlesDetailActivity.updateTintColor(
                            R.color.black,
                            imageViewLike
                        )
                        imageViewLike.background = ContextCompat.getDrawable(
                            this@ArticlesDetailActivity,
                            R.drawable.article_detail_round_border
                        )
                    } else {
                        likeCounter += 1
                        this@ArticlesDetailActivity.updateTintColor(R.color.white, imageViewLike)
                        imageViewLike.background = ContextCompat.getDrawable(
                            this@ArticlesDetailActivity,
                            R.drawable.article_option_selected_bg
                        )
                    }

                } else {
                    likeType = 1
                    articleLikeID =
                        JSONObject(it.first.string()).getJSONObject("data").getString("likeId")
                    likeCounter += 1
                    this@ArticlesDetailActivity.updateTintColor(R.color.white, imageViewLike)
                    imageViewLike.background = ContextCompat.getDrawable(
                        this@ArticlesDetailActivity,
                        R.drawable.article_option_selected_bg
                    )
                }

                txtlikes.text =
                    likeCounter.toString().plus(" ").plus(resources.getString(R.string.like))
            }
        })

        mViewModel.likeCommentErrorResponse.observe(this, Observer {
            dismissProgressDialog()
        })
    }

    /**
     * @desc method will call when tap on comment reply option from comment adapter
     * @param position adapter click item position
     */
    private fun onReplayClick(position: Int) {
        if (sharedPreferences.checkUserLoggedInOrNot()) {
            articleCommentAdapter.addReplyView(position)
        } else {
            launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
        }

    }

    /**
     * @desc method will call when tap on like option from comment adapter
     * @param position adapter click item position
     * @param id Article id
     * @param type like type. it will be(-1,0,1)
     * @param likeId like id if type is -1 then id will be null
     * @param isReplyComment check it's tap on comment like or comment reply like
     * @param replyPosition reply comment adapter item position
     */
    private fun onLikeComment(
        position: Int,
        id: String,
        type: Int,
        likeId: String,
        isReplyComment: Boolean,
        replyPosition: Int
    ) {
        if (sharedPreferences.checkUserLoggedInOrNot()) {
            positionComment = if (replyPosition != -1) {
                replayCommentPosition = position
                replyPosition
            } else {
                position
            }

            isReplyLikeComment = isReplyComment
            if (type == -1) {
                mViewModel.makeJsonObjectForLikeComment(id, sharedPreferences.id, "comment")
            } else {
                commentsLikeID = likeId
                mViewModel.makeJsonObjectForUpdateLike("updateLikeComment", if (type == 1) 0 else 1)
            }
        } else {
            launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
        }


    }


//    /**
//     * @desc assign menu file
//     */
//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.menu_article_detail, menu)
//        return super.onCreateOptionsMenu(menu)
//    }

    /**
     * @desc Register receiver for check internet connection
     */
    override fun onResume() {
        super.onResume()
        registerReceiver(connectivityReceiver, IntentFilter(AppConstants.CONNECTION_ACTION))
        ConnectivityReceiver.connectivityReceiverListener = this
    }


    /**
     * @desc Unregister receiver for check internet connection
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(this@ArticlesDetailActivity).unregisterReceiver(this)
        }
    }

    override fun onBackPressed() {
        if (isBookMarkDeleted) {
            val intent = Intent()
            intent.putExtra("isBookMarkDeleted", isBookMarkDeleted)
            setResult(AppConstants.REFRESH_CODE, intent)
        }
        super.onBackPressed()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && !isDataLoaded) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoInternet.beGone()
            constraintLayoutErrorView.beGone()
            coordinatorLayoutArticleDetail.beGone()
            mViewModel.makeJsonObjectForArticleDetail(id, sharedPreferences.id)
        } else if (!isDataLoaded) {
            coordinatorLayoutArticleDetail.beGone()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoInternet.beVisible()
            constraintLayoutErrorView.beGone()
        }
    }

    private fun manageUIAfterBeforeLogin() {
        if (sharedPreferences.checkUserLoggedInOrNot()) {
            editTextComment.beVisible()
            textViewCommentLBL.beVisible()
            buttonSubmitComment.beVisible()
            relativeLayoutLogin.beGone()
        } else {
            editTextComment.beGone()
            textViewCommentLBL.beGone()
            buttonSubmitComment.beGone()
            relativeLayoutLogin.beVisible()
        }
        articleCommentAdapter.updateUserData()
    }

    override fun onNotify(notifyType: String) {
        if (notifyType == "article") {
            manageUIAfterBeforeLogin()
        }
    }

    private fun launchLoginPopUp(msg: String) {
        displayCustomAlertDialog(msg,
            isCancelable = true,
            isCloseShow = true,
            positiveText = resources.getString(R.string.login),
            positiveClick = {
                it.dismiss()
                redirectType = "article"
                startActivityInline<PhoneSignInActivity>()
            },
            negativeText = resources.getString(R.string.str_cancel),
            negativeClick = {
                it.dismiss()
            }, onCloseClick = {
                it.dismiss()
            })
    }

    private fun bindHTMLText(text:String):String{
        return ("<htm><head><style>body{color:black; font-size: 40px; }  h1 { font-size: 56px; font-weight: bold;}" +
                    "h2 { font-size: 48px; font-weight: bold;  }" +
                "h3 { font-size: 44px; }p{align:justify;font-size:40px;}a{color:black;text-decoration: none;font-weight: bold;}img{ max-width: 100%; }</style></head><body>" ).plus(text).plus("</body></html>")
    }
}