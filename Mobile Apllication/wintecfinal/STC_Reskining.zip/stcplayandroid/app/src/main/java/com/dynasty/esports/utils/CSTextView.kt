package com.dynasty.esports.utils

import android.content.Context
import androidx.appcompat.widget.AppCompatTextView
import android.util.AttributeSet
import androidx.core.content.ContextCompat
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.lightFont
import com.dynasty.esports.extenstion.mediumFont
import com.dynasty.esports.extenstion.semiBoldFont

/**
 * @desc this class will handle TextView properties
 * @author : Mahesh Vayak
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class CSTextView : AppCompatTextView {

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context) : super(context) {
        init()
    }

    fun init() {
        if (!isInEditMode) {
            try {
                typeface = context.semiBoldFont()
                //setTextColor(ContextCompat.getColor(context, R.color.white))
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }

}