package com.dynasty.esports.view.otp_verification

import `in`.aabhasjindal.otptextview.OTPListener
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.CountDownTimer
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.SocialVerificationRequest
import com.dynasty.esports.models.VerifyRequest
import com.dynasty.esports.view.common.SocialLoginActivity
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.signin.email.EmailSignInActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.signup.phone.PhoneNumRegistrationActivity
import com.dynasty.esports.viewmodel.OTPVerificationViewModel
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_o_t_p_verification.*
import kotlinx.android.synthetic.main.content_otp_verification_screen.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class OTPVerificationActivity : SocialLoginActivity(), SMSBroadcastReceiver.OTPReceiveListener {
    var isAccount: Boolean = false
    var email: String? = null
    var type: String? = null

    //var token: String? = null
    var otpValue: String? = null
    var activity: String? = null
    var id: String? = null
    var phoneNumber: String? = null
    var isEmail: Boolean? = false
    private var isSocial: Boolean = false

    private val mViewModel: OTPVerificationViewModel by viewModel()
    internal var TAG = this::class.toString()
    internal var smsBroadcastReceiver: SMSBroadcastReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_o_t_p_verification)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        getIntentData()
        initialize()
        listenToViewModel()
    }

    // to get data
    private fun getIntentData() {
        intent.extras?.apply {
            isAccount = this.getBoolean("isAccount")
            email = this.getString("email").toString()
            type = this.getString("type")
            token = this.getString("token")
            activity = this.getString("activity")
            id = this.getString("id")
            isSocial = this.getBoolean("isSocial")
            phoneNumber = this.getString("phoneNumber")
            isEmail = this.getBoolean("isEmail")
        }
    }

    //initialize view
    private fun initialize() {
        /*here type
        * 1. phone : OTP has been sent on your registered Phone Number
        * 2. email : OTP has been sent on your registered Phone Number
        * 3. login : this is email registration, phone nos not verified flow, so show same msg as that of phone*/
        if (type == "phone" || type == "login") {
            otp_welcome_txt_view.text =
                resources.getString(R.string.password_subtitle_phone)
                    .plus("\n" + phoneNumber)
        } else {
            otp_welcome_txt_view.text =
                resources.getString(R.string.password_subtitle_mail)
                    .plus("\n" + email)
        }

        //Initialise the AppSignatureHelper
        val appSignatureHelper = AppSignatureHelper(applicationContext)
        appSignatureHelper.appSignatures;
        //        Initialize the SmsRetriever client
        val client = SmsRetriever.getClient(this)
//        Start the SMS Retriever task
        val task = client.startSmsRetriever()
        task.addOnSuccessListener { aVoid ->
//            if successfully started, then start the receiver.
            registerReceiver(
                smsBroadcastReceiver,
                IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION)
            )

        }
        task.addOnFailureListener { e ->
            //            if failure print the exception.
            Log.e(TAG, e.toString())
        }

        smsBroadcastReceiver = SMSBroadcastReceiver()
        smsBroadcastReceiver!!.initOTPListener(this)

        resend.makeSpannableString(
            this,
            resources.getString(R.string.resend_title),
            20,
            resources.getString(R.string.resend_title).length,
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    resend.visibility = View.GONE
                    getCountDownTimer()

                    if(isSocial){
                        val jsonObject = JsonObject()
                        jsonObject.addProperty("type", "resend_otp")
                        jsonObject.addProperty("id", id)
                        mViewModel.resendSocialOtp(jsonObject)
                    }else{
                        val jsonObject = JsonObject()
                        jsonObject.addProperty("type", type)
                        if (type == "phone" || type == "login") {
                            jsonObject.addProperty("phoneNumber", phoneNumber)
                        } else if (type == "email" || type == "account") {
                            jsonObject.addProperty("email", email)
                        }
                        mViewModel.resendOtp(jsonObject)
                    }
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })

        getCountDownTimer()

        social_login_fb.click {
            mViewModel.fbLoginClick()

        }

        social_login_gPlus.click {
            mViewModel.googleLoginClick()
        }
        otpVerification_bottom_view.click {
            mViewModel.redirectPhoneRegistration()

        }

        otpVerification_bottom_view.click {
            mViewModel.redirectPhoneSignIn()
        }

        //Issue : after email registration -> NumbeVerificaction - > OTP screen click (Invalid registration type msg)
        otp_continue.click {
            launchProgressDialog()
            when {
                activity.toString().contains("PhoneNumVerificationActivity") -> {
                    val socialReq = SocialVerificationRequest()
                    socialReq.id = id
                    socialReq.otp = otpValue
                    socialReq.type = "verify_mobile"
                    // socialReq.type = type
                    mViewModel.socialOTPVerification(socialReq)
                }
                isAccount -> {
                    val jsonObject = JsonObject()
                    jsonObject.addProperty("type", "email")
                    jsonObject.addProperty("otp", otpValue)
                    mViewModel.verifyEmailOtp(jsonObject)
                }
                else -> {
                    val otpToVerify = VerifyRequest()
                    otpToVerify.otp = otpValue
                    otpToVerify.token = sharedPreferences.accessToken
                    otpToVerify.type = type
                    mViewModel.otpVerify(otpToVerify)
                }
            }
        }

        otp_text.requestFocusOTP()
        otp_text.otpListener = object : OTPListener {
            override fun onInteractionListener() {

            }

            override fun onOTPComplete(otp: String) {
                otpValue = otp
            }
        }
    }

    // listen view model and manage api response
    private fun listenToViewModel() {

        mViewModel.resendOTPSuccessResponse.observe(this, {
            it.string().getMessageFromObject("message").showToast(this)
        })

        mViewModel.resendOTPErrorResponse.observe(this, {
            it.string().getMessageFromObject("message").showToast(this)
        })



        mViewModel.redirectPhoneRegistrationObserver.observe(this, {
            startActivityInline<PhoneNumRegistrationActivity>()
        })

        mViewModel.redirectPhoneSignInObserver.observe(this, {
            startActivityInline<PhoneSignInActivity>()
        })

        // While Email login with phone number verification
        mViewModel.socialOTPVerificationSuccessResponse.observe(this, {
            sharedPreferences.refreshToken = it.first
            it.second.apply {
                this.message.showToast(this@OTPVerificationActivity)
                this.data.apply {
                    sharedPreferences.accessToken = this.token
                    registerFCMToken()
                    commonViewModel.fetchUser()
                }
            }
        })

        mViewModel.socialOTPVerificationErrorResponse.observe(this, {
            dismissProgressDialog()
            otp_text.setOTP("")
            /* here */
            makeSnackBar(
                constraintLayoutOtpVerifiction,
                it.string().getMessageFromObject("message")
            )
        })

        commonViewModel.userSuccessResponse.observe(this, {
            dismissProgressDialog()
            it.data?.apply {
                sharedPreferences.isLoggedIn = true
                if (isSocial)
                    sharedPreferences.isLogin = true
                sharedPreferences.id = this.id.toString()
                sharedPreferences.put("user", this)
//                startActivityInlineWithFinishAll<DashboardActivity>()
                val bundle=Bundle()
                bundle.putString("type",redirectType)
                val intent= Intent(AppConstants.NOTIFY_ACTION)
                intent.putExtras(bundle)
                LocalBroadcastManager.getInstance(this@OTPVerificationActivity).sendBroadcast(intent)
                killAllActivities()
            }
        })

        commonViewModel.userErrorResponse.observe(this, {
            dismissProgressDialog()
            displayCustomAlertDialog(
                resources.getString(R.string.something_wrong_try_again),
                isCancelable = false,
                positiveText = resources.getString(R.string.retry),
                positiveClick = {
                    it.dismiss()
                    redirectToLogin()
                })
        })


        // While Registration

        mViewModel.otpVerificationSuccessResponse.observe(this, {
            dismissProgressDialog()
            if(type=="phone"){
                val bundle=Bundle()
                bundle.putString("email", email)
                bundle.putString("type", "email")
                bundle.putString("phoneNumber", phoneNumber)
                startActivityInline<OTPVerificationActivity>(bundle)
            }else {
                sharedPreferences.refreshToken = it.first
                sharedPreferences.accessToken = it.second.data.token
                registerFCMToken()
                commonViewModel.fetchUser()
            }

        })
        mViewModel.otpVerificationErrorResponse.observe(this, {
            otp_text.setOTP("")
            dismissProgressDialog()
            /*here */
            makeSnackBar(constraintLayoutOtpVerifiction, it)
        })


        // While Update email from account
        mViewModel.emailOTPVerificationSuccessResponse.observe(this, {
            dismissProgressDialog()
            val intent = Intent()
            intent.putExtra("isRefresh", true)
            setResult(AppConstants.REFRESH_CODE, intent)
            finish()
        })

        mViewModel.emailOTPVerificationErrorResponse.observe(this, {
            dismissProgressDialog()
            otp_text.setOTP("")
            makeSnackBar(
                constraintLayoutOtpVerifiction,
                it.string().getMessageFromObject("message")
            )
        })

        mViewModel.noInternetException.observe(this, Observer {
            dismissProgressDialog()
            if (isOnline()) {
                displayCustomAlertDialog(
                    resources.getString(R.string.something_wrong_try_again),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.retry),
                    positiveClick = {
                        it.dismiss()
                    })
            } else {
                displayCustomAlertDialog(
                    resources.getString(R.string.no_internet_message),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.btn_ok),
                    positiveClick = {
                        it.dismiss()
                    })
            }

        })

        commonViewModel.noInternetException.observe(this, Observer {
            if (it == "user") {
                if (isOnline()) {
                    displayCustomAlertDialog(
                        resources.getString(R.string.something_wrong_try_again),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.retry),
                        positiveClick = {
                            it.dismiss()
                            redirectToLogin()
                        })
                } else {
                    displayCustomAlertDialog(
                        resources.getString(R.string.no_internet_message),
                        isCancelable = false,
                        positiveText = resources.getString(R.string.btn_ok),
                        positiveClick = {
                            it.dismiss()
                            redirectToLogin()
                        })
                }
            }
        })

        mViewModel.unAuthorizationException.observe(this, Observer {
            dismissProgressDialog()
            logOut()
        })
    }

    // to get reverse counter for resend
    private fun getCountDownTimer() {
        val timer = object : CountDownTimer(240000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                var diff = millisUntilFinished
                val secondsInMilli: Long = 1000
                val minutesInMilli = secondsInMilli * 60
                val hoursInMilli = minutesInMilli * 60
                val daysInMilli = hoursInMilli * 24

                val elapsedMinutes = diff / minutesInMilli
                diff %= minutesInMilli

                val elapsedSeconds = diff / secondsInMilli

                expries_in_text.text =
                    resources.getString(R.string.expires) + " " + "$elapsedMinutes : $elapsedSeconds "
//                expiresTxt.text = resources.getString(R.string.expires) +" "+ "$elapsedDays days $elapsedHours hs $elapsedMinutes min $elapsedSeconds sec"
            }

            override fun onFinish() {
                expries_in_text?.text = resources.getString(R.string.expires) + " " + "00 : 00 "
                resend?.beVisible()
            }
        }
        timer.start()
    }

    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }

    // to register the device token
//    private fun registerFCMToken(){
//        if(sharedPreferences.FCMToken.isNotEmpty()) {
//            val jsonObject = JsonObject()
//            jsonObject.addProperty("requestType", "register-push-notification")
//            jsonObject.addProperty("platform", "android")
//            jsonObject.addProperty("token", sharedPreferences.FCMToken)
//            mViewModel.registrationPushNotification(jsonObject)
//        }
//    }

//    fun onResendOTP(){
//
//    }

//    fun socialOTPVerification(otpRequest: SocialVerificationRequest) {
//        dialogBoxDisplay(true)
//        ApiClient.POST_INSTANCE.socialloginVerify(otpRequest)
//            .enqueue(object : Callback<SignInResponse> {
//                override fun onFailure(call: Call<SignInResponse>, t: Throwable) {
//                    Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
//                    dialogBoxDisplay(false)
//                }
//
//                override fun onResponse(
//                    call: Call<SignInResponse>,
//                    response: Response<SignInResponse>
//                ) {
//                    if (response.body() != null) {
//                        if (response.body()?.message.equals("Account verified Successfully")) {
//                            Toast.makeText(
//                                applicationContext,
//                                response.body()?.message,
//                                Toast.LENGTH_SHORT
//                            ).show()
//                            val intent = Intent(applicationContext, DashboardActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//                            intent.putExtra("token", response.body()?.data?.token)
//                            startActivity(intent)
//                        } else {
//                            Toast.makeText(
//                                applicationContext,
//                                response.body()?.message,
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                        dialogBoxDisplay(false)
//                    } else {
//                        val jObjError = JSONObject(response.errorBody()!!.string())
//                        Log.d("Error : ", jObjError.getString("message"))
//                        Toast.makeText(
//                            applicationContext,
//                            jObjError.getString("message"),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                        dialogBoxDisplay(false)
//                    }
//                }
//            })
//    }

//    fun onOTPContinue(otpRequest: VerifyRequest) {
//        dialogBoxDisplay(true)
//        ApiClient.POST_INSTANCE.loginVerify(otpRequest)
//            .enqueue(object : Callback<VerifyResponse> {
//                override fun onFailure(call: Call<VerifyResponse>, t: Throwable) {
//                    dialogBoxDisplay(false)
//                    Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
//                }
//
//                override fun onResponse(
//                    call: Call<VerifyResponse>,
//                    response: Response<VerifyResponse>
//                ) {
//                    if (response.body() != null) {
//                        if (response.body()?.message.equals("Account verified Successfully")) {

//                        dialogBoxDisplay(false)
//                    } else {
//                        dialogBoxDisplay(false)
//                        val jObjError = JSONObject(response.errorBody()!!.string())
//                        Log.d("Error : ", jObjError.getString("message"))
//                        Toast.makeText(
//                            applicationContext,
//                            jObjError.getString("message"),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                }
//            })
//    }


    private fun redirectToLogin() {
        if (type.equals("email")) {
            startActivityInlineWithFinishAll<EmailSignInActivity>()
        } else {
            startActivityInlineWithFinishAll<PhoneSignInActivity>()
        }
    }

    override fun onOTPReceived(otp: String?) {
        if (otp != null) {
            otp_text.setOTP(otp)
        }
    }

    override fun onOTPTimeOut() {
        TODO("Not yet implemented")
    }
}