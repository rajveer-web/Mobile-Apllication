package com.dynasty.esports.view.tournamet.manage_tournament.match


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterMatchRoundDetailBinding
import com.dynasty.esports.databinding.AdapterMatchRoundDetailHeaderBinding
import com.dynasty.esports.models.GameRoundDetailModel


class MatchRoundDetailAdapter(
    private var gameRoundDetailList: MutableList<GameRoundDetailModel.DataModel>,
    private val onItemClick: (Int, Int) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: AdapterMatchRoundDetailHeaderBinding =
                    DataBindingUtil.inflate(
                           inflater,
                        R.layout.adapter_match_round_detail_header,
                        parent,
                        false
                    )
                return ViewHolderHeader(binding)
            }
            else -> {
                val binding: AdapterMatchRoundDetailBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_match_round_detail,
                        parent,
                        false
                    )
                return ViewHolderDetail(binding)
            }

           }
    }


    override fun getItemCount(): Int {
        return gameRoundDetailList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) {
            0
        } else {
            1
        }
    }


    inner class ViewHolderHeader(private var binding: AdapterMatchRoundDetailHeaderBinding) :
        RecyclerView.ViewHolder(binding.root) {
//        fun bind(counter: Int) {
//            binding.recyclerViewSets.layoutManager = LinearLayoutManager(itemView.context, LinearLayoutManager.HORIZONTAL, false)
//            binding.recyclerViewSets.setHasFixedSize(false)
//            binding.recyclerViewSets.isNestedScrollingEnabled=false
//            val roundSetLabelAdapter = RoundSetLabelAdapter(counter)
//            binding.recyclerViewSets.adapter = roundSetLabelAdapter
//            binding.recyclerViewSets.scrollToPosition(scrollPosition)
//
//        }

    }

    inner class ViewHolderDetail(private var binding: AdapterMatchRoundDetailBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: GameRoundDetailModel.DataModel) {
            if (data.totalSet!! != data.sets!!.size) {
                for (i in 1..data.totalSet) {
                    if (data.sets.size < i) {
                        data.sets.add(GameRoundDetailModel.SetModel())
                    }
                }
            }
//            val layoutManager=LinearLayoutManager(itemView.context, LinearLayoutManager.HORIZONTAL, false)
//            binding.recyclerViewSets.layoutManager =layoutManager
//            binding.recyclerViewSets.setHasFixedSize(true)
//                //LinearLayoutManager(itemView.context, LinearLayoutManager.HORIZONTAL, false)
//            binding.recyclerViewSets.isNestedScrollingEnabled=false
//
//
//            binding.recyclerViewSets.addOnScrollListener(object : RecyclerView.OnScrollListener(){
//                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                    super.onScrollStateChanged(recyclerView, newState)
//                   scrollPosition=layoutManager.getPosition(recyclerView)
//
//                    notifyItemChanged(0)
//
//                }
//
//
//            })
//            val roundSetLabelAdapter = RoundSetDataAdapter(data.sets)
//            binding.recyclerViewSets.adapter = roundSetLabelAdapter
            data.apply {
                binding.textViewMatch.text = adapterPosition.toString()
                this.teamA?.apply {
                    binding.textViewTeamA.text = this.name?.let { it } ?: ""
                }
                this.teamB?.apply {
                    binding.textViewTeamB.text = this.name?.let { it } ?: ""
                }

                //final Score
                binding.textViewFinalAScrore.text = teamAWinSet.toString()
                binding.textViewFinalBScrore.text = teamBWinSet.toString()

//                if (this.loserTeam == null && this.winnerTeam == null) {
//                    binding.textViewStatusTeamA.text = binding.root.context.resources.getString(R.string.loser)
//                    binding.textViewStatusTeamB.text = binding.root.context.resources.getString(R.string.loser)
//                    binding.textViewStatusTeamA.setBackgroundColor(
//                        ContextCompat.getColor(
//                            binding.root.context,
//                            R.color.color_fbfbfb_2
//                        )
//                    )
//                    binding.textViewStatusTeamB.setBackgroundColor(
//                        ContextCompat.getColor(
//                            binding.root.context,
//                            R.color.color_fbfbfb_2
//                        )
//                    )
//
//                }

                    this.loserTeam?.let {
                        if (it.id == this.teamA?.id) {
                            binding.textViewStatusTeamA.text =binding.root.context.resources.getString(R.string.loser)
                            binding.textViewStatusTeamA.setBackgroundColor(
                                ContextCompat.getColor(
                                    binding.root.context,
                                    R.color.color_fbfbfb_2
                                )
                            )
                        }
                        if (it.id == this.teamB?.id) {
                            binding.textViewStatusTeamB.text =binding.root.context.resources.getString(R.string.loser)
                            binding.textViewStatusTeamB.setBackgroundColor(
                                ContextCompat.getColor(
                                    binding.root.context,
                                    R.color.color_fbfbfb_2
                                )
                            )
                        }
                    }



                    this.winnerTeam?.let {
                        if (it.id == this.teamA?.id) {
                            binding.textViewStatusTeamA.text = binding.root.context.resources.getString(R.string.winner)
                            binding.textViewStatusTeamA.setBackgroundColor(
                                ContextCompat.getColor(
                                    binding.root.context,
                                    R.color.colorAccent
                                )
                            )
                        }
                        if (it.id == this.teamB?.id) {
                            binding.textViewStatusTeamB.text = binding.root.context.resources.getString(R.string.winner)
                            binding.textViewStatusTeamB.setBackgroundColor(
                                ContextCompat.getColor(
                                    binding.root.context,
                                    R.color.colorAccent
                                )
                            )
                        }
                    }


            }
//            val roundSetLabelAdapter = RoundSetLabelAdapter(counter)
//            binding.recyclerViewSets.adapter = roundSetLabelAdapter

        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
              //  (holder as ViewHolderHeader).bind(gameRoundDetailList[position].totalSet!!)
            }
            else -> {
                (holder as ViewHolderDetail).bind(gameRoundDetailList[position])
            }
        }
    }



}