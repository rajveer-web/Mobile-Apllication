package com.dynasty.esports.view.tournamet.tournamet_detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.UpcomingParticipantsViewModel
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.fragment_upcoming_participants.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class TournamentParticipantsFragment : BaseFragment() {

    private lateinit var tournamentObject: TournamentDetailRes
    private val mViewModel: UpcomingParticipantsViewModel by viewModel()

    private lateinit var participantsTeamAdapter: TournamentParticipantsAdapter

    var id: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_upcoming_participants, container, false)
    }

    companion object {

        fun newInstance(gameItem: TournamentDetailRes): Fragment {
            val args = Bundle()
            args.putParcelable("data", gameItem)
            val fragment = TournamentParticipantsFragment()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
        getParticipantsList()
    }

    fun listenToViewModel() {

//      get participantsList Success Response
        mViewModel.participantsListSuccessResponse.observe(
            viewLifecycleOwner,
            {
                pbParticipantList.beGone()
                dismissProgressDialog()
                participantsTeamAdapter.addAll(it.data!!)
                refreshPlaceHolder()
            })

//      get participantsList Error Response
        mViewModel.participantsListErrorResponse.observe(viewLifecycleOwner, {
                pbParticipantList.beGone()
                dismissProgressDialog()
            })
    }

    //    getParticipantsList api call
    private fun getParticipantsList() {
        val jsonObjectQuery = JsonObject()
        jsonObjectQuery.addProperty("tournamentId", tournamentObject.data!!.id)
        jsonObjectQuery.addProperty("participantStatus", "approved")
//        showProgressDialog()
        pbParticipantList.beVisible()
        participants_no_data.beGone()
        mViewModel.getParticipantsList(jsonObjectQuery.toString())
    }

    fun initialise() {
        arguments?.apply {
            tournamentObject = this.getParcelable<TournamentDetailRes>("data")!!
        }

        participantsTeamAdapter = TournamentParticipantsAdapter(onItemClick = ::OnParticipantClick)

        rvParticipants.layoutManager = GridLayoutManager(activity, 3)
        rvParticipants.adapter = participantsTeamAdapter
        rvTeamParticipants.layoutManager =
            LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)

        ivback.click {
            llparticipantsRecyclerView.beVisible()
            llparticipantsGroupInfo.beGone()
            ivback.beGone()
        }
    }

    //  Participant list item click
    private fun OnParticipantClick(position: Int) {
        val data = participantsTeamAdapter.getItem(position)
        if (llparticipantsRecyclerView.isVisible) {
            llparticipantsRecyclerView.beGone()
            llparticipantsGroupInfo.beVisible()
            ivback.beVisible()

            if (data.logo.isNotEmpty()) {
                requireActivity().loadImageFromServer(data.logo, imgParticipantTeam)
            }

            participant_team_name.text = data.teamName?.capitalize()
            participant_team_player_count.text = data.teamMembers?.size.toString() + " Players"
            //Set player adapter :
            if (data.teamMembers!!.size > 0) {
                rvTeamParticipants.adapter = ParticipantsTeamAdapter(data.teamMembers)
            }
        } else {
            llparticipantsRecyclerView.beVisible()
            llparticipantsGroupInfo.beGone()
            ivback.beGone()
        }
    }

    //  refresh view for show no internet view, progress bar and no data display view
    private fun refreshPlaceHolder() {
        pbParticipantList.beGone()
        if (rvParticipants.adapter!!.itemCount > 0) {
            rvParticipants.beVisible()
            participants_no_data.beGone()
        } else {
            rvParticipants.beGone()
            participants_no_data.beVisible()
        }
    }
}