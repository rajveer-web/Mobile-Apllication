package com.dynasty.esports.view.profile


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterProfileOptionBinding
import com.dynasty.esports.databinding.AdapterProfileSubitemBinding
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.models.ProfileModel
import com.dynasty.esports.models.SubProfileOptionModel
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will display sub items of profile option.
 * @author : Mahesh Vayak
 * @created : 24-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ProfileSubItemAdapter(
    private var profileSubItemList: MutableList<SubProfileOptionModel>,
    private val onItemClick: (Int,String) -> Unit = { _,_ -> }
) : RecyclerView.Adapter<BindingHolder<AdapterProfileSubitemBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterProfileSubitemBinding> {
        return BindingHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.adapter_profile_subitem, parent, false))
    }

    /**
     * @desc profile sub item array size count.
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return profileSubItemList.size
    }


    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterProfileSubitemBinding>,
        position: Int
    ) {
        holder.binding.textViewProfileLabel.text = profileSubItemList[position].title

        holder.binding.constraintLayoutOption.click {
            onItemClick(position,profileSubItemList[position].type)
        }
    }


}