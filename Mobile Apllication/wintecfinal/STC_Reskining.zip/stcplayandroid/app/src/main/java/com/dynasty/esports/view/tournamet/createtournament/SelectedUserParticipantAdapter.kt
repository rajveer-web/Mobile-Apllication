package com.dynasty.esports.view.tournamet.createtournament

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.SelectedRegionsItemBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.nullSafeNA
import com.dynasty.esports.models.SearchUser
import com.dynasty.esports.utils.BindingHolder

/**
 * @desc this is class will use for Selected User Participantlist from CreateTournamentStep3Fragment
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class SelectedUserParticipantAdapter constructor(
    private val onItemRemoveClick: (Int) -> Unit = { _ -> }
) :
    RecyclerView.Adapter<BindingHolder<SelectedRegionsItemBinding>>() {

    private var selectedParticipantList: MutableList<SearchUser.Datum> = ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<SelectedRegionsItemBinding> {
        val binding: SelectedRegionsItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.selected_regions_item,
            parent,
            false
        )
        return BindingHolder(binding)
    }

    /**
     * @desc selectedParticipantList array size
     * @return int- array size
     */
    override fun getItemCount(): Int {
        return selectedParticipantList.size
    }

    /**
     * @desc add list in selectedParticipantList and notify adapter
     */
    fun addAll(selectedRegionsList_: MutableList<SearchUser.Datum>) {
        selectedParticipantList.addAll(selectedRegionsList_)
        notifyDataSetChanged()
    }

    /**
     * @desc check is already added in selectedParticipantList
     * @param id check from id. Its added or not in list.
     *       if added then return true otherwise return false
     */
    fun isAlreadyAdded(id: String): Boolean {
        for (i in selectedParticipantList) {
            if (i.id.equals(id, true)) {
                return true
            }
        }
        return false
    }

    /**
     * @desc add item in selectedParticipantList and notify adapter
     */
    fun add(item: SearchUser.Datum) {
        selectedParticipantList.add(item)
        notifyDataSetChanged()
    }

    /**
     * @desc remove item from selectedParticipantList and notify adapter
     */
    fun remove(item: SearchUser.Datum) {
        selectedParticipantList.remove(item)
        notifyDataSetChanged()
    }

    /**
     * @desc get selectedParticipantList( main array list)
     */
    fun getAll(): MutableList<SearchUser.Datum>? {
        return selectedParticipantList
    }

    /**
     * @desc get single item from position
     */
    fun get(position: Int): SearchUser.Datum {
        return selectedParticipantList[position]
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents and to reflect the item at the given position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<SelectedRegionsItemBinding>,
        position: Int) {
        val data = selectedParticipantList[position]
        holder.binding.tvSelectedRegionsText.text = nullSafeNA(data.fullName)
        holder.binding.imgClear.click {
            onItemRemoveClick(position)
        }
    }
}