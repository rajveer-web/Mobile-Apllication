package com.dynasty.esports.viewmodel

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.TextView
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isEmailValid
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.SignInRequest
import com.dynasty.esports.models.SignInResponse
import com.dynasty.esports.models.UploadFilesRes
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.fragment_create_tournament_step2.*
import kotlinx.coroutines.*
import okhttp3.ResponseBody
import retrofit2.HttpException
import java.net.ConnectException
import java.net.UnknownHostException
import java.util.*

class CreateTournamentStep2ViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {

    val validationLiveData = MutableLiveData<Int>()
    val isNextStepFormValid = MutableLiveData<Boolean>()

    val uploadFileSuccessResponse = MutableLiveData<UploadFilesRes>()
    val uploadFileErrorResponse = MutableLiveData<ResponseBody>()

    fun onValidationForNextStep(
        prize_switch: Boolean,
        prizeType: String,
        tvFirstPrice: String,
        tvSecondPrice: String,
        tvThirdPrice: String,
        llForthPrice: Int,
        llFifthPrice: Int,
        llSixthPrice: Int,
        tvFourthPrice: String,
        tvFifthPrice: String,
        tvSixthPrice: String,
        rbHybrid: Boolean,
        rbOnline: Boolean,
        rbOffline: Boolean,
        sponsorsSwitch: Boolean,
        tvHybridSelectStage: String,
        tvHybridAddVenue: String,
        tvHybridSelectCountry: String,
        tvHybridSelectRegion: String,
        addSponsorValidated: Boolean,
        addVanueValidated: Boolean,
        switchPart: Boolean,
        partNumber: Int
    ) {
        when {
            prize_switch && prizeType.isFieldEmpty() -> validationLiveData.postValue(0)
            prize_switch && tvFirstPrice.isFieldEmpty() -> validationLiveData.postValue(1)
            prize_switch && tvSecondPrice.isFieldEmpty() -> validationLiveData.postValue(2)
            prize_switch && tvThirdPrice.isFieldEmpty() -> validationLiveData.postValue(3)

            prize_switch && llForthPrice == 0 && tvFourthPrice.isFieldEmpty() -> validationLiveData.postValue(11)
            prize_switch && llFifthPrice == 0 && tvFifthPrice.isFieldEmpty() -> validationLiveData.postValue(12)
            prize_switch && llSixthPrice == 0 && tvSixthPrice.isFieldEmpty() -> validationLiveData.postValue(13)



            rbHybrid && tvHybridSelectStage.isFieldEmpty() -> validationLiveData.postValue(4)
            rbHybrid && tvHybridAddVenue.isFieldEmpty() -> validationLiveData.postValue(5)
            rbHybrid && tvHybridSelectCountry.isFieldEmpty() -> validationLiveData.postValue(6)
            rbHybrid && tvHybridSelectRegion.isFieldEmpty() -> validationLiveData.postValue(7)
            sponsorsSwitch && !addSponsorValidated -> validationLiveData.postValue(8)
            rbOffline && !addVanueValidated -> validationLiveData.postValue(9)
            switchPart && partNumber < 2 || partNumber > 1024 -> validationLiveData.postValue(10)
            else -> isNextStepFormValid.postValue(true)
        }
    }

    fun uploadFiles(uploadFileJson: JsonObject) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.uploadFiles(uploadFileJson)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    uploadFileSuccessResponse.postValue(response.body())
                }
                else -> {
                    uploadFileErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * Clears the [ViewModel] when the [CreateTournamentActivity] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }
}
