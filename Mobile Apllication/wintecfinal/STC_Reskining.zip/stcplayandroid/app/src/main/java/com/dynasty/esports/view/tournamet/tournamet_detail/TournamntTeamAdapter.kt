package com.dynasty.esports.view.tournamet.tournamet_detail

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.BitmapImageViewTarget
import com.dynasty.esports.R
import com.dynasty.esports.models.TeamListDetail
import kotlinx.android.synthetic.main.listitem_team.view.*


class TournamntTeamAdapter  ( teamList: MutableList<TeamListDetail>,  listener: OnItemClickListener) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var teamListt : MutableList<TeamListDetail>
    var listenerr : OnItemClickListener

    init {
        this.teamListt = teamList
        this.listenerr = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SelectTeamViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.listitem_team, parent, false)
        )
    }

    override fun getItemCount(): Int = teamListt.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val teamViewHolder = viewHolder as SelectTeamViewHolder
        teamViewHolder.bindView(teamListt[position],listenerr)
    }

    class SelectTeamViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(
            gameModel: TeamListDetail,
            listenerr: OnItemClickListener
        ) {
            itemView.team_name.text = gameModel.teamName
//            Glide.with(itemView.context)
//                .load(gameModel.teamIcon)
//                .asBitmap()
//                .into(object : BitmapImageViewTarget(itemView.team_icon) {
//                    override fun setResource(resource: Bitmap) {
//                        val drawable = RoundedBitmapDrawableFactory.create(
//                            itemView.context.resources,
//                            Bitmap.createScaledBitmap(resource, 50, 50, false)
//                        )
//                        drawable.isCircular = true
//                        itemView.team_icon.setImageDrawable(drawable)
//                    }
//                })


            itemView.setOnClickListener {
                listenerr.onItemClick(gameModel.teamPlayersLit)
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(gameName: ArrayList<String>?)
    }
    }