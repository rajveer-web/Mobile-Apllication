package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DiscussionComment {

    @SerializedName("message")
    @Expose
    val message: String? = null

    @SerializedName("success")
    @Expose
    val success: Boolean? = null

    @SerializedName("data")
    @Expose
    val data: MutableList<DataModel>? = null

    class  DataModel{

        @SerializedName("createdOn")
        @Expose
        val createdOn: String? = null

        @SerializedName("status")
        @Expose
        val status: String? = null

        @SerializedName("comment")
        @Expose
        val comment: String? = null

        @SerializedName("userId")
        @Expose
        val userId: String? = null

        @SerializedName("objectId")
        @Expose
        val objectId: String? = null

        @SerializedName("objectType")
        @Expose
        val objectType: String? = null

        @SerializedName("modifiedOn")
        @Expose
        val modifiedOn: String? = null

        @SerializedName("__v")
        @Expose
        val v: Int? = null

        @SerializedName("userDetails")
        @Expose
        val userDetails: HottestPostArticleModel.UserDetailsModel? = null

        @SerializedName("id")
        @Expose
        val id: String? = null

        @SerializedName("type")
        @Expose
        var type: Int? = null

        @SerializedName("likeId")
        @Expose
        var likeId: String? = null

        @SerializedName("totalLikes")
        @Expose
        var totalLikes: Int? = null

        var isReply=false

        @SerializedName("replies")
        @Expose
        var replies: MutableList<DiscussionComment.DataModel>? = null

        var isViewVisible=false

    }
}