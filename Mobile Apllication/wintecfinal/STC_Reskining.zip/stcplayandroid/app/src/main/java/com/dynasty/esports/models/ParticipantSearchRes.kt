package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ParticipantSearchRes {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("messageCode")
    @Expose
    var messageCode: String? = null

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: Data? = null


    class Data {
        @SerializedName("invalidId")
        @Expose
        var invalidId = false

        @SerializedName("isExist")
        @Expose
        var isExist = false
    }
}