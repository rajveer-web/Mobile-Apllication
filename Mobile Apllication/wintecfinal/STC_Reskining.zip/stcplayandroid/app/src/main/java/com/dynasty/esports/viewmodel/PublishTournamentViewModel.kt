package com.dynasty.esports.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.retrofit.RestInterface
import com.dynasty.esports.utils.Validator
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import com.dynasty.esports.models.CreateTournamentRes

class PublishTournamentViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val validationLiveData = MutableLiveData<Int>()
    val isFormValid = MutableLiveData<Boolean>()

    val createTournamentSuccessResponse = MutableLiveData<CreateTournamentRes>()
    val createTournamentErrorResponse = MutableLiveData<ResponseBody>()

    fun onValidationCreatePassword(password: String, confirmPass: String) {
        when {
            password.isFieldEmpty() -> validationLiveData.postValue(0)
            confirmPass.isFieldEmpty() -> validationLiveData.postValue(1)
            !Validator.isValidPassword(password) -> validationLiveData.postValue(2)
            !Validator.isValidPassword(confirmPass) -> validationLiveData.postValue(3)
            else -> isFormValid.postValue(true)
        }
    }

    //   Api call for publish tournament
    fun createTournament(jsonObject: JsonObject, tournamentId: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
//            val response = restInterface.createTournamentPublish(tournamentId, jsonObject)
            val response = restInterface.createTournament(jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    createTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    createTournamentErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    //   Api call for edit tournament
    fun editTournament(jsonObject: JsonObject, tournamentId: String) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
//            val response = restInterface.createTournamentPublish(tournamentId, jsonObject)
            val response = restInterface.editTournament(tournamentId, jsonObject)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    createTournamentSuccessResponse.postValue(response.body())
                }
                else -> {
                    createTournamentErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    /**
     * Clears the [ViewModel] when the [PublishTournamentViewModel] is not visible to user.
     */
    fun onDetach() {
        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
