package com.dynasty.esports.view.inbox

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.InboxMessagesListModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.viewmodel.InboxViewModel
import kotlinx.android.synthetic.main.fragment_inbox.*
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will display specific inbox messages lists.
 * @author : Mahesh Vayak
 * @created : 04-08-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class InboxMessageFragment : BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener {
    val mViewModel: InboxViewModel by viewModel()
    private var id: String = ""
    private var isSeen: Boolean = false
    private var dataList: MutableList<InboxMessagesListModel.DataModel> = mutableListOf()
    private lateinit var inboxListAdapter: InboxMessagesAdapter
    private var connectivityReceiver = ConnectivityReceiver()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_inbox, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /**
         * @desc get data from arguments
         */
        arguments?.apply {
            isSeen = this.getBoolean("seen")
            id = this.getString("id").toString()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        listenToViewModel()
        viewClickListener()
    }

    /**
     * @desc Initialize view and assign Inbox Messages adapter to recyclerview
     */
    private fun initView() {
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        inboxListAdapter = InboxMessagesAdapter(dataList, sharedPreferences.id)
        commonRecyclerView.adapter = inboxListAdapter
        constraintLayoutSendComment.beVisible()
        checkBoxSelectAll.beGone()
        imageViewDelete.beGone()
        commonRecyclerView.addOnLayoutChangeListener { v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (bottom < oldBottom) {
                commonRecyclerView.smoothScrollToPosition(dataList.size - 1)
            }
        }

    }

    /**
     * @desc this method use for assign callback to view
     */
    private fun viewClickListener() {
        buttonSend.click {
            mViewModel.checkMessageValidation(editTextViewMessage.text.toString().trim())

        }
    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make jsonobject for API and un authorization.
     */
    private fun listenToViewModel() {
        mViewModel.unAuthorizationException.observe(viewLifecycleOwner, Observer {
            if (it)
                logOut()
        })
        mViewModel.validationLiveData.observe(viewLifecycleOwner, Observer {
            if (it == 0) {
                resources.getString(R.string.enter_message_error).showToast(requireContext())
            }
        })
        mViewModel.isFormValid.observe(viewLifecycleOwner, Observer {
            mViewModel.makeJsonForPostMessage(
                editTextViewMessage.text.toString().trim(),
                sharedPreferences.id,
                id
            )
        })
        mViewModel.jsonObjectForPostMessages.observe(viewLifecycleOwner, Observer {
            editTextViewMessage.setText("")
            launchProgressDialog()
            mViewModel.postMessage(it)
        })

        mViewModel.jsonObjectForSeenMessage.observe(viewLifecycleOwner, Observer {
            mViewModel.seenMessage(it)
        })

        mViewModel.messagesListSuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()
            it?.apply {
                this.data?.apply {
                    dataList.addAll(this)
                    inboxListAdapter.notifyDataSetChanged()
                    commonRecyclerView.scrollToPosition(dataList.size - 1)
                }
            }

        })

        mViewModel.messagesListErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beVisible()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
        })


        mViewModel.postMessageSuccessResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beVisible()
            constraintLayoutNoInternet.beGone()
            it?.apply {
                this.data?.apply {
                    dataList.add(this)
                    inboxListAdapter.notifyItemInserted(dataList.size)
                    commonRecyclerView.scrollToPosition(dataList.size - 1)
                }
            }
        })

        mViewModel.postMessageErrorResponse.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            displayCustomAlertDialog(
                resources.getString(R.string.something_wrong_try_again),
                isCancelable = false,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })

        mViewModel.noInternetException.observe(viewLifecycleOwner, Observer {
            dismissProgressDialog()
            when (it) {
                "post" -> {
                    if (requireActivity().isOnline()) {
                        displayCustomAlertDialog(
                            resources.getString(R.string.something_wrong_try_again),
                            isCancelable = false,
                            positiveText = resources.getString(R.string.btn_ok),
                            positiveClick = {
                                it.dismiss()
                            })
                    } else {
                        displayCustomAlertDialog(
                            resources.getString(R.string.no_internet_message),
                            isCancelable = false,
                            positiveText = resources.getString(R.string.btn_ok),
                            positiveClick = {
                                it.dismiss()
                            })
                    }
                }
                else -> {
                    if (requireActivity().isOnline()) {
                        linearLayoutProgressBar.beGone()
                        constraintLayoutNoData.beGone()
                        constraintLayoutErrorView.beVisible()
                        commonRecyclerView.beGone()
                        constraintLayoutNoInternet.beGone()
                    }
                }
            }

        })
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
    }

    /**
     * @desc stop apis call and clear view model
     */
    override fun onDestroy() {
        super.onDestroy()
        mViewModel.onDetach()
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && dataList.isNullOrEmpty()) {
            linearLayoutProgressBar.beVisible()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beGone()
            if (!isSeen) {
                mViewModel.makeJsonForSeenMessage(id)
            }
            mViewModel.getAllMessagesFromInboxId("get-message", id)
        } else if (dataList.isNullOrEmpty()) {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            commonRecyclerView.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }
}