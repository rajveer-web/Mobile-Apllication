package com.dynasty.esports.models

import com.google.gson.annotations.SerializedName

data class OTPVerificationREquest (

    @field:SerializedName("otp")
    var otp:String?=null,

    @field:SerializedName("type")
    var type:String?=null,

    @field:SerializedName("id")
    var id:String?=null

    )