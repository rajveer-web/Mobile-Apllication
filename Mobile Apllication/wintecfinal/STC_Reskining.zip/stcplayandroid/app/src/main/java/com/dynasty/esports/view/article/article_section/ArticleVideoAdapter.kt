package com.dynasty.esports.view.article.article_section


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.AdapterArticlesVideosBinding
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.getVideoIdFromYoutubeUrl
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.Docs
import com.dynasty.esports.models.VideosModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.bracket.BracketAdapter
import com.dynasty.esports.view.common.LoadingViewHolder

/**
 * @desc this is class will handle Article videos
 * @author : Mahesh Vayak
 * @created : 20-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ArticleVideoAdapter constructor(
    private var videoList: MutableList<VideosModel.DocModel>,
    private val onItemClick: (String) -> Unit = { _ -> }
) :     RecyclerView.Adapter<RecyclerView.ViewHolder>() {

//    override fun onCreateViewHolder(
//        parent: ViewGroup,
//        viewType: Int
//    ): BindingHolder<AdapterArticlesVideosBinding> {
//        return BindingHolder(
//            DataBindingUtil.inflate(
//                LayoutInflater.from(parent.context),
//                R.layout.adapter_articles_videos,
//                parent,
//                false
//            )
//        )
//
//    }
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: AdapterArticlesVideosBinding =
                    DataBindingUtil.inflate(
                        inflater,
                        R.layout.adapter_articles_videos,
                        parent,
                        false
                    )
                return ViewHolderVideo(binding)
            }
            else -> {
                val binding: ItemLoadMoreBinding =
                    DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
                return LoadingViewHolder(binding)
            }

        }
    }


 
    /**
    * @desc videos array size count.
    * @return int- array size
    */
    override fun getItemCount(): Int {

        return videoList.size
    }

    /**
     * @desc identifying the type of the view needed to represent the item at
     *                 <code>position</code>. Type codes need not be contiguous.
     * @param int- position
     * @return int -view type
     */
    override fun getItemViewType(position: Int): Int {
        return if (videoList[position].isLoadMore) {
            1
        } else {
            0
        }
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderVideo).bind(videoList[position])
            }
            else -> {
                (holder as LoadingViewHolder).progressBar.isIndeterminate = true
            }
        }
    }

//    /**
//     *@desc Called by RecyclerView to display the data at the specified position. This method should
//     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
//     * position.
//     */
//    override fun onBindViewHolder(
//        holder: BindingHolder<AdapterArticlesVideosBinding>,
//        position: Int
//    ) {
//        val data = videoList[adapterPosition]
//
//          
//    }

    /**
     *@desc This call use for display Video data
     */
    inner class ViewHolderVideo(private var binding: AdapterArticlesVideosBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: VideosModel.DocModel) {
            val url = "https://img.youtube.com/vi/" + data.youtubeUrl.toString()
                .getVideoIdFromYoutubeUrl() + "/0.jpg"
            itemView.context.loadImageFromServer(url, binding.imageViewVideoThumbnail)


            if (LocaleHelper.getLanguage(binding.root.context) == "en") {
                binding.textViewTitle.text = data.title?.english?.let { it } ?: ""
                binding.textViewAboutUs.text = data.description?.english?.let { it } ?: ""
            } else {
                binding.textViewTitle.text = data.title?.malay?.let { it } ?: ""
                binding.textViewAboutUs.text = data.description?.malay?.let { it } ?: ""
//                binding.textViewTitle.text = if(data.title?.malay.isNullOrEmpty()) data.title?.english?.let { it } ?: "" else data.title?.malay?.let { it } ?: ""
//                binding.textViewAboutUs.text = if(data.description?.malay.isNullOrEmpty()) data.description?.english?.let { it } ?: "" else data.description?.malay?.let { it } ?: ""
            }

            binding.textViewDate.text = data.createdOn.toString().convertDateToRequireDateFormat(
                AppConstants.API_DATE_FORMAT,
                AppConstants.APP_DATE_FORMAT
            )
            binding.cardViewVideo.click {
                onItemClick(data.youtubeUrl.toString())
            }
        }

    }

}