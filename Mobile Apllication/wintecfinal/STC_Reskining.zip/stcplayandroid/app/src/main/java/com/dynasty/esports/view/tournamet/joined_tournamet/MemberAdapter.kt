package com.dynasty.esports.view.tournamet.joined_tournamet

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.JoinMemberItemBinding
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.MemberList


//row_author_list_article

class MemberAdapter constructor(
    private val onItemPhoneCodeClick: (Int) -> Unit = { _ -> },
    private val onJoinMemberUserNameChanged: (Int, String) -> Unit = { _, _ -> },
    private val onJoinMemberInGameUserNameChanged: (Int, String) -> Unit = { _, _ -> },
    private val llMemberUserNameCheckClick: (Int, String) -> Unit = { _, _ -> },
    private val llMemberGameNameCheckClick: (Int, String) -> Unit = { _, _ -> }
) :
    RecyclerView.Adapter<MemberAdapter.MyViewHolder>() {

    class MyViewHolder(val binding: JoinMemberItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    private var memberList: MutableList<MemberList>? = ArrayList<MemberList>()


    var handler = android.os.Handler()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val binding: JoinMemberItemBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.join_member_item,
            parent,
            false
        )
        return MyViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return memberList!!.size
    }

    fun addAll(venueList: MutableList<MemberList>?) {
        memberList!!.clear()
        memberList!!.addAll(venueList!!)
        notifyDataSetChanged()
    }


    fun remove(item: MemberList, position: Int) {
        memberList!!.remove(item)
        notifyDataSetChanged()
    }

    fun get(position: Int): MemberList {
        return memberList!![position]
    }

    fun setUserNameAvailable(position: Int, b: Boolean) {
        memberList!![position].memberUserNameIsAvailable = b
        notifyItemChanged(position)
    }

    fun setUserGameNameAvailable(position: Int, b: Boolean) {
        memberList!![position].memberInGameUserNameIsAvailable = b
        notifyItemChanged(position)
//        notifyDataSetChanged()
    }

    fun getAll(): MutableList<MemberList> {
        return memberList!!
    }

    fun clear() {
        memberList!!.clear()
        notifyDataSetChanged()
    }

    fun isValidated(): Boolean {
        for (i in memberList!!) {
            if (i.memberName.isEmpty()) {
                return false
            } else if (i.memberEmail.isEmpty()) {
                return false
            } else if (!i.memberEmail.isEmailValid()) {
                return false
            } else if (i.memberUserName.isEmpty()) {
                return false
            } else if (i.memberInGameUserName.isEmpty()) {
                return false
            } else if (!i.memberIsAutoPopulated && i.memberPhoneCode.isEmpty()) {
                return false
            } else if (!i.memberIsAutoPopulated && i.memberPhoneNumber.isEmpty()) {
                return false
            } else if (!i.memberUserNameIsAvailable) {
                return false
            } else if (!i.memberInGameUserNameIsAvailable) {
                return false
            }
        }
        return true
    }

    var isFromNotify = false

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = memberList!![position]
//        holder.binding.addSponorNameTxt.text = data.sponcorName?.let {
//            it
//        } ?: "-"
        holder.binding.joinMember = data
        holder.binding.tvMemberPosition.text =
            holder.itemView.resources.getString(R.string.member).plus(" ")
                .plus((position + 2).toString())

        holder.binding.editJoinMemberPhoneCode.setText(data.memberPhoneCode)

        holder.binding.editJoinMemberPhoneCode.click {
            onItemPhoneCodeClick(position)
        }

        if (data.memberIsAutoPopulated) {
            holder.binding.editJoinMemberAutoMobileNumber.setText(data.memberPhoneNumber)
            holder.binding.tlJoinMemberAutoMobileNumber.beVisible()
            holder.binding.llMemberPhoneInput.beGone()
        } else {
            holder.binding.tlJoinMemberAutoMobileNumber.beGone()
            holder.binding.llMemberPhoneInput.beVisible()
        }

//        holder.binding.editJoinMemberUserName.isFocusable = false
//        holder.binding.editJoinMemberInGameUserName.isFocusable = false

        if (data.memberUserName.isNotEmpty()) {
            holder.binding.tvMemberUserName.beVisible()
            if (data.memberUserNameIsAvailable) {
                holder.binding.tvMemberUserName.text =
                    holder.itemView.context.resources.getString(R.string.tournament_username_is_available)
                holder.binding.tvMemberUserName.setTextColor(
                    holder.itemView.context.resources.getColor(
                        R.color.join_tournament_green_color
                    )
                )
            } else {
                holder.binding.tvMemberUserName.text =
                    holder.itemView.context.resources.getString(R.string.tournament_username_is_not_available)
                holder.binding.tvMemberUserName.setTextColor(
                    holder.itemView.context.resources.getColor(
                        R.color.red
                    )
                )
            }
        } else {
            holder.binding.tvMemberUserName.beGone()
        }

        if (data.memberInGameUserName.isNotEmpty()) {
            holder.binding.tvMemberGameUserName.beVisible()
            if (data.memberInGameUserNameIsAvailable) {
                holder.binding.tvMemberGameUserName.text =
                    holder.itemView.context.resources.getString(R.string.in_game_userid_is_available)
                holder.binding.tvMemberGameUserName.setTextColor(
                    holder.itemView.context.resources.getColor(
                        R.color.join_tournament_green_color
                    )
                )
            } else {
                holder.binding.tvMemberGameUserName.text =
                    holder.itemView.context.resources.getString(R.string.in_game_userid_is_not_available)
                holder.binding.tvMemberGameUserName.setTextColor(
                    holder.itemView.context.resources.getColor(
                        R.color.red
                    )
                )
            }
        } else {
            holder.binding.tvMemberGameUserName.beGone()
        }

        holder.binding.llMemberUserNameCheck.click {
            if (!data.memberUserName.isEmpty()) {
                llMemberUserNameCheckClick(
                    position,
                    holder.binding.editJoinMemberUserName.text.toString().trim()
                )
            } else {
                holder.itemView.context.makeSnackBar(
                    holder.binding.llMemberGameNameCheck,
                    holder.itemView.context.resources.getString(R.string.team_captain_user_name_error)
                )
            }
        }

        holder.binding.llMemberGameNameCheck.click {
            if (!data.memberInGameUserName.isEmpty()) {
                llMemberGameNameCheckClick(
                    position,
                    holder.binding.editJoinMemberInGameUserName.text.toString().trim()
                )
            } else {
                holder.itemView.context.makeSnackBar(
                    holder.binding.llMemberGameNameCheck,
                    holder.itemView.context.resources.getString(R.string.team_captain_in_game_user_error)
                )
            }
        }


//        holder.binding.editJoinMemberUserName.doAfterTextChanged {
//            if (!isFromNotify) {
//                if (it!!.isNotEmpty()) {
//                    handler = android.os.Handler()
//                    handler.postDelayed(Runnable {
//                        onJoinMemberUserNameChanged(position, it.toString())
//                    }, 1000)
//                } else {
//                    setUserGameNameAvailable(position, false)
//                }
//            }
//        }
//
//        holder.binding.editJoinMemberInGameUserName.doAfterTextChanged {
//            if (!isFromNotify) {
//                if (it!!.isNotEmpty()) {
//                    handler = android.os.Handler()
//                    handler.postDelayed(Runnable {
//                        onJoinMemberInGameUserNameChanged(position, it.toString())
//                    }, 1000)
//                } else {
//                    setUserGameNameAvailable(position, false)
//                }
//            }
//        }

        holder.binding.editJoinMemberUserName.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus && !isFromNotify) {
                data.memberUserNameIsAvailable = false
                holder.binding.tvMemberUserName.text =
                    holder.itemView.context.resources.getString(R.string.tournament_username_is_not_available)
                holder.binding.tvMemberUserName.setTextColor(
                    holder.itemView.context.resources.getColor(
                        R.color.red
                    )
                )
                holder.binding.tvMemberUserName.beVisible()
            }
        }
        holder.binding.editJoinMemberInGameUserName.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus && !isFromNotify) {
                data.memberInGameUserNameIsAvailable = false
                holder.binding.tvMemberGameUserName.text =
                    holder.itemView.context.resources.getString(R.string.in_game_userid_is_not_available)
                holder.binding.tvMemberGameUserName.setTextColor(
                    holder.itemView.context.resources.getColor(
                        R.color.red
                    )
                )
                holder.binding.tvMemberGameUserName.beVisible()
            }
        }

//        holder.binding.editJoinMemberUserName.doAfterTextChanged {
//            if (!isFromNotify) {
//                data.memberUserNameIsAvailable = false
//                holder.binding.tvMemberUserName.text =
//                    holder.itemView.context.resources.getString(R.string.tournament_username_is_not_available)
//                holder.binding.tvMemberUserName.setTextColor(
//                    holder.itemView.context.resources.getColor(
//                        R.color.red
//                    )
//                )
//                holder.binding.tvMemberUserName.beVisible()
//                isFromNotify = false
//            }
//        }

//        holder.binding.editJoinMemberInGameUserName.doAfterTextChanged {
//            if (!isFromNotify) {
//                data.memberInGameUserNameIsAvailable = false
//                holder.binding.tvMemberGameUserName.text =
//                    holder.itemView.context.resources.getString(R.string.in_game_userid_is_not_available)
//                holder.binding.tvMemberGameUserName.setTextColor(
//                    holder.itemView.context.resources.getColor(
//                        R.color.red
//                    )
//                )
//                holder.binding.tvMemberGameUserName.beVisible()
//            }
//        }
//        if (data.memberUserName.isEmpty()) {
//            data.memberUserNameIsAvailable = false
//            holder.binding.tvMemberUserName.text =
//                holder.itemView.context.resources.getString(R.string.tournament_username_is_not_available)
//            holder.binding.tvMemberUserName.setTextColor(
//                holder.itemView.context.resources.getColor(
//                    R.color.red
//                )
//            )
//            holder.binding.tvMemberUserName.beVisible()
//        }
//
//        if (data.memberInGameUserName.isEmpty()) {
//            data.memberInGameUserNameIsAvailable = false
//            holder.binding.tvMemberGameUserName.text =
//                holder.itemView.context.resources.getString(R.string.in_game_userid_is_not_available)
//            holder.binding.tvMemberGameUserName.setTextColor(
//                holder.itemView.context.resources.getColor(
//                    R.color.red
//                )
//            )
//            holder.binding.tvMemberGameUserName.beVisible()
//        }

//        holder.binding.editJoinMemberUserName.onFocusChangeListener =
//            OnFocusChangeListener { view, hasFocus ->
//                if (!hasFocus) {
//                    if (holder.binding.editJoinMemberUserName.text.toString().trim().isNotEmpty()) {
//                        onJoinMemberUserNameChanged(
//                            position,
//                            holder.binding.editJoinMemberUserName.text.toString().trim()
//                        )
//                    } else {
//                        setUserNameAvailable(position, false)
//                    }
//                }
//            }
//
//        holder.binding.editJoinMemberInGameUserName.onFocusChangeListener =
//            OnFocusChangeListener { view, hasFocus ->
//                if (!hasFocus) {
//                    if (holder.binding.editJoinMemberInGameUserName.text.toString().trim()
//                            .isNotEmpty()
//                    ) {
//                        onJoinMemberInGameUserNameChanged(
//                            position,
//                            holder.binding.editJoinMemberInGameUserName.text.toString().trim()
//                        )
//                    } else {
//                        setUserGameNameAvailable(position, false)
//                    }
//                }
//            }

//        if (data.isUserNameFocusable) {
//            holder.binding.editJoinMemberUserName.doAfterTextChanged {
//                if (it!!.isNotEmpty()) {
//                    handler = android.os.Handler()
//                    handler.postDelayed(Runnable {
//                        onJoinMemberUserNameChanged(position, it.toString())
//                    }, 1000)
//                } else {
//                    setUserGameNameAvailable(position, false)
//                }
//            }
//        }

//        if (holder.binding.editJoinMemberInGameUserName.isFocusable) {
//            holder.binding.editJoinMemberInGameUserName.doAfterTextChanged {
//                onJoinMemberInGameUserNameChanged(position, it.toString())
//            }
//        }
    }

    fun setCountryCode(s: String, adapterClickPosition: Int) {
        memberList!!.forEachIndexed { index, memberList ->
            if (adapterClickPosition == index) {
                memberList.memberPhoneCode = s
            }
        }
        notifyItemChanged(adapterClickPosition)
    }
}