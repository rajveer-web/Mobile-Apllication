package com.dynasty.esports.utils

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.chaletRegular
import com.dynasty.esports.extenstion.lightFont
import com.dynasty.esports.extenstion.mediumFont
import com.dynasty.esports.extenstion.regularFont

/**
 * @desc this class will handle textview properties
 * @author : Mahesh Vayak
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ChaletRegularTextView : AppCompatTextView {

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context) : super(context) {
        init()
    }

    fun init() {
        if (!isInEditMode) {
            try {
                typeface = context.mediumFont()
                letterSpacing=0.07f
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

}