package com.dynasty.esports.view.chat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.beGone
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.startActivityInline
import kotlinx.android.synthetic.main.activity_chat_list.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*

class ChatListActivity : AppCompatActivity() {
    private var chatListAdapter: ChatListAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)
        initView()
    }

    private fun initView() {
        imageViewClose.click{
            onBackPressed()
        }
        linearLayoutProgressBar.beGone()
        chatListAdapter= ChatListAdapter(mutableListOf(),onItemClick = ::onItemClick)
        commonRecyclerView.layoutManager=LinearLayoutManager(this)
        commonRecyclerView.adapter=chatListAdapter
    }



    fun onItemClick(matchId: String, tournamentID: String) {
        startActivityInline<MessageListActivity>()
    }
}

