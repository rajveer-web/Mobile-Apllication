package com.dynasty.esports.view.tournamet.tournamet_detail

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.dynasty.esports.BuildConfig
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.TournamentDetailRes
import com.dynasty.esports.models.TournamentOptionModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.common.CommonPagerAdapter
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.view.tournamet.TournamentOptionAdapter
import com.dynasty.esports.view.tournamet.joined_tournamet.JoinTournamentActivity
import com.dynasty.esports.viewmodel.TournamentDetailViewModel
import com.google.android.material.appbar.AppBarLayout
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_tournament_detail.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will use for tournament detail page
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class TournamentDetailActivity : BaseActivity(),
    ConnectivityReceiver.ConnectivityReceiverListener,
    ManageRedirectReceiver.NotifyActivityListener {
    private var tournamentURL:String=""
    private val mViewModel: TournamentDetailViewModel by viewModel()
    private var tournamentId: String = ""
    private var isUpcoming: Boolean = false
    private var tournamentDetails: TournamentDetailRes? = null
    private lateinit var tournamentOptionAdapter: TournamentOptionAdapter
    private val tournamentOptionList: MutableList<TournamentOptionModel> = mutableListOf()
    private lateinit var commonPagerAdapter: CommonPagerAdapter
    private var connectivityReceiver = ConnectivityReceiver()
    private val fragmentList: MutableList<Pair<Fragment, String>> = mutableListOf()
    var isAlreadyJoined: Boolean = false
    var dateTimeTimer: String = ""
    var currentPosition: Int = 0
    private var manageRedirectReceiver = ManageRedirectReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tournament_detail)
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
        initIntentParams()
        listenToviewModel()
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            unregisterReceiver(connectivityReceiver)
        }
    }

    //    get and set data from intent.extras
//    if isUpcoming is true then user comes from upcoming list click otherwise its ongoing click
    private fun initIntentParams() {
        try {
            intent.data?.apply {
                tournamentId = this.lastPathSegment.toString()
            }
            intent.extras?.apply {
                if (this.containsKey("tournamentId")) {
                    tournamentId = this.getString("tournamentId").toString()
                }
                if (this.containsKey("isUpcoming")) {
                    isUpcoming = intent.getBooleanExtra("isUpcoming", false)
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * @desc listen observer and receive the events
     * Also, Manage success and failure responces from API, Internet and un authorization.
     */
    private fun listenToviewModel() {
//      observer for join tournament button click
        mViewModel.joinTournamentObservable.observe(this, Observer {
            val bundle = Bundle()
//            bundle.putString("tournamentbject", Gson().toJson(tournamentDetails))
            bundle.putString("tournamentId", tournamentId)
            bundle.putString("tournamentName", tournamentDetails!!.data!!.name)
            bundle.putBoolean("isUpcoming", isUpcoming)
            bundle.putBoolean("isForEditJoin", false)
            startActivityWithBundleResult<JoinTournamentActivity>(bundle, AppConstants.REFRESH_CODE)
        })

        mViewModel.fetchTournamentDetailSuccessResponse.observe(this, Observer {
            debugE("tournamentDetailSuccess", Gson().toJson(it))
            dismissProgressDialog()
            it.data?.apply {
                tournamentDetails = it
                initialise()
            }
        })

        mViewModel.fetchTournamentDetailErrorResponse.observe(this, Observer {
            debugE("tournamentDetailError", it.string())
            constraintLayoutErrorView.beVisible()
            clMain.beGone()
            dismissProgressDialog()
        })

        mViewModel.isAlreadyJoinSuccessResponse.observe(this, Observer {
            debugE("isAlreadyJoinSuccessResponse", Gson().toJson(it))
            if (it.totals!!.count == 0) {
                isAlreadyJoined = false
                if (isUpcoming) {
                    flJoin.beVisible()
                    flAlreadyJoin.beGone()
                }
            } else {
                isAlreadyJoined = true
                flJoin.beGone()
                flAlreadyJoin.beVisible()
            }
            dismissProgressDialog()
        })

        mViewModel.isAlreadyJoinErrorResponse.observe(this, Observer {
            debugE("isAlreadyJoinErrorResponse", it.string())
            dismissProgressDialog()
            if (isUpcoming) {
                flJoin.beVisible()
            }
        })
    }

    /**
     * @desc this method is used for initialize fragments, adapter and recyclerview
     */
    private fun initialise() {
        toolbar.title = ""
        setSupportActionBar(toolbar)

//      set toolbar font
        collapsingToolbar.setCollapsedTitleTypeface(getFontTypeFace(R.font.hkgrotesk_medium))

//      set text to toolbar when toolbar Collapsed and Expanded
        appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            when {
                Math.abs(verticalOffset) - appBarLayout.totalScrollRange == 0 -> {
                    // Collapsed
                    collapsingToolbar.title = tournamentDetails!!.data!!.name
                    if (isAlreadyJoined) {
                        flAlreadyJoin.beGone()
                    }
                }
                else -> {
                    if (isAlreadyJoined) {
                        flAlreadyJoin.beVisible()
                    }

                    collapsingToolbar.title = ""
                    // Expanded
                }
            }
        })
        tournamentOptionList.clear()
        tournamentDetails?.data?.gameDetail?.apply {
            loadImageFromServer(this.image.toString(), imgTournamentDetailBanner)
        }
//        tournamentDetails?.data?.banner?.apply {
//
//        }


//        add data in tournamentOptionList and send data in adapter
        tournamentOptionList.add(TournamentOptionModel(R.mipmap.preview_black_18dp))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_import_highlight_book_18dp))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_group_people_18dp))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_live_tv_black_18dp))
        tournamentOptionList.add(TournamentOptionModel(R.drawable.ic_chat_black_18dp))

//      set recyclerview and adapter to rvTournamentDetail
        rvTournamentDetail.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tournamentOptionAdapter =
            TournamentOptionAdapter(tournamentOptionList, onItemClick = ::onItemClick)
        rvTournamentDetail.adapter = tournamentOptionAdapter


        if (LocaleHelper.getLanguage(this@TournamentDetailActivity) == "en") {

        } else {

            val params = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.LEFT
            }

            flJoin.layoutParams = params
            flAlreadyJoin.layoutParams = params
        }

//      convert date to required formate
        tournamentDetails?.data?.let {
            tvTournamentDetailTitle.text = it.name
//            dateTimeTimer = it.startDate?.convertDateToRequireDateFormat(
//                AppConstants.API_DATE_FORMAT,
//                "yyyy-MM-dd"
//            ).plus(" ").plus(it.startTime)
//
//            if (!it.startTime.isNullOrEmpty()) {
//                if (it.startTime.toString().split(":")[0] > 12.toString()) {
//                    is24Hours = true
//                }
//            }

            if (isUpcoming) {
                it.startDate?.let {
                    if (it.getLeftTime(AppConstants.API_DATE_FORMAT).toInt() == 1) {
                        this@TournamentDetailActivity.countDownTimer(
                            it,
                            AppConstants.API_DATE_FORMAT,
                            tvTournamentDetailSubTitle
                        )
                    } else {
                        tvTournamentDetailSubTitle.text =
                            resources.getText(R.string.start_in).toString().plus(":\n")
                                .plus(
                                    it.getLeftTime(AppConstants.API_DATE_FORMAT).toInt()
                                        .toString().plus(" ").plus(
                                            resources.getString(
                                                R.string.days_left
                                            )
                                        )
                                )

                    }

//                    this@TournamentDetailActivity.countDownTimer(
//                        it,
//                        AppConstants.API_DATE_FORMAT,
//                        tvTournamentDetailSubTitle)
                }
            } else {
                tvTournamentDetailSubTitle.text = dateTimeTimer
            }

        }

//        countDownTimer(
//            dateTimeTimer,
//            if (is24Hours) AppConstants.DATE_AND_TIME_24 else AppConstants.DATE_AND_TIME,
//            tvTournamentDetailSubTitle
//        )

        if (tournamentDetails!!.data!!.participantType.equals("team", true)) {
            tvTournamamentType.text = resources.getString(R.string.team)
        } else {
            tvTournamamentType.text = resources.getString(R.string.one_vs_one)
        }


//      if tournament is upcoming then show count down timer and if tournament is ongoing then show only start date.


//      join tournament button click
        fbJoinTournament.click {
            if (!sharedPreferences.checkUserLoggedInOrNot()) {
                displayCustomAlertDialog(resources.getString(R.string.please_login_to_access_page),
                    isCancelable = true,
                    isCloseShow = true,
                    positiveText = resources.getString(R.string.login),
                    positiveClick = {
                        it.dismiss()
                        redirectType = "tournament_detail"
                        startActivityInline<PhoneSignInActivity>()
                    },
                    negativeText = resources.getString(R.string.str_cancel),
                    negativeClick = {
                        it.dismiss()
                    }, onCloseClick = {
                        it.dismiss()
                    })
            } else {
                mViewModel.joinTournamentClick()
            }

        }
        setViewPager()
        checkJoinOrNotTournament()
    }

    private fun checkJoinOrNotTournament() {
        val jsonObject = JsonObject()
        jsonObject.addProperty("tournamentId", tournamentId)
        jsonObject.addProperty("userId", sharedPreferences.id)
        mViewModel.checkIsAlreadyJoindOrNot(jsonObject)
    }

    //  set currunt fragment on click of tournamentOptionAdapter item
    private fun onItemClick(position: Int) {
        when (position) {
            0 -> {
                pagerTournament.setCurrentItem(0, true)
            }
            1 -> {
                pagerTournament.setCurrentItem(1, true)
            }
            2 -> {
                pagerTournament.setCurrentItem(2, true)
            }
            3 -> {
                pagerTournament.setCurrentItem(3, true)
            }
            4 -> {
                pagerTournament.setCurrentItem(4, true)
            }
        }

//      updateSelection in tournamentOptionAdapter
        tournamentOptionAdapter.updateSelection(position)
    }

    private fun setViewPager() {
//        add fragments in fragmentList and set commonviewpager adapter
        fragmentList.add(
            Pair(
                TournamentOverviewFragment.newInstance(tournamentDetails!!),
                ""
            )
        )
        fragmentList.add(
            Pair(
                TournamentHighlightFragment.newInstance(tournamentDetails!!),
                ""
            )
        )
        fragmentList.add(
            Pair(
                TournamentParticipantsFragment.newInstance(tournamentDetails!!),
                ""
            )
        )
        fragmentList.add(
            Pair(
                TournamentWatchFragments.newInstance(tournamentDetails!!),
                ""
            )
        )
        fragmentList.add(
            Pair(
                TournamentDiscussionFragment.newInstance(tournamentDetails!!),
                ""
            )
        )

//      set commonPagerAdapter
        commonPagerAdapter =
            CommonPagerAdapter(
                fragmentList,
                supportFragmentManager
            )
        pagerTournament.adapter = commonPagerAdapter

        pagerTournament.currentItem = currentPosition

//      updateSelection when page changes
        pagerTournament.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {

            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                tournamentOptionAdapter.updateSelection(position)
            }
        })
    }

    /**
     * @desc check internet connection. this method will call when internet come and gone
     *       call apis and show primary loaders
     * @param isConnected (true if internet available and false if internet not available )
     */
    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && tournamentDetails == null) {
            launchProgressDialog()
            clMain.beVisible()
            constraintLayoutNoInternet.beGone()
            mViewModel.fetchTournamentDetail(tournamentId, "latest", "")
        } else if (tournamentDetails == null) {
            dismissProgressDialog()
            clMain.beGone()
            constraintLayoutNoInternet.beVisible()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == AppConstants.REFRESH_CODE && resultCode == RESULT_OK) {
            flJoin.beGone()
            isAlreadyJoined = true
            flAlreadyJoin.beVisible()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(this@TournamentDetailActivity)
                .unregisterReceiver(this)
        }
    }

    override fun onNotify(notifyType: String) {
        if (notifyType == "tournament_detail") {
            currentPosition = pagerTournament.currentItem
            mViewModel.joinTournamentClick()
            checkJoinOrNotTournament()
        } else if (notifyType == "tournament_detail_discussion") {
            checkJoinOrNotTournament()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_share, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId==R.id.action_share){
            shareTournament()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun shareTournament() {
        val intentShare = Intent(Intent.ACTION_SEND)
        intentShare.type = "text/plain"
        intentShare.putExtra(Intent.EXTRA_SUBJECT, "Sharing URL")
        intentShare.putExtra(Intent.EXTRA_TEXT, BuildConfig.SEED_WEBVIEW_PATH.plus("tournament/").plus(tournamentId))
        startActivity(Intent.createChooser(intentShare, "Share"))
    }
}