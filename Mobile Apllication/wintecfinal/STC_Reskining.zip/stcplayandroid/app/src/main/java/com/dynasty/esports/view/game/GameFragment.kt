package com.dynasty.esports.view.game

import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.text.TextPaint
import android.text.style.ClickableSpan
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.constants.ArticleConstant
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CustomArticleModel
import com.dynasty.esports.receiver.ConnectivityReceiver
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.article.article_detail.ArticlesDetailActivity
import com.dynasty.esports.view.article.article_section.ArticlesAdapter
import com.dynasty.esports.view.article.view_all_article.ViewAllArticlesActivity
import com.dynasty.esports.view.common.AnnouncementBottomDialog
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.common.MatchMakingBottomDialog
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.search.SearchActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.viewmodel.GameTabViewModel
import com.dynasty.esports.viewmodel.HomeViewModel
import kotlinx.android.synthetic.main.content_phone_num_signin_screen.*
import kotlinx.android.synthetic.main.fragment_game.*
import kotlinx.android.synthetic.main.home_app_bbar_layout.*
import org.json.JSONObject
import org.koin.androidx.viewmodel.ext.android.viewModel

class GameFragment :  BaseFragment(), ConnectivityReceiver.ConnectivityReceiverListener ,  ManageRedirectReceiver.NotifyActivityListener {

    private lateinit var articlesAdapter: ArticlesAdapter
    private var artistList: MutableList<CustomArticleModel> = mutableListOf()
    private val mViewModel: GameTabViewModel by viewModel()
    private var manageRedirectReceiver = ManageRedirectReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalBroadcastManager.getInstance(requireContext())
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_game, container, false)
    }

    /**
     * @desc Register internet connection receiver
     */
    override fun onResume() {
        super.onResume()
        requireActivity().registerReceiver(
            connectivityReceiver,
            IntentFilter(AppConstants.CONNECTION_ACTION)
        )
        ConnectivityReceiver.connectivityReceiverListener = this

    }

    /**
     * @desc Unregister internet connection receiver
     */
    override fun onPause() {
        super.onPause()
        ConnectivityReceiver.connectivityReceiverListener?.apply {
            requireActivity().unregisterReceiver(connectivityReceiver)
        }
       // handler.removeCallbacks(timeCounter)
    }

    private var connectivityReceiver = ConnectivityReceiver()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
    }

    fun listenToViewModel(){

        // Get all Post by games response
        mViewModel.allGameSucessReponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBarDialog.beGone()
            it?.data?.apply {
                if (this.isNotEmpty()) {
                    artistList.add(
                        CustomArticleModel(
                            ArticleConstant.CONST_ALL_GAMES,
                            title = resources.getString(R.string.all_games_title),
                            gamesList = this
                        )
                    )
                    articlesAdapter.notifyDataSetChanged()
                }
            }
        })

    }

    fun initialise() {
        gameRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        artistList.clear()
        articlesAdapter =
            ArticlesAdapter(
                artistList,
                onItemClick = ::onItemClick
            )
        gameRecyclerView.adapter = articlesAdapter
        gameBannerButton.click {
            if(sharedPreferences.checkUserLoggedInOrNot()) {
                DashboardActivity.navController.navigate(R.id.settingsFragment)
            }else{
                resources.getString(R.string.please_login).showToast(requireContext())
            }
        }

        gameBannerStep1.makeSpannableString(
            requireContext(),
            resources.getString(R.string.gameBannerStep1),
           0,2,
            object : ClickableSpan() {
                override fun onClick(widget: View) {

                }
                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })

        gameBannerStep2.makeSpannableString(
            requireContext(),
            resources.getString(R.string.gameBannerStep2),
            0,2,
            object : ClickableSpan() {
                override fun onClick(widget: View) {

                }
                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })

        gameBannerStep3.makeSpannableString(
            requireContext(),
            resources.getString(R.string.gameBannerStep3),
            0,2,
            object : ClickableSpan() {
                override fun onClick(widget: View) {

                }
                override fun updateDrawState(ds: TextPaint) {
                    ds.isUnderlineText = false
                }

            })
    }


    /**
     * @desc method will call when tap on view all from article adapter and redirect to view all article screen
     * @param type article type
     * @param title article title
     */
    private fun onViewAllItemClick(type: Int, title: String) {
       
    }

    /**
     * @desc method will call when tap on article from article adapter and redirect to different screen
     * @param type article type
     * @param id article id
     * @param title article title
     */
    fun onItemClick(type: Int, id: Any, title: String) {
//        if (sharedPreferences.checkUserLoggedInOrNot()) {
////            val bottomSheetDialog: MatchMakingBottomDialog = MatchMakingBottomDialog.newInstance(id.toString(),title)
//            bottomSheetDialog.show(parentFragmentManager, "")
//        }else{
//            launchLoginPopUp(resources.getString(R.string.please_login_to_access_page))
//        }


//        when (type) {
//            ArticleConstant.CONST_ALL_GAMES -> {
//                val bundle = Bundle()
//                bundle.putString("id", id.toString())
//                bundle.putBoolean("isGame", true)
//                bundle.putString("title", title)
//                bundle.putInt("type", ArticleConstant.CONST_TRENDING_POST)
//                startActivityFromFragment<ViewAllArticlesActivity>(bundle)
//            }
//        }

    }

    private fun launchLoginPopUp(msg: String) {
        displayCustomAlertDialog(msg,
            isCancelable = true,
            isCloseShow = true,
            positiveText = resources.getString(R.string.login),
            positiveClick = {
                it.dismiss()
                redirectType = "game"
                startActivityFromFragment<PhoneSignInActivity>()
            },
            negativeText = resources.getString(R.string.str_cancel),
            negativeClick = {
                it.dismiss()
            }, onCloseClick = {
                it.dismiss()
            })
    }


    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (isConnected && artistList.isEmpty()) {
            artistList.clear()
            refreshPlaceHolder(true)
            mViewModel.getAllGamesTab()
          /*
                      val jsonObject = JSONObject()
            jsonObject.put("pagination", false)
            jsonObject.put("page", 1)
            jsonObject.put("limit", 3)
            mViewModel.getAllGamesTab(jsonObject.toString())
          Handler().postDelayed({
                mViewModel.getAllArticles(jsonObject.toString())
            }, 500)*/
        } else if (artistList.isEmpty()) {
            refreshPlaceHolder(false)
        }
    }

    private fun refreshPlaceHolder(isInternetAvailable: Boolean) {
        if (isInternetAvailable) {
            gameLayout.beVisible()
            llNoInternet.beGone()
        } else {
            gameLayout.beGone()
            llNoInternet.beVisible()
        }
    }


    override fun onNotify(notifyType: String) {
        if (notifyType == "game") {

        }
    }
}