package com.dynasty.esports.view.profile

import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.SimpleItemAnimator
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ProfileModel
import com.dynasty.esports.models.SubProfileOptionModel
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.receiver.ManageRedirectReceiver
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.chat.ChatListActivity
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.dashboard.DashboardActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.viewmodel.ChatViewModel
import com.dynasty.esports.viewmodel.CommonViewModel
import kotlinx.android.synthetic.main.nav_header.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this is class will display profile options row.
 * @author : Mahesh Vayak
 * @created : 24-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class ProfileFragment : BaseFragment(), ManageRedirectReceiver.NotifyActivityListener {
    private lateinit var profileOptionAdapter: ProfileOptionAdapter
    private var profileOptionList: MutableList<ProfileModel> = mutableListOf()
    private var manageRedirectReceiver = ManageRedirectReceiver()

    private val chatViewModel: ChatViewModel by viewModel()
    //  private val localizationDelegate = LocalizationApplicationDelegate()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalBroadcastManager.getInstance(requireContext())
            .registerReceiver(manageRedirectReceiver, IntentFilter(AppConstants.NOTIFY_ACTION))
        manageRedirectReceiver.setUpRedirectInterface(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        /**
         * add profile option in profile array with sub items.
         * Initialize array list to profile option adapter
         */
        commonRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        initView()
    }

    private fun initView() {

        val subProfileLanguage: MutableList<SubProfileOptionModel> = mutableListOf()
        subProfileLanguage.add(
            SubProfileOptionModel(
                "language",
                resources.getString(R.string.english)
            )
        )
        subProfileLanguage.add(
            SubProfileOptionModel(
                "language",
                resources.getString(R.string.arabic)
            )
        )

        if (!sharedPreferences.checkUserLoggedInOrNot()) {
            leftlayout.beGone()
            relativeLayoutRight.beGone()
            profileOptionList.clear()
            //profileOptionList.add(ProfileModel(resources.getString(R.string.login)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.language),
                    isExpandable = true,
                    expandListData = subProfileLanguage
                )
            )
        }
        else {
            leftlayout?.apply {
                leftlayout.beVisible()
            }
            relativeLayoutRight?.apply {
                relativeLayoutRight.beVisible()
            }


            val subProfileTournament: MutableList<SubProfileOptionModel> = mutableListOf()
            subProfileTournament.add(
                SubProfileOptionModel(
                    "tournament",
                    resources.getString(R.string.joined_tournaments)
                )
            )
            subProfileTournament.add(
                SubProfileOptionModel(
                    "tournament",
                    resources.getString(R.string.created_tournaments)
                )
            )
            profileOptionList.clear()
            profileOptionList.add(ProfileModel(resources.getString(R.string.basic_info)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.language),
                    isExpandable = true,
                    expandListData = subProfileLanguage
                )
            )
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_bracket)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.my_tournament),
                    isExpandable = true,
                    expandListData = subProfileTournament,
                    drawable = ResourcesCompat.getDrawable(requireContext().resources,R.drawable.ic_baseline_arrow_right_24, null)
                )
            )
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_transactions)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_bookmark)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.settings)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.inbox)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.chat)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.logout)))

            listenToPref()


        }

        commonRecyclerView?.apply {
            (commonRecyclerView.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
            profileOptionAdapter = ProfileOptionAdapter(
                profileOptionList,
                onItemClick = ::onProfileItemClick,
                onSubItemClick = ::onSubItemClick
            )
            commonRecyclerView.adapter = profileOptionAdapter
            listenToViewModel()
        }

    }

    /**
     * @desc this method will use for manage API success and failure,Internet connectivity, make json object for API and un authorization.
     */
    private fun listenToViewModel() {
        commonViewModel.logOutSuccessResponse.observe(viewLifecycleOwner, {
            dismissProgressDialog()
            sharedPreferences.clear()
            sharedPreferences.isAppOpenFirstTime = true
            DashboardActivity.navController.navigate(R.id.homeFragment)
        })
        commonViewModel.logOutErrorResponse.observe(viewLifecycleOwner, {

            dismissProgressDialog()
            displayCustomAlertDialog(title = resources.getString(R.string.some_thing_went_wrong),
                isCancelable = true,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })
        chatViewModel.makeJsonObjectForChatLogOut.observe(viewLifecycleOwner,{
            chatViewModel.chatLogout(it)
        })

    }

    /**
     * @desc This method for listen shared preference data and display data
     */
    private fun listenToPref() {
        val data = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        data.apply {
            tvusersmall?.let {
                it.text = this.fullName?.let { it } ?: ""
            }

            tvuseremail?.let {
                if (this.emailisVerified) {
                    it.beVisible()
                    it.text = this.email?.let { it } ?: ""
                } else {
                    it.beGone()
                }
            }

            imageViewInfluencer?.let {
                this.isInfluencer?.apply {
                    if (this == 0) {
                        it.beVisible()
                        textViewInfluencer.beVisible()
                    } else {
                        it.beGone()
                        textViewInfluencer.beGone()
                    }
                }
            }


            imageViewUser?.let {
                this.isVerified?.apply {
                    if (this == 0) {
                        it.borderWidth = 6
                        imageViewVerify.beVisible()
                    } else {
                        it.borderWidth = 0
                        imageViewVerify.beGone()
                    }
                }
            }

            tvorganizerrate?.let {
                this.organizerRating?.apply {
                    if (this.toInt() == 0) {
                        it.beGone()
                        rating.beGone()
                    } else {
                        rating.rating = this.toFloat()
                    }
                }
            }

            textViewPoint?.let {

                this.accountDetail?.apply {
                    textViewPoint.text = this.reward?.let { it.toString() } ?: "0"
                }
            }


            imageViewUser?.let {
                this.profilePicture?.apply {
                    requireActivity().loadImageFromServer(this, it)
                }
            }

            textViewUserName?.let {
                it.text = this.fullName?.let { it } ?: ""
            }

        }

    }

    /**
     * @desc This method will call when tap sub items of sub items
     * @param position - sub item position
     * @param type - sub item type
     */
    private fun onSubItemClick(position: Int, type: String) {
        when (position) {
            0 -> {
                if (type == "tournament") {
                    val bundle = Bundle()
                    bundle.putString("type", "joined")
                    DashboardActivity.navController.navigate(R.id.createdTournament, bundle)
                } else if (type == "language") {
                    if (LocaleHelper.getLanguage(requireContext()) != "en") {
                        launchChangeLanguageDialog("en")
                    }
                }
            }
            1 -> {
                if (type == "tournament") {
                    val bundle = Bundle()
                    bundle.putString("type", "created")
                    DashboardActivity.navController.navigate(R.id.createdTournament, bundle)
                } else if (type == "language") {
                    if (LocaleHelper.getLanguage(requireContext()) != "ar") {
                        launchChangeLanguageDialog("ar")
                    }
                }
            }
        }
    }

    private fun launchChangeLanguageDialog(language: String) {
        displayCustomAlertDialog(
            resources.getString(R.string.language),
            resources.getString(R.string.language_change_msg),
            true,
            positiveText = resources.getString(R.string.yes),
            negativeText = resources.getString(R.string.no),
            positiveClick = {
                it.dismiss()
                LocaleHelper.setLocale(requireContext(), language)
                startActivityFinishAllFromFragment<DashboardActivity>()
            },
            negativeClick = {
                it.dismiss()
            })
    }

    /**
     * @desc This method will call when tap on profile item
     * @param position - profile option position
     */
    private fun onProfileItemClick(position: Int) {
        when (position) {
            0 -> {
                if (!sharedPreferences.checkUserLoggedInOrNot()) {
                    redirectType = "profile"
                    startActivityFromFragment<PhoneSignInActivity>()
                } else {
                    DashboardActivity.navController.navigate(R.id.basicInfoFragment)
                }

            }
            1, 3 -> {
                profileOptionAdapter.expandView(position)
            }
            2 -> {
                DashboardActivity.navController.navigate(R.id.bracketFragment)
            }
            4 -> {
                DashboardActivity.navController.navigate(R.id.transactionHistoryFragment)
            }
            5 -> {
                DashboardActivity.navController.navigate(R.id.bookmark)
            }
            6 -> {
                DashboardActivity.navController.navigate(R.id.settingsFragment)
            }
            7 -> {
                DashboardActivity.navController.navigate(R.id.inbox)
            }
            8 -> {
                startActivityFromFragment<ChatListActivity>()
            }
            9 -> {
                displayCustomAlertDialog(title = resources.getString(R.string.logout),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.yes),
                    negativeText = resources.getString(R.string.str_cancel),
                    negativeClick = {
                        it.dismiss()
                    },
                    positiveClick = {
                        it.dismiss()
                        launchProgressDialog()
                        commonViewModel.logoutUser("true", sharedPreferences.refreshToken)

                    })
            }
        }
    }

    /**
     * @desc make instance of profile fragment
     */
    companion object {
        fun newInstance() = ProfileFragment()
    }

    override fun onDestroy() {
        super.onDestroy()
        manageRedirectReceiver.apply {
            LocalBroadcastManager.getInstance(requireContext()).unregisterReceiver(this)
        }
    }

    override fun onNotify(notifyType: String) {
        if (notifyType == "profile") {
            initView()
        }
    }

}
