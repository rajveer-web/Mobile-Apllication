package com.dynasty.esports.view.esport

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.CreatedTournamentFullModel
import com.dynasty.esports.utils.RecyclerViewLoadMoreScroll
import com.dynasty.esports.view.common.BaseFragment
import com.dynasty.esports.view.tournamet.tournamet_detail.TournamentDetailActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.no_data_display_view.*
import kotlinx.android.synthetic.main.no_internet_view_white.*
import kotlinx.android.synthetic.main.progress_dialog_view.*
import kotlinx.android.synthetic.main.recycler_list_view.*
import kotlinx.android.synthetic.main.server_error_view.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import androidx.lifecycle.Observer
import com.dynasty.esports.models.CommonErrorRes
import com.dynasty.esports.models.TournamentListRes
import com.dynasty.esports.viewmodel.OngoingTournamentViewModel
import com.google.gson.reflect.TypeToken
import com.mugen.Mugen
import com.mugen.MugenCallbacks
import com.mugen.attachers.RecyclerViewAttacher

/**
 * @desc this is class will use for ongoing tournament
 * @author : Nihar Dodiya
 * @created : 20-07-2020
 * @modified : 15-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/

class OngoingTournamentFragment : BaseFragment() {

    private val mViewViewModel: OngoingTournamentViewModel by viewModel()
    private lateinit var ongoingAdapter: OngoingAdapter
    private var createdTournamentList: MutableList<CreatedTournamentFullModel.Doc> = mutableListOf()
    private var pageNo = 0
    private var limit = 10
    var isRunning = false
    lateinit var endlessList: RecyclerViewAttacher

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_ongoing_tournament, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialise()
        listenToViewModel()
        initEndlessList()
    }

    /**
     * @desc method will initialize endless recyclerview to commonRecyclerView for pagination
     */
    private fun initEndlessList() {
        endlessList = Mugen.with(commonRecyclerView, object : MugenCallbacks {
            override fun onLoadMore() {
                if (endlessList.isLoadMoreEnabled) {
                    callOngoingTournamentAPI(false)
                }
            }

            override fun isLoading(): Boolean {
                return isRunning
            }

            override fun hasLoadedAllItems(): Boolean {
                return false
            }
        })

        endlessList.start()
        endlessList.loadMoreOffset = 3
        endlessList.isLoadMoreEnabled = true
    }

    /**
     * @desc listen observer and receive the events
     * Also, Manage success and failure responces from API, Internet and un authorization.
     */
    private fun listenToViewModel() {
//        mViewViewModel.jsonObjectForOngoingTournament.observe(viewLifecycleOwner, Observer {
//            mViewViewModel.fetchOngoingTournament(
//                it.first.toString(),
//                it.second.toString(),
//                "type"
//            )
//        })

        mViewViewModel.fetchOngoingTournamentSuccessResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutErrorView.beGone()
            constraintLayoutNoInternet.beGone()
            commonRecyclerView.beVisible()

            ongoingAdapter.setShowloader_(false)
            dismissProgressDialog()

            debugE("OngoingSuccessResponse", Gson().toJson(it))

            if (!it.data!!.hasNextPage) {
                endlessList.isLoadMoreEnabled = false
            }
            ongoingAdapter.addAll(it.data!!.docs as MutableList<TournamentListRes.Doc>)
            refreshPlaceHolder()
        })
        mViewViewModel.fetchOngoingTournamentErrorResponse.observe(viewLifecycleOwner, Observer {
            linearLayoutProgressBar.beGone()
            constraintLayoutNoData.beGone()
            constraintLayoutNoInternet.beGone()
            try {
                val errorRes: CommonErrorRes = Gson().fromJson(
                    it.string(),
                    object : TypeToken<CommonErrorRes?>() {}.type
                )
                errorRes.err!!.message!!.showToast(requireContext())
            } catch (e: Exception) {
            }

            if (createdTournamentList.isEmpty()) {
                constraintLayoutErrorView.beVisible()
            }
            ongoingAdapter.setShowloader_(false)
            endlessList.isLoadMoreEnabled = false
            dismissProgressDialog()
        })

    }

    companion object {
        fun newInstance(): Fragment {
            val args = Bundle()
            val fragment = OngoingTournamentFragment()
            fragment.arguments = args
            return fragment
        }
    }

    /**
     * @desc this method is used for initialize views, adapter and recyclerview
     *       call get ongoing tournament api
     */
    fun initialise() {
        ongoingAdapter = OngoingAdapter(onItemClick = ::onOngoingClick)
        commonRecyclerView.layoutManager = LinearLayoutManager(requireActivity())
        commonRecyclerView.adapter = ongoingAdapter
        constraintLayoutNoData.beGone()
        constraintLayoutErrorView.beGone()
        constraintLayoutNoInternet.beGone()
        callOngoingTournamentAPI(true)
    }

    /**
     * @desc method will call when tap on ongoingAdapter item and redirect to TournamentDetailActivity
     *       set isUpcoming value false when click from ongoing tournament and send data in tournamentbject
     */
    private fun onOngoingClick(position: Int) {
        val item = ongoingAdapter.getItem(position)
        val bundle = Bundle()
        bundle.putString("tournamentId", item.id)
        bundle.putBoolean("isUpcoming", false)
        requireActivity().startActivityInline<TournamentDetailActivity>(
            bundle
        )
    }

    /**
     * @desc make json for onngoing tournament and call get ongoing tournament list api
     * @param pageNo every time add one unit in pageNo for get next page data
     */
    private fun callOngoingTournamentAPI(showPrimaryLoader: Boolean) {
        pageNo++
        if (showPrimaryLoader) {
            linearLayoutProgressBar.beVisible()
        } else {
            ongoingAdapter.setShowloader_(true)
        }

//        mViewViewModel.makeJsonForOngoingTournament(
//            pageNo,
//            limit,
//            true
//        )
        mViewViewModel.fetchOngoingTournament(
            "1",
            "latest",
            "type", pageNo, limit
        )
    }

    /**
     * @desc refresh view for no data display
     */
    private fun refreshPlaceHolder() {
        if (commonRecyclerView.adapter!!.itemCount > 0) {
            commonRecyclerView.beVisible()
            constraintLayoutNoData.beGone()
        } else {
            commonRecyclerView.beGone()
            constraintLayoutNoData.beVisible()
        }
    }
}