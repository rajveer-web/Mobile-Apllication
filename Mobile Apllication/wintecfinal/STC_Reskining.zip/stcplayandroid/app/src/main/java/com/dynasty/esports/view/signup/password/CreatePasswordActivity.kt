package com.dynasty.esports.view.signup.password

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.text.style.ForegroundColorSpan
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.LoginRequest
import com.dynasty.esports.utils.Validator
import com.dynasty.esports.utils.Validator.Companion.PASSWORD_POLICY
import com.dynasty.esports.view.common.SocialLoginActivity
import com.dynasty.esports.view.otp_verification.OTPVerificationActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.viewmodel.CreatePasswordViewModel
import kotlinx.android.synthetic.main.activity_create_password.*
import kotlinx.android.synthetic.main.content_create_password_screen.*
import kotlinx.android.synthetic.main.content_create_password_screen.social_login_fb
import kotlinx.android.synthetic.main.content_create_password_screen.social_login_gPlus
import kotlinx.android.synthetic.main.content_create_password_screen.social_login_twitter
import kotlinx.android.synthetic.main.content_email_registration_screen.*
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.*
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.nickname
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.phone_nos
import kotlinx.android.synthetic.main.content_phone_num_registration_screen.signup_email
import kotlinx.android.synthetic.main.content_phone_num_signin_screen.*
import kotlinx.android.synthetic.main.fragment_forgot_password_verification.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * @desc this class will hold functions for user interaction
 * examples include registerFCMToken(), listenToViewModel(), initialise()
 * @author Sayali Gogawale
 * @created date
 * @modified date
 * @required
 * ©Dynasty eSports Pte ltd
 **/


class CreatePasswordActivity : SocialLoginActivity() {

    private val mViewModel: CreatePasswordViewModel by viewModel()

    var firstname: String? = null
    var email: String? = null
    var phoneNumber: String? = null
    var dob: String? = null
   // var showPassword = false
    var cnfirmPassword = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_password)
        if (!runningActivities.contains(this)) {
            runningActivities.add(this)
        }
        getIntentData()
        initialize()
//        initialiseSocialLogin()
        listenToViewModel()
    }

    var mTextWatcher: TextWatcher = object : TextWatcher {
        override fun beforeTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun onTextChanged(
            charSequence: CharSequence,
            i: Int,
            i2: Int,
            i3: Int
        ) {
        }

        override fun afterTextChanged(editable: Editable) {
            // check Fields For Empty Values
            checkSignInFieldsForEmptyValues(
                null ,
                create_password_edit_text,
                confirm_password_edit_text,
                create_pass_continue,
                isPhoneSignIn
            )
        }
    }

    // to get the data
    private fun getIntentData() {
        intent.extras?.apply {
            firstname = this.getString("fullname")
            email = this.getString("email")
            phoneNumber = this.getString("phoneNumber")
            dob = this.getString("dob")
        }
    }

    // to initialise the view
    private fun initialize() {

//        create_password_edit_text.addTextChangedListener(mTextWatcher);
//        confirm_password_edit_text.addTextChangedListener(mTextWatcher);

     //   checkSignInFieldsForEmptyValues(null, create_password_edit_text, confirm_password_edit_text, create_pass_continue,false);

//        if (type == "phone") {
            create_password_welcome_txt_view.text =
                resources.getString(R.string.password_registration_text)
                    .plus(" $phoneNumber")
//        } else {
//            create_password_welcome_txt_view.text =
//                resources.getString(R.string.password_registration_text)
//                    .plus(" $email")
//        }



        val wordtoSpan: Spannable = SpannableString(resources.getString(R.string.resend_title))
        wordtoSpan.setSpan(
            ForegroundColorSpan(resources.getColor(R.color.colorAccent)),
            21,
            26,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        createPasseord_bottom_view.text = wordtoSpan

        createPasseord_bottom_view.click {
            mViewModel.redirectPhoneSignIn()

        }



        create_pass_continue.click {
            mViewModel.onValidationCreatePassword(
                create_password_edit_text.text.toString().trim(),
                confirm_password_edit_text.text.toString().trim()
            )
        }

        create_password_edit_text.onRightDrawableClicked {
            if(showPassword){
                showPassword = false
                create_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(baseContext,R.drawable.ic_baseline_visibility_off_24), null)
                create_password_edit_text.transformationMethod = PasswordTransformationMethod.getInstance()
            }else{
                showPassword = true
                create_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(baseContext,R.drawable.ic_password_show), null)
                create_password_edit_text.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
        }

        confirm_password_edit_text.onConfirmDrawableClicked {
            if(cnfirmPassword){
                cnfirmPassword = false
                confirm_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(baseContext,R.drawable.ic_baseline_visibility_off_24), null)
                confirm_password_edit_text.transformationMethod = PasswordTransformationMethod.getInstance()
            }else{
                cnfirmPassword = true
                confirm_password_edit_text.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(baseContext,R.drawable.ic_password_show), null)
                confirm_password_edit_text.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }

        }
    }

    private fun listenToViewModel() {


        mViewModel.redirectPhoneObserver.observe(this, Observer {
            startActivityInline<PhoneSignInActivity>()
        })

        mViewModel.validationLiveData.observe(this, Observer {
            when (it) {
                0 -> {
                    makeSnackBar(
                        constraintLayoutCreatePassword,
                        resources.getString(R.string.create_password_error)
                    )
                }
                1 -> {
                    makeSnackBar(constraintLayoutCreatePassword, resources.getString(R.string.confirm_passsword_error))
                }
                2 -> {
                    hideKeyboard()
                    Validator.PASSWORD_POLICY.showToast(this)
                }
                3 -> {
                    hideKeyboard()
                    Validator.PASSWORD_POLICY.showToast(this)
                }
                4 -> {
                    hideKeyboard()
                    makeSnackBar(constraintLayoutCreatePassword, resources.getString(R.string.passwrd_not_matching))
                }
            }
        })

        mViewModel.isFormValid.observe(this, Observer {
            launchProgressDialog()
            // If it is redirected from Email Registration screen
            val loginRequest = LoginRequest()
            loginRequest.email = email
            loginRequest.fullName = firstname
            loginRequest.password = confirm_password_edit_text.text.toString().trim()
            loginRequest.dob = dob
            loginRequest.phoneNumber = phoneNumber
            mViewModel.signUpAPI(loginRequest)

//            if (type=="email") {
//                val loginRequest = LoginRequest()
//                loginRequest.email = email
//                loginRequest.fullName = firstname
//                loginRequest.password = confirm_password_edit_text.text.toString().trim()
//                loginRequest.type = type
//                mViewModel.signUpAPI(loginRequest)
//            } else {
//                // If it is redirected from Mobile No Registration screen
//
//                val loginRequest = LoginRequest()
//                loginRequest.phoneNumber = phoneNumber
//                loginRequest.fullName = firstname
//                loginRequest.password = confirm_password_edit_text.text.toString().trim()
//                loginRequest.type = type
//                mViewModel.signUpAPI(loginRequest)
//            }
        })

        mViewModel.signUpSuccessResponse.observe(this, {
            dismissProgressDialog()
//            if(type=="phone"){
//                val bundle = Bundle()
//                bundle.putString("fullname",firstname)
//                bundle.putString("email",email)
//                bundle.putString("type","email")
//                startActivityInline<CreatePasswordActivity>(bundle = bundle)
//            }else {

                val bundle = Bundle()
                sharedPreferences.accessToken = it.data.token
                bundle.putString("email", email)
                bundle.putString("type", "phone")
                bundle.putString("activity", this@CreatePasswordActivity::class.simpleName)
                bundle.putString("phoneNumber", phoneNumber)
                Toast.makeText(applicationContext, it.message, Toast.LENGTH_SHORT).show()
                /* here */
                startActivityInline<OTPVerificationActivity>(bundle)
//            }
        })

        mViewModel.signUpErrorResponse.observe(this, Observer {
            dismissProgressDialog()
            /*here get the message n convert iy*/
            makeSnackBar(constraintLayoutCreatePassword,it.string().getMessageFromObject("message"))
        })

    }

    override fun onBackPressed() {
        killActivity(this::class.java)
        super.onBackPressed()
    }

//    private fun createPasswordContinue(
//        firstname: String?,
//        email: String?,
//        phoneNumber: String?,
//        type: String?
//    ) {
//
//        //val type : String = "email"
//        val passwordcreated: Boolean = Validator.isValidPassword(createPass, true)
//        val passwordconfirmed: Boolean = Validator.isValidPassword(confirmPass, true)
//
//        //Checkbox condition needds to be handed
//        if (!TextUtils.isEmpty(createPass) && !TextUtils.isEmpty(createPass)) {
//            if (passwordcreated && passwordconfirmed) {
//                if (createPass.equals(confirmPass)) {
//                    //hit the app call and email will be sent to registered mail id and otp will be send on it
//                    // Redirect t otp screen
//                    Log.d("Dynasty: CreatePass ", "API call : " + firstname + " email " + email)

//
//                } else {
//                    Toast.makeText(this, "different password", Toast.LENGTH_LONG).show()
//                }
//            } else {
//                Toast.makeText(
//                    this,
//                    "Password requires 1 special char, 1Capital case and 1 small case",
//                    Toast.LENGTH_LONG
//                ).show()
//            }
//        } else {
//            Toast.makeText(this, "Please fill the data", Toast.LENGTH_LONG).show()
//        }
//    }
//
//    //    fun registerUserByEmail(firstname: String?, email: String?, confirmPass: String?, type: String?) {
////            ApiClient.postInstance.registerUserByEmail(firstname, email, confirmPass,type)
//    private fun registerUserByEmail(loginREquest: LoginRequest) {
//        dialogBoxDisplay(true)
//        ApiClient.POST_INSTANCE.registerUser(loginREquest)
//            .enqueue(object : Callback<RegisterResponse> {
//                override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
//                    Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
//                    dialogBoxDisplay(false)
//                }
//
//                override fun onResponse(
//                    call: Call<RegisterResponse>,
//                    response: Response<RegisterResponse>
//                ) {
//                    if (response.body() != null) {
//                        if (response.body()?.message.equals("Register Successfully")) {
//                            Log.d("Application Token : ", response.body()!!.data.token)
//                            val intent =
//                                Intent(applicationContext, OTPVerificationActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//                            //Send token value also
//                            intent.putExtra("token", response.body()!!.data.token)
//                            intent.putExtra("email", loginREquest.email)
//                            intent.putExtra("type", loginREquest.type)
//                            intent.putExtra("activity", "createpassword")
//                            intent.putExtra("phoneNumber", phoneNumber)
//                            startActivity(intent)
//                        } else {
//                            Toast.makeText(
//                                applicationContext,
//                                response.body()?.message,
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                        dialogBoxDisplay(false)
//                    } else {
//                        dialogBoxDisplay(false)
//                        val jObjError = JSONObject(response.errorBody()!!.string())
//                        Log.d("Error : ", jObjError.getString("message"))
//                        Toast.makeText(
//                            applicationContext,
//                            jObjError.getString("message"),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                }
//            })
//    }
}