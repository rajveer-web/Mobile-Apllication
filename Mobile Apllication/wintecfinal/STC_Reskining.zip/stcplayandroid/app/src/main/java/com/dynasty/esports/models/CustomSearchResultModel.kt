package com.dynasty.esports.models

data class CustomSearchResultModel(
    val key:Int?=null,
    val title:String?=null,
    val tournamentList:MutableList<TournamentSearchResultModel>?=null,
    val articleList:MutableList<SearchArticleModel.DataModel> ?= null,
    val videoList:MutableList<SearchVideoModel.DataModel> ?= null
)