package com.dynasty.esports.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class SingleTournamentModel {

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("success")
    @Expose
    var success = false

    @SerializedName("data")
    @Expose
    var data: List<Datum> = ArrayList<Datum>()

    @SerializedName("totals")
    @Expose
    var totals: Totals? = null

    class BracketTypes {
        @SerializedName("simple")
        @Expose
        var simple = false

        @SerializedName("double")
        @Expose
        var _double = false

        @SerializedName("single")
        @Expose
        var single = false

        @SerializedName("round_robin")
        @Expose
        var roundRobin = false

        @SerializedName("battle_royale")
        @Expose
        var battleRoyale = false
    }

    class Datum {
        @SerializedName("substituteMembers")
        @Expose
        var substituteMembers = 0

        @SerializedName("participants")
        @Expose
        var participants: List<CreateTournament.Participant> = ArrayList()

        @SerializedName("isSeeded")
        @Expose
        var isSeeded = false

        @SerializedName("regionsAllowed")
        @Expose
        var regionsAllowed: MutableList<String> = mutableListOf()

        @SerializedName("sponsors")
        @Expose
        var sponsors: List<CreateTournament.Sponsor> = ArrayList()

        @SerializedName("status")
        @Expose
        var status: String? = null

        @SerializedName("venueAddress")
        @Expose
        var venueAddress: List<CreateTournament.VenueAddress> = ArrayList()

        @SerializedName("stream")
        @Expose
        var stream: List<Any> = ArrayList()

        @SerializedName("isFinished")
        @Expose
        var isFinished = false

        @SerializedName("rating")
        @Expose
        var rating = 0

        @SerializedName("changeRequest")
        @Expose
        var changeRequest: Any? = null

        @SerializedName("nfMatchBetweenTwoTeam")
        @Expose
        var nfMatchBetweenTwoTeam = 0

        @SerializedName("prizeList")
        @Expose
        var prizeList: ArrayList<CreateTournament.PrizeList> = ArrayList()

        @SerializedName("isAllowMultipleRounds")
        @Expose
        var isAllowMultipleRounds = false

        @SerializedName("noOfPlacement")
        @Expose
        var noOfPlacement: Int = 0

        @SerializedName("placementPoints")
        @Expose
        var placementPoints: List<PlacementPoint> = ArrayList()

        @SerializedName("isFeature")
        @Expose
        var isFeature = false

        @SerializedName("noOfTeamInGroup")
        @Expose
        var noOfTeamInGroup: Int = 0

        @SerializedName("noOfWinningTeamInGroup")
        @Expose
        var noOfWinningTeamInGroup: Int = 0

        @SerializedName("noOfRoundPerGroup")
        @Expose
        var noOfRoundPerGroup: Int = 0

        @SerializedName("isKillPointRequired")
        @Expose
        var isKillPointRequired = false

        @SerializedName("allowAdvanceStage")
        @Expose
        var allowAdvanceStage = false

        @SerializedName("stageBracketType")
        @Expose
        var stageBracketType: String = ""

        @SerializedName("substituteMemberSize")
        @Expose
        var substituteMemberSize = 0

        @SerializedName("allowSubstituteMember")
        @Expose
        var allowSubstituteMember = false

        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("name")
        @Expose
        var name: String = ""

        @SerializedName("url")
        @Expose
        var url: String? = null

        @SerializedName("participantType")
        @Expose
        var participantType: String? = null

        @SerializedName("startDate")
        @Expose
        var startDate: String? = null

        @SerializedName("endDate")
        @Expose
        var endDate: String? = null

        @SerializedName("startTime")
        @Expose
        var startTime: String? = null

        @SerializedName("isPaid")
        @Expose
        var isPaid = false

        @SerializedName("description")
        @Expose
        var description: String? = null

        @SerializedName("rules")
        @Expose
        var rules: String? = null

        @SerializedName("criticalRules")
        @Expose
        var criticalRules: String? = null

        @SerializedName("isPrize")
        @Expose
        var isPrize = false

        @SerializedName("faqs")
        @Expose
        var faqs: String? = null

        @SerializedName("schedule")
        @Expose
        var schedule: String? = null

        @SerializedName("isIncludeSponsor")
        @Expose
        var isIncludeSponsor = false

        @SerializedName("tournamentType")
        @Expose
        var tournamentType: String? = null

        @SerializedName("isScreenshotRequired")
        @Expose
        var isScreenshotRequired = false

        @SerializedName("isShowCountryFlag")
        @Expose
        var isShowCountryFlag = false

        @SerializedName("isSpecifyAllowedRegions")
        @Expose
        var isSpecifyAllowedRegions = false

        @SerializedName("isParticipantsLimit")
        @Expose
        var isParticipantsLimit = false

        @SerializedName("scoreReporting")
        @Expose
        var scoreReporting = 0

        @SerializedName("invitationLink")
        @Expose
        var invitationLink: String? = null

        @SerializedName("youtubeVideoLink")
        @Expose
        var youtubeVideoLink: String? = null

        @SerializedName("facebookVideoLink")
        @Expose
        var facebookVideoLink: String? = null

        @SerializedName("contactDetails")
        @Expose
        var contactDetails: String? = null

        @SerializedName("twitchVideoLink")
        @Expose
        var twitchVideoLink: String? = null

        @SerializedName("visibility")
        @Expose
        var visibility = 0

        @SerializedName("checkInEndDate")
        @Expose
        var checkInEndDate: String? = null

        @SerializedName("banner")
        @Expose
        var banner: String? = null

        @SerializedName("maxParticipants")
        @Expose
        var maxParticipants = 0

        @SerializedName("bracketType")
        @Expose
        var bracketType: String? = null

        @SerializedName("noOfSet")
        @Expose
        var noOfSet = 0

        @SerializedName("contactOn")
        @Expose
        var contactOn: String? = null

        @SerializedName("gameDetail")
        @Expose
        var gameDetail: GameDetail? = null

        @SerializedName("teamSize")
        @Expose
        var teamSize = 0

        @SerializedName("prizeCurrency")
        @Expose
        var prizeCurrency: String? = null

        @SerializedName("slug")
        @Expose
        var slug: String? = null

        @SerializedName("tournamentStatus")
        @Expose
        var tournamentStatus: String? = null

        @SerializedName("organizerDetail")
        @Expose
        var organizerDetail: OrganizerDetail? = null

        @SerializedName("updatedBy")
        @Expose
        var updatedBy: String? = null

        @SerializedName("createdBy")
        @Expose
        var createdBy: String? = null

        @SerializedName("checkInStartDate")
        @Expose
        var checkInStartDate: String? = ""

        @SerializedName("platform")
        @Expose
        var platform: String? = null

        @SerializedName("stageMatch")
        @Expose
        var stageMatch: String = ""

        @SerializedName("stageMatchNoOfSet")
        @Expose
        var stageMatchNoOfSet = 0

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("fullText")
        @Expose
        var fullText: String? = null

        @SerializedName("__v")
        @Expose
        var v = 0
    }

    class GameDetail {
        @SerializedName("activeTournament")
        @Expose
        var activeTournament: String? = null

        @SerializedName("status")
        @Expose
        var status = 0

        @SerializedName("order")
        @Expose
        var order = 0

        @SerializedName("platform")
        @Expose
        var platform: List<String> = ArrayList()

        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("slug")
        @Expose
        var slug: String? = null

        @SerializedName("logo")
        @Expose
        var logo: String? = null

        @SerializedName("image")
        @Expose
        var image: String? = null

        @SerializedName("bracketTypes")
        @Expose
        var bracketTypes: BracketTypes? = null

        @SerializedName("isTournamentAllowed")
        @Expose
        var isTournamentAllowed = false

        @SerializedName("updatedBy")
        @Expose
        var updatedBy: String? = null

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null
    }

    class OrganizerDetail {
        @SerializedName("phoneisVerified")
        @Expose
        var phoneisVerified = false

        @SerializedName("emailisVerified")
        @Expose
        var emailisVerified = false

        @SerializedName("isPassword")
        @Expose
        var isPassword = false

        @SerializedName("accessLevel")
        @Expose
        var accessLevel: List<Any> = ArrayList()

        @SerializedName("Status")
        @Expose
        var status = 0

        @SerializedName("identifiers")
        @Expose
        var identifiers: List<String> = ArrayList()

        @SerializedName("firstLogin")
        @Expose
        var firstLogin = 0

        @SerializedName("isAuthor")
        @Expose
        var isAuthor = 0

        @SerializedName("isInfluencer")
        @Expose
        var isInfluencer = 0

        @SerializedName("isVerified")
        @Expose
        var isVerified = 0

        @SerializedName("organizerRating")
        @Expose
        var organizerRating = 0

        @SerializedName("_id")
        @Expose
        var id: String? = null

        @SerializedName("rating")
        @Expose
        var rating = 0

        @SerializedName("accountType")
        @Expose
        var accountType: String? = null

        @SerializedName("fullName")
        @Expose
        var fullName: String? = null

        @SerializedName("phoneNumber")
        @Expose
        var phoneNumber: String? = null

        @SerializedName("email")
        @Expose
        var email: String? = null

        @SerializedName("profilePicture")
        @Expose
        var profilePicture: String? = null

        @SerializedName("createdBy")
        @Expose
        var createdBy: String? = null

        @SerializedName("updatedBy")
        @Expose
        var updatedBy: String? = null

        @SerializedName("createdOn")
        @Expose
        var createdOn: String? = null

        @SerializedName("updatedOn")
        @Expose
        var updatedOn: String? = null

        @SerializedName("text")
        @Expose
        var text: String? = null

        @SerializedName("__v")
        @Expose
        var v = 0

        @SerializedName("accountDetail")
        @Expose
        var accountDetail: String? = null

        @SerializedName("accountId")
        @Expose
        var accountId: String? = null

        @SerializedName("emailOTP")
        @Expose
        var emailOTP = 0

        @SerializedName("emailOTPexp")
        @Expose
        var emailOTPexp: String? = null

        @SerializedName("phoneOTP")
        @Expose
        var phoneOTP = 0

        @SerializedName("phoneOTPexp")
        @Expose
        var phoneOTPexp: String? = null

        @SerializedName("country")
        @Expose
        var country: String? = null

        @SerializedName("dob")
        @Expose
        var dob: Any? = null

        @SerializedName("gender")
        @Expose
        var gender: String? = null

        @SerializedName("martialStatus")
        @Expose
        var martialStatus: String? = null

        @SerializedName("parentalStatus")
        @Expose
        var parentalStatus: String? = null

        @SerializedName("postalCode")
        @Expose
        var postalCode: String? = null

        @SerializedName("profession")
        @Expose
        var profession: String? = null

        @SerializedName("shortBio")
        @Expose
        var shortBio: String? = null

        @SerializedName("state")
        @Expose
        var state: String? = null
    }

//    class PrizeList {
//        @SerializedName("name")
//        @Expose
//        var name: String? = null
//
//        @SerializedName("value")
//        @Expose
//        var value = 0
//    }

    class Totals {
        @SerializedName("count")
        @Expose
        var count = 0
    }

    class PlacementPoint {
        @SerializedName("position")
        @Expose
        var position: String? = null

        @SerializedName("value")
        @Expose
        var value: String? = null
    }
}