package com.dynasty.esports.viewmodel

import android.app.DatePickerDialog
import android.widget.TextView
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.extenstion.isFieldEmpty
import com.dynasty.esports.models.*
import com.dynasty.esports.retrofit.RestInterface
import com.google.gson.JsonObject
import kotlinx.coroutines.*
import okhttp3.ResponseBody
import java.util.*

class CreateTournamentStep1ViewModel constructor(private val restInterface: RestInterface) :
    BaseViewModel() {
    val datePickerObserver = MutableLiveData<Boolean>()
    val endDatePickerObserver = MutableLiveData<Boolean>()
    val timePickerObserver = MutableLiveData<Boolean>()
    val checStartEdittextObserver = MutableLiveData<Boolean>()
    val llImageUploadObserver = MutableLiveData<Boolean>()
    val iseditUrlNotEmpty = MutableLiveData<Boolean>()

    val validationLiveData = MutableLiveData<Int>()
    val isNextStepFormValid = MutableLiveData<Boolean>()

    val checkUrlSuccessResponse = MutableLiveData<CheckUrlRes>()
    val checkUrlErrorResponse = MutableLiveData<ResponseBody>()

    val uploadFileSuccessResponse = MutableLiveData<UploadFilesRes>()
    val uploadFileErrorResponse = MutableLiveData<ResponseBody>()

    val gameListSuccessResponse = MutableLiveData<TournamentGameRes>()
    val gameListErrorResponse = MutableLiveData<ResponseBody>()

    fun onValidationForNextStep(
        tournamentName: String,
        isTournamentValid: Boolean,
        gameSelected: Boolean, platform_txt: String,
        tournamentType: String?,
        tournamentTeamFormat: String?,
        tournamentTeamNumber: Int,
        isSubstitute: Boolean,
        tournamentSubstituteSize: Int,
        tournamentDate: String,
        tournamentTime: String,
        tournamentEndDate: String,
        tournamentBracket: String,
        nextStagebracketSelectionTxt: String,
        tournamentMatchformate: String,
        selectedStage: String,
        selectedNextStageFormate: String,
        switchAdvanceStage: Boolean,
        paidRegistration: Boolean,
        paidRegistrationType: String,
        paidRegistrationFees: String,
        checkInRequired: Boolean,
        checkInStartDate: String,
        bttelRoyaleError: Boolean,
        roundRobinError: Boolean,
        addPlacementPointvalidated: Boolean,
        maxpartError: Boolean
    ) {

        if (tournamentName.isFieldEmpty()) {
            validationLiveData.postValue(0)
        } else if (!isTournamentValid) {
            validationLiveData.postValue(1)
        } else if (!gameSelected) {
            validationLiveData.postValue(2)
        } else if (platform_txt.isFieldEmpty()) {
            validationLiveData.postValue(16)
        } else if (tournamentType!!.isFieldEmpty()) {
            validationLiveData.postValue(3)
        } else if (tournamentTeamFormat.equals(
                "xvsx",
                true
            ) && tournamentTeamNumber < 2
        ) {
            validationLiveData.postValue(4)
        } else if (tournamentTeamFormat.equals(
                "xvsx",
                true
            ) && tournamentTeamNumber > 10
        ) {
            validationLiveData.postValue(4)
        } else if (isSubstitute && tournamentSubstituteSize < 1) {
            validationLiveData.postValue(24)
        } else if (isSubstitute && tournamentSubstituteSize > 10) {
            validationLiveData.postValue(24)
        } else if (tournamentType.equals(
                "team",
                true
            ) && tournamentTeamFormat.isNullOrEmpty()
        ) {
            validationLiveData.postValue(22)
        } else if (tournamentDate.isFieldEmpty()) {
            validationLiveData.postValue(5)
        } else if (tournamentTime.isFieldEmpty()) {
            validationLiveData.postValue(6)
        } else if (tournamentEndDate.isFieldEmpty()) {
            validationLiveData.postValue(17)
        } else if (tournamentBracket.isFieldEmpty()) {
            validationLiveData.postValue(7)
        } else if (tournamentBracket.equals("round_robin") && nextStagebracketSelectionTxt.isFieldEmpty()) {
            validationLiveData.postValue(23)
        } else if (!tournamentBracket.equals("battle_royale") && tournamentMatchformate.isFieldEmpty()) {
            validationLiveData.postValue(8)
        } else if (switchAdvanceStage && !tournamentBracket.equals("battle_royale") && selectedStage.isFieldEmpty()) {
            validationLiveData.postValue(9)
        } else if (switchAdvanceStage && !tournamentBracket.equals("battle_royale") && selectedNextStageFormate.isFieldEmpty()) {
            validationLiveData.postValue(10)
        } else if (paidRegistration && paidRegistrationType.isFieldEmpty()) {
            validationLiveData.postValue(11)
        } else if (paidRegistration && paidRegistrationFees.isFieldEmpty()) {
            validationLiveData.postValue(12)
        } else if (checkInRequired && checkInStartDate.isFieldEmpty()) {
            validationLiveData.postValue(13)
        } else if (tournamentBracket.equals("battle_royale") && bttelRoyaleError) {
            validationLiveData.postValue(18)
        } else if (tournamentBracket.equals("battle_royale") && !addPlacementPointvalidated) {
            validationLiveData.postValue(19)
        } else if (maxpartError) {
            validationLiveData.postValue(20)
        } else if (tournamentBracket.equals("round_robin") && roundRobinError) {
            validationLiveData.postValue(21)
        } else {
            isNextStepFormValid.postValue(true)
        }
//
//        when {
//            tournamentName.isFieldEmpty() -> validationLiveData.postValue(0)
//            !gameSelected -> validationLiveData.postValue(1)
//            !tournamentType -> validationLiveData.postValue(2)
//            tournamentDate.isFieldEmpty() -> validationLiveData.postValue(3)
//            tournamentTime.isFieldEmpty() -> validationLiveData.postValue(4)
//            !tournamentBracket -> validationLiveData.postValue(5)
//            tournamentMatchformate.isFieldEmpty() -> validationLiveData.postValue(6)
//            !paidRegistration -> validationLiveData.postValue(7)
//            paidRegistrationType.isFieldEmpty() -> validationLiveData.postValue(8)
//            paidRegistrationFees.isFieldEmpty() -> validationLiveData.postValue(9)
//            checkInStartDate.isFieldEmpty() -> validationLiveData.postValue(10)
//            checkInCloseDate.isFieldEmpty() -> validationLiveData.postValue(11)
//            !isBannerSelected -> validationLiveData.postValue(12)
//            else -> isNextStepFormValid.postValue(true)
//        }
    }

    fun checkValidation(editUrl: String) {
        when {
            editUrl.isFieldEmpty() -> validationLiveData.postValue(15)
            else -> iseditUrlNotEmpty.postValue(true)
        }
    }

    fun checkUrlValidOrNot(query: String) {
        viewModelScope.launch(apiException() + Dispatchers.Main) {
            val response = restInterface.checkUrlExiestOrNot(query)
            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    checkUrlSuccessResponse.postValue(response.body())
                }
                else -> {
                    checkUrlErrorResponse.postValue(response.errorBody())
                }
            }
        }
    }

    fun uploadFiles(uploadFileJson: JsonObject) {
        viewModelScope.launch(apiException("all") + Dispatchers.Main) {
            val response = restInterface.uploadFiles(uploadFileJson)

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    uploadFileSuccessResponse.postValue(response.body())
                }
                else -> {
                    uploadFileErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    fun getGameList() {
        viewModelScope.launch(apiException("gameList") + Dispatchers.Main) {
            val response = restInterface.getTournamentGameList()

            when (response.code()) {
                AppConstants.API_SUCCESS_CODE -> {
                    gameListSuccessResponse.postValue(response.body())
                }
                else -> {
                    gameListErrorResponse.postValue(response.errorBody())
                }
            }

        }
    }

    fun pickDateEdittextClick() {
        datePickerObserver.postValue(true)
    }

    fun pickEndDateEdittextClick() {
        endDatePickerObserver.postValue(true)
    }

    fun pickTimeEdittextClick() {
        timePickerObserver.postValue(true)
    }

    fun checStartEdittextClick() {
        checStartEdittextObserver.postValue(true)
    }

    fun llImageUpload() {
        llImageUploadObserver.postValue(true)
    }

    /**
     * Clears the [ViewModel] when the [CreateTournamentActivity] is not visible to user.
     */
    fun onDetach() {
//        viewModelScope.cancel()
    }

//    private val job = Job()
//
//    override val coroutineContext: CoroutineContext
//        get() = Dispatchers.Main + job

}
