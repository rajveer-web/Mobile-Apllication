package com.dynasty.esports.view.dashboard

import android.content.Intent
import android.content.IntentSender.SendIntentException
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import com.dynasty.esports.R
import com.dynasty.esports.extenstion.*
import com.dynasty.esports.models.ProfileModel
import com.dynasty.esports.models.UserModel
import com.dynasty.esports.utils.LocaleHelper
import com.dynasty.esports.view.common.BaseActivity
import com.dynasty.esports.view.common.DrawerAdapter
import com.dynasty.esports.view.profile.ProfileOptionAdapter
import com.dynasty.esports.view.profile.PrrofileActivity
import com.dynasty.esports.view.search.SearchActivity
import com.dynasty.esports.view.signin.mobile.PhoneSignInActivity
import com.dynasty.esports.viewmodel.CommonViewModel
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import kotlinx.android.synthetic.main.activity_dashboard.*
import kotlinx.android.synthetic.main.nav_header.*
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * @desc this class will display basic info of login user
 * @author : Sayali
 * @created : 20-07-2020
 * @modified : 24-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class DashboardActivity : BaseActivity() {
    //    private val mViewModel: DashBoardViewModel by viewModel()
    private lateinit var appBarConfiguration: AppBarConfiguration
    private var mAppUpdateManager: AppUpdateManager? = null
    private lateinit var drawerAdapter: DrawerAdapter
    private var profileOptionList: MutableList<ProfileModel> = mutableListOf()
    private lateinit var profileOptionAdapter: ProfileOptionAdapter
    val commonViewModel: CommonViewModel by viewModel()



//    val profileArray = arrayOf(
//        "BASIC INFO",
//        "MY BRACKET",
//        "MY TOURNAMENT",
//        "MY TRANSACTIONS",
//        "MY BOOKMARKS",
//        "SETTINGS",
//        "INBOX"
//    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mAppUpdateManager = AppUpdateManagerFactory.create(this)

        setStatusBarTransparent()

        setContentView(R.layout.activity_dashboard)
        checkAppUpdate()
        //drawerList
     //   lst_menu_items.layoutManager = LinearLayoutManager(this)
        initialise()
    }

    var listener = InstallStateUpdatedListener {
        if (it.installStatus() == InstallStatus.DOWNLOADED) {
            makeSnackBar(container, resources.getString(R.string.update_download),
                resources.getString(R.string.restart)) {
                mAppUpdateManager?.apply {
                    this.completeUpdate()
                }

            }
        }
    }

    private fun checkAppUpdate() {
        mAppUpdateManager?.apply {
            this.registerListener(listener)
        }


// Checks that the platform will allow the specified type of update.
        mAppUpdateManager?.appUpdateInfo?.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() === UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(
                    AppUpdateType.FLEXIBLE
                )
            ) {
                try {
                    mAppUpdateManager?.startUpdateFlowForResult(
                        appUpdateInfo,
                        AppUpdateType.FLEXIBLE,
                        this,
                        1994
                    )
                } catch (e: SendIntentException) {
                    e.printStackTrace()
                }
            } else if (appUpdateInfo.installStatus() === InstallStatus.DOWNLOADED) {
                makeSnackBar(
                    container, resources.getString(R.string.update_download),
                    resources.getString(R.string.restart)
                ) {
                    mAppUpdateManager?.apply {
                        this.completeUpdate()
                        this.unregisterListener(listener)
                    }
                }
            }
        }
    }

   override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1010) {
            val flag=data?.getIntExtra("flag",-1)
            when(flag) {
                0->{
                    navController.navigate(R.id.basicInfoFragment)
                }
                1->{
                    navController.navigate(R.id.homeFragment)
                }
                2->{
                    navController.navigate(R.id.settingsFragment)
                }
                4 -> {
                    navController.navigate(R.id.createdTournament)
                }
                5 -> {
                    navController.navigate(R.id.bookmark)
                }
                6 -> {
                    navController.navigate(R.id.bracketFragment)
                }
                7 -> {
                    navController.navigate(R.id.inbox)
                }
                8 ->{
                    val bundle = Bundle()
                    bundle.putString("type", "joined")
                    DashboardActivity.navController.navigate(R.id.createdTournament, bundle)
                }
                9->{
                    if (LocaleHelper.getLanguage(this) != "en") {
                        launchChangeLanguageDialog("en")
                    }
                 }
                10->{
                    val bundle = Bundle()
                    bundle.putString("type", "created")
                    navController.navigate(R.id.createdTournament, bundle)
                }
                11->{
                    if (LocaleHelper.getLanguage(this) != "ar") {
                        launchChangeLanguageDialog("ar")
                    }
                }


            }
        }
    }

    fun initialise() {
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.main_nav_host) as NavHostFragment
        navController = navHostFragment.navController
        // val  navController = findNavController(R.id.main_nav_host) //Initialising navController

        appBarConfiguration = AppBarConfiguration.Builder(
            R.id.homeFragment,
            R.id.articlesFragment,
            R.id.esportsFragment,
            R.id.profileFragment,
            R.id.leaderboardTabFragment,
            R.id.gameFragment,
            R.id.profileFragment,
            R.id.bracketFragment,
            R.id.joinTournamentFragment,
            R.id.basicInfoFragment,
            R.id.transactionHistoryFragment,
            R.id.settingsFragment,
            R.id.inbox,
            R.id.inboxMessage,
            R.id.bookmark,
            R.id.joinTournamentFragment,
            R.id.createdTournament

            )/*.setDrawerLayout(main_drawer_layout)*/
            .build()
        (this@DashboardActivity).supportActionBar?.displayOptions =
            androidx.appcompat.app.ActionBar.DISPLAY_SHOW_CUSTOM


        // NavigationUI.setupWithNavController(navigationView, navController);

        // inflating your custom view
        // not quite sure what I should put for root so I have put "null". I am guessing we need to put the root view from `onViewCreated()` ?
        val customView = layoutInflater.inflate(R.layout.custom_actionbar_layout, null)
        val textViewSearch = customView.findViewById<TextView>(R.id.textViewSearch)
        textViewSearch.click {
            startActivityInline<SearchActivity>()
        }
        val drawerImg  = customView.findViewById<ImageView>(R.id.ic_drawer)
        drawerImg.click{
         //   startActivityInlineWithAnimation<PrrofileActivity>()
            startActivityInlineWithAnimation<PrrofileActivity>(resultCode = 1010)

        }
        // setting the whole layout match parent. For some reason, doing match parent from xml wasn't working
        val layoutParams = androidx.appcompat.app.ActionBar.LayoutParams(
            androidx.appcompat.app.ActionBar.LayoutParams.MATCH_PARENT,
            androidx.appcompat.app.ActionBar.LayoutParams.MATCH_PARENT
        )

        // applying the custom view
        (this@DashboardActivity).supportActionBar?.setCustomView(customView, layoutParams)

        // in case you want to change the text yourself
        //  toolBarTitle = customView.findViewById(R.id.customTitle)
        setupActionBarWithNavController(this,
            navController,
            appBarConfiguration) //Setup toolbar with back button and drawer icon according to appBarConfiguration

        showBothNavigation()
        setupNavControl()
        visibilityNavElements() //If you want to hide drawer or bottom navigation configure that in this function

        main_bottom_navigation_view.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.homeFragment -> {
                  //  selectedId = R.id.homeFragment
                    navController.navigate(R.id.homeFragment)
                }
                R.id.articlesFragment -> {
                    //selectedId = R.id.articlesFragment
                    navController.navigate(R.id.articlesFragment)
                }
                R.id.esportsFragment -> {
                  //  selectedId = R.id.esportsFragment
                    navController.navigate(R.id.esportsFragment)
                }
                R.id.leaderBoard -> {
                    //  selectedId = R.id.esportsFragment
                    navController.navigate(R.id.leaderboardTabFragment)
                }
                R.id.tournament -> {
                    //  selectedId = R.id.esportsFragment
                    navController.navigate(R.id.gameFragment)
                }
               // R.id.profileFragment -> {
                 //   navController.navigate(R.id.profileFragment)
//                    if (sharedPreferences.accessToken.isNullOrEmpty()) {
////                        if (navController.currentDestination?.id != R.id.profileFragment) {
//                            displayCustomAlertDialog(title = resources.getString(R.string.please_login_to_access_page),
//                                isCancelable = true,
//                                isCloseShow = true,
//                                positiveText = resources.getString(R.string.yes),
//                                positiveClick = {
//                                    it.dismiss()
//                                    redirectType = "profile"
//                                    startActivityInline<PhoneSignInActivity>()
//                                },
//                                negativeText = resources.getString(R.string.no),
//                                negativeClick = {
//                                    it.dismiss()
//                                    navController.navigate(R.id.profileFragment)
//                                }, onCloseClick = {
//                                    it.dismiss()
//
//                                })
//                            return@setOnNavigationItemSelectedListener true
////                        /}
//                      //  return@setOnNavigationItemSelectedListener true
//                    } else {
//
//                    }
               // }
            }
            return@setOnNavigationItemSelectedListener true
        }
  /*      val myListAdapter = MyListAdapter(this, profileArray)
        lst_menu_items.adapter = myListAdapter

        lst_menu_items.setOnItemClickListener { _, _, position, id ->
            *//* val itemAtPos = adapterView.getItemAtPosition(position)
             val itemIdAtPos = adapterView.getItemIdAtPosition(position)
             Toast.makeText(this, "Click on item at $itemAtPos its item id $itemIdAtPos", Toast.LENGTH_LONG).show()*//*
            when (position) {
                0 -> {
                    navController.navigate(R.id.basicInfoFragment)
                }
                1 -> {
                    navController.navigate(R.id.bracketFragment)

                }
                2 -> {
                    navController.navigate(R.id.joinTournamentFragment)
                }
                3 -> {
                    navController.navigate(R.id.transactionHistoryFragment)
                }

            }
        }*/

        // Drawer list
/*        val subProfileLanguage: MutableList<SubProfileOptionModel> = mutableListOf()
        subProfileLanguage.add(
            SubProfileOptionModel(
                "language",
                resources.getString(R.string.english)
            )
        )
        subProfileLanguage.add(
            SubProfileOptionModel(
                "language",
                resources.getString(R.string.arabic)
            )
        )

        if (!sharedPreferences.checkUserLoggedInOrNot()) {
            leftlayout.beGone()
            relativeLayoutRight.beGone()
         //   guest_nav_head.beVisible()
            profileOptionList.clear()
         //   profileOptionList.add(ProfileModel(resources.getString(R.string.login)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.language),
                    isExpandable = true,
                    expandListData = subProfileLanguage
                )
            )
        }
        else {
            *//*guest_nav_head?.apply {
                guest_nav_head.beGone()
            }*//*
            leftlayout?.apply {
                leftlayout.beVisible()
            }
            relativeLayoutRight?.apply {
                relativeLayoutRight.beVisible()
            }


            val subProfileTournament: MutableList<SubProfileOptionModel> = mutableListOf()
            subProfileTournament.add(
                SubProfileOptionModel(
                    "tournament",
                    resources.getString(R.string.joined_tournaments)
                )
            )
            subProfileTournament.add(
                SubProfileOptionModel(
                    "tournament",
                    resources.getString(R.string.created_tournaments)
                )
            )
            profileOptionList.clear()
            profileOptionList.add(ProfileModel(resources.getString(R.string.basic_info)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.language),
                    isExpandable = true,
                    expandListData = subProfileLanguage
                )
            )
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_bracket)))
            profileOptionList.add(
                ProfileModel(
                    resources.getString(R.string.my_tournament),
                    isExpandable = true,
                    expandListData = subProfileTournament,
                    drawable = ResourcesCompat.getDrawable(this.resources,R.drawable.ic_baseline_arrow_right_24, null)
                )
            )
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_transactions)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.my_bookmark)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.settings)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.inbox)))
            profileOptionList.add(ProfileModel(resources.getString(R.string.logout)))

            listenToPref()
        }

        lst_menu_items?.apply {
            (lst_menu_items.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
            profileOptionAdapter = ProfileOptionAdapter(
                profileOptionList,
                onItemClick = ::onProfileItemClick,
                onSubItemClick = ::onSubItemClick
            )
            lst_menu_items.adapter = profileOptionAdapter
            listenToViewModel()
        }*/

    }

    private fun onProfileItemClick(position: Int) {
        when (position) {
            0 -> {
                if (!sharedPreferences.checkUserLoggedInOrNot()) {
                    redirectType = "profile"
                    closeDrawer()
                    startActivityInline<PhoneSignInActivity>()
                } else {
                    closeDrawer()
                    navController.navigate(R.id.basicInfoFragment)
                }

            }
            1, 3 -> {
                profileOptionAdapter.expandView(position)
            }
            2 -> {
                closeDrawer()
                navController.navigate(R.id.bracketFragment)
            }
            4 -> {
                closeDrawer()
                navController.navigate(R.id.transactionHistoryFragment)
            }
            5 -> {
                closeDrawer()
                navController.navigate(R.id.bookmark)
            }
            6 -> {
                closeDrawer()
                navController.navigate(R.id.settingsFragment)
            }
            7 -> {
                closeDrawer()
                navController.navigate(R.id.inbox)
            }
            8 -> {
                closeDrawer()
                displayCustomAlertDialog(title = resources.getString(R.string.logout),
                    isCancelable = false,
                    positiveText = resources.getString(R.string.yes),
                    negativeText = resources.getString(R.string.str_cancel),
                    negativeClick = {
                        it.dismiss()
                    },
                    positiveClick = {
                        it.dismiss()
                        launchProgressDialog()
                        commonViewModel.logoutUser("true", sharedPreferences.refreshToken)

                    })
            }
        }
    }


    private fun onSubItemClick(position: Int, type: String) {
        when (position) {
            0 -> {
                if (type == "tournament") {
                    val bundle = Bundle()
                    bundle.putString("type", "joined")
                    closeDrawer()
                    navController.navigate(R.id.createdTournament, bundle)
                } else if (type == "language") {
                    if (LocaleHelper.getLanguage(this) != "en") {
                        launchChangeLanguageDialog("en")
                    }
                }
            }
            1 -> {
                if (type == "tournament") {
                    val bundle = Bundle()
                    bundle.putString("type", "created")
                    closeDrawer()
                    navController.navigate(R.id.createdTournament, bundle)
                } else if (type == "language") {
                    if (LocaleHelper.getLanguage(this) != "ar") {
                        closeDrawer()
                        launchChangeLanguageDialog("ar")
                    }
                }
            }
        }
    }

    private fun launchChangeLanguageDialog(language: String) {
        displayCustomAlertDialog(
            resources.getString(R.string.language),
            resources.getString(R.string.language_change_msg),
            true,
            positiveText = resources.getString(R.string.yes),
            negativeText = resources.getString(R.string.no),
            positiveClick = {
                it.dismiss()
                LocaleHelper.setLocale(this, language)
                startActivityInlineWithFinishAll<DashboardActivity>()
            },
            negativeClick = {
                it.dismiss()
            })
    }

    private fun listenToPref() {
        val data = sharedPreferences.getModel<UserModel.UserData>("user") as UserModel.UserData
        data.apply {
            tvusersmall?.let {
                it.text = this.fullName?.let { it } ?: ""
            }

            tvuseremail?.let {
                if (this.emailisVerified) {
                    it.beVisible()
                    it.text = this.email?.let { it } ?: ""
                } else {
                    it.beGone()
                }
            }

            imageViewInfluencer?.let {
                this.isInfluencer?.apply {
                    if (this == 0) {
                        it.beVisible()
                        textViewInfluencer.beVisible()
                    } else {
                        it.beGone()
                        textViewInfluencer.beGone()
                    }
                }
            }


            imageViewUser?.let {
                this.isVerified?.apply {
                    if (this == 0) {
                        it.borderWidth = 6
                        imageViewVerify.beVisible()
                    } else {
                        it.borderWidth = 0
                        imageViewVerify.beGone()
                    }
                }
            }

            tvorganizerrate?.let {
                this.organizerRating?.apply {
                    if (this.toInt() == 0) {
                        it.beGone()
                        rating.beGone()
                    } else {
                        rating.rating = this.toFloat()
                    }
                }
            }

            textViewPoint?.let {
                this.accountDetail?.apply {
                    textViewPoint.text = this.reward?.let { it.toString() } ?: "0"
                }
            }

            imageViewUser?.let {
                this.profilePicture?.apply {
                    loadImageFromServer(this, it)
                }
            }

            textViewUserName?.let {
                it.text = this.fullName?.let { it } ?: ""
            }

        }
    }

    private fun listenToViewModel() {
        commonViewModel.logOutSuccessResponse.observe(this, Observer{
            dismissProgressDialog()
            sharedPreferences.clear()
            sharedPreferences.isAppOpenFirstTime = true
            closeDrawer()
//            startActivityInline<DashboardActivity>(finish = true)
            navController.navigate(R.id.homeFragment)
        })
        commonViewModel.logOutErrorResponse.observe(this, Observer{

            dismissProgressDialog()
            displayCustomAlertDialog(title = resources.getString(R.string.some_thing_went_wrong),
                isCancelable = true,
                positiveText = resources.getString(R.string.btn_ok),
                positiveClick = {
                    it.dismiss()
                })
        })
    }

    private fun visibilityNavElements() {

        //Listen for the change in fragment (navigation) and hide or show drawer or bottom navigation accordingly if required
        //Modify this according to your need
        //If you want you can implement logic to deselect(styling) the bottom navigation menu item when drawer item selected using listener

        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.create_tournament, R.id.inboxMessage -> hideBothNavigation()
                R.id.inbox -> showBothNavigation()
            }
        }


    }

    private fun hideBothNavigation() { //Hide both drawer and bottom navigation bar
        main_bottom_navigation_view.beGone()
       /* main_navigation_view.visibility = View.GONE
        main_drawer_layout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED) *///To lock navigation drawer so that it don't respond to swipe gesture
    }

    private fun showBothNavigation() {
        main_bottom_navigation_view.beVisible()
       /* main_navigation_view.beVisible()
        main_drawer_layout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)*/
       //To configure navController with drawer and bottom navigation
    }

    private fun setupNavControl() {
        NavigationUI.setupWithNavController(main_bottom_navigation_view, navController);
    //    NavigationUI.setupWithNavController(main_navigation_view, navController);
//        main_navigation_view.setupWithNavController(navController) //Setup Drawer navigation with navController
        // main_bottom_navigation_view.setupWithNavController(navController) //Setup Bottom navigation with navController
    }


    override fun onSupportNavigateUp(): Boolean { //Setup appBarConfiguration for back arrow
        return NavigationUI.navigateUp(navController, appBarConfiguration)
    }

    private fun setStatusBarTransparent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            (this@DashboardActivity).window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            (this@DashboardActivity).window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            (this@DashboardActivity).window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
            (this@DashboardActivity).window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
            (this@DashboardActivity).window.statusBarColor =
                ContextCompat.getColor(this, R.color.background_color)

        } else {
            (this@DashboardActivity).window!!.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }
    }


    companion object {
        lateinit var navController: NavController
    }

    override fun onDestroy() {
        super.onDestroy()
        mAppUpdateManager?.apply {
            this.unregisterListener(listener)
        }

    }

/*    override fun onBackPressed() {
       // closeDrawer()
    }*/
    fun closeDrawer(){
        /*when { //If drawer layout is open close that on back pressed
            main_drawer_layout.isDrawerOpen(GravityCompat.START) -> {
                main_drawer_layout.closeDrawer(GravityCompat.START)
            }
            else -> {
                super.onBackPressed() //If drawer is already in closed condition then go back
            }
        }*/
    }

//    override fun onNotify(notifyType: String) {
//        if (notifyType == "profile") {
//            main_bottom_navigation_view.selectedItemId = R.id.profileFragment
//        } else if (notifyType == "home") {
//            main_bottom_navigation_view.selectedItemId = R.id.homeFragment
//        }
//    }

}
