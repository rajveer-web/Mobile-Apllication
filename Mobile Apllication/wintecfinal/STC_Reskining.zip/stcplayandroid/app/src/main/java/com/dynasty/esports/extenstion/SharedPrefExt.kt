package com.dynasty.esports.extenstion

import android.content.SharedPreferences
import androidx.core.content.edit
import com.google.gson.GsonBuilder

internal var SharedPreferences.isAppOpenFirstTime: Boolean
    set(value) {
        edit { putBoolean("app_open_first_time", value) }
    }
    get() {
        getBoolean("app_open_first_time", false).let {
            return it
        }
    }



internal var SharedPreferences.isLogin: Boolean
    set(value) {
        edit { putBoolean("is_login", value) }
    }
    get() {
        getBoolean("is_login", false).let {
            return it
        }
    }


internal var SharedPreferences.isLoggedIn: Boolean
    set(value) {
        edit { putBoolean("is_loggedIn", value) }
    }
    get() {
        getBoolean("is_loggedIn", false).let {
            return it
        }
    }


internal var SharedPreferences.accessToken: String
    set(value) {
        edit { putString("access_token", value) }
    }
    get() {
        getString("access_token", "").let {
            return it.toString()
        }
    }
internal var SharedPreferences.refreshToken: String
    set(value) {
        edit { putString("refresh_token", value) }
    }
    get() {
        getString("refresh_token", "").let {
            return it.toString()
        }
    }



internal var SharedPreferences.chatAccessToken: String
    set(value) {
        edit { putString("chat_access_token", value) }
    }
    get() {
        getString("chat_access_token", "").let {
            return it.toString()
        }
    }
internal var SharedPreferences.chatRefreshToken: String
    set(value) {
        edit { putString("chat_refresh_token", value) }
    }
    get() {
        getString("chat_refresh_token", "").let {
            return it.toString()
        }
    }


internal var SharedPreferences.FCMToken: String
    set(value) {
        edit { putString("fcm_token", value) }
    }
    get() {
        getString("fcm_token", "").let {
            return it.toString()
        }
    }

internal var SharedPreferences.id: String
    set(value) {
        edit { putString("id", value) }
    }
    get() {
        getString("id", "").let {
            return it.toString()
        }
    }



fun <T> SharedPreferences.put( key: String,`object`: T) {
    val editor = this.edit()
    //Convert object to JSON String.
    val jsonString = GsonBuilder().create().toJson(`object`)
    //Save that String in SharedPreferences
   editor.putString(key, jsonString).apply()
}

inline fun <reified T> SharedPreferences.get(key: String): T? {
    //We read JSON String which was saved.
    val value = this.getString(key, null)
    //JSON String was found which means object can be read.
    //We convert this JSON String to model object. Parameter "c" (of
    //type Class < T >" is used to cast.
    return GsonBuilder().create().fromJson(value, T::class.java)
}

inline fun <reified T> SharedPreferences.getModel(key: String): T? {
    //We read JSON String which was saved.

    val value = this.getString(key, null)
    //JSON String was found which means object can be read.
    //We convert this JSON String to model object. Parameter "c" (of
    //type Class < T >" is used to cast.
    return GsonBuilder().create().fromJson(value, T::class.java)
}

fun SharedPreferences.clearPreference(keyString : String){
    val editor = this.edit()
    editor.remove(keyString)
    editor?.apply()
    editor?.commit()
}

fun SharedPreferences.clear() {
    val editor = this.edit()
    editor.clear()
    editor.apply()
}

internal var SharedPreferences.announcementId: String
    set(value) {
        edit { putString("announcementId", value) }
    }
    get() {
        getString("announcementId", "").let {
            return it.toString()
        }
    }


