package com.dynasty.esports.view.bookmark


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.databinding.AdapterArticleVideoBookmarkBinding
import com.dynasty.esports.extenstion.beVisible
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.BookmarkModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.utils.LocaleHelper

/**
 * @desc this is class will be use for bookmark video
 * @author : Mahesh Vayak
 * @created : 25-07-2020
 * @modified : 14-08-2020
 * @required
 * ©Dynasty eSports Pte ltd
 **/
class VideoBookmarkAdapter constructor(
    private val videoList: MutableList<BookmarkModel.VideoBookMark>,
    private val onItemClick: (String) -> Unit = { _ -> },
    private val onDeleteItemClick: (Int) -> Unit = { _ -> }
) :
    RecyclerView.Adapter<BindingHolder<AdapterArticleVideoBookmarkBinding>>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BindingHolder<AdapterArticleVideoBookmarkBinding> {
        val binding: AdapterArticleVideoBookmarkBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.adapter_article_video_bookmark,
            parent,
            false)
        return BindingHolder(binding)
    }

    /**
     * @desc videoList array size count.
     * @return int- size of array
     */
    override fun getItemCount(): Int {
        return videoList.size
    }

    /**
     *@desc Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(
        holder: BindingHolder<AdapterArticleVideoBookmarkBinding>,
        position: Int
    ) {
        val data = videoList[position]
        holder.binding.imageViewPlay.beVisible()
        if (LocaleHelper.getLanguage(holder.binding.root.context) == "en") {
            holder.binding.textViewRewardType.text = data.title?.english?.let { it } ?: ""
            holder.binding.textViewDescription.text = data.description?.english?.let { it } ?: ""
        }else{
            holder.binding.textViewRewardType.text = if(data.title?.malay.isNullOrEmpty())  data.title?.english?.let { it } ?: "" else  data.title?.malay?.let { it } ?: ""
            holder.binding.textViewDescription.text =if(data.description?.malay.isNullOrEmpty()) data.description?.english?.let { it } ?: "" else  data.description?.malay?.let { it } ?: ""
        }

        holder.itemView.context.loadImageFromServer(
            data.thumbnailUrl.toString(),
            holder.binding.imageViewBanner)
        holder.binding.cardViewBookmark.click {
            onItemClick(data.youtubeUrl.toString())
        }
        holder.binding.imageViewDelete.click { onDeleteItemClick(holder.adapterPosition) }
    }
}