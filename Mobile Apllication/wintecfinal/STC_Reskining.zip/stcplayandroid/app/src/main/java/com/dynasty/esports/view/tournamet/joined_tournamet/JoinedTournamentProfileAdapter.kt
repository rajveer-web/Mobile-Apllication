package com.dynasty.esports.view.tournamet.joined_tournamet


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dynasty.esports.R
import com.dynasty.esports.constants.AppConstants
import com.dynasty.esports.databinding.ItemLoadMoreBinding
import com.dynasty.esports.databinding.RowCreatedTurnamentBinding
import com.dynasty.esports.databinding.RowMybracketsBinding
import com.dynasty.esports.extenstion.click
import com.dynasty.esports.extenstion.convertDateToRequireDateFormat
import com.dynasty.esports.extenstion.loadImageFromServer
import com.dynasty.esports.models.CreatedTournamentModel
import com.dynasty.esports.models.Docs
import com.dynasty.esports.models.JoinedTournamentModel
import com.dynasty.esports.utils.BindingHolder
import com.dynasty.esports.view.bracket.BracketAdapter
import com.dynasty.esports.view.common.LoadingViewHolder


class JoinedTournamentProfileAdapter constructor(private val tournamentList: MutableList<JoinedTournamentModel.DocModel>,
                                                 private val onItemClick: (String) -> Unit = {_ -> },private val onItemEditClick: (JoinedTournamentModel.DocModel) -> Unit = {_ -> }) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            0 -> {
                val binding: RowCreatedTurnamentBinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.context),
                    R.layout.row_created_turnament,
                    parent,
                    false
                )
                return ViewHolderTournament(binding)
            }
            else -> {
                val binding: ItemLoadMoreBinding =
                    DataBindingUtil.inflate(inflater, R.layout.item_load_more, parent, false)
                return LoadingViewHolder(binding)
            }

        }
    }



    // total number of cells
    override fun getItemCount(): Int {
        return tournamentList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (tournamentList[position].isLoadMore) {
            1
        } else {
            0
        }
    }

    inner class ViewHolderTournament(private var binding: RowCreatedTurnamentBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(data: JoinedTournamentModel.DocModel) {

            data.tournament?.apply {
                binding.textViewTitle.text = this.name?.let { it } ?: "-"
                binding.textViewDescription.text = this.description?.let { it } ?: "-"

                this.startDate?.apply {
                    binding.textViewDate.text = this.convertDateToRequireDateFormat(
                        AppConstants.API_DATE_FORMAT,
                        AppConstants.REQUIRED_TIME_FORMAT
                    )
                }

                binding.imgEdit.click {
                    onItemEditClick(data)
                }

                if (!this.isPaid!!) {
                    binding.textViewStatus.text =
                        itemView.context.resources.getString(R.string.str_free)
                    binding.cardViewStatus.setCardBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.free_game_bg_color
                        )
                    )
                } else {
                    binding.textViewStatus.text =
                        itemView.context.resources.getString(R.string.str_paid)
                    binding.cardViewStatus.setCardBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.title_text_color
                        )
                    )
                }
                binding.cardViewTournament.click {
                    onItemClick(data.id.toString())
                }


                this.banner?.apply {

                        itemView.context.loadImageFromServer(
                            this,
                            binding.imageViewBanner
                        )

                }
            }
        }

    }



    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            0 -> {
                (holder as ViewHolderTournament).bind(tournamentList[position])
            }
            else -> {
                (holder as LoadingViewHolder).progressBar.isIndeterminate = true
            }
        }
    }

    fun addLoadingView() {
        //add loading item
        val model = JoinedTournamentModel.DocModel()
        model.isLoadMore = true
        tournamentList.add(model)
        notifyItemInserted(tournamentList.size - 1)
    }

    fun removeLoadingView() {
        tournamentList.removeAt(tournamentList.size - 1)
        notifyItemRemoved(tournamentList.size)
    }
}